@echo off
rem ====================================================================
rem  3R ch11 (351.2625 MHz) 4800 sym/s 4FSK monitor.
rem  Logs the non-T98 signal packet by packet to std98_data\fsk4800\<date>\.
rem
rem    ana_run.bat                       live, until Ctrl+C
rem    ana_run.bat --seconds 300         live, 5 minutes
rem    ana_run.bat --replay capture.cf32 from an IQ capture (no SDR needed)
rem
rem  The SDR can be used by one program only: stop the receiver first.
rem  Profile: STD_T98_ANA_CONFIG, else your rtl-sdr profile, else app\devices.
rem ====================================================================
setlocal
cd /d "%~dp0"
set "ROOT=%~dp0"
set "APP=%ROOT%app"

set "PYDIR="
if exist "%ROOT%python\python.exe" set "PYDIR=%ROOT%python"
if not defined PYDIR if exist "%USERPROFILE%\radioconda\python.exe" set "PYDIR=%USERPROFILE%\radioconda"
if not defined PYDIR (
  echo [ERROR] No Python environment found. Run run.bat or setup_env.bat once first.
  pause
  exit /b 1
)
if exist "%PYDIR%\Scripts\activate.bat" call "%PYDIR%\Scripts\activate.bat" "%PYDIR%" >nul 2>&1
set "PATH=%PYDIR%;%PYDIR%\Library\bin;%PYDIR%\Library\usr\bin;%PYDIR%\Library\mingw-w64\bin;%PYDIR%\Scripts;%PATH%"
set "PY=%PYDIR%\python.exe"

set "CFG=%STD_T98_ANA_CONFIG%"
if not defined CFG if exist "%USERPROFILE%\.config\std-t98\profiles\rtl-sdr.toml" set "CFG=%USERPROFILE%\.config\std-t98\profiles\rtl-sdr.toml"
if not defined CFG set "CFG=%APP%\devices\rtl-sdr.toml"
echo [INFO] Profile: %CFG%

rem A live run fails if the receiver still holds the SDR; say so up front.
echo %* | findstr /i /c:"--replay" >nul
if errorlevel 1 (
  powershell -NoProfile -Command "if (Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'std_t98_30ch_multi_rf_backend|std_t98_rf_server|std_t98_record_iq' -and $_.CommandLine -notmatch '--replay|--rf-remote' }) { exit 1 }"
  if errorlevel 1 (
    echo [WARN] The STD-T98 receiver is using the SDR. Stop it in the GUI, then press a key.
    pause
  )
)

"%PY%" "%APP%\tools\std_t98_fsk4800_monitor.py" --config "%CFG%" %*
echo.
echo [INFO] Stopped. Logs: %ROOT%std98_data\fsk4800\
pause
endlocal
