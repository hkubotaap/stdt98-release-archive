@echo off
setlocal
cd /d "%~dp0"
set "PYDIR=%~dp0python"
if not exist "%PYDIR%\python.exe" set "PYDIR=%USERPROFILE%\radioconda"
if not exist "%PYDIR%\python.exe" (
  echo [ERROR] Python not found. Run setup_env.bat or run_gui.bat first.
  pause
  exit /b 1
)
if exist "%PYDIR%\Scripts\activate.bat" call "%PYDIR%\Scripts\activate.bat" "%PYDIR%" >nul 2>&1
set "PATH=%PYDIR%;%PYDIR%\Library\bin;%PYDIR%\Scripts;%PATH%"
set "STD_T98_NO_SECRET=1"
"%PYDIR%\python.exe" "%~dp0app\key_tool.py"
endlocal
