' STD-T98 receiver - start the desktop GUI without a console window.
' Runs run_gui.bat hidden. On first use (no Python environment yet) it runs
' visibly instead, so the radioconda download progress and errors can be seen.
Option Explicit
Dim fso, shell, here, profile, ready
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
here = fso.GetParentFolderName(WScript.ScriptFullName)
profile = shell.ExpandEnvironmentStrings("%USERPROFILE%")
ready = fso.FileExists(here & "\python\python.exe") Or fso.FileExists(profile & "\radioconda\python.exe")
If ready Then
    shell.Run "cmd /c """"" & here & "\run_gui.bat"" hidden""", 0, False
Else
    shell.Run "cmd /c """"" & here & "\run_gui.bat""""", 1, False
End If
