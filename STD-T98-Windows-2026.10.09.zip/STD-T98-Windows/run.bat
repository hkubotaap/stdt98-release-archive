@echo off
rem ====================================================================
rem  STD-T98 (digital kan) receiver - GNU Radio / SoapySDR edition
rem  Windows launcher (terminal). Portable: prefers the python\ env in
rem  this same folder, so the whole folder can be copied as-is.
rem ====================================================================
setlocal
cd /d "%~dp0"
set "ROOT=%~dp0"
set "APP=%ROOT%app"

rem --- 1) Resolve the Python environment (bundled python\ first) -------
rem     Without either, radioconda is downloaded and installed automatically;
rem     with radioconda, missing SoapySDR packages are added.
set "PYDIR="
if exist "%ROOT%python\python.exe" set "PYDIR=%ROOT%python"
if not defined PYDIR (
  if not exist "%USERPROFILE%\radioconda\python.exe" echo [INFO] No Python environment found. Installing radioconda ^(about 630 MB download^) ...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%APP%\tools\install_radioconda.ps1" -Target "%USERPROFILE%\radioconda"
  if errorlevel 1 (
    echo [ERROR] radioconda / SoapySDR setup failed. See the messages above.
    pause
    exit /b 1
  )
  set "PYDIR=%USERPROFILE%\radioconda"
)
echo [INFO] Python: %PYDIR%

rem --- 2) Activate the conda env so SoapySDR device DLLs resolve.
rem        Child service processes inherit PATH from here. The AMBE+2 voice
rem        decoder is bundled at app\vendor\ambe2 (self-contained, no PYTHONPATH).
if exist "%PYDIR%\Scripts\activate.bat" call "%PYDIR%\Scripts\activate.bat" "%PYDIR%" >nul 2>&1
set "PATH=%PYDIR%;%PYDIR%\Library\bin;%PYDIR%\Library\usr\bin;%PYDIR%\Library\mingw-w64\bin;%PYDIR%\Scripts;%PATH%"
set "PY=%PYDIR%\python.exe"

rem --- 3) pip-layer deps: sounddevice ----------------------------------
"%PY%" -c "import sounddevice" 2>nul
if errorlevel 1 (
  echo [INFO] Installing sounddevice ...
  "%PY%" -m pip install --no-input sounddevice
)

rem --- 4) GNU Radio / SoapySDR must be present (cannot pip-install) ----
"%PY%" -c "from gnuradio import gr, soapy" 2>nul
if errorlevel 1 (
  echo [ERROR] GNU Radio / gnuradio.soapy not found in this environment.
  echo         Rebuild python\ with setup_env.bat, or use radioconda.
  pause
  exit /b 1
)

rem --- 5) Privacy-key analysis is disabled in this distribution -------
set "SECRET_ARG=--no-secret"
set "STD_T98_NO_SECRET=1"
echo [INFO] Privacy-key analysis disabled.

rem --- 6) Detect the connected SDR driver (override: STD_T98_SDR_DRIVER) ---
set "DRV=%STD_T98_SDR_DRIVER%"
if not defined DRV (
  for /f "usebackq delims=" %%D in (`"%PY%" -c "import SoapySDR;S={'hackrf','rtlsdr','airspy','airspyhf','uhd','bladerf','lime','sdrplay','plutosdr','rtltcp'};print(next((dict(d).get('driver','') for d in SoapySDR.Device.enumerate() if dict(d).get('driver','') in S),''))" 2^>nul`) do set "DRV=%%D"
)
if /i "%DRV%"=="hackrf" if not defined STD_T98_BACKEND_CONFIG set "STD_T98_BACKEND_CONFIG=%APP%\devices\hackrf.toml"
set "BACKEND_SDR="
if defined DRV if not "%DRV%"=="" (
  echo [INFO] SDR detected: driver=%DRV%
  set "BACKEND_SDR=--backend-arg=--driver --backend-arg=%DRV%"
) else (
  echo [WARN] No SoapySDR device detected. Using the backend default ^(rtlsdr^).
  echo        Connect your SDR, or set STD_T98_SDR_DRIVER=hackrf ^(etc.^) before run.bat.
)

rem --- 7) Launch -------------------------------------------------------
echo [INFO] Starting STD-T98 receiver ...
"%PY%" "%APP%\std_t98_multi_service_launcher.py" %SECRET_ARG% %BACKEND_SDR% %*
set "RC=%ERRORLEVEL%"
echo.
echo [INFO] Stopped (exit %RC%).
pause
endlocal
