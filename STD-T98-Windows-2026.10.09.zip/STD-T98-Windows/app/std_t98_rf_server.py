#!/usr/bin/env python3
"""RF-only capture/resampling server; decoding and audio run on IP clients."""
import argparse
import os
import signal
import threading
import time
from gnuradio import blocks, filter, gr

from core.rf.backend_config import add_config_arguments, load_config, derive_rates
from core.rf.remote_iq import IQServer, stream_metadata, DEFAULT_PORT, TOKEN_ENV, FRAME_FORMAT
from core.rf.remote_iq_blocks import IQNetworkSink
from core.rf.soapy_source import open_source
from core.rf.correct_iq import CorrectIQ
from core.rf.auto_gain import AutoGainController
from core.rf.hackrf_gain import HackRFAutoGainController
from core.pipeline.runtime_status import StatusPublisher
from ipc.message_schema import STATUS_SOURCE_RF
from std_t98_30ch_multi_rf_backend import test3, _InputLevelMeter, _run_control_loop, _make_spectrum_tap


class RFServerGraph(test3):
    """Use the backend's existing live gain/capture controls on an RF-only graph."""
    def __init__(self, config, server, replay=None, correct_iq=True):
        gr.top_block.__init__(self, "STD-T98 RF IQ server", catch_exceptions=True)
        self.config = config
        self.replay = replay
        self.remote_iq = None
        self.num_channels = config.channelizer.num_channels
        self.flowgraph_started = threading.Event()
        self._gain_stop = threading.Event()
        self._gain_lock = threading.RLock()
        self._correct_iq = CorrectIQ(correct_iq)
        self.simple_squelch = []
        self._base_squelch = config.demod.squelch_threshold
        self._reference_gain = self._current_gain = config.sdr.tuner_gain
        self._auto_gain = config.sdr.resolved_auto_gain() and not replay
        self._gain_controller = AutoGainController(self._current_gain)
        rates = derive_rates(config.sdr, config.channelizer)
        if replay:
            self.file_source = blocks.file_source(gr.sizeof_gr_complex, str(replay), False)
            self.throttle = blocks.throttle(gr.sizeof_gr_complex, rates.samp_rate_post_resamp1, True, 0)
            self.connect(self.file_source, self.throttle)
            source = self.throttle
        else:
            self._source = open_source(config.sdr)
            if self._source.is_hackrf:
                self._reference_gain = self._current_gain = self._source.hackrf_gains.total_db
                self._gain_controller = HackRFAutoGainController(self._source.hackrf_gains)
            if config.sdr.agc and self._source.has_agc:
                self._auto_gain = False
            self._level_meter = _InputLevelMeter()
            self.resampler = filter.rational_resampler_ccc(
                interpolation=rates.resamp1_interp, decimation=rates.resamp1_decim, taps=[], fractional_bw=0)
            self.connect(self._source.source, self._level_meter)
            self.connect(self._source.source, self.resampler)
            source = self.resampler
        self.network_sink = IQNetworkSink(server)
        self.connect(source, self._correct_iq, self.network_sink)
        self.spectrum_tap = _make_spectrum_tap(config, rates.samp_rate_post_resamp1, self.num_channels)
        self.connect(self._correct_iq, self.spectrum_tap)


def frame_server_graph(config, server, replay=None, correct_iq=True):
    """Demodulate every channel here and send only sync-word frames to clients."""
    tb = test3(config=config, replay=replay, correct_iq=correct_iq)
    # The correlator already speaks FramePacket; swap its local IPC endpoint
    # for the authenticated network broadcast.
    tb.sync_word_corr.transport.close()
    tb.sync_word_corr.transport = server
    return tb


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    add_config_arguments(parser)
    parser.add_argument("--rf-listen", default="0.0.0.0")
    parser.add_argument("--rf-port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--rf-max-clients", type=int, default=4)
    parser.add_argument("--rf-iq-format", choices=("cs16", "cf32", "frames"), default="cs16",
                        help="IQ transfer precision: compact scaled 16-bit (default) or float32; "
                             "frames demodulates every channel here and sends only sync-word frames")
    parser.add_argument("--status-socket")
    parser.add_argument("--control-socket")
    parser.add_argument("--replay", help="Broadcast an existing post-resampler .cf32 file at real-time speed")
    parser.add_argument('--no-correct-iq', action='store_true')
    args = parser.parse_args(argv)
    if not 1 <= args.rf_max_clients <= 16 or not 1 <= args.rf_port <= 65535:
        parser.error("Invalid RF port or client limit")
    config = load_config(args)
    wire_format = {"cs16": "cs16-scaled-le", "cf32": "cf32-le", "frames": FRAME_FORMAT}[args.rf_iq_format]
    server = IQServer(args.rf_listen, args.rf_port, stream_metadata(config, wire_format), os.environ.get(TOKEN_ENV, ""), args.rf_max_clients)
    publisher = None
    tb = None
    reporting = None
    stop = threading.Event()
    try:
        graph = frame_server_graph if wire_format == FRAME_FORMAT else RFServerGraph
        tb = graph(config, server, args.replay, not args.no_correct_iq)
        publisher = StatusPublisher(args.status_socket, STATUS_SOURCE_RF)
        def report():
            while not stop.wait(.5):
                publisher.publish(payload_dict={"rf_network": {
                    "mode": "server", "endpoint": f"{args.rf_listen}:{server.port}",
                    "metadata": server.metadata, **server.snapshot()}})
        def shutdown(*unused):
            stop.set()
            tb._gain_stop.set()
            tb.stop()
        signal.signal(signal.SIGINT, shutdown)
        signal.signal(signal.SIGTERM, shutdown)
        if args.control_socket:
            threading.Thread(target=_run_control_loop, args=(tb, args.control_socket), daemon=True).start()
        tb.start()
        tb.flowgraph_started.set()
        print(f"RF IQ server listening on {args.rf_listen}:{server.port}", flush=True)
        if not args.replay:
            threading.Thread(target=tb.run_auto_gain, daemon=True).start()
        reporting = threading.Thread(target=report, daemon=True)
        reporting.start()
        tb.wait()
    finally:
        stop.set()
        if tb is not None:
            tb._gain_stop.set()
            tb.stop()
            tb.wait()
            if args.replay:
                tb.file_source.close()
        if reporting is not None:
            reporting.join(1)
        if publisher is not None:
            publisher.close()
        server.close()


if __name__ == "__main__":
    main()
