#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import functools
from collections import deque
from dataclasses import dataclass, field
import importlib
import json
import math
import os
import select
import sys
import threading
import time

import numpy as np

from core.audio.ambe_adapter import payloads_3600_to_2450
from core.audio.voice_playback import INITIAL_SPEECH_AGC_GAIN, VoicePlayback
from core.audio.secret_replay import SecretReplayCall
from core.audio.recordings import (AudioSettings, RecordingWorker, channel_frequencies, channel_ids_for,
                                   is_excluded_channel, DEFAULT_PLAYBACK_BUFFER_FRAMES)
from core.audio.recovery import gate_recovered
from core.protocol.voice_gaps import MAX_FILLED_FRAMES
from core.crypto.pn_sequence import generate_pn_sequence_196
from core.crypto.secret_voice import descramble_burst
from core.pipeline.runtime_status import StatusPublisher
from ipc.message_schema import (
    SECRET_RESULT_CURRENT_KEY,
    SECRET_RESULT_FULL_SEARCH,
    SECRET_RESULT_GLOBAL_CACHE,
    SECRET_RESULT_NONE,
    STATUS_SOURCE_AUDIO,
    VOICE_BURST_BLOCK_BYTES_AMBE_2450,
    VOICE_BURST_BLOCK_BYTES_RAW_3600,
    VOICE_FORMAT_RAW_3600,
    SecretCrackRequestPacket,
    SecretCrackResultPacket,
    VoiceBurstPacket,
)
from ipc.transport.compat_poll import POLLIN, Poller
from ipc.transport.uds_seqpacket import (
    UdsSeqpacketClient,
    resolve_secret_request_socket_path,
    resolve_secret_result_socket_path,
    resolve_voice_socket_path,
)


sd = importlib.import_module("sounddevice")


CHANNEL_COUNT = 30
DECRYPTION_KEY = 0
SAMPLE_RATE = 48000
AUDIO_CHANNELS = 1
AUDIO_DTYPE = "int16"
AUDIO_BYTES_PER_FRAME = 2
AUDIO_RECOVERY_DELAY_SEC = 0.5
AUDIO_UNDERFLOW_RECOVERY_THRESHOLD = 8
# Live voice jitter buffer, per channel. One voice burst is 80 ms of PCM.
# A channel starts (and restarts after running dry) only with the configured
# number of bursts queued ("playback_buffer_frames", default 4), so uneven
# burst arrival does not cut the speech.
AUDIO_LIVE_PREFILL_FRAMES = DEFAULT_PLAYBACK_BUFFER_FRAMES
AUDIO_BURST_BYTES = int(SAMPLE_RATE * AUDIO_BYTES_PER_FRAME * 0.08)
# A transmission ending with fewer queued bursts plays after this silence.
AUDIO_LIVE_FLUSH_SECONDS = 0.25
# Queue limit: the prefill plus headroom for bursts arriving in clumps.
AUDIO_QUEUE_HEADROOM_FRAMES = 6
AUDIO_QUEUE_MAX_SECONDS = 0.8
AUDIO_QUEUE_MAX_BYTES = int(SAMPLE_RATE * AUDIO_BYTES_PER_FRAME * AUDIO_QUEUE_MAX_SECONDS)
UPSAMPLE_FACTOR = 6
DEFAULT_AUDIO_GAIN = 4.0
CALL_STAT_SECRET = 1
SECRET_MIN_WINDOW_BURSTS = 5
SECRET_MAX_WINDOW_BURSTS = 10
SECRET_RECHECK_INTERVAL_BURSTS = 10

SECRET_RESULT_LABELS = {
    SECRET_RESULT_NONE: "Search Miss",
    SECRET_RESULT_CURRENT_KEY: "Current Key Verified",
    SECRET_RESULT_GLOBAL_CACHE: "Global Cache Hit",
    SECRET_RESULT_FULL_SEARCH: "Full Search Hit",
}
DEBUG_REPORT_INTERVAL_SEC = 1.0
DEBUG_ACTIVE_WINDOW_SEC = 2.0


def _parse_audio_latency(value):
    if value is None:
        return None

    text = str(value).strip()
    if not text:
        return None

    lowered = text.lower()
    if lowered in ("low", "high"):
        return lowered

    try:
        return float(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"Invalid audio latency value: {value}") from exc


def _parse_audio_gain(value):
    if value is None:
        return DEFAULT_AUDIO_GAIN

    text = str(value).strip()
    if not text:
        return DEFAULT_AUDIO_GAIN

    try:
        gain = float(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"Invalid audio gain value: {value}") from exc

    if gain <= 0.0:
        raise argparse.ArgumentTypeError(f"Audio gain must be greater than zero: {value}")

    return gain


@dataclass
class SecretChannelState:
    session_id: int = 0
    secret_active: bool = False
    active_key: int = 0
    pending_request: bool = False
    last_request_burst_index: int = -SECRET_RECHECK_INTERVAL_BURSTS
    burst_window: deque[bytes] = field(default_factory=lambda: deque(maxlen=SECRET_MAX_WINDOW_BURSTS))


@dataclass
class AudioChannelDebug:
    voice_packets: int = 0
    pcm_chunks: int = 0
    empty_decodes: int = 0
    filled_frames: int = 0
    pending_bytes: int = 0
    peak_pending_bytes: int = 0
    trim_events: int = 0
    trim_bytes: int = 0
    last_packet_at: float = 0.0


def _parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Run the split multi-channel audio service.")
    parser.add_argument("--headless", action="store_true", help="Suppress local startup logs.")
    parser.add_argument("--status-socket", help="Optional UDS socket path used to publish status events.")
    parser.add_argument("--audio-settings", help="Live audio settings JSON shared with the GUI.")
    parser.add_argument("--record-dir", help="SDR# compatible raw/rec/edu recording folder.")
    parser.add_argument("--stop-file", help="Supervisor-created graceful shutdown marker.")
    parser.add_argument("--rf-args-json", default="[]", help="RF configuration arguments for recording frequency labels.")
    parser.add_argument("--device", default=None if sys.platform == "win32" else "pipewire", help="Audio output device name passed to sounddevice.")
    parser.add_argument(
        "--latency",
        default=_parse_audio_latency(os.environ.get("STD_T98_AUDIO_LATENCY")),
        type=_parse_audio_latency,
        help="Optional sounddevice latency. Use 'high', 'low', or seconds. Default uses PortAudio's device default.",
    )
    parser.add_argument(
        "--gain",
        default=_parse_audio_gain(os.environ.get("STD_T98_AUDIO_GAIN")),
        type=_parse_audio_gain,
        help=f"Linear output gain applied after channel mixing. Default: {DEFAULT_AUDIO_GAIN}.",
    )
    return parser.parse_args(argv)


def _split_payload_blocks(payload: bytes, block_size: int):
    return [payload[index : index + block_size] for index in range(0, len(payload), block_size)]


def _ensure_key_sequence(key_sequences, key):
    if key not in key_sequences:
        key_sequences[key] = generate_pn_sequence_196(key)
    return key_sequences[key]


def _secret_burst_payload(payloads_2450):
    return b"".join(payloads_2450)


def _start_secret_session(secret_state):
    secret_state.session_id += 1
    secret_state.secret_active = True
    secret_state.pending_request = False
    secret_state.last_request_burst_index = -SECRET_RECHECK_INTERVAL_BURSTS
    secret_state.burst_window.clear()


def _stop_secret_session(secret_state):
    secret_state.secret_active = False
    secret_state.pending_request = False
    secret_state.last_request_burst_index = -SECRET_RECHECK_INTERVAL_BURSTS
    secret_state.burst_window.clear()


def _connect_secret(request_socket_path, result_socket_path, headless):
    return None, None


def _maybe_send_secret_request(packet, secret_state, request_client, request_sequence):
    return request_sequence, False


def _audio_stream_kwargs(device, latency):
    kwargs = {
        "samplerate": SAMPLE_RATE,
        "channels": AUDIO_CHANNELS,
        "dtype": AUDIO_DTYPE,
        "device": device,
    }
    if latency is not None:
        kwargs["latency"] = latency
    return kwargs


def _open_audio_stream(device, latency):
    audio_stream = sd.RawOutputStream(**_audio_stream_kwargs(device, latency))
    audio_stream.start()
    return audio_stream


def _close_audio_stream(audio_stream):
    if audio_stream is None:
        return

    try:
        audio_stream.close()
    except Exception:
        pass


def _open_audio_stream_with_retry(device, latency, headless):
    waiting_reported = False
    while True:
        try:
            return _open_audio_stream(device, latency)
        except sd.PortAudioError as exc:
            if not headless:
                if not waiting_reported:
                    print("Audio output unavailable; retrying until the device becomes ready...", file=sys.stderr)
                    waiting_reported = True
                print(f"Audio stream open failed: {exc}", file=sys.stderr)
            time.sleep(AUDIO_RECOVERY_DELAY_SEC)


def _trim_audio_backlog(audio_queue, queued_bytes, max_bytes):
    queued_bytes, _, _ = _trim_audio_backlog_with_stats(audio_queue, queued_bytes, max_bytes)
    return queued_bytes


def _trim_audio_backlog_with_stats(audio_queue, queued_bytes, max_bytes):
    dropped_bytes = 0
    dropped_chunks = 0
    while audio_queue and queued_bytes > max_bytes:
        dropped = audio_queue.popleft()
        queued_bytes -= len(dropped)
        dropped_bytes += len(dropped)
        dropped_chunks += 1
    return queued_bytes, dropped_bytes, dropped_chunks


PRIORITY_HOLD_SEC = 1.5  # keep others ducked across short gaps between priority bursts
# A channel's call (for the simultaneous-playback limit) ends after this long
# without any of its audio reaching the mixer.
PLAYBACK_CALL_END_SEC = 1.5


def _mix_pcm_chunks(pcm_chunks, gain, weights=None):
    weights = [1.0] * len(pcm_chunks) if weights is None else weights
    valid = [(chunk[: len(chunk) - (len(chunk) % AUDIO_BYTES_PER_FRAME)], weight)
             for chunk, weight in zip(pcm_chunks, weights) if chunk]
    valid_chunks = [chunk for chunk, _ in valid]
    if not valid_chunks:
        return b""

    mixed_length = max(len(chunk) for chunk in valid_chunks) // AUDIO_BYTES_PER_FRAME
    mixed = np.zeros(mixed_length, dtype=np.float32)

    for chunk, weight in valid:
        samples = np.frombuffer(chunk, dtype=np.int16).astype(np.float32)
        mixed[: samples.size] += samples * weight

    audible = sum(1 for _, weight in valid if weight > 0)
    if audible > 1:
        mixed /= math.sqrt(audible)

    mixed *= gain
    np.clip(mixed, np.iinfo(np.int16).min, np.iinfo(np.int16).max, out=mixed)
    return mixed.astype(np.int16).tobytes()


@dataclass
class ChannelAudioState:
    pending_pcm: deque[bytes] = field(default_factory=deque)
    pending_bytes: int = 0
    primed: bool = False
    last_enqueue_at: float = 0.0


class AudioOutputWorker:
    def __init__(self, device, latency, headless, gain):
        self.device = device
        self.latency = latency
        self.headless = headless
        self.gain = gain
        self.speaker_agc = None
        self.audio_stream = None
        self.closed = False
        self.pending_channels = {}
        self.replay_calls = {}
        self.queue_trim_events = 0
        self.queue_trim_bytes = 0
        self.max_total_pending_bytes = 0
        self.write_calls = 0
        self.write_bytes = 0
        self.underflow_count = 0
        self.write_failures = 0
        self.stream_open_count = 0
        self.stream_reopen_count = 0
        self.played_until = {}
        self.chunk_channels = set()
        # Listening roles, refreshed from the audio settings by the main loop.
        self.solo_ids = frozenset()
        self.mute_ids = frozenset()
        self.priority_ids = frozenset()
        self.duck_gain = 0.25
        # Live jitter buffer depth in bursts, refreshed from the audio settings.
        self.prefill_frames = AUDIO_LIVE_PREFILL_FRAMES
        # Simultaneous playback limit (0 = no limit), refreshed from the settings.
        self.max_playback = 0
        self.playback_admitted = {}   # channel -> last chunk time of its admitted call
        self.playback_refused = {}    # channel -> last chunk time of its refused call
        self.priority_active_until = 0.0
        self.condition = threading.Condition()
        self.thread = threading.Thread(target=self._run, name="std-t98-audio-output", daemon=True)

    def start(self):
        self.thread.start()

    @property
    def queue_max_bytes(self):
        """Per-channel limit: never below the prefill plus clump headroom."""
        return max(AUDIO_QUEUE_MAX_BYTES, (self.prefill_frames + AUDIO_QUEUE_HEADROOM_FRAMES) * AUDIO_BURST_BYTES)

    def fill_room(self, channel_id):
        """Bursts to insert so that, with the burst about to be queued, the
        channel is back at its jitter-buffer target (k after k lost bursts)."""
        with self.condition:
            state = self.pending_channels.get(channel_id)
            return max(0, self.prefill_frames - 1 - (len(state.pending_pcm) if state else 0))

    def enqueue(self, channel_id, pcm_out):
        if not pcm_out:
            return None

        queue_max_bytes = self.queue_max_bytes
        if len(pcm_out) > queue_max_bytes:
            pcm_out = pcm_out[-queue_max_bytes:]

        with self.condition:
            if self.closed:
                return None

            channel_state = self.pending_channels.setdefault(channel_id, ChannelAudioState())
            channel_state.pending_pcm.append(pcm_out)
            channel_state.pending_bytes += len(pcm_out)
            channel_state.last_enqueue_at = time.monotonic()
            channel_state.pending_bytes, dropped_bytes, dropped_chunks = _trim_audio_backlog_with_stats(
                channel_state.pending_pcm,
                channel_state.pending_bytes,
                queue_max_bytes,
            )
            self.queue_trim_events += dropped_chunks
            self.queue_trim_bytes += dropped_bytes
            total_pending_bytes = self._total_pending_bytes_locked()
            if total_pending_bytes > self.max_total_pending_bytes:
                self.max_total_pending_bytes = total_pending_bytes
            self.condition.notify()
        return {
            "pending_bytes": channel_state.pending_bytes,
            "total_pending_bytes": total_pending_bytes,
            "dropped_bytes": dropped_bytes,
            "dropped_chunks": dropped_chunks,
        }

    def close(self):
        with self.condition:
            self.closed = True
            for calls in self.replay_calls.values():
                for call in calls:
                    call.close()
            self.replay_calls.clear()
            self.condition.notify_all()

        self.thread.join(timeout=1.0)
        _close_audio_stream(self.audio_stream)
        self.audio_stream = None

    def enqueue_secret(self, call):
        with self.condition:
            if self.closed:
                call.close()
                return
            calls = self.replay_calls.setdefault(call.channel_id, [])
            if call not in calls:
                calls.append(call)
            self.condition.notify_all()

    def _has_pending_audio_locked(self):
        return (any(channel_state.pending_bytes > 0 for channel_state in self.pending_channels.values())
                or any(call.ready for calls in self.replay_calls.values() for call in calls))

    def _total_pending_bytes_locked(self):
        return (sum(channel_state.pending_bytes for channel_state in self.pending_channels.values())
                + sum(call.queued * 7680 for calls in self.replay_calls.values() for call in calls if call.ready))

    def snapshot_metrics(self):
        with self.condition:
            return {
                "pending_bytes": self._total_pending_bytes_locked(),
                "active_channels": sum(1 for channel_state in self.pending_channels.values() if channel_state.pending_bytes > 0),
                "max_pending_bytes": self.max_total_pending_bytes,
                "queue_trim_events": self.queue_trim_events,
                "queue_trim_bytes": self.queue_trim_bytes,
                "write_calls": self.write_calls,
                "write_bytes": self.write_bytes,
                "underflows": self.underflow_count,
                "write_failures": self.write_failures,
                "stream_reopens": self.stream_reopen_count,
                "key_wait_bursts": sum(call.queued for calls in self.replay_calls.values() for call in calls if not call.ready and not call.closed),
            }

    def snapshot_playing(self):
        with self.condition:
            now = time.monotonic()
            self.played_until = {ch: until for ch, until in self.played_until.items() if until > now}
            return set(self.played_until)

    def _ready_channels_locked(self, now):
        """Live channels allowed to play: primed by ``prefill_frames`` bursts,
        or holding a short transmission's tail after it went quiet."""
        ready = set()
        for channel_id, channel_state in self.pending_channels.items():
            if channel_state.pending_bytes <= 0:
                continue
            if not channel_state.primed and (
                    len(channel_state.pending_pcm) >= self.prefill_frames
                    or now - channel_state.last_enqueue_at >= AUDIO_LIVE_FLUSH_SECONDS):
                channel_state.primed = True
            if channel_state.primed:
                ready.add(channel_id)
        return ready

    def _pop_mixed_chunk_locked(self, ready_channels=None):
        pcm_chunks = []
        self.chunk_channels = set()
        empty_channel_ids = []

        for channel_id, channel_state in self.pending_channels.items():
            if channel_state.pending_bytes <= 0:
                empty_channel_ids.append(channel_id)
                continue
            if ready_channels is not None and channel_id not in ready_channels:
                continue  # Still filling its jitter buffer.

            pcm_chunk = channel_state.pending_pcm.popleft()
            if np.any(np.frombuffer(pcm_chunk, dtype=np.int16)):
                self.chunk_channels.add(channel_id)
            channel_state.pending_bytes -= len(pcm_chunk)
            if channel_state.pending_bytes <= 0:
                empty_channel_ids.append(channel_id)
            pcm_chunks.append((channel_id, pcm_chunk))

        for channel_id in empty_channel_ids:
            if self.pending_channels[channel_id].pending_bytes <= 0:
                # Ran dry: the next burst refills the buffer before playing.
                self.pending_channels.pop(channel_id, None)

        replay_tasks = []
        for channel, calls in tuple(self.replay_calls.items()):
            for call in tuple(calls):
                if call.closed or (call.finished and (not call.queued or (not call.key and not call.pending_search))):
                    calls.remove(call)
                    call.close()
            for call in calls:
                if call.ready:
                    replay_tasks.append((call, call.pop()))
                    break
            if not calls:
                del self.replay_calls[channel]
        return pcm_chunks, replay_tasks

    def _channel_weights(self, channels, audible):
        """Muted channels and (with solo) non-solo channels are silent; calls
        beyond the simultaneous-playback limit are silent; a talking priority
        channel ducks the rest. Recording is unaffected."""
        solo, priority = self.solo_ids, self.priority_ids
        weights = {channel: 0.0 for channel in channels if channel in self.mute_ids}
        if solo:
            weights.update({channel: 0.0 for channel in channels if channel not in solo})
        now = time.monotonic()
        self._apply_playback_limit([channel for channel in channels if channel not in weights], weights, now)
        if any(channel in priority and channel not in weights for channel in audible):
            self.priority_active_until = now + PRIORITY_HOLD_SEC
        if priority and now < self.priority_active_until:
            for channel in channels:
                if channel not in priority and channel not in weights:
                    weights[channel] = self.duck_gain
        return weights

    def _apply_playback_limit(self, candidates, weights, now):
        """Admit at most ``max_playback`` ordinary calls. A refused call stays
        silent until it ends, like the recording limit. Priority channels always
        play on top of the limit and do not use its slots."""
        for table in (self.playback_admitted, self.playback_refused):
            for channel, last in tuple(table.items()):
                if now - last > PLAYBACK_CALL_END_SEC:
                    del table[channel]   # call ended: its slot / refusal is released
        priority = self.priority_ids
        for channel in candidates:
            for table in (self.playback_admitted, self.playback_refused):
                if channel in table:
                    table[channel] = now
        limit = self.max_playback
        for channel in dict.fromkeys(candidates):
            if channel in priority or channel in self.playback_admitted or channel in self.playback_refused:
                continue
            used = sum(1 for admitted in self.playback_admitted if admitted not in priority)
            if not limit or used < limit:
                self.playback_admitted[channel] = now
            else:
                self.playback_refused[channel] = now
        for channel in candidates:
            if channel in self.playback_refused and channel not in priority:
                weights[channel] = 0.0

    def _prune_replays_locked(self):
        for channel, calls in tuple(self.replay_calls.items()):
            for call in tuple(calls):
                if call.closed or (call.finished and (not call.queued or (not call.key and not call.pending_search))):
                    calls.remove(call)
                    call.close()
            if not calls:
                del self.replay_calls[channel]

    def _next_chunk(self):
        with self.condition:
            while True:
                self._prune_replays_locked()
                ready = self._ready_channels_locked(time.monotonic())
                if ready or any(call.ready for calls in self.replay_calls.values() for call in calls):
                    return self._pop_mixed_chunk_locked(ready)
                if self._has_pending_audio_locked():
                    # Bursts are queued but still below the prefill.
                    self.condition.wait(timeout=0.02)
                    continue
                if self.closed:
                    return None
                self.condition.wait(timeout=0.1)

    def _run(self):
        output_underflow_count = 0

        while True:
            item = self._next_chunk()
            if item is None:
                if self.closed:
                    break
                continue

            pcm_chunks, replay_tasks = item
            output_channels = set(self.chunk_channels)
            for call, task in replay_tasks:
                if self.speaker_agc is not None:
                    packet, key, replay_options = task
                    replay_options["speaker_agc"] = self.speaker_agc
                    task = packet, key, replay_options
                rendered = call.render(task)
                pcm_chunks.append((call.channel_id, rendered))
                if np.any(np.frombuffer(rendered, dtype=np.int16)):
                    output_channels.add(call.channel_id)
            weights = self._channel_weights([channel for channel, _ in pcm_chunks], output_channels)
            output_channels = {channel for channel in output_channels if weights.get(channel, 1.0) > 0}
            pcm_out = _mix_pcm_chunks([chunk for _, chunk in pcm_chunks], self.gain,
                                      [weights.get(channel, 1.0) for channel, _ in pcm_chunks])
            if not pcm_out:
                continue

            if self.audio_stream is None:
                self.audio_stream = _open_audio_stream_with_retry(self.device, self.latency, self.headless)
                with self.condition:
                    if self.stream_open_count > 0:
                        self.stream_reopen_count += 1
                    self.stream_open_count += 1

            try:
                underflowed = self.audio_stream.write(pcm_out)
            except sd.PortAudioError as exc:
                if not self.headless:
                    print(f"Audio write failed: {exc}", file=sys.stderr)
                with self.condition:
                    self.write_failures += 1
                _close_audio_stream(self.audio_stream)
                self.audio_stream = None
                output_underflow_count = 0
                time.sleep(AUDIO_RECOVERY_DELAY_SEC)
                continue

            with self.condition:
                self.write_calls += 1
                self.write_bytes += len(pcm_out)
                if self.gain > 0:
                    # Publish only after a successful write to the actual output.
                    until = time.monotonic() + max(0.3, len(pcm_out) / (SAMPLE_RATE * AUDIO_BYTES_PER_FRAME))
                    for channel_id in output_channels:
                        self.played_until[channel_id] = until

            if underflowed:
                with self.condition:
                    self.underflow_count += 1
                output_underflow_count += 1
                if output_underflow_count >= AUDIO_UNDERFLOW_RECOVERY_THRESHOLD:
                    if not self.headless:
                        print("Audio output kept underflowing; reopening the audio stream.", file=sys.stderr)
                    _close_audio_stream(self.audio_stream)
                    self.audio_stream = None
                    output_underflow_count = 0
                continue

            output_underflow_count = 0

        _close_audio_stream(self.audio_stream)
        self.audio_stream = None


_gate_recovered = gate_recovered


def _lost_frame_fill(decoder, quality, options, room=MAX_FILLED_FRAMES):
    """48 kHz PCM chunks (one per lost 80 ms burst) to play before this burst.

    ``room`` is how many bursts the channel's jitter buffer is below its
    target: refilling exactly that restores the timing without adding delay
    (a gap longer than the buffer has already paused the speaker).
    """
    if not options.get("fill_lost_frames", True):
        return []
    try:
        missed = min(MAX_FILLED_FRAMES, max(0, int(room)), max(0, int((quality or {}).get("missed", 0))))
    except (TypeError, ValueError):
        return []
    if not missed:
        return []
    pcm = decoder.upsample(decoder.conceal_missing(missed, options), UPSAMPLE_FACTOR, options.get("hq_resampler", True))
    size = len(pcm) // missed
    # One chunk per burst: the jitter buffer counts queued bursts.
    return [pcm[i * size:(i + 1) * size] for i in range(missed)]


def _format_audio_channel_debug(debug_stats):
    return (
        f"rx={debug_stats.voice_packets} pcm={debug_stats.pcm_chunks} empty={debug_stats.empty_decodes} "
        f"fill={debug_stats.filled_frames} "
        f"q={debug_stats.pending_bytes}B peak={debug_stats.peak_pending_bytes}B "
        f"trim={debug_stats.trim_events}/{debug_stats.trim_bytes}B"
    )


def _format_audio_service_summary(audio_output, debug_by_channel, current_time):
    output_metrics = audio_output.snapshot_metrics()
    total_voice_packets = sum(debug_stats.voice_packets for debug_stats in debug_by_channel.values())
    active_channels = sum(
        1
        for debug_stats in debug_by_channel.values()
        if debug_stats.last_packet_at and (current_time - debug_stats.last_packet_at) <= DEBUG_ACTIVE_WINDOW_SEC
    )
    return (
        f"rx={total_voice_packets} q={output_metrics['pending_bytes']}B peak={output_metrics['max_pending_bytes']}B "
        f"trim={output_metrics['queue_trim_events']}/{output_metrics['queue_trim_bytes']}B "
        f"write={output_metrics['write_calls']} under={output_metrics['underflows']} "
        f"err={output_metrics['write_failures']} reopen={output_metrics['stream_reopens']} active={active_channels}"
        f" keywait={output_metrics.get('key_wait_bursts', 0)}"
        + (f" | {audio_output.recording_error}" if getattr(audio_output, "recording_error", "") else "")
    )


def _maybe_publish_audio_metrics(status_publisher, audio_output, debug_by_channel, next_report_at, current_time, decoders=None):
    if current_time < next_report_at:
        return next_report_at

    status_publisher.publish(
        payload_dict={
            "event": "service_metrics",
            "summary": _format_audio_service_summary(audio_output, debug_by_channel, current_time),
        }
    )

    for channel_id, debug_stats in debug_by_channel.items():
        if debug_stats.voice_packets <= 0:
            continue
        if (current_time - debug_stats.last_packet_at) > DEBUG_ACTIVE_WINDOW_SEC and debug_stats.pending_bytes <= 0:
            continue
        status_publisher.publish(
            channel_id=channel_id,
            payload_dict={
                "event": "channel_state",
                "audio_debug": _format_audio_channel_debug(debug_stats),
                **(_decoder_quality_payload(decoders.get(channel_id)) if decoders else {}),
            },
        )

    return current_time + DEBUG_REPORT_INTERVAL_SEC


def _decoder_quality_payload(decoder):
    if decoder is None:
        return {}
    values = decoder.crc_window
    return {"crc_percent": 100.0 * sum(values) / len(values) if values else None,
            **({"audio_status": "Data"} if decoder.last_reason == "Data" else {})}


def main(argv=None):
    args = _parse_args(argv)
    voice_socket_path = resolve_voice_socket_path(channel_count=CHANNEL_COUNT)
    secret_request_socket_path = resolve_secret_request_socket_path(channel_count=CHANNEL_COUNT)
    secret_result_socket_path = resolve_secret_result_socket_path(channel_count=CHANNEL_COUNT)
    voice_client = UdsSeqpacketClient(socket_path=voice_socket_path)
    secret_request_client, secret_result_client = _connect_secret(
        secret_request_socket_path, secret_result_socket_path, args.headless)
    poller = Poller()
    poller.register(voice_client.fileno(), POLLIN)
    if secret_result_client is not None:
        poller.register(secret_result_client.fileno(), POLLIN)
    key_sequences = {DECRYPTION_KEY: generate_pn_sequence_196(DECRYPTION_KEY)}
    decoders = {}
    secret_states = {}
    unplayed_recovered = {}  # channel -> (slots of dropped recovered bursts, time of the last)
    audio_debug = {}
    last_playing_publish = {}
    secret_replays = {}
    replay_sessions = {}
    secret_request_sequence = 0
    status_publisher = StatusPublisher(socket_path=args.status_socket, source=STATUS_SOURCE_AUDIO)
    audio_output = AudioOutputWorker(args.device, args.latency, args.headless, args.gain)
    settings = AudioSettings(args.audio_settings, args.record_dir)
    settings.values["frequencies"] = channel_frequencies(json.loads(args.rf_args_json))
    audio_output.recording_error = ""
    def recording_error(message):
        audio_output.recording_error = message
        status_publisher.publish(payload_dict={"event":"service_metrics", "summary":message})
    record_worker = RecordingWorker(recording_error)
    last_burst = {}
    last_station = {}
    next_debug_report_at = time.time() + DEBUG_REPORT_INTERVAL_SEC
    next_playback_report_at = 0.0
    previously_playing = set()

    if not args.headless:
        print(f"Audio service waiting for voice bursts on {voice_socket_path}")
        print(f"Decryption Key (LFSR Init) set to: {DECRYPTION_KEY}")
        print(f"Secret request socket: {secret_request_socket_path}")
        print(f"Secret result socket: {secret_result_socket_path}")
        print(f"Audio output gain: {args.gain}x")

    status_publisher.publish(
        payload_dict={
            "event": "service_started",
            "service": "audio",
            "voice_socket": voice_socket_path,
            "secret_request_socket": secret_request_socket_path,
            "secret_result_socket": secret_result_socket_path,
            "device": args.device,
            "latency": args.latency if args.latency is not None else "default",
            "gain": args.gain,
        }
    )

    try:
        audio_output.start()

        while True:
            if args.stop_file and os.path.exists(args.stop_file):
                break
            events = dict(poller.poll(100))
            current_time = time.time()
            options = settings.poll(current_time)
            audio_output.speaker_agc = options.get("speaker_agc", True)
            audio_output.solo_ids = channel_ids_for(options, "solo_frequencies")
            audio_output.mute_ids = channel_ids_for(options, "mute_frequencies")
            audio_output.priority_ids = channel_ids_for(options, "priority_frequencies")
            audio_output.duck_gain = options.get("priority_duck_percent", 25) / 100
            audio_output.prefill_frames = options.get("playback_buffer_frames", AUDIO_LIVE_PREFILL_FRAMES)
            audio_output.max_playback = options.get("max_playback_channels", 0)
            audio_output.gain = ((1.0 if options.get("speaker_agc", True) else args.gain) * options.get("volume", 1.0)
                                 if options.get("voice_output", True) else 0.0)

            if secret_result_client is not None and secret_result_client.fileno() in events:
                while True:
                    result_payload = secret_result_client.try_recv()
                    if not result_payload:
                        break

                    result_packet = SecretCrackResultPacket.decode(result_payload)
                    replay = replay_sessions.get((result_packet.channel_id, result_packet.session_id))
                    if replay is not None:
                        replay.pending_search = False
                    if replay is not None and result_packet.resolved_key > 0:
                        replay.set_key(result_packet.resolved_key)
                        audio_output.enqueue_secret(replay)
                    secret_state = secret_states.get(result_packet.channel_id)
                    if secret_state is not None and secret_state.session_id == result_packet.session_id:
                        secret_state.pending_request = False
                        if result_packet.resolved_key > 0:
                            secret_state.active_key = result_packet.resolved_key
                        status_publisher.publish(
                            channel_id=result_packet.channel_id,
                            payload_dict={
                                "event": "channel_state",
                                "audio_status": "Replaying from start" if result_packet.resolved_key > 0 else "Key required",
                                "secret_status": SECRET_RESULT_LABELS[result_packet.result_source],
                                "secret_key": secret_state.active_key,
                            },
                        )

            if voice_client.fileno() in events:
                while True:
                    voice_payload = voice_client.try_recv()
                    if not voice_payload:
                        break

                    packet = VoiceBurstPacket.decode(voice_payload)
                    packet = _gate_recovered(packet, options, unplayed_recovered, current_time)
                    if packet is None:
                        continue
                    if is_excluded_channel(options, packet.channel_id):
                        # Excluded frequencies are neither played, recorded nor
                        # sent for key search; open calls end via the 2 s timeout.
                        if current_time - last_playing_publish.get(packet.channel_id, 0.0) >= 1.0:
                            status_publisher.publish(channel_id=packet.channel_id, payload_dict={
                                "event": "channel_state", "audio_status": "Excluded"})
                            last_playing_publish[packet.channel_id] = current_time
                        continue
                    debug_stats = audio_debug.setdefault(packet.channel_id, AudioChannelDebug())
                    debug_stats.voice_packets += 1
                    debug_stats.last_packet_at = current_time
                    secret_state = secret_states.setdefault(packet.channel_id, SecretChannelState(active_key=DECRYPTION_KEY))

                    station = str((packet.quality or {}).get("csm", ""))
                    station_changed = bool(station and last_station.get(packet.channel_id) and station != last_station[packet.channel_id])
                    incoming_quality = packet.quality or {}
                    trusted_control = incoming_quality.get("crc_ok", True) and incoming_quality.get("parity_ok", True)
                    previous_decoder = decoders.get(packet.channel_id)
                    mode_changed = (previous_decoder is not None and previous_decoder.secret is not None
                                    and trusted_control and previous_decoder.secret != (packet.call_stat == CALL_STAT_SECRET))
                    if packet.channel_id not in decoders or current_time - last_burst.get(packet.channel_id, 0) > 2 or station_changed or mode_changed:
                        previous_replay = secret_replays.get(packet.channel_id)
                        if previous_replay is not None:
                            previous_replay.finish()
                        agc_gain = previous_decoder.agc.gain if previous_decoder is not None else INITIAL_SPEECH_AGC_GAIN
                        decoders[packet.channel_id] = VoicePlayback(agc_gain=agc_gain)
                        _stop_secret_session(secret_state)
                        secret_state.session_id += 1
                        secret_state.active_key = DECRYPTION_KEY
                        secret_replays[packet.channel_id] = SecretReplayCall(
                            packet.channel_id, secret_state.session_id,
                            decoder_factory=functools.partial(VoicePlayback, agc_gain=agc_gain))
                        last_station[packet.channel_id] = station
                        if not args.headless:
                            print(f"Opened audio decoder for channel {packet.channel_id:02d}")
                        status_publisher.publish(
                            channel_id=packet.channel_id,
                            payload_dict={
                                "event": "channel_state",
                                "audio_status": "Decoder Ready",
                            },
                        )

                    decoder = decoders[packet.channel_id]
                    if station:
                        last_station[packet.channel_id] = station
                    if current_time - last_burst.get(packet.channel_id, current_time) > .3:
                        decoder.agc.new_segment()
                    last_burst[packet.channel_id] = current_time
                    quality = packet.quality or {}
                    trusted = quality.get("crc_ok", True) and quality.get("parity_ok", True)
                    if trusted:
                        decoder.secret = packet.call_stat == CALL_STAT_SECRET
                    is_secret = decoder.secret is True
                    replay = secret_replays[packet.channel_id]
                    if replay.closed and is_secret and options.get("voice_output", True):
                        replay = SecretReplayCall(packet.channel_id, secret_state.session_id,
                                                  decoder_factory=functools.partial(VoicePlayback, agc_gain=decoder.agc.gain))
                        secret_replays[packet.channel_id] = replay
                        replay_sessions[(packet.channel_id, secret_state.session_id)] = replay
                    if decoder.secret is False:
                        replay.close()
                    elif options.get("voice_output", True):
                        replay.secret = is_secret
                        replay.append(packet, options)
                        audio_output.enqueue_secret(replay)
                    else:
                        replay.close()
                    manual_key = settings.key_for(packet)
                    if packet.payload_format == VOICE_FORMAT_RAW_3600:
                        payloads_3600 = _split_payload_blocks(packet.payload, VOICE_BURST_BLOCK_BYTES_RAW_3600)
                        payloads_2450 = payloads_3600_to_2450(payloads_3600) if is_secret else None
                    else:
                        payloads_2450 = _split_payload_blocks(packet.payload, VOICE_BURST_BLOCK_BYTES_AMBE_2450)

                    if is_secret:
                        if not secret_state.secret_active:
                            _start_secret_session(secret_state)
                            replay.session_id = secret_state.session_id
                            replay_sessions[(packet.channel_id, secret_state.session_id)] = replay
                            status_publisher.publish(
                                channel_id=packet.channel_id,
                                payload_dict={
                                    "event": "channel_state",
                                    "audio_status": "Key required",
                                    "secret_status": "Collecting",
                                    "secret_key": secret_state.active_key,
                                },
                            )

                        if trusted and quality.get("mode", 3) == 3:
                            secret_state.burst_window.append(_secret_burst_payload(payloads_2450))
                        secret_request_sequence, request_sent = _maybe_send_secret_request(
                            packet,
                            secret_state,
                            None if manual_key else secret_request_client,
                            secret_request_sequence,
                        )
                        if request_sent:
                            replay.pending_search = True
                            status_publisher.publish(
                                channel_id=packet.channel_id,
                                payload_dict={
                                    "event": "channel_state",
                                    "audio_status": "Key required" if not secret_state.active_key else "Replaying from start",
                                    "secret_status": "Search Pending",
                                    "secret_key": secret_state.active_key,
                                },
                            )
                    elif secret_state.secret_active:
                        _stop_secret_session(secret_state)
                        status_publisher.publish(
                            channel_id=packet.channel_id,
                            payload_dict={
                                "event": "channel_state",
                                "audio_status": "Playing",
                                "secret_status": "Idle",
                                "secret_key": secret_state.active_key,
                            },
                        )

                    decryption_key = (manual_key or secret_state.active_key) if is_secret else DECRYPTION_KEY
                    if is_secret and decryption_key:
                        replay.set_key(decryption_key)
                        audio_output.enqueue_secret(replay)
                    pcm_8k, _ = decoder.decode(packet, decryption_key, options, payloads_2450)
                    record_worker.submit(packet, pcm_8k, options, current_time)
                    if is_secret or decoder.secret is None:
                        # Speaker history is decoded on the output thread at
                        # playback speed, so releasing a key never floods the
                        # half-second live PCM queue and drops the call's head.
                        last_publish_time = last_playing_publish.get(packet.channel_id, 0.0)
                        if current_time - last_publish_time >= 1.0:
                            status_publisher.publish(channel_id=packet.channel_id, payload_dict={
                                "event": "channel_state",
                                "audio_status": "Replaying from start" if replay.ready else decoder.last_reason,
                                **({"secret_status":"Manual Key", "secret_key":manual_key} if is_secret and manual_key else {}),
                            })
                            last_playing_publish[packet.channel_id] = current_time
                        continue
                    if decoder.last_reason == "Data":
                        continue  # Data-channel silence must not attenuate the speech mix.
                    fill_chunks = _lost_frame_fill(decoder, quality, options, audio_output.fill_room(packet.channel_id))
                    pcm_out = decoder.upsample(pcm_8k, UPSAMPLE_FACTOR, options.get("hq_resampler", True))
                    if not options.get("voice_output", True):
                        continue
                    if not pcm_out:
                        debug_stats.empty_decodes += 1
                        continue
                    for chunk in fill_chunks:
                        # Lost bursts keep their 80 ms on the speaker, so the
                        # jitter buffer does not drain and stop to refill.
                        audio_output.enqueue(packet.channel_id, chunk)
                        debug_stats.filled_frames += 1

                    enqueue_result = audio_output.enqueue(packet.channel_id, pcm_out)
                    if enqueue_result is None:
                        continue
                    debug_stats.pcm_chunks += 1
                    debug_stats.pending_bytes = enqueue_result["pending_bytes"]
                    if debug_stats.pending_bytes > debug_stats.peak_pending_bytes:
                        debug_stats.peak_pending_bytes = debug_stats.pending_bytes
                    debug_stats.trim_events += enqueue_result["dropped_chunks"]
                    debug_stats.trim_bytes += enqueue_result["dropped_bytes"]

                    last_publish_time = last_playing_publish.get(packet.channel_id, 0.0)
                    if current_time - last_publish_time >= 1.0:
                        status_publisher.publish(
                            channel_id=packet.channel_id,
                            payload_dict={
                                "event": "channel_state",
                                "audio_status": decoder.last_reason,
                                **({"secret_status":"Manual Key", "secret_key":manual_key} if is_secret and manual_key else {}),
                            },
                        )
                        last_playing_publish[packet.channel_id] = current_time

            for channel, replay in secret_replays.items():
                if current_time - last_burst.get(channel, current_time) > 2:
                    replay.finish()
            for identity, replay in tuple(replay_sessions.items()):
                if replay.closed:
                    del replay_sessions[identity]
            if current_time >= next_playback_report_at:
                playing = audio_output.snapshot_playing()
                for channel_id in playing | previously_playing:
                    status_publisher.publish(channel_id=channel_id, payload_dict={
                        "event": "channel_state", "playback_active": channel_id in playing,
                    })
                previously_playing = playing
                next_playback_report_at = current_time + 0.2
            next_debug_report_at = _maybe_publish_audio_metrics(
                status_publisher,
                audio_output,
                audio_debug,
                next_debug_report_at,
                current_time,
                decoders,
            )

    except KeyboardInterrupt:
        if not args.headless:
            sys.stdout.write("\n")
            print("Audio service stopped by user.")
    finally:
        record_worker.close()
        audio_output.close()
        for replay in (*secret_replays.values(), *replay_sessions.values()):
            replay.close()
        status_publisher.close()
        voice_client.close()
        if secret_request_client is not None:
            secret_request_client.close()
        if secret_result_client is not None:
            secret_result_client.close()


if __name__ == "__main__":
    main()
