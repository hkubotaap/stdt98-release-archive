#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from dataclasses import dataclass
from pathlib import Path
import select
import tempfile
import sys
import time

import numpy as np

from core.pipeline.multi_channel_dashboard import ChannelContext, print_dashboard
from core.pipeline.runtime_status import StatusPublisher
from core.protocol.ambe_soft import soft_decode_block
from core.protocol.dewhiten import dewhiten, dewhiten_soft
from core.protocol.frame_layout import (decode_soft_symbols, parse_frame_symbols, quantize_float_symbols,
                                        soft_bit_values, split_soft_bits, FRAME_STRUCTURE,
                                        symbols_to_binary_string)
from core.protocol.pich import decode_pich
from core.protocol.rich import decode_rich
from core.protocol.sacch import decode_sacch
from core.protocol.tch import block_strings_to_payloads_3600, split_traffic_blocks
from core.protocol.voice_gaps import VoiceGapTracker
from ipc.message_schema import FRAME_FLAG_FLYWHEEL, FRAME_FLAG_SOFT_SYMBOLS, STATUS_SOURCE_PROTOCOL, VOICE_FORMAT_RAW_3600, FramePacket, VoiceBurstPacket
from ipc.transport.compat_poll import POLLIN, Poller
from ipc.transport.uds_seqpacket import (
    UdsSeqpacketClient,
    UdsSeqpacketServer,
    resolve_frame_socket_path,
    resolve_voice_socket_path,
)


CHANNEL_COUNT = 30


def _soft_voice_fec(blocks_payload, soft_fields):
    """Soft-decision C0/C1 decoding of the burst's four AMBE blocks, for the
    audio service's "soft_voice_fec" option. The packet payload itself stays
    the hard bits (recordings, remote clients and the secret search use it)."""
    tch = np.concatenate((soft_fields["TCH1"], soft_fields["TCH2"]))
    results = [soft_decode_block(blocks_payload[i*9:(i+1)*9], tch[i*72:(i+1)*72]) for i in range(len(blocks_payload)//9)]
    return {"blocks": b"".join(r.payload for r in results).hex(),
            "errors": [[r.c0_errors, r.total_errors] for r in results]}
CHANNEL_CLOSE_TIMEOUT = 0.5
VOICE_KEY_ID = 0
DEBUG_REPORT_INTERVAL_SEC = 1.0
DEBUG_ACTIVE_WINDOW_SEC = 2.0


@dataclass
class ProtocolDebugStats:
    frames_received: int = 0
    rich_decode_failures: int = 0
    sync_bursts: int = 0
    traffic_bursts: int = 0
    voice_sent: int = 0
    voice_send_blocked: int = 0
    sacch_crc_ok: int = 0
    sacch_crc_fail: int = 0
    last_frame_at: float = 0.0


FLYWHEEL_LOG_INTERVAL_SEC = 60.0
# Probes count only on channels in a confirmed call: a received traffic frame
# with a valid SACCH CRC this recently. Open-squelch noise syncs arm the probe
# too, and their probes would cost decoding and swamp the counts.
FLYWHEEL_CALL_WINDOW_SEC = 2.0


class FlywheelStats:
    """Counts for the RF flywheel probe (FRAME_FLAG_FLYWHEEL): slots where a
    call's next frame was due but no sync word was detected. A probe frame
    with a valid SACCH CRC is one the receiver could have recovered. Appends
    cumulative totals to %TEMP%/std-t98-flywheel.log once a minute."""

    def __init__(self, path=None):
        self.path = Path(path) if path else Path(tempfile.gettempdir()) / "std-t98-flywheel.log"
        self.probes = self.rich_ok = self.traffic = self.sacch_ok = self.sync_bursts = 0
        self.frames = self.frames_sacch_ok = 0
        self.by_slot = {}  # slot -> [probes, traffic_sacch_ok]
        self.call_at = {}  # channel -> time of its last SACCH-valid received frame
        self.next_log_at = 0.0

    def received(self, channel_id, sacch_ok, now):
        """A normal (sync-detected) traffic frame, for comparison."""
        self.frames += 1
        self.frames_sacch_ok += bool(sacch_ok)
        if sacch_ok:
            self.call_at[channel_id] = now

    def probe(self, packet, now=None):
        """Count a probe frame. Returns (fields, soft_fields, rich, sacch) for
        a traffic frame with valid RICH parity and SACCH CRC on a channel in
        a confirmed call (a flywheel-recoverable burst), else None."""
        if now is not None and now - self.call_at.get(packet.channel_id, -1e9) > FLYWHEEL_CALL_WINDOW_SEC:
            return
        self.probes += 1
        slot = self.by_slot.setdefault(packet.missed, [0, 0])
        slot[0] += 1
        soft = decode_soft_symbols(packet.symbols)
        fields = parse_frame_symbols(dewhiten(quantize_float_symbols(soft)))
        soft_fields = split_soft_bits(soft_bit_values(dewhiten_soft(soft)))
        try:
            rich = decode_rich(fields["RICH"])
        except Exception:
            return None
        if not rich.get("Parity_OK"):
            return None
        self.rich_ok += 1
        if rich["F"] == 0:
            self.sync_bursts += 1
        elif rich["F"] == 1:
            self.traffic += 1
            sacch = decode_sacch(fields["SACCH"], soft_fields.get("SACCH"))
            if sacch.get("CRC_OK"):
                self.sacch_ok += 1
                slot[1] += 1
                return fields, soft_fields, rich, sacch
        return None

    def maybe_log(self, now):
        if now < self.next_log_at or not self.probes:
            return
        self.next_log_at = now + FLYWHEEL_LOG_INTERVAL_SEC
        line = (f"{time.strftime('%Y-%m-%d %H:%M:%S')} probes={self.probes} rich_ok={self.rich_ok} "
                f"sync_bursts={self.sync_bursts} traffic={self.traffic} traffic_sacch_ok={self.sacch_ok} | "
                f"received traffic={self.frames} sacch_ok={self.frames_sacch_ok} | by slot (probes/sacch_ok) "
                + " ".join(f"{k}:{v[0]}/{v[1]}" for k, v in sorted(self.by_slot.items())) + "\n")
        try:
            with open(self.path, "a", encoding="utf-8") as stream:
                stream.write(line)
        except OSError:
            pass


def _voice_burst(packet, channel_id, fields, soft_fields, rich_data, sacch_data, csm, missed, burst_index,
                 recovered=False):
    blocks_payload = b"".join(block_strings_to_payloads_3600(split_traffic_blocks(fields)))
    # Preserve the hard decisions before whitening removal and the exact bits
    # supplied to the protocol decoders. The 36-byte audio payload omits SW,
    # RICH and SACCH and cannot be used to reconstruct them later.
    frame_data = {}
    if all(isinstance(fields.get(name), str) and len(fields[name]) == length
           and set(fields[name]) <= {"0", "1"} for name, length in FRAME_STRUCTURE):
        bits = "".join(fields[name] for name, _length in FRAME_STRUCTURE)
        frame_data["frame_dw_hex"] = int(bits, 2).to_bytes(48, "big").hex()
        symbols = packet.symbols
        if packet.flags & FRAME_FLAG_SOFT_SYMBOLS:
            symbols = quantize_float_symbols(decode_soft_symbols(symbols))
        if len(symbols) == 192 and np.all(np.isin(symbols, (-3, -1, 1, 3))):
            bits = symbols_to_binary_string(symbols)
            frame_data["frame_rx_hex"] = int(bits, 2).to_bytes(48, "big").hex()
    return VoiceBurstPacket(
        sequence=packet.sequence,
        channel_id=channel_id,
        call_stat=sacch_data.get("CallStat", 0) if sacch_data.get("CRC_OK") else 0,
        key_id=VOICE_KEY_ID,
        burst_index=burst_index,
        payload_format=VOICE_FORMAT_RAW_3600,
        payload=blocks_payload,
        quality={"crc_ok": bool(sacch_data.get("CRC_OK")),
                 "parity_ok": bool(rich_data.get("Parity_OK")),
                 "mode": rich_data.get("M", 3),
                 "csm": csm or "",
                 "sacch": sacch_data,
                 # Lost 80 ms slots just before this burst.
                 "missed": missed,
                 **frame_data,
                 **({"soft_fec": _soft_voice_fec(blocks_payload, soft_fields)} if soft_fields else {}),
                 # Flywheel: no sync word was detected for this frame. The
                 # audio service plays it only with "flywheel_recovery".
                 **({"recovered": True} if recovered else {})},
    )


def _parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Run the split multi-channel protocol service.")
    parser.add_argument("--headless", action="store_true", help="Disable the local dashboard UI.")
    parser.add_argument("--status-socket", help="Optional UDS socket path used to publish status events.")
    return parser.parse_args(argv)


def _publish_channel_state(status_publisher, channel_id, channel_context):
    if status_publisher is None:
        return
    status_publisher.publish(
        channel_id=channel_id,
        payload_dict={
            "event": "channel_state",
            "rx_status": channel_context.rx_status,
            "protocol_status": channel_context.audio_status,
            "csm": channel_context.csm,
            "sacch": channel_context.sacch,
        },
    )


def _format_protocol_debug(debug_stats):
    return (
        f"frm={debug_stats.frames_received} sync={debug_stats.sync_bursts} "
        f"traf={debug_stats.traffic_bursts} ipc={debug_stats.voice_sent}/{debug_stats.voice_send_blocked} "
        f"rich_fail={debug_stats.rich_decode_failures} sacch={debug_stats.sacch_crc_ok}/{debug_stats.sacch_crc_fail}"
    )


def _format_protocol_service_summary(debug_by_channel, current_time):
    totals = ProtocolDebugStats()
    active_channels = 0

    for debug_stats in debug_by_channel.values():
        totals.frames_received += debug_stats.frames_received
        totals.rich_decode_failures += debug_stats.rich_decode_failures
        totals.sync_bursts += debug_stats.sync_bursts
        totals.traffic_bursts += debug_stats.traffic_bursts
        totals.voice_sent += debug_stats.voice_sent
        totals.voice_send_blocked += debug_stats.voice_send_blocked
        totals.sacch_crc_ok += debug_stats.sacch_crc_ok
        totals.sacch_crc_fail += debug_stats.sacch_crc_fail
        if debug_stats.last_frame_at and (current_time - debug_stats.last_frame_at) <= DEBUG_ACTIVE_WINDOW_SEC:
            active_channels += 1

    return (
        f"frames={totals.frames_received} sync={totals.sync_bursts} traffic={totals.traffic_bursts} "
        f"ipc={totals.voice_sent}/{totals.voice_send_blocked} rich_fail={totals.rich_decode_failures} "
        f"sacch={totals.sacch_crc_ok}/{totals.sacch_crc_fail} active={active_channels}"
    )


def _maybe_publish_protocol_metrics(status_publisher, debug_by_channel, next_report_at, current_time):
    if current_time < next_report_at:
        return next_report_at

    status_publisher.publish(
        payload_dict={
            "event": "service_metrics",
            "summary": _format_protocol_service_summary(debug_by_channel, current_time),
        }
    )

    for channel_id, debug_stats in debug_by_channel.items():
        if debug_stats.frames_received <= 0:
            continue
        if (current_time - debug_stats.last_frame_at) > DEBUG_ACTIVE_WINDOW_SEC and debug_stats.voice_send_blocked <= 0:
            continue
        status_publisher.publish(
            channel_id=channel_id,
            payload_dict={
                "event": "channel_state",
                "protocol_debug": _format_protocol_debug(debug_stats),
            },
        )

    return current_time + DEBUG_REPORT_INTERVAL_SEC


def main(argv=None):
    args = _parse_args(argv)
    frame_socket_path = resolve_frame_socket_path(channel_count=CHANNEL_COUNT)
    voice_socket_path = resolve_voice_socket_path(channel_count=CHANNEL_COUNT)
    status_publisher = StatusPublisher(socket_path=args.status_socket, source=STATUS_SOURCE_PROTOCOL)

    frame_client = UdsSeqpacketClient(socket_path=frame_socket_path)
    voice_server = UdsSeqpacketServer(socket_path=voice_socket_path)
    poller = Poller()
    poller.register(frame_client.fileno(), POLLIN)

    channels = {}
    debug_by_channel = {}
    voice_gaps = VoiceGapTracker()
    voice_burst_index = 0
    next_debug_report_at = time.time() + DEBUG_REPORT_INTERVAL_SEC

    if not args.headless:
        print(f"Protocol service listening to frames on {frame_socket_path}")
        print(f"Protocol service publishing voice bursts on {voice_socket_path}\n")
        print("\n" * 15, end="")
        printed_lines = print_dashboard(channels, 0, title="STD-T98 Multi Protocol Service")
    else:
        printed_lines = 0

    status_publisher.publish(
        payload_dict={
            "event": "service_started",
            "service": "protocol",
            "frame_socket": frame_socket_path,
            "voice_socket": voice_socket_path,
        }
    )
    flywheel = FlywheelStats()

    try:
        while True:
            events = dict(poller.poll(100))
            current_time = time.time()
            dashboard_changed = False

            if frame_client.fileno() in events:
                while True:
                    payload = frame_client.try_recv()
                    if not payload:
                        break

                    packet = FramePacket.decode(payload)
                    if packet.flags & FRAME_FLAG_FLYWHEEL:
                        # Never updates the channel state; a valid traffic
                        # frame of a confirmed call goes on as a recovered burst.
                        recovered = flywheel.probe(packet, current_time)
                        flywheel.maybe_log(current_time)
                        if recovered and packet.channel_id in channels:
                            fields, soft_fields, rich_data, sacch_data = recovered
                            voice_packet = _voice_burst(
                                packet, packet.channel_id, fields, soft_fields, rich_data, sacch_data,
                                channels[packet.channel_id].csm,
                                voice_gaps.recovered(packet.channel_id, packet.monotonic_ns),
                                voice_burst_index, recovered=True)
                            voice_burst_index += 1
                            voice_server.send(voice_packet.encode())
                        continue
                    channel_id = packet.channel_id
                    channel_changed = False

                    if channel_id not in channels:
                        channels[channel_id] = ChannelContext()
                        channel_changed = True

                    ctx_ch = channels[channel_id]
                    if current_time - ctx_ch.last_update > 2:
                        ctx_ch.csm = None
                        ctx_ch.sacch = None
                    debug_stats = debug_by_channel.setdefault(channel_id, ProtocolDebugStats())
                    debug_stats.frames_received += 1
                    debug_stats.last_frame_at = current_time

                    if ctx_ch.rx_status != "OPEN":
                        ctx_ch.rx_status = "OPEN"
                        channel_changed = True

                    ctx_ch.last_update = current_time
                    voice_gaps.frame(channel_id, packet.missed)

                    if packet.flags & FRAME_FLAG_SOFT_SYMBOLS:
                        # Hard fields for RICH/voice; soft values for the
                        # convolutionally coded SACCH and PICH.
                        soft = decode_soft_symbols(packet.symbols)
                        fields = parse_frame_symbols(dewhiten(quantize_float_symbols(soft)))
                        soft_fields = split_soft_bits(soft_bit_values(dewhiten_soft(soft)))
                    else:
                        fields = parse_frame_symbols(dewhiten(packet.symbols))
                        soft_fields = {}

                    try:
                        rich_data = decode_rich(fields["RICH"])
                    except Exception:
                        debug_stats.rich_decode_failures += 1
                        voice_gaps.non_voice(channel_id)
                        continue

                    if rich_data["F"] != 1:
                        voice_gaps.non_voice(channel_id)

                    if rich_data["F"] == 0:
                        debug_stats.sync_bursts += 1
                        pich_data = decode_pich(fields["TCH1"], soft_fields.get("TCH1"))
                        if rich_data.get("Parity_OK") and pich_data.get("CRC_OK") and ctx_ch.csm != pich_data.get("CSM"):
                            ctx_ch.csm = pich_data.get("CSM")
                            channel_changed = True

                        if ctx_ch.audio_status != "Sync Burst":
                            ctx_ch.audio_status = "Sync Burst"
                            channel_changed = True

                        dashboard_changed = dashboard_changed or channel_changed
                        if channel_changed:
                            _publish_channel_state(status_publisher, channel_id, ctx_ch)
                        continue

                    if rich_data["F"] != 1:
                        continue

                    debug_stats.traffic_bursts += 1
                    sacch_data = decode_sacch(fields["SACCH"], soft_fields.get("SACCH"))
                    flywheel.received(channel_id, sacch_data.get("CRC_OK"), current_time)
                    if sacch_data.get("CRC_OK"):
                        debug_stats.sacch_crc_ok += 1
                        if rich_data.get("Parity_OK") and ctx_ch.sacch != sacch_data:
                            ctx_ch.sacch = sacch_data
                            channel_changed = True
                    else:
                        debug_stats.sacch_crc_fail += 1

                    voice_packet = _voice_burst(
                        packet, channel_id, fields, soft_fields, rich_data, sacch_data, ctx_ch.csm,
                        voice_gaps.voice(channel_id, packet.monotonic_ns), voice_burst_index)
                    voice_burst_index += 1

                    if voice_server.send(voice_packet.encode()):
                        debug_stats.voice_sent += 1
                        next_audio_status = "Traffic->IPC"
                    else:
                        debug_stats.voice_send_blocked += 1
                        next_audio_status = "Traffic (no client)"

                    if ctx_ch.audio_status != next_audio_status:
                        ctx_ch.audio_status = next_audio_status
                        channel_changed = True

                    dashboard_changed = dashboard_changed or channel_changed
                    if channel_changed:
                        _publish_channel_state(status_publisher, channel_id, ctx_ch)
            else:
                for channel_id, ctx_ch in channels.items():
                    if ctx_ch.rx_status == "OPEN" and (current_time - ctx_ch.last_update) > CHANNEL_CLOSE_TIMEOUT:
                        ctx_ch.rx_status = "CLOSE"
                        ctx_ch.audio_status = "Idle"
                        dashboard_changed = True
                        _publish_channel_state(status_publisher, channel_id, ctx_ch)

            next_debug_report_at = _maybe_publish_protocol_metrics(
                status_publisher,
                debug_by_channel,
                next_debug_report_at,
                current_time,
            )

            if dashboard_changed and not args.headless:
                printed_lines = print_dashboard(channels, printed_lines, title="STD-T98 Multi Protocol Service")

    except KeyboardInterrupt:
        if not args.headless:
            sys.stdout.write("\n")
            print("Protocol service stopped by user.")
    finally:
        status_publisher.close()
        frame_client.close()
        voice_server.close()


if __name__ == "__main__":
    main()
