r"""
STD-T98 秘話キー 試聴・保存ツール(キー解析無効版、スタンドアロン GUI)。

生録音(.t98raw)を読み、平文または手入力した既知キーで試聴する。
既知キーは manual_keys.csv に保存できる。キー探索・解析は無効化されている。

ライブのプラグインとは独立(SDR# が動いていなくても使える)。
post_decode.py / gr_port の復号処理を再利用する。

起動:  python key_tool.py
"""
import calendar
import csv
import datetime
import json
import math
import os
import re
import struct
import sys
import tempfile
import threading
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk
import wave as wavemod
import webbrowser
import winsound

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np


def _ui_color(system, fallback):
    return system if sys.platform == "win32" else fallback

from core.protocol.pich import crc12_check, decode_coded_tch, decode_nonvoice_tch
from core.protocol.rich import decode_rich
from core.protocol.sacch import decode_sacch
from post_decode import (
    read_raw, decode_to_pcm, build_burst_payload, is_voice, IndependentCodec, pitch_continuity,
    channel_label, load_manual_keys, MANUAL_KEYS_CSV,
    FFNN_MODEL, HYBRID_MODEL,
)
from core.audio.offline_render import LIVE_OPTIONS, load_edu_rows
from core.audio.offline_render import available as live_available
from core.audio.offline_render import render as live_render
from core.audio.offline_render import max_frames as live_max_frames
from core.audio.offline_render import render_chunks as live_render_chunks
from core.audio.recordings import AudioSettings
from core.audio import independent_ambe
from core.audio.data_paths import resolve_data_dir
from core.audio.listening_agc import ListeningAgc, adjust_listening_volume

DATA_DIR = str(resolve_data_dir(os.environ.get("STD_T98_DATA_DIR"), os.path.dirname(os.path.abspath(__file__))))
RAW_DIR = os.path.join(DATA_DIR, "raw")
REC_DIR = os.path.join(DATA_DIR, "rec")
EDU_DIR = os.path.join(DATA_DIR, "edu")
CSM_ALIAS_CSV = os.path.join(DATA_DIR, "csm_alias.csv")
USER_ALIAS_CSV = os.path.join(DATA_DIR, "user_alias.csv")
MAKER_CODES_CSV = os.path.join(DATA_DIR, "maker_codes.csv")
RX_LOG_CSV = os.path.join(DATA_DIR, "rx_log.csv")
AUDIO_SETTINGS_JSON = os.path.join(DATA_DIR, "audio_settings.json")
LIVE_RATE = 48000
UI_POLL_MS = 15  # 背景の準備完了→再生開始を100ms単位で待たせない
# 統計ダッシュボード(HTML)関連。テンプレートと Chart.js はツール本体と同じ場所に置く。
_TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
STATS_TPL = os.path.join(_TOOL_DIR, "stats_dashboard.tpl.html")
CHARTJS_LOCAL = os.path.join(_TOOL_DIR, "chart.umd.min.js")
CHARTJS_CDN = "https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"


def _day_sub(name):
    """"yyyyMMdd_..." というファイル名 → 日付サブフォルダ名 "yyyy-MM-dd"。取れなければ None。"""
    b = os.path.basename(name)
    return f"{b[0:4]}-{b[4:6]}-{b[6:8]}" if len(b) >= 8 and b[:8].isdigit() else None


def _list_files(root, ext):
    """root 以下(日付サブフォルダ含む)の *ext を再帰的に列挙。旧フラット配置も拾う。"""
    out = []
    if os.path.isdir(root):
        for dp, _dn, fns in os.walk(root):
            for fn in fns:
                if fn.endswith(ext):
                    out.append(os.path.join(dp, fn))
    return out


def _edu_path(base):
    """交信ベース名(拡張子なし)に対応する edu jsonl を、日付サブフォルダ→edu直下(旧)の順に探す。"""
    sub = _day_sub(base)
    if sub:
        p = os.path.join(EDU_DIR, sub, base + ".jsonl")
        if os.path.exists(p):
            return p
    p = os.path.join(EDU_DIR, base + ".jsonl")
    return p if os.path.exists(p) else None


def recording_files(raw_path):
    """raw 録音と、同じ交信ベース名の edu(jsonl) / rec(WAV: *_live.wav, *_enh_*.wav)。

    ベース名は時刻+ch+周波数+一意IDなので、前方一致(base + "_")で他の交信を巻き込まない。
    """
    base = os.path.splitext(os.path.basename(raw_path))[0]
    files = [raw_path]
    ep = _edu_path(base)
    if ep:
        files.append(ep)
    sub = _day_sub(base)
    for d in ([os.path.join(REC_DIR, sub)] if sub else []) + [REC_DIR]:
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if fn.lower().endswith(".wav") and (fn == base + ".wav" or fn.startswith(base + "_")):
                files.append(os.path.join(d, fn))
    return files


def delete_recordings(raw_paths):
    """録音(raw)と付随ファイルを削除。戻り値 (削除できた raw の一覧, [(path, 例外)])。

    raw を消せなかった交信は付随ファイルも残す(一覧と中身の食い違いを作らない)。
    既に無いファイル(録音側の自動破棄など)は削除済みとして扱う。
    """
    deleted, errors = [], []
    for raw in raw_paths:
        group = recording_files(raw)
        try:
            os.remove(raw)
        except FileNotFoundError:
            pass
        except OSError as exc:
            errors.append((raw, exc))
            continue
        deleted.append(raw)
        for path in group[1:]:
            try:
                os.remove(path)
            except FileNotFoundError:
                pass
            except OSError as exc:
                errors.append((path, exc))
    return deleted, errors


def _rec_day_dir(base):
    """base に対応する rec の日付サブフォルダ(無ければ作成)。日付が取れなければ rec 直下。"""
    sub = _day_sub(base)
    d = os.path.join(REC_DIR, sub) if sub else REC_DIR
    os.makedirs(d, exist_ok=True)
    return d
# 「この局の全録音で探索」で採点に使うブロック数の上限。鍵は局ごとに固定なので、
# 新しい良質なブロックを一定数使えば十分。件数が多くても探索時間を頭打ちにする。
MAX_POOL_BLOCKS = 40
# 設定はツール本体と同じ場所に置く(他環境へ移しても付いてくる)。
CONFIG_PATH = os.path.join(DATA_DIR, "key_tool_config.json")


def load_config():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def read_header(path):
    """全読込せずヘッダだけ読み (freq_hz, csm) を返す。一覧の絞り込み用に高速。
    読めなければ (None, None)。"""
    try:
        with open(path, "rb") as f:
            h = f.read(52)
        magic = h[:8]
        if magic in (b"T98RAW02", b"T98RAW03"):   # v02/v03 とも CSM は 32:48
            csm = h[32:48].split(b"\x00")[0].decode("utf-8", "ignore").strip()
        elif magic == b"T98RAW01":
            csm = ""
        else:
            return None, None
        freq = struct.unpack_from("<q", h, 8)[0]
        return freq, csm
    except Exception:
        return None, None


def read_secret_flag(path):
    """ヘッダだけ読み秘話フラグを返す: True=秘話 / False=平文 / None=不明。
    v03 のみ +48 に 1B(0=不明/1=平文/2=秘話)。v01/v02 や読めない場合は不明。"""
    try:
        with open(path, "rb") as f:
            h = f.read(49)
        if h[:8] != b"T98RAW03" or len(h) < 49:
            return None
        return True if h[48] == 2 else False if h[48] == 1 else None
    except Exception:
        return None


SECRET_LABEL = {False: "平文", True: "秘話", None: "不明"}


def load_csm_alias():
    m = {}
    try:
        import csv
        with open(CSM_ALIAS_CSV, encoding="utf-8-sig", newline="") as f:
            for row in csv.reader(f):
                if not row or row[0].strip().startswith(("#", "csm")):
                    continue
                if len(row) >= 2 and row[0].strip():
                    m[row[0].strip()] = row[1].strip()
    except Exception:
        pass
    return m


def save_csm_alias(mapping):
    """csm_alias.csv を書き出す(プラグインと共有する csm,alias 形式)。
    プラグイン側は各行を最初のカンマで2分割して読むので、csv標準の引用付きでも互換。"""
    import csv
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(CSM_ALIAS_CSV, "w", encoding="utf-8", newline="") as f:
        f.write("# CSM(呼出名称記憶装置の識別信号) -> 局名エイリアス (csm,alias)\n")
        f.write("# key_tool の [ファイル > CSM別名の編集] または手動で編集できます。\n")
        w = csv.writer(f)
        w.writerow(["csm", "alias"])
        for csm in sorted(mapping):
            alias = str(mapping[csm]).strip()
            csm = str(csm).strip()
            if csm and alias:
                w.writerow([csm, alias])


def load_user_alias():
    """user_alias.csv (user,alias) を読む。ユーザ番号(int, 0-511)→別名。"""
    m = {}
    try:
        import csv
        with open(USER_ALIAS_CSV, encoding="utf-8-sig", newline="") as f:
            for row in csv.reader(f):
                if not row or row[0].strip().startswith(("#", "user")):
                    continue
                if len(row) >= 2 and row[0].strip() and row[1].strip():
                    try:
                        m[int(row[0].strip())] = row[1].strip()
                    except ValueError:
                        pass
    except Exception:
        pass
    return m


def save_user_alias(mapping):
    """user_alias.csv を書き出す(user,alias 形式、番号順)。"""
    import csv
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(USER_ALIAS_CSV, "w", encoding="utf-8", newline="") as f:
        f.write("# ユーザ番号(SACCH userCode 0-511) -> 別名 (user,alias)\n")
        f.write("# key_tool の [ファイル > ユーザ番号別名の編集] または手動で編集できます。\n")
        w = csv.writer(f)
        w.writerow(["user", "alias"])
        for uc in sorted(mapping):
            alias = str(mapping[uc]).strip()
            if alias:
                w.writerow([int(uc), alias])


def load_maker_codes():
    """maker_codes.csv (code,name) を読む。メーカー番号→名称。ヘッダ/コメント/空行は無視。"""
    m = {}
    try:
        import csv
        with open(MAKER_CODES_CSV, encoding="utf-8-sig", newline="") as f:
            for row in csv.reader(f):
                if not row or row[0].strip().startswith(("#", "code")):
                    continue
                if len(row) >= 2 and row[0].strip():
                    try:
                        m[int(row[0].strip())] = row[1].strip()
                    except ValueError:
                        pass
    except Exception:
        pass
    return m


def save_maker_codes(mapping):
    """maker_codes.csv (code,name) を書き出す。メーカー番号(0-127)→名称。"""
    import csv
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(MAKER_CODES_CSV, "w", encoding="utf-8", newline="") as f:
        f.write("# メーカー番号 -> 名称 (code,name)\n")
        f.write("# key_tool の [ファイル > メーカ名の編集] または手動で編集できます。\n")
        w = csv.writer(f)
        w.writerow(["code", "name"])
        for code in sorted(mapping):
            name = str(mapping[code]).strip()
            if name:
                w.writerow([int(code), name])


def load_key_bindings():
    """manual_keys.csv を読み、紐づけ一覧 [(kind, value, key)] を返す。
    形式: csm,freq_hz,key,user(4列目=任意)。kind は "csm"/"user"/"freq"。key<=0 は無視。"""
    import csv
    out = []
    try:
        with open(MANUAL_KEYS_CSV, encoding="utf-8-sig", newline="") as f:
            for row in csv.reader(f):
                if not row or row[0].strip().startswith(("#", "csm")):
                    continue
                cells = [c.strip() for c in row]
                csm = cells[0] if len(cells) > 0 else ""
                freq = cells[1] if len(cells) > 1 else ""
                key = cells[2] if len(cells) > 2 else ""
                user = cells[3] if len(cells) > 3 else ""
                try:
                    k = int(key)
                except ValueError:
                    continue
                if k <= 0:
                    continue
                if csm:
                    out.append(("csm", csm, k))
                elif user:
                    try: out.append(("user", int(user), k))
                    except ValueError: pass
                elif freq:
                    try: out.append(("freq", int(freq), k))
                    except ValueError: pass
    except FileNotFoundError:
        pass
    except Exception:
        pass
    return out


def load_manual_keys_full():
    """(by_csm, by_freq, by_user) を返す(4列目 user 対応)。試聴ツールの鍵解決に使う。"""
    by_csm, by_freq, by_user = {}, {}, {}
    for kind, val, k in load_key_bindings():
        if kind == "csm":
            by_csm[val] = k
        elif kind == "user":
            by_user[val] = k
        elif kind == "freq":
            by_freq[val] = k
    return by_csm, by_freq, by_user


def set_key_binding(kind, value, key):
    """manual_keys.csv の紐づけを更新。kind: "csm"/"user"/"freq"。key<=0 で削除。
    コメント/ヘッダ/他種別の行は保持。行形式は csm,freq_hz,key,user。"""
    keep = []
    try:
        with open(MANUAL_KEYS_CSV, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        lines = ["csm,freq_hz,key,user"]
    for s in lines:
        t = s.strip()
        if t == "" or t.startswith("#") or t.lower().startswith("csm,"):
            keep.append(s); continue
        cells = [c.strip() for c in t.split(",")]
        rcsm = cells[0] if len(cells) > 0 else ""
        rfreq = cells[1] if len(cells) > 1 else ""
        ruser = cells[3] if len(cells) > 3 else ""
        if kind == "csm" and rcsm and rcsm == str(value):
            continue
        if kind == "user" and (not rcsm) and ruser == str(value):
            continue
        if kind == "freq" and (not rcsm) and (not ruser) and rfreq == str(value):
            continue
        keep.append(s)
    if key and key > 0:
        if kind == "csm":
            keep.append(f"{value},,{key}")
        elif kind == "user":
            keep.append(f",,{key},{value}")
        else:
            keep.append(f",{value},{key}")
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(MANUAL_KEYS_CSV, "w", encoding="utf-8") as f:
        f.write("\n".join(keep) + "\n")


# ---- CRCエラー音声の扱い(試聴を聞きやすくする) ----
# raw の各フレームは edu の F=1 行と順番どおり 1対1(プラグインは F=1 フレームだけ raw に書く)。
# edu の SACCH CRC で壊れフレームを、RICH の M で非音声(データ)枠を判別し、復号後 PCM を加工する。
SAMPLES_PER_BLOCK = 160                  # AMBE 1ブロック = 20ms @8kHz
SAMPLES_PER_FRAME = 4 * SAMPLES_PER_BLOCK
CRC_MODES = [                            # (設定値, 表示名)
    ("raw", "そのまま再生"),
    ("mute", "無音にする"),
    ("skip", "除去して詰める"),
    ("repeat", "直前の音でつなぐ"),
]
REPEAT_DECAY = 0.6                       # 補間を続けるごとに音量をこの倍率で下げる
REPEAT_MAX = 3                           # 連続この数を超えた壊れフレームは無音
EDGE_FADE = 32                           # 継ぎ目のクリック除けフェード(4ms)


def edu_frame_quality(raw_path, n_frames):
    """raw の各フレームの品質 [(crc_ok, [voice x4]) または None, ...] を edu から作る。
    edu が無い / edu の方が多い(対応が取れない)場合は None(加工しない)。
    edu が途中までしか無い(旧プラグインは 200 フレームで記録を打ち切っていた)場合は、
    記録のある先頭部分だけ品質を入れ、残りは None(不明=加工せずそのまま)で埋める。
    voice はプラグインと同じ規則: RICH parity OK のとき TCH1(ブロック0,1)は M∈{2,3}、
    TCH2(ブロック2,3)は M∈{1,3} が音声。parity NG なら判別できないので音声扱い。"""
    base = os.path.splitext(os.path.basename(raw_path))[0]
    ep = _edu_path(base)
    if not ep:
        return None
    q = []
    try:
        for line in open(ep, encoding="utf-8-sig"):
            line = line.strip()
            if not line:
                continue
            try:
                o = json.loads(line)
            except Exception:
                continue
            if o.get("type") == "header" or o.get("F") != 1:
                continue
            r = o.get("rich") or {}
            ok = bool((o.get("sacch") or {}).get("crcOK"))
            if r.get("parityOK"):
                m = r.get("M")
                v1, v2 = m in (2, 3), m in (1, 3)
            else:
                v1 = v2 = True
            q.append((ok, [v1, v1, v2, v2]))
    except Exception:
        return None
    if not q or len(q) > n_frames:
        return None
    return q + [None] * (n_frames - len(q))


def conceal_pcm(pcm, quality, mode):
    """CRCエラーフレームを mode に従って加工した PCM と (壊れ数, データ枠数) を返す。
    raw=加工なし / mute=無音 / skip=除去して詰める / repeat=直前の良フレームを減衰させて繰返し。
    mode が raw 以外なら、データ(非音声)枠は AMBE に通すとモガモガ音になるので無音にする。"""
    pcm = np.asarray(pcm, dtype=np.int16)
    if mode == "raw" or quality is None or len(pcm) != len(quality) * SAMPLES_PER_FRAME:
        return pcm, (None, None)
    segs = []          # (配列, 由来) 由来が変わる継ぎ目にフェードを掛ける
    last_good = None
    run = 0
    n_bad = n_data = 0
    for i, qi in enumerate(quality):
        # None = edu の記録が無い部分(途中で打ち切られた録音)。品質不明なので加工せず鳴らす。
        ok, voice = qi if qi is not None else (True, [True] * 4)
        fr = pcm[i * SAMPLES_PER_FRAME:(i + 1) * SAMPLES_PER_FRAME].astype(np.float64)
        for b, v in enumerate(voice):
            if not v:
                fr[b * SAMPLES_PER_BLOCK:(b + 1) * SAMPLES_PER_BLOCK] = 0.0
                n_data += 1
        if ok:
            run = 0
            last_good = fr
            segs.append((fr, ("good", i)))
            continue
        n_bad += 1
        run += 1
        if mode == "skip":
            continue
        if mode == "repeat" and last_good is not None and run <= REPEAT_MAX:
            segs.append((last_good * (REPEAT_DECAY ** run), ("rep", i)))
        else:
            segs.append((np.zeros(SAMPLES_PER_FRAME), ("mute", i)))
    if not segs:
        return np.zeros(0, dtype=np.int16), (n_bad, n_data)
    out = np.concatenate([s for s, _ in segs])
    # 連続していない継ぎ目(差し替え・詰めた箇所)だけ短くフェードアウト/インしてプチ音を消す
    ramp = np.linspace(0.0, 1.0, EDGE_FADE)
    pos = 0
    for k in range(1, len(segs)):
        pos += len(segs[k - 1][0])
        (pk, pi), (ck, ci) = segs[k - 1][1], segs[k][1]
        if pk == "good" and ck == "good" and ci == pi + 1:
            continue
        out[pos - EDGE_FADE:pos] *= ramp[::-1]
        out[pos:pos + EDGE_FADE] *= ramp
    return np.clip(out, -32768, 32767).astype(np.int16), (n_bad, n_data)


def normalize_gain(pcm, target_rms=4000.0, peak_limit=30000.0):
    """候補比較用の固定ゲイン(倍率)。無音・極小は 1.0。
    ブラインド比較の音量合わせに使い、再生中の追従調整とは分ける。"""
    a = np.asarray(pcm, dtype=np.float64)
    n = len(a) // 160
    if n == 0:
        return 1.0
    frames = a[:n * 160].reshape(n, 160)
    fr = np.sqrt((frames ** 2).mean(axis=1))
    mx = fr.max()
    if mx <= 1:
        return 1.0
    active = fr[fr > 0.2 * mx]
    speech_rms = float(active.mean()) if len(active) else float(mx)
    if speech_rms < 1:
        return 1.0
    gain = target_rms / speech_rms
    peak = float(np.max(np.abs(a)))
    if peak > 0 and peak * gain > peak_limit:
        gain = peak_limit / peak
    return gain


def normalize_speech(pcm, target_rms=4000.0, peak_limit=30000.0):
    """候補比較用の固定音量合わせ。無音を除いた発話部の RMS を target_rms に合わせ、
    ピークが peak_limit を超えないようゲインを抑える(クリップ防止)。
    録音ごとの「デカい/小さい」ばらつきを均す。原音の保存物には手を加えない。"""
    g = normalize_gain(pcm, target_rms, peak_limit)
    if g == 1.0:
        return np.asarray(pcm, dtype=np.int16)
    return np.clip(np.asarray(pcm, dtype=np.float64) * g, -32768, 32767).astype(np.int16)


class _ListeningVolume:
    """One render's selected volume mode; fixed mode preserves legacy streaming."""
    def __init__(self, rate, automatic, following, volume):
        self.automatic, self.volume, self.gain = automatic, volume, None
        self.follower = ListeningAgc(rate) if automatic and following else None

    def process(self, pcm):
        if self.follower:
            pcm = self.follower.process(pcm)
            gain = self.volume
        else:
            if self.automatic and self.gain is None:
                value = normalize_gain(pcm)
                self.gain = value if value != 1.0 else None
            gain = (self.gain or 1.0)*self.volume
        return (np.clip(pcm.astype(np.float64)*gain, -32768, 32767).astype(np.int16)
                if abs(gain-1.0) > 1e-3 else pcm)


def voiced_frac(pcm):
    a = np.asarray(pcm, dtype=np.float64)
    n = len(a) // 160
    if n == 0:
        return 0, 0.0
    rms = np.empty(n); zcr = np.empty(n)
    for i in range(n):
        f = a[i * 160:(i + 1) * 160]
        rms[i] = np.sqrt(np.mean(f * f))
        zcr[i] = np.count_nonzero(np.diff(np.signbit(f))) / 160
    mx = rms.max()
    if mx <= 0:
        return 0, 0.0
    act = rms > mx * 0.2
    na = int(act.sum())
    return na, (float(np.count_nonzero(act & (zcr < 0.18)) / na) if na else 0.0)


def build_all_blocks(frames):
    """録音の全バーストから 5バースト=1ブロックを非重複で作る(末尾詰め)。
    cracker 標準は末尾2ブロックのみだが、ここでは全区間をブロック化して証拠を増やす。
    返り値: [新しい→古い] の block 配列リスト(各 (FRAMES_PER_BLOCK, 49))。"""
    from core.secret.onnx_cracker import (
        _burst_payload_to_raw_bits, SECRET_BURST_BYTES_AMBE_2450, BURSTS_PER_BLOCK,
    )
    bp = build_burst_payload(frames)
    nb = len(bp) // SECRET_BURST_BYTES_AMBE_2450
    if nb < BURSTS_PER_BLOCK:
        return []
    raw = [_burst_payload_to_raw_bits(bp[i * SECRET_BURST_BYTES_AMBE_2450:(i + 1) * SECRET_BURST_BYTES_AMBE_2450])
           for i in range(nb)]
    blocks = []
    end = len(raw)
    while end >= BURSTS_PER_BLOCK:
        blocks.append(np.vstack(raw[end - BURSTS_PER_BLOCK:end]))
        end -= BURSTS_PER_BLOCK
    return blocks


def search_candidates(cracker, blocks, top_n=15, prune_blocks=2, max_blocks=None, force=False):
    raise RuntimeError("Privacy-key analysis is disabled in this distribution")


# 鍵候補の「声らしさ」検証(独自AMBE+2)。新しい方から SPEECH_CHECK_FRAMES フレーム(約5秒)を
# 候補の鍵で復号し、ピッチの連続性を測る。SPEECH_OK 以上を声らしいとみなす(秘話8録音で
# 正しい鍵 0.55..0.71、誤った鍵は最大 0.33)。比べたフレーム対が SPEECH_MIN_PAIRS 未満なら判定しない。
SPEECH_CHECK_FRAMES = 64
SPEECH_OK = 0.45
SPEECH_MIN_PAIRS = 10


def speech_likeness(frames, key):
    """frames を鍵 key で独自AMBE+2 復号したときの (声らしさ 0..1, 比べたフレーム対の数)。"""
    metas = []
    IndependentCodec().decode(frames[-SPEECH_CHECK_FRAMES:], key, metas)
    return pitch_continuity(metas)


def verify_candidates(frames, cands, progress=None):
    """search_candidates の候補 [(key, 一致率, score)] を独自AMBE+2 の声らしさで検証し、
    [(key, 一致率, score, 声らしさ or None)] を声らしさ順(同点・判定不能は ML の順)で返す。"""
    out = []
    for i, (key, conf, sc) in enumerate(cands):
        if progress:
            progress(i, len(cands))
        value, pairs = speech_likeness(frames, key)
        out.append((key, conf, sc, value if pairs >= SPEECH_MIN_PAIRS else None))
    return order_by_likeness(out)


def order_by_likeness(cands):
    """[(key, 一致率, score, 声らしさ or None)] を声らしさ順に(同点・判定不能は元の順)。"""
    order = sorted(range(len(cands)), key=lambda i: (-(cands[i][3] if cands[i][3] is not None else -1.0), i))
    return [cands[i] for i in order]


def _raw_frame_count(path):
    """全読込せずファイルサイズからフレーム数を見積もる(選抜用に高速)。読めなければ 0。"""
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            magic = f.read(8)
        hlen = (52 if magic == b"T98RAW03" else 48 if magic == b"T98RAW02"
                else 32 if magic == b"T98RAW01" else None)
        if hlen is None:
            return 0
        return max(0, (size - hlen) // 36)
    except Exception:
        return 0


def gather_pool_frames(csm, freq_hz, budget_frames):
    """② 同じ局(CSM)/周波数の録音を「新しい順」に budget_frames 到達まで束ねる。
    鍵は局ごとに固定なので全件は不要。件数が多くても読込・FEC を頭打ちにする。
    返り値 (frames, 使用ファイル数, 該当総ファイル数)。
    CSM があれば CSM 一致、無ければ周波数一致で集める。"""
    # 1) 該当ファイルをヘッダだけで高速抽出(全読込しない)。日付サブフォルダも再帰で拾う。
    matching = []
    for p in _list_files(RAW_DIR, ".t98raw"):
        f, c = read_header(p)
        if f is None:
            continue
        if csm:
            if (c or "") != csm:
                continue
        elif f != freq_hz:
            continue
        matching.append(p)
    # 2) 新しい順(ファイル名=時刻)に、予算フレーム数に達するまで選ぶ。
    matching.sort(reverse=True)
    selected, acc = [], 0
    for p in matching:
        selected.append(p)
        acc += _raw_frame_count(p)
        if acc >= budget_frames:
            break
    # 3) 連結は時系列(古→新)。build_all_blocks は末尾=最新から採点するため。
    selected.sort()
    frames, used = [], 0
    for p in selected:
        try:
            f, fr, c, _sec = read_raw(p)
        except Exception:
            continue
        frames += fr; used += 1
    return frames, used, len(matching)


def _stat_band(freq):
    f = int(freq)
    if 351_000_000 <= f < 352_000_000:
        return "登録局351"
    if 467_000_000 <= f < 468_000_000:
        return "免許局467"
    if 154_000_000 <= f < 155_000_000:
        return "免許局154"
    return "その他"


def _secret_code(state):
    # 秘話ステート文字列 → JS側と共有する短いコード。
    return {"Off": "Off", "SuspectedOn": "SuspectedOn", "KeyMismatch": "KeyMismatch",
            "KeyApplied": "KeyApplied"}.get(state, "Unknown")


def compute_stats():
    """統計ダッシュボード用の「生データ」を返す。集計はブラウザ側で行い、日時範囲で
    対話的に絞り込めるようにするため、ここでは交信(sessions)と edu(CRC用)を素のまま渡す。
      sessions: [t_epoch, dur_s, freq_hz, csm, secret_state, user_code(-1=無)]
      edu:      [t_epoch, freq_hz, total_frames, sacch_crc_ok]   (CRCは日時でも絞れる)
    ch/帯/公式ch名は freq から JS で導出する(channel_label 相当を JS に移植)。"""
    import glob
    rows = []
    with open(RX_LOG_CSV, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            rows.append(r)

    def pt(s):
        try:
            return datetime.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
        except Exception:
            return None

    sessions = []
    for r in rows:
        st = pt(r.get("start", ""))
        if not st:
            continue
        try:
            dur = round(float(r.get("duration_s") or 0), 1)
        except ValueError:
            dur = 0.0
        try:
            fr = int(r["freq_hz"])
        except (KeyError, ValueError):
            continue
        try:
            uc = int(r["user_code"]) if r.get("user_code", "").strip() != "" else -1
        except ValueError:
            uc = -1
        sessions.append([int(st.timestamp()), dur, fr, r.get("csm", "").strip(),
                         _secret_code(r.get("secret_state", "Unknown") or "Unknown"), uc])
    if not sessions:
        raise ValueError("rx_log.csv に有効な行がありません")

    edu = []
    for p in _list_files(EDU_DIR, ".jsonl"):
        base = os.path.basename(p)
        try:
            ts = datetime.datetime.strptime(base[:15], "%Y%m%d_%H%M%S")
        except ValueError:
            continue
        tot = ok = 0
        freq = 0
        try:
            for line in open(p, encoding="utf-8-sig"):
                line = line.strip()
                if not line:
                    continue
                try:
                    o = json.loads(line)
                except Exception:
                    continue
                if o.get("type") == "header":
                    freq = o.get("freq_hz", 0); continue
                tot += 1
                if (o.get("sacch") or {}).get("crcOK"):
                    ok += 1
        except Exception:
            continue
        if tot > 0 and freq:
            edu.append([int(ts.timestamp()), int(freq), tot, ok])

    tsall = [s[0] for s in sessions]
    meta = dict(
        generated=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        span_start_ts=min(tsall), span_end_ts=max(tsall),
        n_sessions=len(sessions), n_edu=len(edu),
        user_alias={str(k): v for k, v in load_user_alias().items()},   # UC表示に別名を併記
    )
    return dict(meta=meta, sessions=sessions, edu=edu)


def render_dashboard(stats, chartjs_src, out_path):
    """テンプレートに統計JSONと Chart.js の参照先を差し込んで HTML を書き出す。"""
    with open(STATS_TPL, encoding="utf-8") as f:
        tpl = f.read()
    html = (tpl.replace("__STATS_JSON__", json.dumps(stats, ensure_ascii=False, default=str))
               .replace("__CHARTJS__", chartjs_src))
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    return out_path


def set_manual_key(csm, freq_hz, key):
    """manual_keys.csv を更新: 同じ csm(あれば) / freq の既存データ行を置き換えて追記。
    コメント/ヘッダ行は保持。csm があれば 'csm,,key'、無ければ ',freq,key'。"""
    keep = []
    try:
        with open(MANUAL_KEYS_CSV, encoding="utf-8-sig") as f:
            for line in f:
                s = line.rstrip("\n")
                t = s.strip()
                if t == "" or t.startswith("#") or t.lower().startswith("csm,"):
                    keep.append(s); continue
                cells = [c.strip() for c in t.split(",")]
                rcsm = cells[0] if len(cells) > 0 else ""
                rfreq = cells[1] if len(cells) > 1 else ""
                # 置換対象(同じ局 or 同じ周波数)は捨てる
                if csm and rcsm == csm:
                    continue
                if (not csm) and rfreq == str(freq_hz):
                    continue
                keep.append(s)
    except FileNotFoundError:
        keep = ["csm,freq_hz,key"]
    row = f"{csm},,{key}" if csm else f",{freq_hz},{key}"
    keep.append(row)
    with open(MANUAL_KEYS_CSV, "w", encoding="utf-8") as f:
        f.write("\n".join(keep) + "\n")


class SeekPlayer:
    """sounddevice によるシーク可能な再生(int16 モノラル・任意レート)。
    sounddevice が無ければ available=False。呼び出し側は winsound にフォールバックする。"""

    def __init__(self):
        self._sd = None
        self.available = False
        try:
            import sounddevice as sd
            self._sd = sd
            self.available = True
        except Exception:
            pass
        self._lock = threading.Lock()
        self._pcm = np.zeros(0, dtype=np.int16)
        self._rate = 8000
        self._pos = 0
        self._filled = 0            # ストリーミングで実際に書き込み済みのサンプル数
        self._total = 0             # 予定総サンプル数(0=非ストリーミング=len(_pcm))
        self._streaming = False     # まだ復号途中(末尾で止めずに無音待機する)
        self._stream = None
        self._playing = False
        self._finished = False      # 末尾まで再生してコールバックが停止した(再開は作り直す)
        self._volume = 1.0          # 手動音量は出力時に適用(PCM/再生位置を変更しない)
        self._stream_token = 0      # 切替後の古いワーカーからの追記を拒否する

    def set_volume(self, volume):
        with self._lock:
            self._volume = max(0.0, min(2.0, float(volume)))

    def _avail(self):
        return self._filled if self._total else len(self._pcm)

    def _length(self):
        return self._total if self._total else len(self._pcm)

    def _callback(self, outdata, frames, time_info, status):
        with self._lock:
            avail = self._avail()
            end = min(self._pos + frames, avail)
            chunk = self._pcm[self._pos:end]
            self._pos = end
            at_end = self._pos >= self._length()
            streaming = self._streaming
            volume = self._volume
        n = len(chunk)
        if volume == 1.0:
            outdata[:n, 0] = chunk
        else:
            outdata[:n, 0] = np.clip(chunk.astype(np.float32) * volume, -32768, 32767)
        if n < frames:
            outdata[n:, 0] = 0
            # 末尾に到達: ストリーミング中は止めず無音で待つ(復号が追いつくのを待機)。
            if at_end and not streaming:
                self._playing = False
                self._finished = True   # このストリームは終了。次の再生は作り直す。
                raise self._sd.CallbackStop()

    def load(self, pcm, rate):
        self.stop()
        with self._lock:
            self._pcm = np.asarray(pcm, dtype=np.int16)
            self._rate = int(rate)
            self._pos = 0
            self._total = 0; self._filled = len(self._pcm); self._streaming = False
            self._finished = False

    # ---- プログレッシブ(逐次追記)再生 ----
    def start_stream(self, rate, total_len, pcm=None):
        self.stop()
        with self._lock:
            self._rate = int(rate)
            self._pcm = pcm if pcm is not None else np.zeros(int(total_len), dtype=np.int16)
            self._total = int(total_len)
            self._filled = 0
            self._pos = 0
            self._streaming = True
            self._finished = False
            return self._stream_token

    def append(self, pcm, token=None):
        pcm = np.asarray(pcm, dtype=np.int16)
        with self._lock:
            if token is not None and token != self._stream_token:
                return
            end = min(self._filled + len(pcm), self._total)
            self._pcm[self._filled:end] = pcm[:end - self._filled]
            self._filled = end

    def finish_stream(self, token=None):
        with self._lock:
            if token is not None and token != self._stream_token:
                return
            self._streaming = False
            if self._total and self._filled < self._total:
                self._total = self._filled   # 予定より短かった場合は詰める

    def _ensure_stream(self):
        if self._stream is not None and int(self._stream.samplerate) != self._rate:
            try: self._stream.close()
            except Exception: pass
            self._stream = None
        if self._stream is None:
            self._stream = self._sd.OutputStream(
                samplerate=self._rate, channels=1, dtype="int16", callback=self._callback)

    def play(self, restart=True):
        if not self.available or self._length() == 0:
            return
        with self._lock:
            if restart or self._pos >= self._length():
                self._pos = 0
        # 末尾まで鳴らして停止したストリームは start() で再開しないので作り直す。
        if self._finished:
            try:
                if self._stream is not None: self._stream.close()
            except Exception: pass
            self._stream = None
            self._finished = False
        try:
            self._ensure_stream()
            self._stream.start()
            self._playing = True
        except Exception:
            # 直前に終端で止まったストリームは start に失敗しうる。作り直して再試行。
            try:
                if self._stream is not None: self._stream.close()
            except Exception: pass
            self._stream = None
            try:
                self._ensure_stream()
                self._stream.start()
                self._playing = True
            except Exception:
                self._playing = False

    def pause(self):
        self._playing = False
        try:
            if self._stream is not None: self._stream.stop()
        except Exception: pass

    def toggle(self):
        if self._playing: self.pause()
        else: self.play(restart=False)

    def stop(self):
        self._playing = False
        self._finished = False
        try:
            if self._stream is not None: self._stream.stop()
        except Exception: pass
        with self._lock:
            self._stream_token += 1
            self._pos = 0

    def seek_frac(self, frac):
        with self._lock:
            L = self._length()
            if L:
                # 復号済みの範囲まで(ストリーミング中は _avail まで)にクランプ。
                target = int(max(0.0, min(1.0, frac)) * L)
                self._pos = min(target, max(0, self._avail() - 1))

    def position_frac(self):
        with self._lock:
            L = self._length()
            return (self._pos / L) if L else 0.0

    def position_sec(self):
        with self._lock:
            return self._pos / self._rate if self._rate else 0.0

    def duration(self):
        with self._lock:
            return self._length() / self._rate if self._rate else 0.0

    @property
    def playing(self):
        return self._playing

    def close(self):
        try:
            if self._stream is not None: self._stream.close()
        except Exception: pass
        self._stream = None


try:   # GUI と同じ公式チャンネル名(3R CH13 など)。単体配布で core が無い場合は ch 番号表示。
    from core.rf.channel_plan import PLAN_BY_FREQUENCY, call_stat_verified
except Exception:
    PLAN_BY_FREQUENCY = {}
    def call_stat_verified(_freq):
        return True

_NAME_FREQ = re.compile(r"_ch\d+_(\d{6,10})_")


def recording_row(path, duration):
    """一覧の即時表示用の列値。日時・ch・周波数はファイル名から(ヘッダを読まずに済む)。
    局/UC/秘話/CRC は背景処理で埋める。"""
    b = os.path.basename(path)
    if len(b) >= 15 and b[:8].isdigit() and b[8] == "_" and b[9:15].isdigit():
        when = f"{b[4:6]}/{b[6:8]} {b[9:11]}:{b[11:13]}:{b[13:15]}"
    else:
        when = os.path.splitext(b)[0][:16]
    m = _NAME_FREQ.search(b)
    freq = int(m.group(1)) if m else None
    return (when, frequency_label(freq) if freq else "", f"{freq / 1e6:.5f}" if freq else "",
            f"{duration:.1f}s" if duration is not None else "?", "", "", "", "")


# 並べ替え: すぐ求まる列(ファイル名/サイズ)は即時、edu/ヘッダが要る列は背景で計算。
QUICK_SORT_COLUMNS = {"time", "ch", "freq", "dur"}
# 初回クリック時の向き(True=降順)。新しい/長い/良好を上に。
DEFAULT_DESCENDING = {"time": True, "dur": True, "crc": True}


def name_frequency(path):
    m = _NAME_FREQ.search(os.path.basename(path))
    return int(m.group(1)) if m else None


def channel_sort_key(freq):
    """ch 列の順序: グループ→ch番号(3R CH01..30, 3S, 3T, 3U)。プラン外は周波数で末尾へ。"""
    info = PLAN_BY_FREQUENCY.get(int(freq))
    return (0, info.group, info.channel_number) if info is not None else (1, "", int(freq))


def sort_files(files, key_of, descending):
    """key_of(path) の値で並べ替え。None(不明)は向きに関係なく末尾。
    同値は新しい順(ファイル名=時刻の降順)を保つ(安定ソート)。"""
    newest = sorted(files, key=os.path.basename, reverse=True)
    keyed = [(key_of(path), path) for path in newest]
    known = [item for item in keyed if item[0] is not None]
    unknown = [path for k, path in keyed if k is None]
    known.sort(key=lambda item: item[0], reverse=descending)
    return [path for _k, path in known] + unknown


def frequency_label(freq):
    info = PLAN_BY_FREQUENCY.get(int(freq))
    return info.label if info is not None else channel_label(freq)


class RecordingTable(ttk.Frame):
    """録音一覧(列表示)。KeyTool の既存コードがそのまま使えるよう Listbox 互換の
    メソッド(curselection / selection_set / nearest / itemconfig ...)を持つ。
    行の iid は表示順の番号(= KeyTool.files の添字)。"""

    # (列, 見出し, 幅の目安になる最長クラスの値, 寄せ)。幅はフォント実測で決める
    # (Windows の表示倍率でフォントが大きくなっても欠けない)。
    COLUMNS = (("time", "日時", "10/02 00:49:14", "w"), ("ch", "ch", "3R CH30", "w"),
               ("freq", "周波数", "351.20000", "e"), ("dur", "長さ", "15.3s", "e"),
               ("csm", "局 (CSM)", "あいうえお (200446991)", "w"), ("uc", "UC", "0(一斉)", "w"),
               ("secret", "秘話", "秘話", "center"), ("crc", "CRC", "100%", "e"))
    KEYS = [c[0] for c in COLUMNS]

    def __init__(self, master, on_sort=None):
        super().__init__(master)
        self._on_sort = on_sort
        body, heading = tkfont.nametofont("TkDefaultFont"), tkfont.nametofont("TkHeadingFont")
        style = ttk.Style(self)
        style.configure("Recordings.Treeview", rowheight=body.metrics("linespace") + 6)
        self.tree = ttk.Treeview(self, columns=self.KEYS, show="headings", selectmode="extended",
                                 style="Recordings.Treeview")
        pad = body.measure("00")
        for key, title, sample, anchor in self.COLUMNS:
            width = max(body.measure(sample), heading.measure(title + " ▼*")) + pad
            self.tree.heading(key, text=title, anchor=anchor,
                              command=lambda k=key: self._on_sort and self._on_sort(k))
            self.tree.column(key, width=width, minwidth=heading.measure(title) + pad // 2,
                             anchor=anchor, stretch=key == "csm")
        self.scrollbar_width = 18
        vsb = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.tree.yview)
        self.hscroll = ttk.Scrollbar(self, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=self.hscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        self.hscroll.grid(row=1, column=0, sticky="ew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self._colors = set()
        self._programmatic = None   # 直前のプログラム選択(Listbox 同様、選択イベントを出さない)

    # --- Listbox 互換 API ---------------------------------------------------
    def bind(self, sequence=None, func=None, add=None):
        if sequence == "<<ListboxSelect>>":
            def on_select(event, func=func):
                if self._programmatic is not None and self.tree.selection() == self._programmatic:
                    self._programmatic = None
                    return None
                self._programmatic = None
                return func(event)
            return self.tree.bind("<<TreeviewSelect>>", on_select, add)
        return self.tree.bind(sequence, func, add)

    def focus_set(self):
        self.tree.focus_set()

    def size(self):
        return len(self.tree.get_children())

    def _last(self, value):
        return self.size() - 1 if value in (tk.END, "end") else int(value)

    def curselection(self):
        return tuple(sorted(int(iid) for iid in self.tree.selection()))

    def selection_set(self, first, last=None):
        last = first if last is None else last
        items = [str(i) for i in range(self._last(first), self._last(last) + 1)]
        if items:
            self.tree.selection_add(items)
            self._programmatic = self.tree.selection()

    def selection_clear(self, first=0, last=None):
        if self.tree.selection():
            self.tree.selection_remove(self.tree.selection())
            self._programmatic = self.tree.selection()

    def activate(self, index):
        if 0 <= index < self.size():
            self.tree.focus(str(index))

    def index(self, what):
        if what in (tk.ACTIVE, "active"):
            focus = self.tree.focus()
            return int(focus) if focus else -1
        return self._last(what)

    def nearest(self, y):
        iid = self.tree.identify_row(y)
        return int(iid) if iid else -1

    def see(self, index):
        if 0 <= index < self.size():
            self.tree.see(str(index))

    def delete(self, first=0, last=None):
        self.tree.delete(*self.tree.get_children())

    def insert(self, _index, *rows):
        start = self.size()
        for offset, values in enumerate(rows):
            self.tree.insert("", tk.END, iid=str(start + offset), values=values)

    def itemconfig(self, index, foreground=None, **_kw):
        if foreground:
            self._color_tag(foreground)
            self.tree.item(str(index), tags=(foreground,))

    # --- 列表示 -------------------------------------------------------------
    def _color_tag(self, color):
        if color not in self._colors:
            self.tree.tag_configure(color, foreground=color)
            self._colors.add(color)

    def set_sort_indicator(self, column, descending):
        self._sort_state = (column, descending)
        self._render_headings()

    def set_filtered_columns(self, columns):
        """絞り込み中の列の見出しに * を付ける。"""
        self._filtered = set(columns)
        self._render_headings()

    def _render_headings(self):
        column, descending = getattr(self, "_sort_state", (None, False))
        filtered = getattr(self, "_filtered", set())
        for key, title, _sample, _anchor in self.COLUMNS:
            mark = (" ▼" if descending else " ▲") if key == column else ""
            self.tree.heading(key, text=title + mark + ("*" if key in filtered else ""))

    def heading_at(self, x, y):
        """(x, y) が列見出しなら列キー、それ以外は None。"""
        if self.tree.identify_region(x, y) != "heading":
            return None
        column = self.tree.identify_column(x)          # "#1".."#8"
        try:
            return self.KEYS[int(column.lstrip("#")) - 1]
        except (ValueError, IndexError):
            return None

    def selected_paths(self, files):
        return [files[i] for i in self.curselection() if i < len(files)]

    def natural_width(self):
        """全列が欠けずに見える幅(初回の仕切り位置に使う)。"""
        return sum(int(self.tree.column(key, "width")) for key in self.KEYS) + self.scrollbar_width + 8

    def update_row(self, index, color=None, **values):
        iid = str(index)
        if not self.tree.exists(iid):
            return
        for key, value in values.items():
            self.tree.set(iid, key, value)
        if color:
            self.itemconfig(index, foreground=color)


class CandidateTable(ttk.Frame):
    """Numeric candidate rows; the key is data, never parsed from a label."""

    COLUMNS = (("key", "キー", 70), ("match", "一致率", 76),
               ("score", "スコア", 80), ("speech", "声らしさ", 80),
               ("state", "検証", 94))

    def __init__(self, master):
        super().__init__(master)
        self.rows = {}
        self.sort_state = None
        self.tree = ttk.Treeview(self, columns=[c[0] for c in self.COLUMNS],
                                 show="headings", selectmode="browse", height=6)
        font = tkfont.nametofont("TkDefaultFont")
        ttk.Style(self).configure("Candidates.Treeview", rowheight=font.metrics("linespace") + 6)
        self.tree.configure(style="Candidates.Treeview")
        for name, title, width in self.COLUMNS:
            self.tree.heading(name, text=title, command=lambda col=name: self.sort(col))
            self.tree.column(name, width=max(width, font.measure(title) + 22),
                             minwidth=font.measure(title) + 16,
                             anchor="w" if name == "state" else "e", stretch=True)
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

    def bind(self, sequence=None, func=None, add=None):
        return self.tree.bind(sequence, func, add)

    def delete(self, *_args):
        self.tree.delete(*self.tree.get_children())
        self.rows.clear()

    def selected_key(self):
        selected = self.tree.selection()
        return int(selected[0]) if selected else None

    def show(self, candidates, checked=False, pending=False):
        selected = self.selected_key()
        self.delete()
        for key, match, score, speech in candidates:
            state = ("声らしい" if speech is not None and speech >= SPEECH_OK else "低い") if speech is not None else (
                "検証中" if checked and pending else "未判定")
            self.rows[str(key)] = (key, match, score, speech, state)
            self.tree.insert("", tk.END, iid=str(key), values=(
                key, f"{match * 100:.0f}%", f"{score:+.2f}",
                f"{speech:.2f}" if speech is not None else "—", state))
        if self.sort_state:
            self._sort_rows()
        if selected is not None and str(selected) in self.rows:
            self.tree.selection_set(str(selected))
            self.tree.focus(str(selected))
            self.tree.see(str(selected))

    def sort(self, column):
        current, descending = self.sort_state or (None, False)
        self.sort_state = (column, not descending if column == current else column != "key")
        self._sort_rows()

    def _sort_rows(self):
        column, descending = self.sort_state
        index = [c[0] for c in self.COLUMNS].index(column)
        known = [iid for iid, row in self.rows.items() if row[index] is not None]
        unknown = [iid for iid, row in self.rows.items() if row[index] is None]
        ordered = sorted(known, key=lambda iid: self.rows[iid][index], reverse=descending) + unknown
        for position, iid in enumerate(ordered):
            self.tree.move(iid, "", position)
        for name, title, _width in self.COLUMNS:
            mark = (" ▼" if descending else " ▲") if name == column else ""
            self.tree.heading(name, text=title + mark)


class ScrollablePanel(ttk.Frame):
    """Provide overflow for long recording labels and enlarged system fonts."""

    def __init__(self, master):
        super().__init__(master)
        self._resizing = False
        self.canvas = tk.Canvas(self, borderwidth=0, highlightthickness=0,
                                bg=_ui_color("SystemButtonFace", "#f0f0f0"), width=1, height=1)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.content = ttk.Frame(self.canvas, padding=(8, 0, 4, 0))
        self.window = self.canvas.create_window(0, 0, anchor="nw", window=self.content)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.canvas.bind("<Configure>", self._resize)
        self.content.bind("<Configure>", self._resize)

    def enable_wheel(self):
        # A local bind tag avoids global mouse-wheel handlers and leaves tables,
        # text and numeric controls to handle their own wheel input.
        tag = "KeyToolWheel:" + str(self)
        self._wheel_tag = tag
        self._wheel_binding = self.bind_class(tag, "<MouseWheel>", self._wheel)
        def attach(widget):
            if widget.winfo_class() in ("Canvas", "TFrame", "TLabel", "TLabelframe", "TButton", "TCheckbutton", "TRadiobutton"):
                widget.bindtags((tag,) + widget.bindtags())
            for child in widget.winfo_children():
                attach(child)
        attach(self.content)
        self.canvas.bind("<MouseWheel>", self._wheel)

    def destroy(self):
        if hasattr(self, "_wheel_binding"):
            self.unbind_class(self._wheel_tag, "<MouseWheel>")
            self.tk.deletecommand(self._wheel_binding)
        super().destroy()

    def _wheel(self, event):
        if self.canvas.yview() == (0.0, 1.0):
            return None
        self.canvas.yview_scroll(-int(event.delta / 120), "units")
        return "break"

    def _resize(self, _event=None):
        if self._resizing:
            return
        self._resizing = True
        try:
            width, height = self.canvas.winfo_width(), self.canvas.winfo_height()
            if width <= 1 or height <= 1:
                return
            self.canvas.itemconfigure(self.window, width=width)
            # Settle nested grid/pack requests before calculating overflow.
            # A fixed canvas window can otherwise hide a child's new size.
            self.content.update_idletasks()
            needed = self.content.winfo_reqheight()
            self.canvas.itemconfigure(self.window, height=max(height, needed))
            self.canvas.configure(scrollregion=(0, 0, width, max(height, needed)))
            if needed > height:
                self.scrollbar.grid()
            else:
                self.canvas.yview_moveto(0)
                self.scrollbar.grid_remove()
        finally:
            self._resizing = False


def binomial_tail(k, n):
    """P(X >= k) for X ~ Binomial(n, 1/2): chance of choosing "on" k+ times by luck."""
    from math import comb
    return sum(comb(n, i) for i in range(k, n + 1)) / 2 ** n


class BlindCompare(tk.Toplevel):
    """Blind A/B test of one live option on the current recording.

    Each trial plays the option on and off as A/B in random order; the listener
    picks the better one. Both versions are loudness-matched, so a louder
    version cannot win by volume alone. At the end the count of trials where
    "on" was chosen is tested against chance (one-sided binomial).
    """

    def __init__(self, tool):
        super().__init__(tool)
        self.tool = tool
        self.title("ブラインド比較")
        self.resizable(False, False)
        self.versions = None      # {"on": pcm48, "off": pcm48}
        self.order = []           # per trial: label of A ("on"/"off")
        self.choices = []         # per trial: True if "on" was chosen
        top = tk.Frame(self); top.pack(fill=tk.X, padx=10, pady=8)
        tk.Label(top, text="比べるオプション").pack(side=tk.LEFT)
        self.optvar = tk.StringVar(value=LIVE_OPTIONS[0][1])
        ttk.Combobox(top, textvariable=self.optvar, state="readonly", width=14,
                     values=[label for _n, label in LIVE_OPTIONS]).pack(side=tk.LEFT, padx=4)
        tk.Label(top, text="回数").pack(side=tk.LEFT, padx=(10, 0))
        self.nvar = tk.IntVar(value=10)
        tk.Spinbox(top, from_=4, to=30, width=4, textvariable=self.nvar).pack(side=tk.LEFT, padx=4)
        self.startbtn = tk.Button(top, text="開始", command=self._start)
        self.startbtn.pack(side=tk.LEFT, padx=8)
        tk.Label(self, text="他のオプションはメイン画面のチェックのまま。A/B はどちらがオンか伏せてあります。\n"
                            "音量は A/B でそろえてあります。良いと思う方を選んでください。",
                 fg="gray", justify=tk.LEFT).pack(anchor="w", padx=10)
        self.progress = tk.Label(self, text="", font=("", 11, "bold")); self.progress.pack(pady=6)
        row = tk.Frame(self); row.pack(pady=4)
        self.buttons = [
            tk.Button(row, text="▶ A を再生", width=12, command=lambda: self._play("A")),
            tk.Button(row, text="▶ B を再生", width=12, command=lambda: self._play("B")),
            tk.Button(row, text="A が良い", width=12, command=lambda: self._choose("A")),
            tk.Button(row, text="B が良い", width=12, command=lambda: self._choose("B")),
        ]
        for i, button in enumerate(self.buttons):
            button.grid(row=i // 2, column=i % 2, padx=4, pady=3)
            button.config(state=tk.DISABLED)
        self.result = tk.Label(self, text="", justify=tk.LEFT, wraplength=420)
        self.result.pack(padx=10, pady=8, anchor="w")

    def _option(self):
        label = self.optvar.get()
        return next(name for name, lab in LIVE_OPTIONS if lab == label)

    def _start(self):
        tool = self.tool
        if not tool.frames:
            self.result.config(text="先に録音を選んでください。")
            return
        name, n = self._option(), max(4, min(30, int(self.nvar.get())))
        key = tool._listen_key()
        base = tool._live_options()
        rows = tool._current_edu_rows()
        frames, secret = tool.frames, tool.secret
        self.startbtn.config(state=tk.DISABLED)
        self.result.config(text="作成中...")

        def work():
            try:
                versions = {state: live_render(frames, rows, key, {**base, name: state == "on"}, secret)[1]
                            for state in ("on", "off")}
            except Exception as exc:
                self.after(0, lambda e=exc: self._fail(f"作成に失敗しました: {e}"))
                return
            self.after(0, lambda: self._ready(versions, n))

        threading.Thread(target=work, daemon=True).start()

    def _fail(self, text):
        self.startbtn.config(state=tk.NORMAL)
        self.result.config(text=text)

    def _ready(self, versions, n):
        if len(versions["on"]) == len(versions["off"]) and np.array_equal(versions["on"], versions["off"]):
            label = self.optvar.get()
            self._fail(f"この録音では「{label}」をオン/オフしても音が変わりません。\n"
                       "（軟判定・取りこぼし再生は 2026-10-04 夜以降の録音のみ。秘話の誤り補間は鍵が要ります）")
            return
        # Same loudness for both, so the choice is not won by volume.
        self.versions = {state: normalize_speech(pcm) for state, pcm in versions.items()}
        import random
        self.order = [random.choice(("on", "off")) for _ in range(n)]
        self.choices = []
        for button in self.buttons:
            button.config(state=tk.NORMAL)
        self.result.config(text="")
        self._show()

    def _show(self):
        self.progress.config(text=f"{len(self.choices) + 1} / {len(self.order)} 回目")

    def _state(self, ab):
        a = self.order[len(self.choices)]
        return a if ab == "A" else ("off" if a == "on" else "on")

    def _play(self, ab):
        if self.versions and len(self.choices) < len(self.order):
            self.tool._play_plain(self.versions[self._state(ab)], LIVE_RATE)

    def _choose(self, ab):
        if not self.versions or len(self.choices) >= len(self.order):
            return
        self.choices.append(self._state(ab) == "on")
        if len(self.choices) < len(self.order):
            self._show()
            return
        for button in self.buttons:
            button.config(state=tk.DISABLED)
        self.startbtn.config(state=tk.NORMAL)
        k, n = sum(self.choices), len(self.choices)
        p_on, p_off = binomial_tail(k, n), binomial_tail(n - k, n)
        if p_on < 0.05:
            verdict = "オンの方が良いと、偶然ではなく聞き分けられています。"
        elif p_off < 0.05:
            verdict = "オフの方が良いと、偶然ではなく聞き分けられています。"
        else:
            verdict = "偶然と区別できる差は出ていません（差が小さい／好みが分かれる／回数不足）。"
        self.progress.config(text="結果")
        self.result.config(text=f"「{self.optvar.get()}」: オンを選んだのは {k}/{n} 回\n"
                                f"偶然でこれ以上オンを選ぶ確率 p = {p_on:.3f}\n{verdict}")


class KeyTool(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("STD-T98 秘話キー 試聴ツール（キー解析無効版）")
        self._cfg = load_config()
        self.geometry(self._initial_geometry(self._cfg))
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.frames = None
        self.freq = 0
        self.csm = ""
        self.secret = None           # v03 ヘッダの秘話フラグ (True/False/None=不明)
        self.alias = load_csm_alias()
        self.user_alias = load_user_alias()
        self.makers = load_maker_codes()
        self.cracker = None          # lazy
        self._play = None            # SeekPlayer(lazy)。sounddevice が要る
        self._sd_tried = False       # sounddevice 自動インストールを試みたか
        self._play_pcm = None        # いま再生バーに載っている音(音量等適用後 int16)
        self._play_rate = 8000       # その音のサンプルレート
        self._play_src = None        # 再生バーの音がどの録音ファイル由来か(クリック再生判定用)
        self._spec_img = None        # スペクトログラム PhotoImage の保持(GC防止)
        self._edu_cache = {}         # edu解析キャッシュ: edu_path -> (mtime, summary)
        self._dur_cache = {}         # 録音長キャッシュ: raw_path -> 秒(rawは追記されないので不変)
        self._color_gen = 0          # 一覧の色付け背景処理の世代(更新でキャンセル)
        self._cur_pcm = None         # 直近に再生した音(CRC処理後。スライダ再生/AI強調用にキャッシュ)
        self._cur_raw_pcm = None     # 直近に復号した原音(CRC処理前。処理方法の切替時に使う)
        self._cur_quality = None     # 直近の原音に対応するフレーム品質(edu 由来)
        # 一覧フィルタ: field -> (mode, set(values))。mode は "inc"(含む)/"exc"(含まない)。
        # field: "freq"(Hz) / "csm"(str) / "user"(int) / "maker"(int) / "secret"(True/False/None)。
        # 各 field は AND で結合。未設定の field は制約なし。
        # 前回終了時のフィルタを復元(次回起動時に読み込む)。
        self._filters, self._dur_filter = deserialize_filters(self._cfg)
        # 日付は前回の値を引き継がず、起動時は今日の録音から表示する。
        self._filters["date"] = ("inc", {datetime.date.today().strftime("%Y%m%d")})
        # 日時範囲フィルタ: None / (from_key, to_key)。各 key は "YYYYMMDDHHMMSS"(14桁)or None。
        tf = self._cfg.get("time_range")
        self._time_filter = tuple(tf) if isinstance(tf, list) and len(tf) == 2 else None
        self._decode_gen = 0         # 背景復号の世代(連打・切替時に古い結果を捨てる)
        self._render_pending = False
        self._file_gen = 0          # 非同期ファイル読込の世代
        self._loading_path = None
        self._load_autoplay = False
        self._load_play_request = None
        self._spec_gen = 0          # 古いスペクトログラムの表示を拒否する
        self._spec_lock = threading.Lock()
        self._hdr_cache = {}         # ヘッダ(freq,csm)キャッシュ: raw_path -> (freq, csm)
        self._sec_cache = {}         # 秘話フラグキャッシュ: raw_path -> True/False/None
        self._edu_path_cache = {}    # edu パス解決キャッシュ: base -> ep(None可)
        self._list_gen = 0           # 一覧の絞り込みスキャン世代(変更で古いスキャンを中断)
        self._sort_gen = 0           # 背景並べ替えの世代(新しい並べ替え・再表示で古い結果を捨てる)
        self._search_gen = 0
        self._search_busy = False
        self._search_lock = threading.Lock()
        saved_sort = self._cfg.get("sort")
        self._sort = ((saved_sort[0], bool(saved_sort[1]))
                      if isinstance(saved_sort, list) and len(saved_sort) == 2 and saved_sort[0] in RecordingTable.KEYS
                      else ("time", True))
        self.files = []              # 一覧に表示中の raw パス(背景スキャン完了まで空)
        self._cur_key = 0            # 直前に再生した音の鍵(0=平文)
        self._vf = None              # VoiceFixer(起動時に裏で事前ロード。無ければ初回強調時)
        self._vf_lock = threading.Lock()   # VoiceFixer 構築の排他(事前ロードと強調の競合防止)
        self._enh_cache = {}         # AI強調結果: (path, key, crcmode) -> 出力wav。再強調を即再生
        self._tmp = os.path.join(tempfile.gettempdir(), f"std98_keytool_preview_{os.getpid()}.wav")

        # ワーカースレッド→UI はキュー経由(Tkinter は他スレッドからの直接操作が不安定)。
        import queue
        self._ui_queue = queue.Queue()
        self._build()
        self._refresh_files()
        self.after(UI_POLL_MS, self._drain_ui)
        self.after(200, self._playhead_tick)   # 再生位置(赤線)と時間表示の更新ループ
        # スペクトログラム用の重いライブラリ(matplotlib 等)を裏で先読みし、初回再生の
        # もたつき(約1秒)を無くす。閲覧中に済ませておく。
        threading.Thread(target=self._prewarm, daemon=True).start()
        # 起動時の事前ロードは設定で切替。オフでも初回のAI強調時には読み込める。
        if self.vf_startupvar.get():
            threading.Thread(target=self._prewarm_vf, daemon=True).start()

    LAYOUT_VERSION = 3          # 共通の再生操作と用途別タブ。保存サイズはv3と互換。

    @classmethod
    def _initial_geometry(cls, cfg):
        """保存サイズを復元。旧UIの保存値なら候補比較用に一度だけ広げる。"""
        geometry = cfg.get("geometry") or "1240x780"
        if cfg.get("layout_version", 1) >= cls.LAYOUT_VERSION:
            return geometry
        m = re.match(r"(\d+)x(\d+)(.*)", geometry)
        if not m:
            return "1240x780"
        width, height = max(int(m.group(1)), 1240), max(int(m.group(2)), 780)
        return f"{width}x{height}{m.group(3)}"

    @staticmethod
    def _prewarm():
        try:
            import scipy.signal  # noqa: F401
            import matplotlib.cm  # noqa: F401
            import PIL.Image, PIL.ImageTk  # noqa: F401
        except Exception:
            pass

    def _on_close(self):
        """終了時に設定(音量自動調整・音量・ウィンドウ位置/サイズ)を保存して終了。"""
        self._file_gen += 1
        self._decode_gen += 1
        self._spec_gen += 1
        self._search_gen += 1
        try:
            save_config({
                **self._cfg,
                "geometry": self.geometry(),
                "layout_version": self.LAYOUT_VERSION,
                "list_width": int(self.pane.sashpos(0)),
                "norm": bool(self.normvar.get()),
                "volume_follow": bool(self.followvar.get()),
                "vol": int(self.volvar.get()),
                "crcmode": self._crc_mode(),
                "hide_low": bool(self.hidelowvar.get()),
                "hide_low_pct": int(self.qminvar.get()),
                "time_range": list(self._time_filter) if self._time_filter else None,
                "sort": list(self._sort),
                **serialize_filters(self._filters, self._dur_filter),
            })
        except Exception:
            pass
        try:
            winsound.PlaySound(None, winsound.SND_PURGE)
        except Exception:
            pass
        try:
            if self._play is not None:
                self._play.stop(); self._play.close()
        except Exception:
            pass
        self.destroy()

    def _post(self, fn):
        """別スレッドから UI 更新を依頼(メインスレッドの _drain_ui が実行)。"""
        self._ui_queue.put(fn)

    def _drain_ui(self):
        try:
            while True:
                fn = self._ui_queue.get_nowait()
                try:
                    fn()
                except Exception:
                    pass
        except Exception:
            pass
        self.after(UI_POLL_MS, self._drain_ui)

    def _build(self):
        menubar = tk.Menu(self)
        m_file = tk.Menu(menubar, tearoff=0)
        m_file.add_command(label="CSM別名の登録・編集・削除...", command=self._open_alias_editor)
        m_file.add_command(label="ユーザ番号別名の登録・編集・削除...", command=self._open_user_alias_editor)
        m_file.add_command(label="メーカ名の登録・編集・削除...", command=lambda: MakerAliasEditor(self))
        m_file.add_command(label="秘話キーの紐づけ(CSM/ユーザ/周波数)...", command=lambda: KeyBindingEditor(self))
        m_file.add_separator()
        self.vf_startupvar = tk.BooleanVar(master=self, value=bool(self._cfg.get("voicefixer_preload", True)))
        m_file.add_checkbutton(label="起動時にVoiceFixerを読み込む（次回起動から）",
                              variable=self.vf_startupvar, command=self._vf_startup_changed)
        m_file.add_separator()
        m_file.add_command(label="設定をエクスポート (zip)...", command=self._export_settings)
        m_file.add_command(label="設定をインポート (zip)...", command=self._import_settings)
        m_file.add_separator()
        m_file.add_command(label="終了", command=self._on_close)
        menubar.add_cascade(label="ファイル", menu=m_file)
        self.config(menu=menubar)
        self.minsize(1040, 680)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        self.pane = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        self.pane.grid(row=0, column=0, sticky="nsew", padx=8, pady=(8, 4))
        left = ttk.Frame(self.pane, padding=(0, 0, 6, 0))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(5, weight=1)
        self.pane.add(left, weight=1)
        heading = ttk.Frame(left)
        heading.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(heading, text="録音ライブラリ", font=("", 11, "bold")).pack(side=tk.LEFT)
        self.file_count = ttk.Label(heading, text="0 件")
        self.file_count.pack(side=tk.RIGHT)

        date_row = ttk.Frame(left)
        date_row.grid(row=1, column=0, sticky="ew", pady=2)
        ttk.Label(date_row, text="日付").pack(side=tk.LEFT)
        self.datevar = tk.StringVar()
        self.datecb = ttk.Combobox(date_row, textvariable=self.datevar, state="readonly", width=14)
        self.datecb.pack(side=tk.LEFT, padx=6)
        self.datecb.bind("<<ComboboxSelected>>", lambda e: self._on_date_pick())
        ttk.Button(date_row, text="更新", command=self._refresh_files).pack(side=tk.RIGHT)
        self._refresh_date_list()

        filter_row = ttk.Frame(left)
        filter_row.grid(row=2, column=0, sticky="ew", pady=2)
        ttk.Button(filter_row, text="詳細フィルタ…", command=self._open_filter_dialog).pack(side=tk.LEFT)
        self.clear_filters_btn = ttk.Button(filter_row, text="条件解除（日付・品質は維持）",
                                            command=lambda: self._clear_filters(keep_date=True))
        self.clear_filters_btn.pack(side=tk.LEFT, padx=6)
        quality_row = ttk.Frame(left)
        quality_row.grid(row=3, column=0, sticky="ew", pady=2)
        self.hidelowvar = tk.BooleanVar(value=bool(self._cfg.get("hide_low", False)))
        ttk.Checkbutton(quality_row, text="低品質を隠す  CRC ≥", variable=self.hidelowvar,
                        command=self._refresh_files).pack(side=tk.LEFT)
        self.qminvar = tk.IntVar(value=int(self._cfg.get("hide_low_pct", 60)))
        self.quality_input = ttk.Spinbox(quality_row, from_=0, to=100, increment=10,
                                         width=4, textvariable=self.qminvar, command=self._refresh_files,
                                         validate="key", validatecommand=(self.register(
                                             lambda text: self._valid_uint(text, 100)), "%P"))
        self.quality_input.pack(side=tk.LEFT, padx=4)
        self.quality_input.bind("<Return>", lambda e: self._refresh_files())
        self.quality_input.bind("<FocusOut>", lambda e: self._refresh_files())
        ttk.Label(quality_row, text="%（品質不明は表示）").pack(side=tk.LEFT)
        self.filterlabel = ttk.Label(left, text="絞込: なし", anchor="w", foreground="#1763ae", wraplength=480)
        self.filterlabel.grid(row=4, column=0, sticky="ew", pady=(4, 6))

        self.filelist = RecordingTable(left, on_sort=self._on_sort)
        self.filelist.set_sort_indicator(*self._sort)
        self.filelist.grid(row=5, column=0, sticky="nsew")
        self.filelist.bind("<<ListboxSelect>>", self._on_file)
        self.filelist.bind("<Double-Button-1>", self._on_file_dclick)
        self.filelist.bind("<Return>", self._on_file_enter)
        self.filelist.bind("<Button-3>", self._on_file_rclick)
        self.filelist.bind("<Delete>", lambda e: self._delete_selected())
        self.filelist.bind("<Control-a>", self._select_all_files)
        self.filemenu = tk.Menu(self, tearoff=0)
        hint = ttk.Label(left, text="ダブルクリック / Enter: 再生   Ctrl / Shift: 複数選択\n見出し: 並べ替え   右クリック: 絞り込み・削除",
                         wraplength=480, foreground="#5b6573")
        hint.grid(row=6, column=0, sticky="ew", pady=(6, 0))
        left.bind("<Configure>", lambda e: [w.configure(wraplength=max(200, e.width - 12))
                                           for w in (self.filterlabel, hint)])

        self.right_panel = ScrollablePanel(self.pane)
        self.pane.add(self.right_panel, weight=1)
        right = self.right_panel.content
        right.columnconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)
        self.after_idle(self._init_sash)
        self.pane.bind("<Configure>", lambda e: self.after_idle(self._clamp_sash))

        info_group = ttk.LabelFrame(right, text="選択した録音", padding=6)
        info_group.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        self.info = ttk.Label(info_group, text="左の一覧から録音を選択してください", anchor="w",
                              justify="left", font=("", 10, "bold"), wraplength=540)
        self.info.pack(fill=tk.X)

        player = ttk.LabelFrame(right, text="再生・音量（各タブ共通）", padding=6)
        player.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        key_row = ttk.Frame(player)
        key_row.pack(fill=tk.X, pady=(0, 3))
        ttk.Label(key_row, text="試聴キー").pack(side=tk.LEFT)
        self.keyvar = tk.IntVar(value=0)
        self.key_input = ttk.Entry(key_row, textvariable=self.keyvar, width=8, validate="key",
                                    validatecommand=(self.register(lambda text: self._valid_uint(text, 32767)), "%P"))
        self.key_input.pack(side=tk.LEFT, padx=6)
        self.key_input.bind("<Return>", lambda e: self._play_entered_key())
        ttk.Label(key_row, text="0 = 平文").pack(side=tk.LEFT)
        self.keyvar.trace_add("write", lambda *args: self._update_key_target())

        transport = ttk.Frame(player)
        transport.pack(fill=tk.X, pady=2)
        self.playbtn = ttk.Button(transport, text="▶ 再生", width=12, command=self._toggle_play)
        self.playbtn.pack(side=tk.LEFT)
        ttk.Button(transport, text="■ 停止", command=self._stop_play, width=8).pack(side=tk.LEFT, padx=4)
        self.plain_btn = ttk.Button(transport, text="平文で試聴", command=lambda: self._play_key(0))
        self.plain_btn.pack(side=tk.LEFT)
        self.timelbl = ttk.Label(transport, text="0:00 / 0:00", anchor="e")
        self.timelbl.pack(side=tk.RIGHT, padx=4)
        self.play_source = ttk.Label(player, text="再生キー: —", foreground="#5b6573")
        self.play_source.pack(in_=key_row, side=tk.RIGHT)

        self.workspace_tabs = ttk.Notebook(right)
        self.workspace_tabs.grid(row=2, column=0, sticky="nsew")
        self.listen_page = ttk.Frame(self.workspace_tabs, padding=(0, 6, 0, 0))
        self.analysis_page = ttk.Frame(self.workspace_tabs, padding=(0, 6, 0, 0))
        self.details_page = ttk.Frame(self.workspace_tabs, padding=(0, 6, 0, 0))
        self.workspace_tabs.add(self.listen_page, text="試聴・音声処理")
        self.workspace_tabs.add(self.analysis_page, text="キー入力・保存")
        self.workspace_tabs.add(self.details_page, text="補助解析・ログ")
        for page in (self.listen_page, self.analysis_page):
            page.columnconfigure(0, weight=1)
            page.rowconfigure(0, weight=1)
        self.workspace_tabs.bind("<<NotebookTabChanged>>", lambda e: self.right_panel.after_idle(self.right_panel._resize))
        spectrum = ttk.LabelFrame(self.listen_page, text="スペクトログラム（クリックで再生位置を移動）", padding=4)
        spectrum.grid(row=0, column=0, sticky="nsew", pady=(0, 6))
        self.seek = tk.Canvas(spectrum, height=80, bg=_ui_color("SystemWindow", "#ffffff"),
                              highlightthickness=0, cursor="sb_h_double_arrow")
        self.seek.pack(fill=tk.BOTH, expand=True)
        self.seek.bind("<Button-1>", self._seek_click)
        self.seek.bind("<B1-Motion>", self._seek_click)
        self.seek.bind("<Configure>", lambda e: self._draw_spectrogram())
        self.seekvar = tk.DoubleVar(value=0)
        self._setting_seek = False
        self.seekbar = ttk.Scale(player, from_=0, to=100, variable=self.seekvar, command=self._seek_scale)
        self.seekbar.pack(fill=tk.X, pady=(0, 2))
        self.normvar = tk.BooleanVar(value=bool(self._cfg.get("norm", True)))
        volume_row = ttk.Frame(player)
        volume_row.pack(fill=tk.X)
        ttk.Label(volume_row, text="音量").pack(side=tk.LEFT)
        self.volvar = tk.IntVar(value=int(self._cfg.get("vol", 100)))
        self.volvar.trace_add("write", self._manual_volume_changed)
        tk.Scale(volume_row, from_=0, to=200, orient=tk.HORIZONTAL, variable=self.volvar,
                 showvalue=True, length=160, resolution=5, highlightthickness=0).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(volume_row, text="%").pack(side=tk.LEFT)
        ttk.Checkbutton(volume_row, text="音量自動調整", variable=self.normvar,
                        command=self._volume_changed).pack(side=tk.LEFT, padx=(6, 0))

        candidates = ttk.LabelFrame(self.analysis_page, text="既知のキーを入力・保存（解析無効）", padding=6)
        candidates.grid(row=0, column=0, sticky="nsew")
        candidates.columnconfigure(0, weight=1)
        candidates.rowconfigure(2, weight=1)
        searches = ttk.Frame(candidates)
        searches.grid(row=0, column=0, sticky="ew")
        self.search_btn = ttk.Button(searches, text="この録音を探索", command=lambda: self._search(pool=False))
        self.search_btn.pack(side=tk.LEFT)
        self.pool_btn = ttk.Button(searches, text="この局の全録音で探索", command=lambda: self._search(pool=True))
        self.pool_btn.pack(side=tk.LEFT, padx=6)
        advanced_search = ttk.Frame(candidates)
        advanced_search.grid(row=1, column=0, sticky="ew", pady=4)
        self.force_btn = ttk.Button(advanced_search, text="強制探索（非351MHz帯）", state=tk.DISABLED,
                                    command=lambda: self._search(pool=False, force=True))
        self.force_btn.pack(side=tk.LEFT)
        self.cancel_search_btn = ttk.Button(advanced_search, text="探索を取り消す", command=self._cancel_search, state=tk.DISABLED)
        self.cancel_search_btn.pack(side=tk.LEFT, padx=6)
        self.candlist = CandidateTable(candidates)
        self.candlist.grid(row=2, column=0, sticky="nsew")
        self.candlist.bind("<Double-Button-1>", self._on_cand)
        self.candlist.bind("<Return>", self._on_cand)
        self.candlist.bind("<<TreeviewSelect>>", self._candidate_selected)
        self.candidate_status = ttk.Label(candidates, text="未探索。候補は耳で確認してください。", wraplength=520)
        self.candidate_status.grid(row=3, column=0, sticky="ew", pady=(3, 0))
        self.key_target = ttk.Label(candidates, text="保存先: CSMのある録音を選択してください", wraplength=520)
        self.key_target.grid(row=4, column=0, sticky="ew", pady=3)
        self.restore_row = ttk.Frame(candidates)
        self.restore_row.grid(row=5, column=0, sticky="ew")
        self.preview_candidate_btn = ttk.Button(self.restore_row, text="選択した候補を試聴", command=self._on_cand, state=tk.DISABLED)
        self.preview_candidate_btn.pack(side=tk.LEFT)
        self.restore_btn = ttk.Button(self.restore_row, text="この局にキーを保存", command=self._restore_with_csm, state=tk.DISABLED)
        self.restore_btn.pack(side=tk.LEFT, padx=6)

        sound = ttk.LabelFrame(self.listen_page, text="音声処理", padding=8)
        sound.grid(row=1, column=0, sticky="ew")
        self.details_tabs = ttk.Notebook(self.details_page)
        self.details_tabs.pack(fill=tk.BOTH, expand=True)
        tools = ttk.Frame(self.details_tabs, padding=8)
        logs = ttk.Frame(self.details_tabs, padding=4)
        self.logs_page = logs
        self.details_tabs.add(tools, text="補助解析")
        self.details_tabs.add(logs, text="ログ")
        self.followvar = tk.BooleanVar(value=bool(self._cfg.get("volume_follow", False)))
        self.followcb = ttk.Checkbutton(sound, text="録音途中の音量に緩やかに追従", variable=self.followvar, command=self._volume_changed)
        self.followcb.grid(row=0, column=0, sticky="w", pady=(0, 6))
        self.enhance_btn = ttk.Button(sound, text="AI音声強調（直前の再生音）", command=self._enhance)
        self.enhance_btn.grid(row=0, column=1, sticky="w", padx=6, pady=(0, 6))
        self._sync_volume_widgets()
        mode_row = ttk.Frame(sound)
        mode_row.grid(row=1, column=0, columnspan=2, sticky="ew")
        self.livevar = tk.BooleanVar(value=bool(self._cfg.get("live_mode", False)))
        ttk.Radiobutton(mode_row, text="通常の試聴処理", variable=self.livevar, value=False, command=self._live_changed).pack(side=tk.LEFT)
        ttk.Radiobutton(mode_row, text="受信と同じ処理", variable=self.livevar, value=True, command=self._live_changed).pack(side=tk.LEFT, padx=8)
        ttk.Label(sound, text="CRCエラー音声").grid(row=2, column=0, sticky="w", pady=4)
        self.crcvar = tk.StringVar(value=dict(CRC_MODES).get(self._cfg.get("crcmode", "repeat"), "直前の音でつなぐ"))
        self.crccb = ttk.Combobox(sound, textvariable=self.crcvar, state="readonly", width=19, values=[lab for _, lab in CRC_MODES])
        self.crccb.grid(row=2, column=1, sticky="w", padx=6)
        self.crccb.bind("<<ComboboxSelected>>", lambda e: self._reapply_crc())
        ttk.Label(sound, text="通常処理:「そのまま」以外はデータ枠も無音にします。\nAI強調は推定補完です。", wraplength=480).grid(row=3, column=0, columnspan=2, sticky="w")
        self.live_mutevar = tk.BooleanVar(value=bool(self._cfg.get("live_receiver_mute", False)))
        self.live_mutecb = ttk.Checkbutton(sound, text="受信時のミュートを適用（CRC率・鍵待ち・雑音判定）", variable=self.live_mutevar, command=self._live_changed)
        self.live_mutecb.grid(row=4, column=0, columnspan=2, sticky="w", pady=4)
        options = ttk.Frame(sound)
        options.grid(row=5, column=0, columnspan=2, sticky="ew")
        self.live_opt_vars, self.live_opt_checks = {}, {}
        for index, (name, label) in enumerate(LIVE_OPTIONS):
            var = tk.BooleanVar(value=bool(self._cfg.get("live_opts", {}).get(name, True)))
            check = ttk.Checkbutton(options, text=label, variable=var, command=self._live_changed)
            check.grid(row=index // 2, column=index % 2, sticky="w", padx=(0, 12), pady=2)
            self.live_opt_vars[name], self.live_opt_checks[name] = var, check
        self._cur_play = None
        self._sync_live_widgets()
        for index, (label, command) in enumerate((
                ("ブラインド比較", lambda: BlindCompare(self)),
                ("フレーム解剖", self._open_anatomy),
                ("データ解析", self._open_data_analysis),
                ("統計", self._open_stats))):
            ttk.Button(tools, text=label, command=command).grid(row=index // 2, column=index % 2, sticky="ew", padx=3, pady=4)
        tools.columnconfigure(0, weight=1)
        tools.columnconfigure(1, weight=1)
        ttk.Label(tools, text="フレーム解剖は通信構造、データ解析はRTCM3/NMEA/UBXを確認します。",
                  wraplength=470).grid(row=3, column=0, columnspan=2, sticky="ew", pady=4)
        self.log = tk.Text(logs, height=8, wrap="word", state=tk.DISABLED,
                           bg=_ui_color("SystemWindow", "#ffffff"), relief="flat")
        log_scroll = ttk.Scrollbar(logs, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=log_scroll.set)
        self.log.grid(row=0, column=0, sticky="nsew")
        log_scroll.grid(row=0, column=1, sticky="ns")
        logs.rowconfigure(0, weight=1)
        logs.columnconfigure(0, weight=1)
        right.bind("<Configure>", lambda e: [label.configure(wraplength=max(260, e.width - 40))
                                            for label in (self.info, self.candidate_status, self.key_target)], add=True)

        status = ttk.Frame(self, padding=(8, 3, 8, 6))
        status.grid(row=1, column=0, sticky="ew")
        status.columnconfigure(0, weight=1)
        self.statusvar = tk.StringVar(value="録音を選択してください")
        ttk.Label(status, textvariable=self.statusvar, anchor="w", width=1).grid(row=0, column=0, sticky="ew")
        self.progress = ttk.Progressbar(status, mode="indeterminate", length=100)
        self.progress.grid(row=0, column=1, padx=8)
        ttk.Button(status, text="ログを表示", command=self._show_log).grid(row=0, column=2)
        self._update_key_target()
        self._set_search_state(False, "未探索。候補は耳で確認してください。")
        self.right_panel.enable_wheel()


    def _init_sash(self):
        """仕切りの初期位置。ウィンドウ配置が済むまで待ち、操作パネル側に最低幅を残す。"""
        width = self.pane.winfo_width()
        if width <= 1:
            self.after(50, self._init_sash)
            return
        wanted = int(self._cfg.get("list_width") or self.filelist.natural_width() + 12)
        self.pane.sashpos(0, max(340, min(wanted, width - 540)))
        self.pane.bind("<ButtonRelease-1>", lambda e: self._clamp_sash(), add=True)

    def _clamp_sash(self):
        width = self.pane.winfo_width()
        if width < 880:
            return
        current = self.pane.sashpos(0)
        position = max(340, min(current, width - 540))
        if position != current:
            self.pane.sashpos(0, position)

    @staticmethod
    def _valid_uint(text, maximum):
        return text == "" or (text.isascii() and text.isdecimal() and len(text) <= 5 and int(text) <= maximum)

    def _read_key(self):
        try:
            key = self.keyvar.get()
        except (tk.TclError, ValueError):
            key = None
        if key is None or not 0 <= key <= 32767:
            self._msg("試聴キーは0〜32767の整数で入力してください。")
            self.key_input.focus_set()
            return None
        return key

    def _play_entered_key(self):
        key = self._read_key()
        if key is not None:
            self._play_key(key)

    def _update_key_target(self):
        if not hasattr(self, "key_target"):
            return
        try:
            key = self.keyvar.get()
        except (tk.TclError, ValueError):
            key = None
        valid = key is not None and 0 <= key <= 32767
        enabled = bool(self.frames and self.csm and self.freq and valid)
        self.restore_btn.configure(state=tk.NORMAL if enabled else tk.DISABLED)
        state = tk.NORMAL if self.frames else tk.DISABLED
        self.playbtn.configure(state=state)
        self.plain_btn.configure(state=state)
        if not self.frames or not self.csm:
            text = "保存先: CSMのある録音を選択してください"
        elif not valid:
            text = "保存先: キーを0〜32767で入力してください"
        else:
            alias = self.alias.get(self.csm)
            destination = f"{alias}（CSM {self.csm}）" if alias else f"CSM {self.csm}"
            value = "平文（鍵不要）" if key == 0 else f"キー {key}"
            text = f"保存先: {destination} → {value}\n保存すると同じ周波数の録音も再デコードします。"
        self.key_target.configure(text=text)
        self.right_panel.after_idle(self.right_panel._resize)

    def _candidate_selected(self, _event=None):
        key = self.candlist.selected_key()
        self.preview_candidate_btn.configure(state=tk.NORMAL if key is not None else tk.DISABLED)
        if key is not None and key != getattr(self, "_selected_candidate_key", None):
            self.keyvar.set(key)
        self._selected_candidate_key = key

    def _on_file_enter(self, _event=None):
        self._on_file(None, autoplay=True)
        return "break"

    def _show_log(self):
        self.workspace_tabs.select(self.details_page)
        self.details_tabs.select(self.logs_page)
        self.update_idletasks()
        self.right_panel.canvas.yview_moveto(0)

    def _set_search_state(self, busy, text):
        self._search_busy = False
        self.candidate_status.configure(text="秘話キー解析は無効です。既知のキーを手入力・保存できます。")
        self.right_panel.after_idle(self.right_panel._resize)
        for button in (self.search_btn, self.pool_btn, self.force_btn, self.cancel_search_btn):
            button.configure(state=tk.DISABLED)
        self.progress.stop()
        self.progress.configure(value=0)

    def _cancel_search(self):
        self._search_gen += 1
        self._set_search_state(False, "探索を取り消しました。表示済みの候補は試聴できます。")

    def _msg(self, s):
        self.log.configure(state=tk.NORMAL)
        try:
            self.log.insert(tk.END, s + "\n")
            self.log.see(tk.END)
        finally:
            self.log.configure(state=tk.DISABLED)
        self.statusvar.set(s.replace("\n", " "))
        self.update_idletasks()

    def _settings_files(self):
        """インポート/エクスポート対象: (basename, フルパス, 再読込関数) の一覧。"""
        return [
            ("csm_alias.csv", CSM_ALIAS_CSV, lambda: setattr(self, "alias", load_csm_alias())),
            ("user_alias.csv", USER_ALIAS_CSV, lambda: setattr(self, "user_alias", load_user_alias())),
            ("maker_codes.csv", MAKER_CODES_CSV, lambda: setattr(self, "makers", load_maker_codes())),
            ("manual_keys.csv", MANUAL_KEYS_CSV, None),
            ("filter_templates.json", FILTER_TPL_PATH, None),
            ("key_tool_config.json", CONFIG_PATH, None),
        ]

    def _export_settings(self):
        """各設定ファイルを1つの zip にまとめて書き出す。"""
        from tkinter import filedialog, messagebox
        import zipfile
        out = filedialog.asksaveasfilename(
            parent=self, title="設定のエクスポート", defaultextension=".zip",
            initialfile=f"std98_settings_{datetime.datetime.now():%Y%m%d}.zip",
            filetypes=[("ZIP", "*.zip")])
        if not out:
            return
        n = 0
        try:
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                for base, path, _ in self._settings_files():
                    if os.path.exists(path):
                        z.write(path, base); n += 1
        except Exception as exc:
            messagebox.showerror("エクスポート失敗", str(exc), parent=self); return
        messagebox.showinfo("エクスポート完了", f"{n} 個の設定ファイルを書き出しました:\n{out}", parent=self)

    def _import_settings(self):
        """zip から既知の設定ファイルを取り込む(上書き確認あり)。取り込み後に再読込。"""
        from tkinter import filedialog, messagebox
        import zipfile
        src = filedialog.askopenfilename(parent=self, title="設定のインポート",
                                         filetypes=[("ZIP", "*.zip"), ("すべて", "*.*")])
        if not src:
            return
        targets = {base: (path, reload) for base, path, reload in self._settings_files()}
        try:
            with zipfile.ZipFile(src) as z:
                names = [n for n in z.namelist() if os.path.basename(n) in targets]
                if not names:
                    messagebox.showwarning("インポート", "この zip に取り込める設定ファイルがありません", parent=self); return
                if not messagebox.askyesno("インポートの確認",
                        "次のファイルを取り込みます(既存は上書き):\n\n"
                        + "\n".join(os.path.basename(n) for n in names)
                        + "\n\n※元に戻せません", parent=self):
                    return
                done = []
                for n in names:
                    base = os.path.basename(n)
                    path, _ = targets[base]
                    data = z.read(n)
                    os.makedirs(os.path.dirname(path), exist_ok=True)
                    with open(path, "wb") as f:
                        f.write(data)
                    done.append(base)
        except Exception as exc:
            messagebox.showerror("インポート失敗", str(exc), parent=self); return
        # 取り込んだものをメモリへ再読込(config は次回起動から反映)。
        self._edu_cache.clear()
        for base, path, reload in self._settings_files():
            if base in done and reload:
                try: reload()
                except Exception: pass
        self._refresh_files()
        if self.filelist.curselection():
            self._on_file(None)
        note = "  ※ツール設定(key_tool_config.json)は次回起動から反映" if "key_tool_config.json" in done else ""
        messagebox.showinfo("インポート完了", f"{len(done)} 個を取り込みました。{note}", parent=self)

    def _open_alias_editor(self):
        """[ファイル > CSM別名の編集] 現在選択中ファイルのCSMを初期値にして開く。"""
        CsmAliasEditor(self, preset_csm=self.csm or "")

    def _open_user_alias_editor(self):
        """[ファイル > ユーザ番号別名の編集] 現在選択中ファイルのユーザ番号を初期値にして開く。"""
        uc = None
        if getattr(self, "curpath", None):
            uc, _mk = self._edu_user_maker(self.curpath)
        UserAliasEditor(self, preset_key="" if uc is None else str(uc))

    def _reload_aliases(self):
        """エディタで別名を更新したら再読込し、選択中ファイルの表示・絞込表示も更新する。"""
        self.alias = load_csm_alias()
        self.user_alias = load_user_alias()
        self.makers = load_maker_codes()
        if "user" in self._filters:
            self._update_filter_label()
        if self.filelist.curselection():
            self._on_file(None)

    def _user_label(self, uc):
        """ユーザ番号の表示文字列。別名があれば「N(別名)」、0 は別名なしなら「0(一斉)」。"""
        a = self.user_alias.get(uc, "")
        if a:
            return f"{uc}({a})"
        return "0(一斉)" if uc == 0 else str(uc)

    def _raw_duration(self, path):
        """録音長(秒)。raw は追記されないのでパスをキーにキャッシュ(多数ファイル対策)。"""
        v = self._dur_cache.get(path)
        if v is not None:
            return v if v >= 0 else None
        dur = self._raw_duration_calc(path)
        self._dur_cache[path] = dur if dur is not None else -1.0
        return dur

    @staticmethod
    def _raw_duration_calc(path):
        try:
            size = os.path.getsize(path)
            with open(path, "rb") as f:
                magic = f.read(8)
            hdr = (52 if magic == b"T98RAW03" else 48 if magic == b"T98RAW02"
                   else 32 if magic == b"T98RAW01" else None)
            if hdr is None:
                return None
            frames = (size - hdr) // 36
            return frames * 4 * 160 / 8000.0   # 1フレーム=4x160サンプル @8kHz
        except Exception:
            return None

    def _refresh_files(self, on_complete=None):
        # The input may be temporarily empty while editing; never pass TclError
        # into a file scan or persist an invalid threshold.
        try:
            qmin = self.qminvar.get()
            if not 0 <= qmin <= 100:
                raise ValueError("CRC threshold out of range")
        except (tk.TclError, ValueError):
            self.qminvar.set(60)
        # 日付サブフォルダ(新)と raw 直下(旧)を再帰的に集め、ファイル名(時刻)新しい順。
        all_files = sorted(_list_files(RAW_DIR, ".t98raw"),
                           key=lambda p: os.path.basename(p), reverse=True)
        self._list_gen += 1
        gen = self._list_gen
        previous = getattr(self, "_filter_completion", None)
        self._filter_completion = (gen, on_complete) if on_complete else None
        if previous:
            previous[1](None)  # A newer request supersedes the old result.
        hide = self.hidelowvar.get()
        filters = {field: (mode, frozenset(values)) for field, (mode, values) in self._filters.items()}
        time_range, duration = self._time_filter, self._dur_filter
        # 条件なし → 即時表示(スキャン不要で最速)。
        if not filters and duration is None and time_range is None and not hide:
            self._populate_files(gen, all_files)
            return
        # 条件あり → 絞り込み(edu/ヘッダ読みが要る)は背景スレッドで。UI を固めない。
        self.filterlabel.config(text=f"絞込: {self._filter_summary()} (絞り込み中...)")
        qmin = self.qminvar.get()

        def scan():
            res = []
            for p in all_files:
                if gen != self._list_gen:
                    return   # 新しい絞り込み要求 → 中断
                if not self._passes_filters(p, filters=filters, time_range=time_range, dur=duration):
                    continue
                if hide:
                    pct = self._edu_crc_pct(p)
                    if pct is not None and pct < qmin:
                        continue
                res.append(p)
            if gen == self._list_gen:
                self._post(lambda: self._populate_files(gen, res))

        threading.Thread(target=scan, daemon=True).start()

    def _populate_files(self, gen, files):
        if gen != self._list_gen:
            return
        self._show_sorted(files)
        completion = getattr(self, "_filter_completion", None)
        if completion and completion[0] == gen:
            self._filter_completion = None
            completion[1](len(files))

    def _show_files(self, files, keep=()):
        """一覧を files の順で表示。keep(パス)の選択と先頭の可視位置を引き継ぐ。"""
        self.files = files
        self.filelist.delete(0, tk.END)
        rows = [recording_row(p, self._raw_duration(p)) for p in files]
        if rows:
            self.filelist.insert(tk.END, *rows)
        if keep:
            position = {path: i for i, path in enumerate(files)}
            indices = sorted(position[p] for p in keep if p in position)
            for i in indices:
                self.filelist.selection_set(i)
            if indices:
                self.filelist.activate(indices[0])
                self.filelist.see(indices[0])
        self._update_filter_label()
        if hasattr(self, "file_count"):
            self.file_count.configure(text=f"{len(files)} 件")
        self._start_coloring()

    def _on_sort(self, column):
        """列見出しクリック: 同じ列なら向きを反転、別の列はその列の既定の向きで並べ替え。"""
        current, descending = self._sort
        self._sort = (column, not descending) if column == current else (column, DEFAULT_DESCENDING.get(column, False))
        self.filelist.set_sort_indicator(*self._sort)
        self._show_sorted(list(self.files), keep=self.filelist.selected_paths(self.files))

    def _show_sorted(self, files, keep=()):
        column, descending = self._sort
        self._sort_gen += 1
        if column in QUICK_SORT_COLUMNS:
            self._show_files(sort_files(files, lambda p: self._sort_value(p, column), descending), keep)
            return
        # 局/UC/秘話/CRC は edu・ヘッダ読みが要るので背景で。済むまで今の順で表示しておく。
        if files != self.files:
            self._show_files(files, keep)
        gen = self._sort_gen
        self.filterlabel.config(text=f"絞込: {self._filter_summary()} ({len(files)}件)  並べ替え中...")

        def work():
            ordered = sort_files(files, lambda p: self._sort_value(p, column), descending)

            def apply():
                if gen == self._sort_gen and self.files == files:
                    self._show_files(ordered, self.filelist.selected_paths(self.files) or keep)
            self._post(apply)

        threading.Thread(target=work, daemon=True).start()

    def _sort_value(self, path, column):
        """並べ替えキー。None=不明(末尾へ)。表示と同じ規則(別名優先の局名など)。"""
        if column == "time":
            return os.path.basename(path)
        if column in ("ch", "freq"):
            freq = name_frequency(path) or self._header_cached(path)[0]
            if not freq:
                return None
            return channel_sort_key(freq) if column == "ch" else int(freq)
        if column == "dur":
            return self._raw_duration(path)
        if column == "csm":
            csm = self._header_cached(path)[1]
            return (self.alias.get(csm) or csm) if csm else None
        if column == "uc":
            return self._edu_user_maker(path)[0]
        if column == "secret":
            secret = self._file_field(path, "secret")
            return None if secret is None else int(secret)   # 平文 < 秘話
        if column == "crc":
            return self._edu_crc_pct(path)
        return None

    def _start_coloring(self):
        """一覧の CRC 色・局・UC・秘話を背景で埋める(キャッシュ利用)。新しい更新が来たら中断。"""
        self._color_gen += 1
        gen = self._color_gen
        files = list(self.files)

        def work():
            batch = []
            for i, p in enumerate(files):
                if gen != self._color_gen:
                    return
                batch.append((i, self._row_details(p)))
                if len(batch) >= 100:
                    b = batch; batch = []
                    self._post(lambda b=b, g=gen: self._apply_colors(g, b))
            if batch:
                self._post(lambda b=batch, g=gen: self._apply_colors(g, b))

        threading.Thread(target=work, daemon=True).start()

    def _row_details(self, path):
        """背景スレッド用: 一覧の後埋め列(色・局・UC・秘話・CRC。ファイル名に無ければ ch/周波数も)。"""
        pct = self._edu_crc_pct(path)
        freq, csm = self._header_cached(path)
        uc, _mk = self._edu_user_maker(path)
        secret = self._file_field(path, "secret")
        alias = self.alias.get(csm, "") if csm else ""
        details = {"color": self._crc_color(pct),
                   "csm": (f"{alias} ({csm})" if alias else csm) or "-",
                   "uc": "-" if uc is None else self._user_label(uc),
                   "secret": {True: "秘話", False: "平文"}.get(secret, "?"),
                   "crc": "-" if pct is None else f"{pct:.0f}%"}
        if freq and not _NAME_FREQ.search(os.path.basename(path)):
            details.update(ch=frequency_label(freq), freq=f"{freq / 1e6:.5f}")
        return details

    def _apply_colors(self, gen, items):
        if gen != self._color_gen:
            return
        for i, details in items:
            details = dict(details)
            self.filelist.update_row(i, details.pop("color", None), **details)

    def _header_cached(self, path):
        c = self._hdr_cache.get(path)
        if c is None:
            c = read_header(path)
            self._hdr_cache[path] = c
        return c

    def _file_field(self, path, field):
        """フィルタ判定用に、ファイルの field 値を返す(freq/csm はヘッダ、user/maker は edu)。"""
        if field == "date":
            b = os.path.basename(path)
            return b[:8] if len(b) >= 8 and b[:8].isdigit() else ""
        if field == "freq":
            return self._header_cached(path)[0]
        if field == "csm":
            return self._header_cached(path)[1] or ""
        if field == "secret":
            v = self._sec_cache.get(path, 0)
            if v == 0:   # 未キャッシュ(0 はセンチネル。True/False/None と区別)
                v = read_secret_flag(path)
                self._sec_cache[path] = v
            return v
        s = self._edu_summary(path)
        if field == "user":
            return None if s is None else s["uc"]
        if field == "maker":
            return None if s is None else s["mk"]
        return None

    def _passes_filters(self, path, filters=None, time_range="keep", dur="keep"):
        """全 field 制約(AND)を満たすか。inc=値が集合に含む / exc=含まない。"""
        # 背景スレッドから呼ばれる。イテレート中に self._filters が差し替わっても安全なよう複製。
        conditions = self._filters if filters is None else filters
        for field, (mode, vals) in list(conditions.items()):
            v = self._file_field(path, field)
            inside = v in vals
            if mode == "inc" and not inside:
                return False
            if mode == "exc" and inside:
                return False
        # 日時範囲フィルタ(ファイル名 YYYYMMDD_HHMMSS を14桁キーで比較)。
        span = self._time_filter if time_range == "keep" else time_range
        if span is not None:
            b = os.path.basename(path)
            key = (b[:15].replace("_", "")) if len(b) >= 15 else ""
            if not key.isdigit():
                return False
            lo, hi = span
            if lo and key < lo:
                return False
            if hi and key > hi:
                return False
        # 音源の長さ(秒)フィルタ。長さ不明の録音は対象外(隠す)。
        duration = self._dur_filter if dur == "keep" else dur
        if duration is not None:
            op, sec = duration
            dur = self._raw_duration(path)
            if dur is None:
                return False
            if op == ">=" and not (dur >= sec):
                return False
            if op == "<=" and not (dur <= sec):
                return False
            if op == "==" and abs(dur - sec) > 0.5:   # 長さは0.08s刻み → ±0.5sで「ちょうど」
                return False
        return True

    def _fval_text(self, field, v):
        if v is None or v == "":
            return "CSMなし" if field == "csm" else "不明"
        if field == "date":
            return f"{v[0:4]}-{v[4:6]}-{v[6:8]}" if len(v) == 8 else str(v)
        if field == "freq":
            return f"{v/1e6:.5f}MHz"
        if field == "user":
            return self._user_label(v)
        if field == "maker":
            name = self.makers.get(v)
            return f"{v}({name})" if name else str(v)
        if field == "secret":
            return SECRET_LABEL.get(v, str(v))
        return str(v)

    _FIELD_LABEL = {"date": "日付", "freq": "周波数", "csm": "CSM", "user": "ユーザ", "maker": "メーカ", "secret": "秘話"}

    def _filter_summary(self):
        parts = []
        for field, (mode, vals) in self._filters.items():
            vtxt = "・".join(self._fval_text(field, v) for v in vals)
            parts.append(f"{self._FIELD_LABEL.get(field, field)}{'=' if mode=='inc' else '≠'}{vtxt}")
        if self._time_filter is not None:
            lo, hi = self._time_filter
            parts.append("日時 " + (self._fmt_dt_key(lo) if lo else "…") + "〜" + (self._fmt_dt_key(hi) if hi else "…"))
        if self._dur_filter is not None:
            op, sec = self._dur_filter
            parts.append(f"長さ{op}{sec:g}s")
        hide_low = getattr(self, "hidelowvar", None)
        if hide_low is not None and hide_low.get():
            parts.append(f"CRC≥{int(self.qminvar.get())}%")
        return " / ".join(parts) if parts else "なし"

    @staticmethod
    def _fmt_dt_key(key):
        """Keep the year and seconds visible so the condition is unambiguous."""
        if not key or len(key) != 14:
            return str(key)
        return f"{key[:4]}-{key[4:6]}-{key[6:8]} {key[8:10]}:{key[10:12]}:{key[12:14]}"

    @staticmethod
    def parse_dt_key(text, is_end):
        """Parse a real calendar date; omitted components use lower/upper bounds."""
        match = re.fullmatch(
            r"([0-9]{4})(?:[-/]([0-9]{1,2})(?:[-/]([0-9]{1,2})"
            r"(?:[ T]([0-9]{1,2})(?::([0-9]{1,2})(?::([0-9]{1,2}))?)?)?)?)?",
            (text or "").strip())
        if match is None:
            return None
        try:
            year, month, day, hour, minute, second = match.groups()
            year = int(year)
            month = int(month) if month is not None else (12 if is_end else 1)
            day = int(day) if day is not None else (calendar.monthrange(year, month)[1] if is_end else 1)
            hour = int(hour) if hour is not None else (23 if is_end else 0)
            minute = int(minute) if minute is not None else (59 if is_end else 0)
            second = int(second) if second is not None else (59 if is_end else 0)
            datetime.datetime(year, month, day, hour, minute, second)
            return f"{year:04d}{month:02d}{day:02d}{hour:02d}{minute:02d}{second:02d}"
        except ValueError:
            return None

    def _update_filter_label(self):
        self.filterlabel.config(text=f"絞込: {self._filter_summary()} ({len(self.files)}件)")
        self.filelist.set_filtered_columns(self._filtered_columns())

    def _on_file_rclick(self, event):
        column = self.filelist.heading_at(event.x, event.y)
        if column is not None:
            menu = self._header_menu(column)
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()
            return
        idx = self.filelist.nearest(event.y)
        if idx < 0 or idx >= len(self.files):
            return
        selected = self.filelist.curselection()
        if idx not in selected or len(selected) <= 1:
            self.filelist.selection_clear(0, tk.END)
            self.filelist.selection_set(idx)
            selected = (idx,)
        self.filelist.activate(idx)
        self._on_file(None)
        freq, csm = read_header(self.files[idx])
        uc, mk = self._edu_user_maker(self.files[idx])   # ユーザ/メーカは edu 由来
        m = self.filemenu
        m.delete(0, tk.END)

        # 各 field を「含む/含まない」で追加(サブメニュー)。
        def add_field(label, field, value):
            sub = tk.Menu(m, tearoff=0)
            sub.add_command(label="含む に追加", command=lambda: self._add_filter(field, "inc", value))
            sub.add_command(label="含まない に追加", command=lambda: self._add_filter(field, "exc", value))
            m.add_cascade(label=label, menu=sub)

        if freq is not None:
            add_field(f"周波数: {freq/1e6:.5f}MHz {channel_label(freq)}", "freq", freq)
        if csm:
            a = self.alias.get(csm, "")
            add_field("CSM: " + csm + (f" ({a})" if a else ""), "csm", csm)
        if uc is not None:
            add_field("ユーザ: " + self._user_label(uc), "user", uc)
        if mk is not None:
            add_field("メーカ: " + self._fval_text("maker", mk), "maker", mk)
        cur = read_secret_flag(self.files[idx])
        add_field(f"秘話: {SECRET_LABEL[cur]}", "secret", cur)

        m.add_separator()
        m.add_command(label="🔎 詳細フィルタ...", command=self._open_filter_dialog)
        m.add_command(label="絞り込み解除 (全表示)", command=self._clear_filters)
        m.add_separator()
        if len(selected) > 1:
            m.add_command(label=f"🗑 選択した {len(selected)} 件を削除...  (Delete)", command=self._delete_selected)
        else:
            m.add_command(label="🗑 このファイルを削除...  (Delete)", command=lambda i=idx: self._delete_file(i))
        try:
            m.tk_popup(event.x_root, event.y_root)
        finally:
            m.grab_release()

    def _select_all_files(self, _event=None):
        self.filelist.selection_set(0, tk.END)
        return "break"   # Listbox 既定の Ctrl+A(先頭へ移動)を抑止

    def _delete_file(self, idx):
        """raw 録音(と対応する edu / rec WAV)を確認のうえ削除する。"""
        if 0 <= idx < len(self.files):
            self._delete_paths([self.files[idx]])

    def _delete_selected(self):
        paths = [self.files[i] for i in self.filelist.curselection() if 0 <= i < len(self.files)]
        if paths:
            self._delete_paths(paths)

    def _delete_paths(self, paths):
        """複数の録音をまとめて確認・削除。raw と同じ交信の edu / rec(WAV) も消す。"""
        from tkinter import messagebox
        groups = [recording_files(p) for p in paths]
        n_edu = sum(1 for g in groups for f in g[1:] if f.endswith(".jsonl"))
        n_wav = sum(1 for g in groups for f in g[1:] if f.lower().endswith(".wav"))
        names = [os.path.basename(p) for p in paths]
        shown = "\n".join(names[:8]) + (f"\n…ほか {len(names) - 8} 件" if len(names) > 8 else "")
        title = "この録音" if len(paths) == 1 else f"{len(paths)} 件の録音"
        if not messagebox.askyesno("削除の確認",
                f"{title}を削除しますか?\n\n{shown}\n\n"
                f"削除するファイル: 生音声 raw {len(paths)} / デバッグ記録 edu {n_edu} / 音声 WAV {n_wav}\n\n"
                "※元に戻せません", parent=self):
            return
        # 再生中の音が消すファイル由来なら止める(Windows は開いているファイルを消せない)。
        current = getattr(self, "curpath", None)
        if current in paths:
            self._stop_play()
        deleted, errors = delete_recordings(paths)
        gone = set(deleted)
        if current in gone:
            self._file_gen += 1
            self._loading_path = None
            self.curpath = None; self.frames = None
            self._play_pcm = None; self._draw_spectrogram()
        for key in [k for k in self._enh_cache if k[0] in gone]:
            del self._enh_cache[key]
        if errors:
            detail = "\n".join(f"{os.path.basename(p)}: {e}" for p, e in errors[:10])
            more = f"\n…ほか {len(errors) - 10} 件" if len(errors) > 10 else ""
            messagebox.showerror("削除失敗", f"一部のファイルを削除できませんでした:\n{detail}{more}", parent=self)
        self._msg(f"削除: {os.path.basename(deleted[0])}" if len(deleted) == 1 else f"削除: {len(deleted)} 件")
        self._refresh_files()

    def _set_filter(self, filt):
        """後方互換: 単一フィルタ設定。None=全解除、("freq",v) 等=その field を include に。"""
        if filt is None:
            self._filters = {}
        else:
            field, val = filt
            self._filters = {field: ("inc", {val})}
        self._refresh_files()

    def _add_filter(self, field, mode, value):
        """右クリックからの追加。同 field・同モードなら値を集合に追加(累積=OR)。
        別モードに切り替えたときはその値で作り直す(include と exclude は同 field で両立しない)。"""
        cur = self._filters.get(field)
        if cur and cur[0] == mode:
            vals = set(cur[1]); vals.add(value)
        else:
            vals = {value}
        self._filters[field] = (mode, vals)
        self._refresh_files()

    # --- 列見出しの右クリック: 列ごとの絞り込み -------------------------------
    _COLUMN_FIELD = {"ch": "freq", "freq": "freq", "csm": "csm", "uc": "user", "secret": "secret"}
    _COLUMN_TITLE = {key: title for key, title, _s, _a in RecordingTable.COLUMNS}
    DUR_PRESETS = ((">=", 1), (">=", 2), (">=", 5), (">=", 10), (">=", 30), ("<=", 1), ("<=", 2))
    CRC_PRESETS = (30, 40, 50, 60, 70, 80, 90)
    MAX_MENU_VALUES = 60

    def _filtered_columns(self):
        cols = set()
        if "date" in self._filters or self._time_filter is not None:
            cols.add("time")
        if "freq" in self._filters:
            cols |= {"ch", "freq"}
        if self._dur_filter is not None:
            cols.add("dur")
        for column, field in (("csm", "csm"), ("uc", "user"), ("secret", "secret")):
            if field in self._filters:
                cols.add(column)
        if self.hidelowvar.get():
            cols.add("crc")
        return cols

    def _value_label(self, column, value):
        if value is None or value == "":
            return {"csm": "(CSM なし)", "secret": "不明"}.get(column, "(不明)")
        if column == "ch":
            return f"{frequency_label(value)}  {value / 1e6:.5f}MHz"
        if column == "freq":
            return f"{value / 1e6:.5f}MHz  {frequency_label(value)}"
        if column == "csm":
            alias = self.alias.get(value, "")
            return f"{alias} ({value})" if alias else value
        if column == "uc":
            return self._user_label(value)
        return SECRET_LABEL.get(value, str(value))

    def _column_values(self, column):
        """表示中の一覧に現れる値と件数 [(値, 件数)]。絞り込み中の値は 0 件でも残す。"""
        from collections import Counter
        field = self._COLUMN_FIELD[column]
        counts = Counter(self._file_field(p, field) for p in self.files)
        current = self._filters.get(field)
        for value in (current[1] if current else ()):
            counts.setdefault(value, 0)

        def order(value):
            if value is None or value == "":
                return (1, 0)
            if column == "ch":
                return (0, channel_sort_key(value))
            if column == "secret":
                return (0, int(value))
            if column == "csm":
                return (0, self._value_label(column, value))
            return (0, value)
        return sorted(counts.items(), key=lambda item: order(item[0]))

    def _header_menu(self, column):
        """列見出しの右クリックメニュー(その列の絞り込み)。"""
        m = tk.Menu(self, tearoff=0)
        title = self._COLUMN_TITLE[column]
        m.add_command(label=f"「{title}」で絞り込み  (表示中 {len(self.files)} 件)", state=tk.DISABLED)
        m.add_separator()
        if column == "time":
            current = self._filters.get("date")
            picked = next(iter(current[1])) if current and current[1] else None
            for day in self._available_dates():
                value = day.replace("-", "")
                m.add_command(label=("✓ " if value == picked else "   ") + day,
                              command=lambda v=value: self._set_field_filter("date", "inc", {v}))
            m.add_separator()
            m.add_command(label="日時の範囲を指定...", command=self._open_filter_dialog)
        elif column == "dur":
            for op, sec in self.DUR_PRESETS:
                mark = "✓ " if self._dur_filter == (op, float(sec)) else "   "
                m.add_command(label=f"{mark}{sec} 秒{'以上' if op == '>=' else '以下'}",
                              command=lambda o=op, v=sec: self._set_dur_filter((o, float(v))))
        elif column == "crc":
            hidden = self.hidelowvar.get()
            for pct in self.CRC_PRESETS:
                mark = "✓ " if hidden and int(self.qminvar.get()) == pct else "   "
                m.add_command(label=f"{mark}CRC {pct}% 未満を隠す", command=lambda v=pct: self._set_crc_filter(v))
        else:
            field = self._COLUMN_FIELD[column]
            mode, chosen = self._filters.get(field, (None, set()))
            values = self._column_values(column)
            for value, count in values[:self.MAX_MENU_VALUES]:
                mark = ("✓ " if mode == "inc" else "✕ ") if value in chosen else "   "
                sub = tk.Menu(m, tearoff=0)
                sub.add_command(label="これだけ表示", command=lambda v=value: self._set_field_filter(field, "inc", {v}))
                sub.add_command(label="含む に追加", command=lambda v=value: self._add_filter(field, "inc", v))
                sub.add_command(label="含まない に追加", command=lambda v=value: self._add_filter(field, "exc", v))
                m.add_cascade(label=f"{mark}{self._value_label(column, value)}  ({count})", menu=sub)
            if len(values) > self.MAX_MENU_VALUES:
                m.add_command(label=f"…ほか {len(values) - self.MAX_MENU_VALUES} 件(詳細フィルタで指定)", state=tk.DISABLED)
        m.add_separator()
        m.add_command(label="この項目の絞り込みを解除", command=lambda: self._clear_column_filter(column),
                      state=tk.NORMAL if column in self._filtered_columns() else tk.DISABLED)
        m.add_command(label="🔎 詳細フィルタ...", command=self._open_filter_dialog)
        m.add_command(label="絞り込みをすべて解除", command=self._clear_filters)
        return m

    def _set_field_filter(self, field, mode, values):
        self._filters[field] = (mode, set(values))
        if field == "date" and hasattr(self, "datecb"):
            self._refresh_date_list()
        self._refresh_files()

    def _set_dur_filter(self, dur):
        self._dur_filter = dur
        self._refresh_files()

    def _set_crc_filter(self, pct):
        self.qminvar.set(pct)
        self.hidelowvar.set(True)
        self._refresh_files()

    def _clear_column_filter(self, column):
        if column == "time":
            self._filters.pop("date", None)
            self._time_filter = None
            if hasattr(self, "datecb"):
                self._refresh_date_list()
        elif column == "dur":
            self._dur_filter = None
        elif column == "crc":
            self.hidelowvar.set(False)
        else:
            self._filters.pop(self._COLUMN_FIELD[column], None)
        self._refresh_files()

    def _clear_filters(self, keep_date=False):
        """条件解除は日付・品質を維持。全表示は品質条件も含めて解除する。"""
        date = self._filters.get("date") if keep_date else None
        self._filters = {"date": date} if date else {}
        self._dur_filter = None
        self._time_filter = None
        if hasattr(self, "datevar") and not date:
            self.datevar.set("全日")
        if not keep_date and hasattr(self, "hidelowvar"):
            self.hidelowvar.set(False)
        self._refresh_files()

    def _available_dates(self):
        """raw の日付サブフォルダ(YYYY-MM-DD)を新しい順に返す。無ければ空。"""
        dates = []
        try:
            for name in os.listdir(RAW_DIR):
                if len(name) == 10 and name[4] == "-" and name[7] == "-" and \
                        name.replace("-", "").isdigit() and os.path.isdir(os.path.join(RAW_DIR, name)):
                    dates.append(name)
        except Exception:
            pass
        return sorted(dates, reverse=True)

    def _refresh_date_list(self):
        """日付プルダウンの候補を更新。現在のフィルタ状態を選択表示に反映。"""
        dates = [d.replace("-", "") for d in self._available_dates()]
        # 選択中の日付(起動時の今日など)は、まだ録音フォルダが無くても候補に出す。
        cur = self._filters.get("date")
        if cur and cur[0] == "inc":
            dates += [v for v in cur[1] if v not in dates]
        vals = ["全日"] + sorted(dates, reverse=True)
        # 表示は YYYY-MM-DD、内部値は YYYYMMDD。表示用マップを持つ。
        disp = ["全日"] + [self._fval_text("date", v) for v in vals[1:]]
        self.datecb["values"] = disp
        self._date_disp_to_val = {d: v for d, v in zip(disp, vals)}
        cur = self._filters.get("date")
        if cur and cur[1]:
            v = next(iter(cur[1]))
            self.datevar.set(self._fval_text("date", v))
        else:
            self.datevar.set("全日")

    def _on_date_pick(self):
        val = self._date_disp_to_val.get(self.datevar.get())
        if not val or val == "全日":
            self._filters.pop("date", None)
        else:
            self._filters["date"] = ("inc", {val})
        self._refresh_files()

    def _open_filter_dialog(self):
        FilterDialog(self)

    def _apply_filter_spec(self, spec, dur="keep", time_range="keep", on_complete=None):
        """FilterDialog からの適用。spec: field -> (mode, set(values))。
        dur: (op,秒)/None/"keep"。 time_range: (from,to)/None/"keep"。"""
        # 日付プルダウン由来の "date" 条件はダイアログで扱わないので保持する。
        keep_date = self._filters.get("date")
        self._filters = {k: v for k, v in spec.items() if v[1]}
        if keep_date and "date" not in self._filters:
            self._filters["date"] = keep_date
        if dur != "keep":
            self._dur_filter = dur
        if time_range != "keep":
            self._time_filter = time_range
        if on_complete:
            self._refresh_files(on_complete=on_complete)
        else:
            self._refresh_files()

    def _resolve_key_for_current(self):
        """このファイルの復号鍵を決定: CSM優先 → ユーザ → 周波数、無ければ 0(平文)。
        ただし秘話フラグが「平文」と確定している録音は、紐づけ鍵があっても無視して 0 を返す
        (平文を鍵で復号すると壊れるため。同じ局でもこの交信だけ平文、というケースに対応)。"""
        summary = self._edu_summary(self.curpath) if getattr(self, "curpath", None) else None
        return self._resolve_recording_key(self.freq, self.csm, self.secret, summary)

    @staticmethod
    def _resolve_recording_key(freq, csm, secret, summary):
        if secret is False:
            return 0
        by_csm, by_freq, by_user = load_manual_keys_full()
        if csm and csm in by_csm:
            return by_csm[csm]
        if summary and summary["uc"] in by_user:
            return by_user[summary["uc"]]
        if freq in by_freq:
            return by_freq[freq]
        return 0

    def _on_file_dclick(self, event):
        idx = self.filelist.nearest(event.y)
        if idx < 0 or idx >= len(self.files):
            return
        self.filelist.selection_clear(0, tk.END)
        self.filelist.selection_set(idx)
        self.filelist.activate(idx)
        self._on_file(None, autoplay=True)

    def _autoplay_loaded(self):
        if not self.frames:
            return
        key = self.keyvar.get()
        if key > 0:
            self._play_key(key)
        elif self.secret is True:
            self._msg("秘話キー解析は無効です。再生するには既知のキーを入力してください。")
        else:
            self.keyvar.set(0)
            self._play_key(0)

    def _on_file(self, _evt, autoplay=False):
        sel = self.filelist.curselection()
        if not sel:
            return
        active = self.filelist.index(tk.ACTIVE)
        path = self.files[active if active in sel else sel[0]]
        if self._loading_path == path:
            self._load_autoplay = self._load_autoplay or autoplay
            return
        if path == getattr(self, "curpath", None) and self.frames is not None:
            if not autoplay:
                return
        if hasattr(self, "_search_gen"):
            self._search_gen += 1
            self._set_search_state(False, "録音を読み込み中…")
        self._stop_play()
        self._file_gen += 1
        gen = self._file_gen
        self._loading_path = path
        self._load_autoplay = autoplay
        self._load_play_request = None
        self.frames = None
        self.curpath = path
        self._cur_pcm = self._cur_raw_pcm = self._cur_quality = self._cur_play = None
        self._play_pcm = None
        self._draw_spectrogram()
        self.info.config(text=f"読み込み中: {os.path.basename(path)}")
        self.candlist.delete(0, tk.END)
        if hasattr(self, "key_target"):
            self.preview_candidate_btn.configure(state=tk.DISABLED)
            self._update_key_target()
        self._msg("録音を読み込み中...")

        def work():
            try:
                recording = read_raw(path)
                if gen != self._file_gen:
                    return
                summary = self._edu_summary(path)
                freq, frames, csm, secret = recording
                known = self._resolve_recording_key(freq, csm, secret, summary)
                # 表示用の品質解析も Tk スレッドを止めずに済ませる。
                crc, um = self._edu_crc_summary(path), self._user_maker_text(path)
                note = self._data_comm_note(path)
            except Exception as exc:
                self._post(lambda e=exc: self._file_load_failed(gen, path, e))
                return
            self._post(lambda: self._file_loaded(gen, path, recording, known, crc, um, note))

        threading.Thread(target=work, name="recording-load", daemon=True).start()

    def _file_load_failed(self, gen, path, exc):
        if gen != self._file_gen:
            return
        self._loading_path = None
        self._load_autoplay = False
        self._load_play_request = None
        self.frames = None
        self.curpath = None
        if isinstance(exc, FileNotFoundError):
            self._msg(f"このファイルは自動破棄されました(短信号/CRC無し): {os.path.basename(path)}")
            self._refresh_files()
        else:
            self._msg(f"読込失敗: {exc}")
        self.info.config(text="録音を選択してください")
        if hasattr(self, "key_target"):
            self._set_search_state(False, "読み込みに失敗しました。別の録音を選択してください。")
            self._update_key_target()

    def _file_loaded(self, gen, path, recording, known, crc, um, note):
        if gen != self._file_gen:
            return
        self._loading_path = None
        self.freq, self.frames, self.csm, self.secret = recording
        self.curpath = path
        dur = len(self.frames) * 4 * 160 / 8000
        ch = frequency_label(self.freq)
        alias = self.alias.get(self.csm, "")
        csmdisp = f"{self.csm}({alias})" if alias else (self.csm or "-")
        # 秘話フラグ(v03 ヘッダの SACCH通話識別由来): True=秘話 / False=平文 / None=不明
        sec = "秘話" if self.secret is True else "平文" if self.secret is False else "不明"
        self.info.config(text=f"{self.freq/1e6:.5f}MHz  {ch}   CSM: {csmdisp}   秘話: {sec}\n"
                              f"{len(self.frames)}フレーム  {dur:.2f}秒   {crc}\n"
                              f"{um}")
        self.candlist.delete(0, tk.END)
        # 録音の周波数によらずキー探索は無効。
        if getattr(self, "force_btn", None) is not None:
            self.force_btn.config(state=tk.DISABLED)
        self.restore_btn.config(state=tk.NORMAL if self.csm and self.freq else tk.DISABLED)
        # 選択した時点で、manual_keys.csv の既知鍵を手動キー欄に反映(登録済みなら探索不要)。
        self.keyvar.set(known)
        if hasattr(self, "key_target"):
            self._set_search_state(False, "未探索。候補は耳で確認してください。")
            self._update_key_target()
        kmsg = f"  [登録済み鍵={known}]" if known > 0 else ""
        self._msg(f"読込: {os.path.basename(path)}{kmsg}")
        # データ通信は音声にならないので注意を出す(edu の M で判定)。
        if note:
            self._msg(note)
        request, autoplay = self._load_play_request, self._load_autoplay
        self._load_play_request = None
        self._load_autoplay = False
        if request is not None:
            self.keyvar.set(request[0])
            self._play_key(request[0], start_frac=request[1])
        elif autoplay:
            self._autoplay_loaded()

    def _edu_summary(self, raw_path):
        """edu(jsonl)を1回だけ解析し、要約を返す(mtime キーでキャッシュ)。edu 無しは None。
        {tot, okc, okp, crc_pct, voice, traffic, uc, mk} を持つ。多数ファイルでの重さ対策の要。"""
        base = os.path.splitext(os.path.basename(raw_path))[0]
        if base in self._edu_path_cache:
            ep = self._edu_path_cache[base]
        else:
            ep = _edu_path(base)
            self._edu_path_cache[base] = ep
        if not ep:
            return None
        try:
            mt = os.path.getmtime(ep)
        except OSError:
            return None
        cached = self._edu_cache.get(ep)
        if cached and cached[0] == mt:
            return cached[1]
        tot = okc = okp = voice = traffic = 0
        ucs = {}; mks = {}
        try:
            for line in open(ep, encoding="utf-8-sig"):
                line = line.strip()
                if not line:
                    continue
                try:
                    o = json.loads(line)
                except Exception:
                    continue
                if o.get("type") == "header":
                    continue
                tot += 1
                s = o.get("sacch") or {}
                r = o.get("rich") or {}
                sc = bool(s.get("crcOK")); pk = bool(r.get("parityOK"))
                if sc: okc += 1
                if pk: okp += 1
                if o.get("F") == 1 and pk:
                    traffic += 1
                    if r.get("M") in (1, 2, 3):
                        voice += 1
                    if sc:   # 識別情報は RICH parity + SACCH CRC 両OKのみ(偽陽性除け)
                        uc = s.get("userCode"); mk = s.get("makerCode")
                        if isinstance(uc, int) and uc >= 0:
                            ucs[uc] = ucs.get(uc, 0) + 1
                        if isinstance(mk, int) and mk >= 0:
                            mks[mk] = mks.get(mk, 0) + 1
        except Exception:
            return None
        summ = {
            "tot": tot, "okc": okc, "okp": okp,
            "crc_pct": (100.0 * okc / tot if tot else None),
            "voice": voice, "traffic": traffic,
            "uc": (max(ucs, key=ucs.get) if ucs else None),
            "mk": (max(mks, key=mks.get) if mks else None),
        }
        self._edu_cache[ep] = (mt, summ)
        return summ

    def _data_comm_note(self, raw_path):
        """データ通信(音声枠がほぼ無い)なら注意文を返す。判定できない/音声主体なら ''。"""
        s = self._edu_summary(raw_path)
        if s is None or s["traffic"] == 0:
            return ""
        voice, traffic = s["voice"], s["traffic"]
        if voice / traffic < 0.2:
            return f"⚠ データ通信の可能性大(音声枠 {voice}/{traffic})。音声として再生できる見込みは低いです"
        return ""

    def _edu_crc_counts(self, raw_path):
        s = self._edu_summary(raw_path)
        return None if s is None else (s["tot"], s["okc"], s["okp"])

    def _edu_crc_pct(self, raw_path):
        s = self._edu_summary(raw_path)
        return None if s is None else s["crc_pct"]

    def _edu_user_maker(self, raw_path):
        s = self._edu_summary(raw_path)
        return (None, None) if s is None else (s["uc"], s["mk"])

    def _user_maker_text(self, raw_path):
        """情報欄用の「ユーザ: N   メーカ: N(名称)」文字列。unknown は --。"""
        uc, mk = self._edu_user_maker(raw_path)
        utxt = "--" if uc is None else self._user_label(uc)   # UC=0 は一斉(全体呼出)
        if mk is None:
            mtxt = "--"
        else:
            name = self.makers.get(mk)
            mtxt = f"{mk}({name})" if name else str(mk)
        return f"ユーザ: {utxt}   メーカ: {mtxt}"

    @staticmethod
    def _crc_color(pct):
        """CRC OK率→ファイル名色(信号品質の色分け)。良好は緑にして既定文字色(薄灰)や
        デバッグ記録なし(灰)と明確に区別する。赤(不良)→黄→青→緑(良好)。"""
        if pct is None:
            return "#6b7280"          # CRC不明(デバッグ記録なし): 暗めグレーで目立たせない
        if pct <= 50:
            return "#b42318"          # 赤: 聞き取り困難
        if pct <= 70:
            return "#956300"          # 黄: やや不良
        if pct <= 80:
            return "#1763ae"          # 青: 良
        return "#217a45"             # 緑: 良好(白だと既定色と紛れるため緑に)

    def _edu_crc_summary(self, raw_path):
        c = self._edu_crc_counts(raw_path)
        if c is None:
            return "CRC: デバッグ記録なし"
        tot, okc, okp = c
        if tot == 0:
            return "CRC: フレームなし"
        return f"CRC OK {100*okc/tot:.0f}%  (RICH {100*okp/tot:.0f}%, {tot}f)"

    def _decode(self, key):
        return np.array(decode_to_pcm(self.frames, key), dtype=np.int16)

    # ---- 受信と同じ処理での再生 ----
    def _sync_live_widgets(self):
        self.crccb.config(state=tk.DISABLED if self.livevar.get() else "readonly")
        state = tk.NORMAL if self.livevar.get() else tk.DISABLED
        self.live_mutecb.config(state=state)
        for check in self.live_opt_checks.values():
            check.configure(state=state)

    def _codec(self):
        """試聴用の復号器(独自AMBE+2)。1 回の再生ごとに新しく作り、先頭から順に処理する。"""
        return IndependentCodec()

    def _live_changed(self):
        self._cfg["live_mode"] = bool(self.livevar.get())
        self._cfg["live_receiver_mute"] = bool(self.live_mutevar.get())
        self._cfg["live_opts"] = {name: bool(var.get()) for name, var in self.live_opt_vars.items()}
        save_config(self._cfg)
        self._sync_live_widgets()
        if self.frames:
            self._play_key(self._listen_key())

    def _listen_key(self):
        """The key last played for the loaded recording, else the key field."""
        if getattr(self, "_last_key_path", None) == self.curpath:
            return self._last_key
        try:
            return int(self.keyvar.get())
        except (tk.TclError, ValueError):
            return 0

    def _live_options(self):
        """受信中の音声設定 + このツールのオプションのチェック。"""
        options = dict(AudioSettings(AUDIO_SETTINGS_JSON, DATA_DIR).poll(0))
        options.update({name: bool(var.get()) for name, var in self.live_opt_vars.items()})
        options["listen_preserve_audio"] = not bool(self.live_mutevar.get())
        if self._following_volume():
            # Listening owns the volume follower; do not cascade receiver AGC.
            options["speaker_agc"] = False
        return options

    def _current_edu_rows(self, path=None):
        path = path or self.curpath
        if not path:
            return None
        edu = _edu_path(os.path.splitext(os.path.basename(path))[0])
        return load_edu_rows(edu) if edu else None

    def _play_key_live(self, key, gen):
        frames, secret = self.frames, self.secret
        path = self.curpath
        options = self._live_options()     # Tk変数はメインスレッドで読む
        srcj = "平文" if key == 0 else f"鍵{key}"
        self._msg(f"受信と同じ処理で作成中... ({srcj})")
        # 最初は160ms分、その後は約2秒分ずつ作る。
        progressive = self._ensure_player()
        player = self._play if progressive else None
        vol, use_norm = self.volvar.get() / 100.0, self.normvar.get()
        use_follow = self._following_volume()
        self._cur_play = None

        def work(rows, total, played, token):
            out8, out48 = [], []
            normalizer = _ListeningVolume(LIVE_RATE, use_norm, use_follow, 1.0 if progressive else vol)
            filled, started = 0, False
            try:
                for c8, c48 in live_render_chunks(frames, rows, key, options, secret,
                                                 first_chunk_frames=2):
                    if gen != self._decode_gen:
                        return   # 新しい再生要求 → 破棄
                    out8.append(c8)
                    out48.append(c48)
                    if not progressive:
                        continue
                    play_c = normalizer.process(c48)
                    n = min(len(play_c), total - filled)
                    if gen != self._decode_gen:
                        return
                    played[filled:filled + n] = play_c[:n]
                    player.append(play_c[:n], token)
                    filled += n
                    if not started:
                        started = True
                        self._post(lambda: self._start_stream_ui(gen, f"{srcj} 受信と同じ処理"))
                if progressive:
                    if gen != self._decode_gen:
                        return
                    player.finish_stream(token)
            except Exception as exc:
                self._post(lambda e=exc: self._decode_failed(gen, e))
                return
            pcm8 = np.concatenate(out8) if out8 else np.zeros(0, dtype=np.int16)
            pcm48 = np.concatenate(out48) if out48 else np.zeros(0, dtype=np.int16)

            def done():
                if gen != self._decode_gen:
                    return
                self._cur_raw_pcm = None    # CRC処理の掛け直しはこのモードでは使わない
                self._cur_quality = None
                self._cur_key = key
                self._cur_pcm = pcm8        # AI強調などは 8kHz の音を使う
                self._cur_play = (pcm48, LIVE_RATE, use_follow)
                self._render_pending = False
                on = [label for name, label in LIVE_OPTIONS if options.get(name)]
                avail = live_available(rows)
                missing = [label for name, label in LIVE_OPTIONS
                           if options.get(name) and avail.get(name) is False]
                note = f"  ※この録音では効果なし: {'・'.join(missing)}" if missing else ""
                if rows is None:
                    note += "  ※デバッグ記録(edu)なし: CRC/欠落の情報なしで処理"
                if options.get("listen_preserve_audio"):
                    note += "  [受信時のミュートなし・選択した鍵/平文で試聴]"
                self._msg(f"試聴 {srcj} 受信と同じ処理 [オン: {'・'.join(on) or 'なし'}]{note}")
                if progressive:
                    self._play_pcm = played[:filled]   # 再生中の音はそのまま。表示を確定
                    self._draw_spectrogram()
                else:
                    self._render_and_play(pcm48, LIVE_RATE, use_follow)
            self._post(done)

        def prepare():
            try:
                rows = self._current_edu_rows(path)
                if gen != self._decode_gen:
                    return
                total = live_max_frames(frames, rows) * SAMPLES_PER_FRAME * (LIVE_RATE // 8000)
                played = np.zeros(total, dtype=np.int16) if progressive else None
                buffer = np.zeros(total, dtype=np.int16) if progressive else None
            except Exception as exc:
                self._post(lambda e=exc: self._decode_failed(gen, e))
                return

            def begin():
                if gen != self._decode_gen:
                    return
                token = None
                if progressive:
                    self._play_pcm, self._play_rate, self._play_src = played, LIVE_RATE, path
                    player.set_volume(self.volvar.get() / 100.0)
                    token = player.start_stream(LIVE_RATE, total, pcm=buffer)
                threading.Thread(target=lambda: work(rows, total, played, token), daemon=True).start()
            self._post(begin)

        threading.Thread(target=prepare, name="recording-prepare", daemon=True).start()

    def _play_plain(self, pcm, rate):
        """スペクトログラムや再生バーの表示を変えずに鳴らす(ブラインド比較用)。"""
        play = np.asarray(pcm, dtype=np.int16)
        if self._ensure_player():
            self._play.set_volume(self.volvar.get() / 100.0)
            self._play.load(play, rate)
            self._play.play(restart=True)
        else:
            play = np.clip(play.astype(np.float64) * (self.volvar.get() / 100.0), -32768, 32767).astype(np.int16)
            with wavemod.open(self._tmp, "wb") as wf:
                wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(rate)
                wf.writeframes(play.tobytes())
            winsound.PlaySound(self._tmp, winsound.SND_FILENAME | winsound.SND_ASYNC)

    def _crc_mode(self):
        lab = self.crcvar.get()
        return next((k for k, l in CRC_MODES if l == lab), "raw")

    def _apply_crc(self):
        """原音に CRCエラー処理を掛けて _cur_pcm を作り、結果の説明文を返す。"""
        mode = self._crc_mode()
        pcm, (n_bad, n_data) = conceal_pcm(self._cur_raw_pcm, self._cur_quality, mode)
        self._cur_pcm = pcm
        if mode == "raw":
            return ""
        if n_bad is None:
            return "  [CRC処理なし: デバッグ記録(edu)が無い/対応不一致]"
        n = len(self._cur_quality)
        known = sum(1 for x in self._cur_quality if x is not None)
        empty = " ※全フレームCRCエラーのため音なし" if n_bad == n and mode in ("skip", "mute") else ""
        part = f" ※edu は先頭 {known}/{n} フレームのみ(以降はそのまま)" if known < n else ""
        return f"  [CRCエラー {n_bad}/{known}フレーム→{self.crcvar.get()} / データ枠 {n_data}無音]{empty}{part}"

    def _reapply_crc(self):
        """処理方法を切り替えたら、直近の原音に掛け直して再生。"""
        if self._cur_raw_pcm is None:
            return
        note = self._apply_crc()
        self._msg(f"CRCエラー音声: {self.crcvar.get()}{note}")
        self._render_and_play(self._cur_pcm)

    def _play_key(self, key, start_frac=None):
        if getattr(self, "_loading_path", None):
            self._load_play_request = (key, start_frac)
            return
        if not self.frames:
            return
        self._decode_gen += 1
        gen = self._decode_gen
        if self._play is not None and self._play.available:
            self._play.stop()
        self._play_pcm = None
        self._draw_spectrogram()
        self._render_pending = True
        self._last_key, self._last_key_path = key, self.curpath
        if hasattr(self, "play_source"):
            self.play_source.configure(text=f"再生キー: {'平文' if key == 0 else key}")
        if self.livevar.get():
            self._play_key_live(key, gen)
            return
        self._cur_play = None
        # sounddevice が使えるなら「先頭から順に復号しながら即再生」(長い録音でも待たない)。
        # 使えない環境は従来どおり全復号してから winsound 再生。
        if self._ensure_player():
            self._play_key_progressive(key, gen, start_frac)
        else:
            self._play_key_whole(key, gen)

    def _play_key_progressive(self, key, gen, start_frac=None):
        frames = self.frames
        path = self.curpath
        self._play_src = path        # いま再生バーに載っている音がどのファイル由来か
        total = len(frames) * SAMPLES_PER_FRAME
        target = min(max(0, total - 1), int(max(0.0, min(1.0, start_frac)) * total)) if start_frac else 0
        mode = self._crc_mode()
        srcj = "平文" if key == 0 else f"鍵{key}"
        self._msg(f"再生準備中... ({srcj})")
        player = self._play
        use_norm = self.normvar.get()   # Tk変数はメインスレッドで読む(ワーカーから触らない)
        use_follow = self._following_volume()
        CHUNK = 32   # 開始後は大きい単位で処理して効率を保つ

        def work(quality, codec, played, raw_all, prepared_all, token):
            normalizer = _ListeningVolume(8000, use_norm, use_follow, 1.0)
            rfilled = 0   # raw_all の書き込み位置
            filled = 0    # played/player の書き込み位置(skipモードで raw と異なる)
            started = False
            try:
                fi = 0
                while fi < len(frames):
                    if gen != self._decode_gen:
                        return   # 新しい再生要求 → 破棄
                    size = 2 if fi == 0 else CHUNK
                    fchunk = frames[fi:fi + size]
                    raw_c = np.array(decode_to_pcm(fchunk, key, codec), dtype=np.int16)
                    raw_all[rfilled:rfilled + len(raw_c)] = raw_c
                    rfilled += len(raw_c)
                    # CRC処理(このチャンク分の品質で)
                    q_c = quality[fi:fi + len(fchunk)] if quality is not None else None
                    proc, _ = conceal_pcm(raw_c, q_c, mode)
                    proc = np.asarray(proc, dtype=np.int16)
                    play_c = normalizer.process(proc)
                    n = min(len(play_c), total - filled)
                    if gen != self._decode_gen:
                        return
                    prepared_all[filled:filled + n] = proc[:n]
                    played[filled:filled + n] = play_c[:n]
                    player.append(play_c[:n], token)
                    filled += n
                    # クリック開始位置(target)まで復号できたら、そこから再生を始める。
                    if not started and filled > target:
                        started = True
                        self._post(lambda: self._start_stream_ui(gen, srcj, start_frac))
                    fi += len(fchunk)
                if gen != self._decode_gen:
                    return
                if not started and filled:
                    self._post(lambda: self._start_stream_ui(gen, srcj, start_frac))
                player.finish_stream(token)
                completed_pcm, _ = conceal_pcm(raw_all, quality, mode)
                voice_stats = voiced_frac(raw_all)
                if gen == self._decode_gen:
                    self._post(lambda: self._finish_progressive(gen, key, raw_all, quality, srcj,
                                                               prepared_all[:filled], completed_pcm, voice_stats))
            except Exception as exc:
                self._post(lambda e=exc: self._decode_failed(gen, e))

        def prepare():
            try:
                quality = edu_frame_quality(path, len(frames)) if path else None
                codec = self._codec()
                if gen != self._decode_gen:
                    return
                played, raw_all, prepared_all, buffer = [np.zeros(total, dtype=np.int16) for _ in range(4)]
            except Exception as exc:
                self._post(lambda e=exc: self._decode_failed(gen, e))
                return

            def begin():
                if gen != self._decode_gen:
                    return
                self._play_pcm, self._play_rate = played, 8000
                player.set_volume(self.volvar.get() / 100.0)
                token = player.start_stream(8000, total, pcm=buffer)
                threading.Thread(target=lambda: work(quality, codec, played, raw_all, prepared_all, token),
                                 daemon=True).start()
            self._post(begin)

        threading.Thread(target=prepare, name="recording-prepare", daemon=True).start()

    def _decode_failed(self, gen, exc):
        if gen != self._decode_gen:
            return
        self._stop_play()
        self._msg(f"復号失敗: {exc}")

    def _start_stream_ui(self, gen, srcj, start_frac=None):
        if gen != self._decode_gen:
            return
        if start_frac:
            self._play.seek_frac(start_frac)
            self._play.play(restart=False)   # クリック位置から再生
        else:
            self._play.play(restart=True)
        self.playbtn.config(text="⏸ 一時停止")
        self._draw_spectrogram()
        pos = " (クリック位置から)" if start_frac else ""
        self._msg(f"試聴 {srcj}{pos} (再生開始・残りを復号中...)")

    def _finish_progressive(self, gen, key, raw_all, quality, srcj, prepared_pcm=None,
                            completed_pcm=None, voice_stats=None):
        if gen != self._decode_gen:
            return
        # 全復号完了 → 原音/品質を確定(AI強調・CRC再適用・スライダ再生が正しく効くように)。
        self._cur_raw_pcm = raw_all
        self._cur_quality = quality
        self._cur_key = key
        if completed_pcm is None:
            self._apply_crc()
        else:
            self._cur_pcm = completed_pcm
        # Toggle/volume replay starts from unadjusted PCM, never the AGC output.
        self._cur_play = (prepared_pcm if prepared_pcm is not None else self._cur_pcm, 8000)
        self._render_pending = False
        self._draw_spectrogram()      # 全体のスペクトログラムに更新
        na, frac = voice_stats if voice_stats is not None else voiced_frac(raw_all)
        self._msg(f"復号完了 {srcj} (有声率{frac:.2f} ※参考)")

    def _play_key_whole(self, key, gen):
        frames = self.frames
        path = self.curpath
        codec = self._codec()
        self._msg(f"復号中... ({'平文' if key == 0 else '鍵'+str(key)})")

        def work():
            try:
                raw = np.array(decode_to_pcm(frames, key, codec), dtype=np.int16)
                q = edu_frame_quality(path, len(frames)) if path else None
            except Exception as exc:
                self._post(lambda exc=exc: self._decode_failed(gen, exc))
                return

            def done():
                if gen != self._decode_gen:
                    return
                self._cur_raw_pcm = raw
                self._cur_quality = q
                self._cur_key = key
                note = self._apply_crc()
                na, frac = voiced_frac(raw)
                vol = " 音量追従" if self._following_volume() else " 音量自動" if self.normvar.get() else ""
                self._msg(f"試聴 {'平文' if key == 0 else '鍵'+str(key)}  (有声率{frac:.2f} ※参考){vol}{note}")
                self._render_and_play(self._cur_pcm)
            self._post(done)

        threading.Thread(target=work, daemon=True).start()

    def _render_and_play(self, pcm, rate=8000, live_norm=None):
        """原音に 自動調整(任意)→ 手動音量(スライダ) を掛け、再生バーに載せて再生。
        sounddevice があればシーク可能に、無ければ winsound で従来どおり再生する。"""
        source = np.asarray(pcm, dtype=np.int16)
        self._cur_play = (source, rate, live_norm)
        self._render_pending = False
        play = (adjust_listening_volume(source, rate) if self._following_volume()
                else normalize_speech(source) if self.normvar.get() else source)
        self._play_pcm = play
        self._play_rate = rate
        self._play_src = getattr(self, "curpath", None)   # 再生中の音の由来ファイル
        self._draw_spectrogram()
        if self._ensure_player():
            self._play.set_volume(self.volvar.get() / 100.0)
            self._play.load(play, rate)
            self._play.play(restart=True)
            self.playbtn.config(text="⏸ 一時停止")
        else:
            play = np.clip(play.astype(np.float64) * (self.volvar.get() / 100.0), -32768, 32767).astype(np.int16)
            with wavemod.open(self._tmp, "wb") as wf:
                wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(rate)
                wf.writeframes(play.tobytes())
            winsound.PlaySound(self._tmp, winsound.SND_FILENAME | winsound.SND_ASYNC)

    # ---- 再生バー(シーク + スペクトログラム) ----
    def _ensure_player(self):
        """SeekPlayer を用意。sounddevice が無ければ初回だけ裏で自動インストールを試みる。"""
        if self._play is None:
            self._play = SeekPlayer()
            if not self._play.available and not self._sd_tried:
                self._sd_tried = True
                self._msg("sounddevice を自動インストール中... 完了後の再生からシーク可能になります")
                threading.Thread(target=self._install_sd, daemon=True).start()
        return self._play is not None and self._play.available

    def _install_sd(self):
        if self._ensure_pip_package("sounddevice", "sounddevice"):
            def done():
                self._play = SeekPlayer()
                self._msg("sounddevice 準備完了。次の再生からシークできます")
            self._post(done)

    def _toggle_play(self):
        key = self._read_key()
        if key is None:
            return
        same_key = (getattr(self, "_last_key_path", None) == getattr(self, "curpath", None)
                    and getattr(self, "_last_key", None) == key)
        if self._ensure_player() and self._play_pcm is not None and same_key:
            self._play.toggle()
            self.playbtn.config(text="⏸ 一時停止" if self._play.playing else "▶ 再生")
        else:
            self._play_key(key)

    def _stop_play(self):
        self._decode_gen += 1
        self._render_pending = False
        self._load_autoplay = False
        self._load_play_request = None
        if self._play is not None and self._play.available:
            self._play.stop()
        else:
            try: winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception: pass
        self.playbtn.config(text="▶ 再生")
        self._draw_playhead(); self._update_time()

    def _seek_click(self, e):
        self._seek_fraction(e.x / max(1, self.seek.winfo_width()))

    def _seek_scale(self, value):
        if not self._setting_seek:
            self._seek_fraction(float(value) / 100)

    def _seek_fraction(self, frac):
        if not (self._play is not None and self._play.available):
            return
        frac = min(max(frac, 0.0), 1.0)
        if self._play_pcm is not None and self._play_src == getattr(self, "curpath", None):
            # いま載っている音=このファイル → その位置へシークして再生(終了後でも再開)。
            self._play.seek_frac(frac)
            if not self._play.playing:
                self._play.play(restart=False)
            self.playbtn.config(text="⏸ 一時停止" if self._play.playing else "▶ 再生")
            self._draw_playhead(); self._update_time()
        elif self.frames:
            # まだ再生していない/別ファイルを選んだ状態 → このファイルをクリック位置から再生。
            key = self._read_key()
            if key is not None:
                self._play_key(key, start_frac=frac)

    def _update_time(self):
        if self._play is not None and self._play.available and self._play_pcm is not None:
            p, d = self._play.position_sec(), self._play.duration()
        else:
            p = 0.0
            d = (len(self._play_pcm) / self._play_rate) if self._play_pcm is not None else 0.0
        self.timelbl.config(text=f"{int(p//60)}:{int(p%60):02d} / {int(d//60)}:{int(d%60):02d}")
        if hasattr(self, "seekvar"):
            self._setting_seek = True
            try:
                self.seekvar.set(100 * p / d if d else 0)
            finally:
                self._setting_seek = False
            can_seek = bool(self._play is not None and self._play.available and self.frames)
            self.seekbar.configure(state=tk.NORMAL if can_seek else tk.DISABLED)
            key = getattr(self, "_last_key", None)
            same_file = getattr(self, "_last_key_path", None) == getattr(self, "curpath", None)
            self.play_source.configure(text=(f"再生キー: {'平文' if key == 0 else key}" if same_file and key is not None else "再生キー: —"))

    def _playhead_tick(self):
        try:
            if self._play is not None and self._play.available and self._play_pcm is not None:
                self._draw_playhead(); self._update_time()
                self.playbtn.config(text="⏸ 一時停止" if self._play.playing else "▶ 再生")
        except Exception:
            pass
        self.after(60, self._playhead_tick)

    def _draw_playhead(self):
        c = self.seek
        w = int(c.winfo_width()); h = int(c.winfo_height())
        c.delete("ph")
        if self._play_pcm is None or w < 2:
            return
        frac = self._play.position_frac() if (self._play is not None and self._play.available) else 0.0
        x = int(frac * w)
        c.create_line(x, 0, x, h, fill="#ff4b4b", width=1, tags="ph")

    def _draw_spectrogram(self):
        self._spec_gen += 1
        gen = self._spec_gen
        c = self.seek
        w = int(c.winfo_width()); h = int(c.winfo_height())
        if w < 10 or h < 10:
            return
        c.delete("all")
        self._spec_img = None
        pcm = self._play_pcm
        rate = self._play_rate
        self._draw_playhead()
        if pcm is None or len(pcm) < 256:
            return

        def work():
            # 連打時は最新の描画だけ計算する。Tk操作は完了通知側だけ。
            with self._spec_lock:
                if gen != self._spec_gen:
                    return
                try:
                    im = self._spectrogram_image(pcm, rate, w, h)
                except Exception:
                    return
            self._post(lambda: self._show_spectrogram(gen, im))

        threading.Thread(target=work, name="recording-spectrogram", daemon=True).start()

    @staticmethod
    def _spectrogram_image(pcm, rate, width, height):
        from scipy.signal import spectrogram as _spec
        import matplotlib.cm as cm
        import PIL.Image
        # 計算量を制限し、復号中の配列は小さなスナップショットで読む。
        step = len(pcm) // 240000 + 1 if len(pcm) > 240000 else 1
        src = pcm[::step].astype(np.float64)
        f, t, S = _spec(src, fs=rate / step, nperseg=256, noverlap=192)
        S = 10.0 * np.log10(S + 1e-6)
        lo, hi = np.percentile(S, 5), np.percentile(S, 99)
        S = np.clip((S - lo) / max(1e-6, hi - lo), 0.0, 1.0)
        rgb = (cm.magma(np.flipud(S))[..., :3] * 255).astype(np.uint8)
        return PIL.Image.fromarray(rgb).resize((width, height))

    def _show_spectrogram(self, gen, im):
        if gen != self._spec_gen:
            return
        import PIL.ImageTk
        self._spec_img = PIL.ImageTk.PhotoImage(im, master=self.seek)
        self.seek.delete("all")
        self.seek.create_image(0, 0, anchor="nw", image=self._spec_img)
        self._draw_playhead()

    def _manual_volume_changed(self, *_args):
        if self._play is not None and self._play.available:
            self._play.set_volume(self.volvar.get() / 100.0)
        elif getattr(self, "_cur_play", None) is not None:
            # winsound は実行中の音量変更APIを持たないため従来の再生を使用。
            self._replay()

    def _following_volume(self):
        return bool(self.normvar.get() and self.followvar.get())

    def _sync_volume_widgets(self):
        self.followcb.config(state=tk.NORMAL if self.normvar.get() else tk.DISABLED)

    def _volume_changed(self):
        self._sync_volume_widgets()
        self._replay()

    def _replay(self):
        """自動調整トグル変更時に、直近の音声を掛け直して再生。"""
        if getattr(self, "_render_pending", False):
            self._play_key(self._listen_key())
            return
        if self._cur_play is not None:
            live_norm = self._cur_play[2] if len(self._cur_play) > 2 else None
            if live_norm is not None and live_norm != self._following_volume():
                # The upstream AGC changes with this switch: regenerate from
                # frames instead of playing cached PCM from the other setting.
                self._play_key(self._listen_key())
                return
            self._render_and_play(*self._cur_play)
        elif self._cur_pcm is not None:
            self._render_and_play(self._cur_pcm)

    def _play_enhanced(self, path):
        r"""強調後WAV(44.1kHz等)を、音量自動調整+スライダーを適用して再生。
        原PCMと違いレートが可変なので専用に処理する。保存物(rec\_enh_*)は無加工のまま。"""
        try:
            with wavemod.open(path, "rb") as wf:
                rate = wf.getframerate(); ch = wf.getnchannels()
                pcm = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16)
            if ch > 1:
                pcm = pcm.reshape(-1, ch).mean(axis=1).astype(np.int16)
            # 音量自動調整・スライダーは _render_and_play が適用する。原音(mono)を渡す。
            self._render_and_play(pcm, rate)
        except Exception:
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)

    # ---- AI音声強調 (VoiceFixer) ----
    def _vf_startup_changed(self):
        """次回起動時の事前ロード設定を保存。読み込み済みのモデルには触れない。"""
        enabled = bool(self.vf_startupvar.get())
        self._cfg["voicefixer_preload"] = enabled
        save_config(self._cfg)
        self._msg(f"VoiceFixerの起動時読み込み: {'有効' if enabled else '無効'}（次回起動から反映）")

    @staticmethod
    def _vf_models_present():
        """VoiceFixer のモデルがローカルに揃っているか(DL せずに確認)。"""
        home = os.path.expanduser("~")
        specs = [
            (os.path.join(home, ".cache/voicefixer/analysis_module/checkpoints/vf.ckpt"), 400_000_000),
            (os.path.join(home, ".cache/voicefixer/synthesis_module/44100/model.ckpt-1490000_trimed.pt"), 100_000_000),
        ]
        return all(os.path.exists(p) and os.path.getsize(p) >= n for p, n in specs)

    def _prewarm_vf(self):
        """起動時: voicefixer が導入済みでモデルもあれば、裏で VoiceFixer を構築しておく。
        未導入・モデル無しの場合は何もしない(初回強調時に導入する)。"""
        try:
            import importlib.util
            if importlib.util.find_spec("voicefixer") is None:
                return
            if not self._vf_models_present():
                return
        except Exception:
            return
        self._load_voicefixer(prewarm=True)

    def _load_voicefixer(self, prewarm=False):
        """VoiceFixer を構築して self._vf に入れる(排他)。成功=True。"""
        with self._vf_lock:
            if self._vf is not None:
                return True
            try:
                self._post(lambda: self._msg("VoiceFixer 読込中..." + (" (起動時の事前ロード)" if prewarm else "")))
                from voicefixer import VoiceFixer
                vf = VoiceFixer()
                self._vf = vf
                self._post(lambda: self._msg("VoiceFixer 準備完了"))
                return True
            except Exception as exc:
                if not prewarm:
                    self._post(lambda exc=exc: self._msg(f"VoiceFixer 読込失敗: {exc}"))
                return False

    def _enhance(self):
        if not self.frames or not getattr(self, "curpath", None):
            return
        if self._cur_pcm is None:
            self._msg("先にファイルを再生してください。『その再生音(平文/鍵)』を強調します。")
            return
        # 同じ音(ファイル・鍵・CRC処理)の強調結果があれば、再実行せず即再生。
        ck = (self.curpath, self._cur_key, self._crc_mode())
        cached = self._enh_cache.get(ck)
        if cached and os.path.exists(cached):
            self._msg("AI音声強調(キャッシュ)を再生します")
            self._play_enhanced(cached)
            return
        src = "平文" if self._cur_key == 0 else f"鍵{self._cur_key}"
        self._msg(f"AI音声強調 準備中... 対象=直前の再生音【{src}】 (初回は導入/モデルDLで時間)")
        threading.Thread(target=self._enhance_bg, args=(ck,), daemon=True).start()

    def _ensure_pip_package(self, module, package):
        """他環境向け: module が無ければ pip で自動インストールして import する。
        成功=True。ネット必要。初回のみ時間がかかる。"""
        import importlib
        try:
            importlib.import_module(module)
            return True
        except ImportError:
            pass
        self._post(lambda: self._msg(
            f"{package} を自動インストール中... (初回のみ・ネット必要・数分かかります)"))
        import subprocess
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", package],
                           check=True, capture_output=True, text=True, timeout=3600)
        except Exception as exc:
            self._post(lambda: self._msg(
                f"{package} 自動インストール失敗: {exc}. 手動: python -m pip install {package}"))
            return False
        try:
            importlib.invalidate_caches()
            importlib.import_module(module)
            return True
        except ImportError:
            self._post(lambda: self._msg(f"{package} インストール後も読込できません"))
            return False

    def _ensure_voicefixer_models(self):
        """他環境向け: VoiceFixer のモデル(vf.ckpt / vocoder)が欠落/破損していたら
        信頼できる HuggingFace ミラーから取得する。VoiceFixer 標準の Zenodo 自動DLは
        403/途中切れが多く壊れたckptを掴むため、ここで検証して確実に入れ直す。"""
        import zipfile, urllib.request
        home = os.path.expanduser("~")
        HF = "https://huggingface.co/Diogodiogod/voicefixer-models/resolve/main/"
        specs = [
            (os.path.join(home, ".cache/voicefixer/analysis_module/checkpoints/vf.ckpt"),
             HF + "vf.ckpt", 400_000_000, True),
            (os.path.join(home, ".cache/voicefixer/synthesis_module/44100/model.ckpt-1490000_trimed.pt"),
             HF + "model.ckpt-1490000_trimed.pt", 100_000_000, False),
        ]
        for path, url, minsize, need_zip in specs:
            ok = (os.path.exists(path) and os.path.getsize(path) >= minsize
                  and (not need_zip or zipfile.is_zipfile(path)))
            if ok:
                continue
            self._post(lambda p=path: self._msg(f"モデルDL中: {os.path.basename(p)} (HFミラー, 数百MB)..."))
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = path + ".part"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
            if need_zip and not zipfile.is_zipfile(tmp):
                try: os.remove(tmp)
                except OSError: pass
                raise RuntimeError(f"モデルDLが不正: {os.path.basename(path)}")
            os.replace(tmp, path)
        return True

    def _enhance_bg(self, ck=None):
        try:
            if self._vf is None:
                if not self._ensure_pip_package("voicefixer", "voicefixer"):
                    return
                try:
                    self._ensure_voicefixer_models()
                except Exception as exc:
                    self._post(lambda exc=exc: self._msg(f"モデルDL失敗: {exc}"))
                    return
                if not self._load_voicefixer():
                    return
            # 直前に再生した音(平文 or 特定鍵)そのものを強調対象にする。
            pcm = self._cur_pcm
            ckey = self._cur_key
            if pcm is None:
                return
            src = "plain" if ckey == 0 else f"key{ckey}"
            srcj = "平文" if ckey == 0 else f"鍵{ckey}"
            tin = os.path.join(tempfile.gettempdir(), "std98_vf_in.wav")
            base = os.path.splitext(os.path.basename(self.curpath))[0]
            tout = os.path.join(_rec_day_dir(base), f"{base}_enh_{src}.wav")   # rec日付サブフォルダに、対象を名前に明記
            with wavemod.open(tin, "wb") as wf:
                wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(8000)
                wf.writeframes(np.asarray(pcm, dtype=np.int16).tobytes())
            self._post(lambda: self._msg(f"AI音声強調 実行中...【{srcj}】"))
            self._vf.restore(input=tin, output=tout, cuda=False, mode=0)
            if ck is not None:
                self._enh_cache[ck] = tout   # 同じ音の再強調は次回から即再生
            def done():
                self._msg(f"強調完了【{srcj}】→再生: {os.path.basename(tout)}")
                self._play_enhanced(tout)   # 音量自動調整+スライダーを適用して再生
            self._post(done)
        except ImportError:
            self._post(lambda: self._msg(
                "voicefixer 未インストール。radioconda で:  python -m pip install voicefixer"))
        except Exception as exc:
            self._post(lambda exc=exc: self._msg(f"AI強調エラー: {exc}"))

    def _search(self, pool=False, autoplay=False, force=False):
        self._set_search_state(False, "秘話キー解析は無効です。既知のキーを手入力してください。")
        self._msg("この版では秘話キー解析は使用できません。")

    def _search_bg(self, pool, autoplay, force, verify, gen, frames, csm, freq):
        # Capture the selected recording before starting. Both background and
        # queued UI results are invalidated on cancellation / recording switch.
        return


    def _show_candidates(self, tag, nblk, cands, checked, pending, play, force):
        """候補一覧を表示する。checked=独自AMBE+2で検証した(する)、pending=検証の途中、
        play=最有力候補を再生する。検証の途中経過と完了で 2 回呼ばれることがある。"""
        message = f"候補 {len(cands)} 件。" + ("声らしさを検証中…" if pending else "一致率は正解確率ではありません。耳で確認してください。")
        self._set_search_state(bool(cands and pending), message)
        if nblk == 0:
            self.candlist.delete(0, tk.END)
            self._candidate_selected()
            self.candidate_status.configure(text="データ不足。長い録音か、この局の全録音で探索してください。")
            self._msg(f"[{tag}] データ不足(5バースト未満)。長い交信か「全録音で探索」を。"); return
        if not cands:
            self.candlist.delete(0, tk.END)
            self._candidate_selected()
            if force:
                self._msg(f"[{tag}] 鍵候補なし。全鍵で復号しても音声にならないので、"
                          f"この交信はSTD-T98秘話ではありません(別コーデック/データ/強い暗号の可能性)。")
            else:
                self._msg(f"[{tag}] 候補なし(受信不良か対応外)。")
            return
        if cands[0][0] == 0:
            self.candlist.delete(0, tk.END)
            self._candidate_selected()
            self.candidate_status.configure(text="平文と判定しました。「平文で試聴」で確認してください。")
            if play:
                self.keyvar.set(0); self._msg(f"[{tag}] → 平文と判定。平文で再生します。"); self._play_key(0)
            else:
                self._msg(f"[{tag}] → 平文(秘話OFF)と判定。「平文で試聴」で確認を。")
            return
        self.candlist.show(cands, checked, pending)
        self._candidate_selected()
        note = ""
        if checked and pending:
            note = " 独自AMBE+2で残りの候補を検証中…(終わると声らしさ順に並べ替え)"
        elif checked:
            ok = sum(1 for c in cands if c[3] is not None and c[3] >= SPEECH_OK)
            note = (f" 独自AMBE+2で検証し声らしさ順に並べ替え(✓ {ok}件)。" if ok
                    else " 独自AMBE+2で検証: 声らしい候補なし(✓ 0件)。")
        scored = min(nblk, MAX_POOL_BLOCKS)
        if play:
            # 自動復号: 最有力候補を手動キー欄にセットして復号再生。他候補は一覧から試聴可。
            best = cands[0][0]
            self.keyvar.set(best)
            self._msg(f"[{tag}] 自動復号: 鍵{best}(一致{cands[0][1]*100:.0f}%)で再生。{note}"
                      f"※不確実なので耳で確認を。他候補は下の一覧からダブルクリック。"
                      f" 正しければ「この局にキーを保存」で保存。")
            self._play_key(best)
        else:
            self._msg(f"[{tag}] {scored}/{nblk}ブロックで採点。候補{len(cands)}件。{note}"
                      f"上のものからダブルクリックで試聴して確定を。")

    def _on_cand(self, _evt=None):
        key = self.candlist.selected_key()
        if key is not None:
            self.keyvar.set(key)
            self._play_key(key)
        return "break"

    def _restore_with_csm(self):
        """手動キーをこの局(CSM)に紐付けて manual_keys.csv に保存し、以後 CSM+キー で
        自動復元されるようにする。周波数+CSM がそろっている録音でのみ呼ばれる。
        手動キー=0 のときは平文(鍵不要)として復元する。"""
        if not self.frames or not self.csm or not self.freq:
            return
        key = self._read_key()
        if key is None:
            return
        # key<=0 のときは csm,,0 を書く(load_manual_keys が無視=平文既定に戻る)。
        set_manual_key(self.csm, self.freq, key)
        if key <= 0:
            self._msg(f"保存: CSM {self.csm} → 平文(鍵不要)  (manual_keys.csv)。この周波数を再デコードします。")
        else:
            self._msg(f"保存: CSM {self.csm} → 鍵{key}  (manual_keys.csv)。この周波数を再デコードします。")
        self._redecode()

    def _redecode(self):
        import subprocess
        try:
            subprocess.Popen([sys.executable,
                              os.path.join(os.path.dirname(os.path.abspath(__file__)), "redecode.py"),
                              "--freq", str(self.freq), "--force"])
            self._msg(f"redecode 起動: freq={self.freq} → rec\\ に *_ch*_*.wav 生成")
        except Exception as exc:
            self._msg(f"redecode 起動失敗: {exc}")


    def _open_data_analysis(self):
        """選択中(なければ再生中)の録音の、データフレームのユーザデータを解析する。"""
        from data_analysis_window import DataAnalysisWindow
        paths = self.filelist.selected_paths(self.files)
        if not paths and getattr(self, "curpath", None):
            paths = [self.curpath]
        pairs = self._data_analysis_pairs(paths)
        if not pairs:
            self._msg("データ解析: 録音を選んでください(edu ファイルのある録音が対象です)。")
            return
        DataAnalysisWindow(self, pairs, expand=lambda: self._same_channel_day(paths[0]),
                           sender_label=self._sender_label)

    def _sender_label(self, user_code, maker_code):
        """データ解析の送信局表示: 「ユーザ N(別名) / メーカ N(名称)」。"""
        name = self.makers.get(maker_code)
        return f"ユーザ {self._user_label(user_code)} / メーカ {maker_code}" + (f"({name})" if name else "")

    @staticmethod
    def _data_analysis_pairs(paths):
        pairs = []
        for raw in sorted(set(paths), key=os.path.basename):     # ファイル名=時刻順
            edu = _edu_path(os.path.splitext(os.path.basename(raw))[0])
            if edu:
                pairs.append((raw, edu))
        return pairs

    def _same_channel_day(self, raw):
        """raw と同じ周波数・同じ日の全録音(時刻順)。"""
        freq, _ = read_header(raw)
        base = os.path.splitext(os.path.basename(raw))[0]
        sub = _day_sub(base)
        folder = os.path.join(RAW_DIR, sub) if sub else os.path.dirname(raw)
        same = [os.path.join(folder, fn) for fn in os.listdir(folder)
                if fn.endswith(".t98raw") and read_header(os.path.join(folder, fn))[0] == freq]
        return self._data_analysis_pairs(same)

    def _open_anatomy(self):
        # 録音を選択中なら、同じ交信(同時刻・同周波数)の edu を自動で開く。
        base = None
        if getattr(self, "curpath", None):
            base = os.path.splitext(os.path.basename(self.curpath))[0]
        FrameAnatomy(self, base)

    def _ensure_chartjs(self):
        """Chart.js をツール同梱(ローカル)にする。無ければCDNから一度DLして保存。
        返り値: HTMLから参照する src(ローカルにあれば絶対 file パス、無ければCDN URL)。"""
        if os.path.exists(CHARTJS_LOCAL) and os.path.getsize(CHARTJS_LOCAL) > 100000:
            return CHARTJS_LOCAL
        try:
            import urllib.request
            self._post(lambda: self._msg("Chart.js を初回のみ取得中(以後オフライン可)..."))
            req = urllib.request.Request(CHARTJS_CDN, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            if len(data) > 100000:
                with open(CHARTJS_LOCAL, "wb") as f:
                    f.write(data)
                return CHARTJS_LOCAL
        except Exception:
            pass
        return CHARTJS_CDN   # DL失敗時はCDN参照(オンラインなら表示可)

    def _open_stats(self):
        """rx_log.csv を集計し、統計ダッシュボード(HTML)を生成してブラウザで開く。"""
        if not os.path.exists(RX_LOG_CSV):
            self._msg(f"統計を出せません: {RX_LOG_CSV} が見つかりません。")
            return
        if not os.path.exists(STATS_TPL):
            self._msg(f"統計テンプレートがありません: {STATS_TPL}")
            return
        self._msg("統計を集計中...")
        threading.Thread(target=self._open_stats_bg, daemon=True).start()

    def _open_stats_bg(self):
        try:
            stats = compute_stats()
            src = self._ensure_chartjs()
            # ローカルChart.jsはHTMLと同じ場所に置いてある(ツールdir)。HTMLもそこに書けば
            # 相対参照でオフライン表示できる。CDNフォールバック時はURLをそのまま使う。
            if src == CHARTJS_LOCAL:
                out = os.path.join(_TOOL_DIR, "stats_dashboard.html")
                chartjs_ref = "chart.umd.min.js"
            else:
                out = os.path.join(tempfile.gettempdir(), "std98_stats_dashboard.html")
                chartjs_ref = src
            render_dashboard(stats, chartjs_ref, out)
            m = stats["meta"]
            def done():
                self._msg(f"統計を表示: {m['n_sessions']}交信 / edu {m['n_edu']}件 "
                          f"→ ブラウザで開きました(日時範囲で絞り込めます)。")
                try:
                    webbrowser.open("file:///" + out.replace("\\", "/"))
                except Exception as exc:
                    self._msg(f"ブラウザ起動失敗: {exc}  ファイル: {out}")
            self._post(done)
        except Exception as exc:
            self._post(lambda exc=exc: self._msg(f"統計エラー: {exc}"))


# 非音声(データ)を運ぶ TCH: RICH M → データ側の TCH。M=1/2 は片方が音声。
DATA_TCH = {0: ("TCH1", "TCH2"), 4: ("TCH1", "TCH2"), 1: ("TCH1",), 2: ("TCH2",)}
TEXT_ENCODINGS = (("ASCII", "ascii"), ("Shift_JIS", "shift_jis"), ("UTF-8", "utf-8"))


def render_text(data, encoding):
    """表示用の文字列化。復号できないバイトは �、制御文字は · にする(桁がずれないように)。"""
    text = data.decode(encoding, errors="replace")
    return "".join(ch if ch.isprintable() or ch == "�" else "·" for ch in text)


def raw_tch_frames(base):
    """交信ベース名の raw から、フレームごとの TCH ビット列(288bit: TCH1+TCH2)。無ければ None。

    raw は 1 フレーム 36 byte = TCH1/TCH2 を順にそのまま(デホワイトニング後)保存している。"""
    sub = _day_sub(base)
    for path in ([os.path.join(RAW_DIR, sub, base + ".t98raw")] if sub else []) + [os.path.join(RAW_DIR, base + ".t98raw")]:
        try:
            with open(path, "rb") as f:
                blob = f.read()
        except OSError:
            continue
        header = {b"T98RAW03": 52, b"T98RAW02": 48, b"T98RAW01": 32}.get(blob[:8])
        if header is None:
            return None
        return ["".join(f"{b:08b}" for b in blob[i:i + 36]) for i in range(header, len(blob) - 35, 36)]
    return None


def raw_recording_header(base):
    """Read recording-level context without decoding or reading the payload."""
    sub = _day_sub(base)
    paths = ([os.path.join(RAW_DIR, sub, base + ".t98raw")] if sub else []) + [os.path.join(RAW_DIR, base + ".t98raw")]
    for path in paths:
        try:
            with open(path, "rb") as stream:
                header = stream.read(52)
        except OSError:
            continue
        size = {b"T98RAW01": 32, b"T98RAW02": 48, b"T98RAW03": 52}.get(header[:8])
        if size is None or len(header) < size:
            continue
        freq, start_ms = struct.unpack_from("<qq", header, 8)
        blocks, block_bytes = struct.unpack_from("<II", header, 24)
        info = {"freq_hz": freq, "start_ms": start_ms, "raw_version": header[:8].decode("ascii"),
                "blocks": blocks, "block_bytes": block_bytes}
        if size >= 48:
            info["csm"] = header[32:48].split(b"\0")[0].decode("utf-8", "replace").strip()
        if size >= 52:
            info["secret"] = {1: False, 2: True}.get(header[48])
        return info
    return {}


def data_halves(frame):
    """RICH から、このフレームでデータを運ぶ TCH 名。通話フレームで RICH が正常なときのみ。"""
    rich = frame.get("rich") or {}
    if frame.get("F") != 1 or not rich.get("parityOK"):
        return ()
    return DATA_TCH.get(rich.get("M"), ())


def decode_data_frame(frame, tch_bits):
    """非音声フレームのデータ側 TCH を復号。[(TCH名, decode_nonvoice_tch の結果, 生ビット)]。
    データを含まない/RICH が誤り(M 不明)/ビット無しなら空。"""
    halves = data_halves(frame)
    if not halves or not tch_bits:
        return []
    bits = {"TCH1": tch_bits[:144], "TCH2": tch_bits[144:288]}
    return [(name, decode_nonvoice_tch(bits[name]), bits[name]) for name in halves if len(bits[name]) == 144]


def data_payload(decoded):
    """CRC OK の TCH だけを順に連結したペイロード(bytes)。無ければ b""。"""
    return b"".join(result["data"] for _name, result, _bits in decoded if result["CRC_OK"])


class FrameAnatomy(tk.Toplevel):
    """STD-T98 フレーム解剖(デバッグ)。edu\\*.jsonl のフルフレームを、パケット形式に
    沿って色分け・図解で表示する。ローレベル構造の確認/学習用。"""

    # (フィールド, ビット長, 文字色) 合計384bit = 192シンボル×2bit。
    # 文字色は白背景でコントラスト 4.5:1 以上。構成バーは同系の淡色(FILL)で塗り、文字色で縁取る。
    LAYOUT = [("SW", 20, "#b42318"), ("RICH", 16, "#8a5a00"),
              ("SACCH", 60, "#1d5fbf"), ("TCH1", 144, "#116329"), ("TCH2", 144, "#0b7285")]
    SACCH_FIELDS = (("F", "F", 0, 0, "bit_other"), ("Wr", "Wr", 1, 2, "bit_other"),
                    ("種別", "msgType", 3, 7, "bit_other"), ("通話識別", "callStat", 8, 9, "bit_call"),
                    ("ユーザ", "userCode", 10, 18, "bit_user"), ("メーカ", "makerCode", 19, 25, "bit_maker"))
    RICH_FIELDS = (("F", 0, 1, "bit_call"), ("予約1", 2, 3, "bit_other"),
                   ("予約2", 4, 5, "bit_other"), ("M", 6, 11, "bit_user"),
                   ("D", 12, 13, "bit_maker"), ("パリティ", 14, 15, "bit_crc"))
    FILL = {"SW": "#fde4e2", "RICH": "#fbefcb", "SACCH": "#dce9fb", "TCH1": "#dcf2e2", "TCH2": "#d4eff3"}
    # 略語の正式名(フルスペル)。解剖表示で「略語 (正式名)」の形で併記する。
    FULL = {
        "SW":    "Synchronization Word",
        "RICH":  "Radio Information CHannel",
        "SACCH": "Slow Associated Control CHannel",
        "TCH":   "Traffic CHannel",
        "TCH1":  "Traffic CHannel 1",
        "TCH2":  "Traffic CHannel 2",
        "PICH":  "Parameter Information CHannel",
        "CSM":   "Call Sign Memory",
        "AMBE":  "Advanced Multi-Band Excitation",
        "CRC":   "Cyclic Redundancy Check",
        "FEC":   "Forward Error Correction",
        "FSK":   "Frequency Shift Keying",
        "PN":    "Pseudorandom Noise",
    }
    BG = _ui_color("SystemWindow", "#ffffff"); FG = _ui_color("SystemWindowText", "#222222"); PANEL = _ui_color("SystemButtonFace", "#f0f0f0"); SEL = _ui_color("SystemHighlight", "#0078d4")
    DIM = "#57606a"        # 説明文(白地で約6:1)
    VALUE = "#6f42c1"      # 値
    OK_INK = "#116329"; NG_INK = "#b42318"; NOTE_INK = "#8a5a00"
    CODE_BG = "#f3f4f6"    # ビット列の地
    RULE = "#d0d7de"       # 面の境界線

    def __init__(self, master, target_base=None):
        super().__init__(master)
        self.title("STD-T98 フレーム解剖 (デバッグ)")
        self.geometry("980x660")
        self.configure(bg=self.PANEL)
        self.frames = []
        self.header = {}
        self.tch = []
        self.decoded = []
        self._cur_fr = None
        self._target = target_base
        self.recording = {}
        self.csm_context = []
        self.tch_sources = []
        self._raw_tch = []
        self._selected_region = None
        self._bar_regions = {}
        self._voice_window = None
        self.trial_key_var = getattr(master, "keyvar", None) or tk.StringVar(self, value="0")
        self.alias = getattr(master, "alias", None) or load_csm_alias()
        self.user_alias = getattr(master, "user_alias", None) or load_user_alias()
        self.makers = getattr(master, "makers", None) or load_maker_codes()

        surface = dict(bg=self.BG, fg=self.FG, selectbackground=self.SEL, selectforeground="#ffffff",
                       highlightthickness=1, highlightbackground=self.RULE, highlightcolor=self.RULE,
                       borderwidth=0, font=("Consolas", 9), activestyle="none")
        left = tk.Frame(self, bg=self.PANEL); left.pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=8)
        tk.Label(left, text="DEBUG 記録", bg=self.PANEL, fg=self.FG,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.filelist = tk.Listbox(left, width=32, height=11, exportselection=False, **surface)
        self.filelist.pack(fill=tk.Y)
        self.filelist.bind("<<ListboxSelect>>", self._on_file)
        tk.Label(left, text="フレーム", bg=self.PANEL, fg=self.FG,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(8, 0))
        self.framelist = tk.Listbox(left, width=32, height=20, exportselection=False, **surface)
        self.framelist.pack(fill=tk.Y, expand=True)
        self.framelist.bind("<<ListboxSelect>>", self._on_frame)

        right = tk.Frame(self, bg=self.PANEL); right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=8, pady=8)
        # 構成バーの高さはフォント実測で決める(表示倍率で下段の説明が欠けないように)。
        self._bar_font = tkfont.Font(family="Segoe UI", size=9, weight="bold")
        self._bar_small = tkfont.Font(family="Consolas", size=7)
        self._bar_tight = tkfont.Font(family="Segoe UI", size=7, weight="bold")   # 狭い区画(RICH)用
        line = self._bar_font.metrics("linespace")
        self._bar_geom = (6, line + 14)    # (上余白, セグメント高さ)
        bar_height = sum(self._bar_geom) + 2 * self._bar_small.metrics("linespace") + line + 14
        self.bar = tk.Canvas(right, height=bar_height, bg=self.PANEL, highlightthickness=0, cursor="hand2", takefocus=True)
        self.bar.pack(fill=tk.X)
        self.bar.bind("<Configure>", lambda e: self._draw_bar())
        self.bar.bind("<Button-1>", self._on_bar_click)
        self.bar.bind("<Left>", lambda e: self._cycle_region(-1))
        self.bar.bind("<Right>", lambda e: self._cycle_region(1))
        region_row = ttk.Frame(right)
        region_row.pack(fill=tk.X, pady=(3, 0))
        region_row.columnconfigure(0, weight=1)
        self.region_status = ttk.Label(region_row, text="上のボックスをクリックすると、その領域のダンプを表示します。", wraplength=480)
        self.region_status.grid(row=0, column=0, sticky="ew")
        self.voice_button = ttk.Button(region_row, text="音声ビット解析・試聴…", command=self._open_voice_analysis, state="disabled")
        self.voice_button.grid(row=0, column=1, padx=(6, 0))
        whole_button = ttk.Button(region_row, text="フレーム全体", command=self._show_full_frame)
        whole_button.grid(row=0, column=2, padx=(6, 0))
        region_row.bind("<Configure>", lambda e: self.region_status.configure(wraplength=max(160, e.width - whole_button.winfo_reqwidth() - self.voice_button.winfo_reqwidth() - 20)))
        self.pages = tk.PanedWindow(right, orient=tk.VERTICAL, bg=self.PANEL, sashwidth=7,
                                   borderwidth=0, sashrelief=tk.FLAT)
        self.pages.pack(fill=tk.BOTH, expand=True, pady=(8, 0))
        self.dump_host = ttk.Frame(self.pages)
        dump_tools = ttk.Frame(self.dump_host)
        dump_tools.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(dump_tools, text="元データ", font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT)
        self._dump_stage = "rx"
        self.dump_stage = tk.StringVar(self, "復調直後（元ビット）")
        self.dump_stage_menu = ttk.Combobox(dump_tools, textvariable=self.dump_stage,
                                           width=29, state="readonly")
        self.dump_stage_menu.pack(side=tk.LEFT, padx=8)
        self.dump_stage_menu.bind("<<ComboboxSelected>>", self._change_dump_stage)
        self.copy_hex = ttk.Button(dump_tools, text="HEXをコピー", command=lambda: self._copy_dump(True))
        self.copy_hex.pack(side=tk.RIGHT)
        self.copy_bits = ttk.Button(dump_tools, text="ビット列をコピー", command=self._copy_dump)
        self.copy_bits.pack(side=tk.RIGHT, padx=4)
        dump_body = ttk.Frame(self.dump_host)
        dump_body.pack(fill=tk.BOTH, expand=True)
        dump_body.rowconfigure(0, weight=1)
        dump_body.columnconfigure(0, weight=1)
        self.dump = tk.Text(dump_body, wrap="none", height=10, bg=self.BG, fg=self.FG,
                            font=("Consolas", 10), padx=12, pady=8, borderwidth=0)
        self.dump.grid(row=0, column=0, sticky="nsew")
        dump_y = ttk.Scrollbar(dump_body, command=self.dump.yview)
        dump_y.grid(row=0, column=1, sticky="ns")
        dump_x = ttk.Scrollbar(dump_body, orient=tk.HORIZONTAL, command=self.dump.xview)
        dump_x.grid(row=1, column=0, sticky="ew")
        self.dump.configure(yscrollcommand=dump_y.set, xscrollcommand=dump_x.set)
        self.detail_host = ttk.Frame(self.pages)
        self.pages.add(self.detail_host, minsize=130, stretch="always")
        self.detail = tk.Text(self.detail_host, wrap="word", bg=self.BG, fg=self.FG, insertbackground=self.FG,
                              font=("Consolas", 10), highlightthickness=1, highlightbackground=self.RULE,
                              highlightcolor=self.RULE, borderwidth=0, padx=14, pady=12)
        detail_scroll = ttk.Scrollbar(self.detail_host, orient="vertical", command=self.detail.yview)
        self.detail_scroll = detail_scroll
        self.detail.configure(yscrollcommand=detail_scroll.set)
        detail_scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=(8, 0))
        self.detail.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, pady=(8, 0))
        for name, _, col in self.LAYOUT:
            self.detail.tag_configure("h_" + name, foreground=col, font=("Consolas", 11, "bold"))
        self.detail.tag_configure("title", foreground=self.FG, font=("Segoe UI", 13, "bold"))
        self.detail.tag_configure("val", foreground=self.VALUE, font=("Consolas", 10, "bold"))
        self.detail.tag_configure("abbr", foreground=self.FG, font=("Consolas", 10, "bold"))
        self.detail.tag_configure("ok", foreground=self.OK_INK, font=("Consolas", 10, "bold"))
        self.detail.tag_configure("ng", foreground=self.NG_INK, font=("Consolas", 10, "bold"))
        self.detail.tag_configure("note", foreground=self.NOTE_INK)
        self.detail.tag_configure("dim", foreground=self.DIM)
        self.detail.tag_configure("bits", foreground="#24292f", background=self.CODE_BG, font=("Consolas", 9))
        for tag, ink, fill in (("bit_csm", self.OK_INK, self.FILL["TCH1"]),
                               ("bit_user", self.OK_INK, self.FILL["TCH1"]),
                               ("bit_maker", "#0b7285", self.FILL["TCH2"]),
                               ("bit_call", self.NOTE_INK, self.FILL["RICH"]),
                               ("bit_crc", "#1d5fbf", self.FILL["SACCH"]),
                               ("bit_other", self.DIM, self.CODE_BG)):
            self.detail.tag_configure(tag, foreground=ink, background=fill, font=("Consolas", 10, "bold"))
        for name, _length, ink in self.LAYOUT:
            self.detail.tag_configure("wire_" + name, foreground=ink, background=self.FILL[name], font=("Consolas", 10, "bold"))
        for name, ink, fill in (("voice_C0", self.NOTE_INK, self.FILL["RICH"]),
                                ("voice_C1", self.OK_INK, self.FILL["TCH1"]),
                                ("voice_C2", "#0b7285", self.FILL["TCH2"]),
                                ("voice_C3", "#1d5fbf", self.FILL["SACCH"])):
            self.detail.tag_configure(name, foreground=ink, background=fill, font=("Consolas", 10, "bold"))

        for tag in self.detail.tag_names():
            self.dump.tag_configure(tag, **{option: spec[-1] for option, spec in self.detail.tag_configure(tag).items()})
        self.dump.tag_configure("original", foreground=self.FG, background=self.CODE_BG,
                                font=("Consolas", 12, "bold"))
        self.dump.configure(state="disabled")

        self._refresh()

    def _refresh(self):
        # 日付サブフォルダ(新)と edu 直下(旧)を再帰的に集め、ファイル名(時刻)新しい順。
        self.files = sorted(_list_files(EDU_DIR, ".jsonl"),
                            key=lambda p: os.path.basename(p), reverse=True)
        self.filelist.delete(0, tk.END)
        for p in self.files:
            self.filelist.insert(tk.END, os.path.basename(p))
        if not self.files:
            self._plain("フレーム記録がありません。\n\nMulti Receiver の「音声設定…」→「音声・録音」で、"
                        "「チャンネル別の生音声・WAVを自動保存」と「SW・RICH・SACCHも保存」をオンにして、"
                        "新たに通話を受信・録音してください。\n保存先の edu フォルダにフレーム解析用のビットが保存されます。\n\n"
                        "SDR#版では「デバッグ: フルフレーム記録」で保存した記録も開けます。")
            return
        if self._target:
            for i, p in enumerate(self.files):
                if os.path.splitext(os.path.basename(p))[0] == self._target:
                    self.filelist.selection_set(i); self.filelist.activate(i); self.filelist.see(i)
                    self._on_file(None); return
            self._plain(f"選択中の録音に対応するフレーム記録がありません:\n  {self._target}\n\n"
                        "保存先の edu フォルダに、その録音の記録があるか確認してください。")

    def _on_file(self, _e):
        sel = self.filelist.curselection()
        if not sel:
            return
        if self._voice_window is not None:
            self._voice_window.destroy()
            self._voice_window = None
        self.voice_button.configure(state="disabled")
        self.frames = []; self.header = {}; self.tch = []; self.decoded = []
        self.recording = {}; self.csm_context = []; self.tch_sources = []
        self._raw_tch = []; self._selected_region = None
        self.region_status.configure(text="上のボックスをクリックすると、その領域のダンプを表示します。")
        self.framelist.delete(0, tk.END)
        self._cur_fr = None
        self._draw_bar()
        try:
            with open(self.files[sel[0]], encoding="utf-8-sig") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    obj = json.loads(line)
                    if obj.get("type") == "header":
                        self.header = obj
                    else:
                        self.frames.append(self._normalise_frame(obj))
        except Exception as exc:
            self._plain(f"読込失敗: {exc}"); return
        # TCH ビット列: SDR# 版の edu はフレームに持つ。本体の edu は持たないので対応する raw から。
        base = os.path.splitext(os.path.basename(self.files[sel[0]]))[0]
        self.recording = raw_recording_header(base)
        if not self.header.get("freq_hz") and self.recording.get("freq_hz"):
            self.header["freq_hz"] = self.recording["freq_hz"]
        self.csm_context = self._build_csm_context()
        raw = raw_tch_frames(base)
        if raw is not None and len(raw) != len(self.frames):
            raw = None   # 数が合わなければ対応づけない(誤ったフレームのデータを見せない)
        self._raw_tch = raw or []
        halves = [(self._section_bits(i, "TCH1"), self._section_bits(i, "TCH2")) for i in range(len(self.frames))]
        self.tch = [first + second if first and second else "" for first, second in halves]
        self.tch_sources = []
        self.decoded = []
        for i, fr in enumerate(self.frames):
            sources = [self._section_source(i, name) for name in ("TCH1", "TCH2")]
            self.tch_sources.append(sources[0] if sources[0] == sources[1] else f"TCH1={sources[0]} / TCH2={sources[1]}")
            self.decoded.append([(name, decode_nonvoice_tch(self._section_bits(i, name)), self._section_bits(i, name))
                                 for name in data_halves(fr) if self._section_bits(i, name)])
        self.framelist.delete(0, tk.END)
        for i, fr in enumerate(self.frames):
            data_tch = data_halves(fr)
            rich = fr.get("rich") or {}
            kind = ("CTRL" if fr.get("F") == 0 else "?" if fr.get("F") != 1 or not rich.get("parityOK") else
                    "IDLE" if rich.get("M") == 5 else "DATA" if data_tch and len(data_tch) == 2 else
                    "V+D" if data_tch else "VOICE" if rich.get("M") == 3 else "?")
            extra = ""
            if self.decoded[i]:
                ok = sum(r["CRC_OK"] for _n, r, _b in self.decoded[i])
                extra = f" データ{ok}/{len(self.decoded[i])}OK"
            elif fr.get("F") == 0 and fr.get("pich"):
                extra = " " + str(fr["pich"].get("csm", ""))
            elif fr.get("sacch"):
                extra = " CRC" + ("OK" if fr["sacch"].get("crcOK") else "NG")
            self.framelist.insert(tk.END, f"#{i:03d} {kind:5s}{extra}")
            bad = (fr.get("sacch") and not fr["sacch"].get("crcOK")) or \
                  (fr.get("F") == 0 and fr.get("pich") and not fr["pich"].get("crcOK"))
            colour = (self.NG_INK if bad else self.NOTE_INK if fr.get("F") == 0
                      else self.VALUE if kind in ("DATA", "V+D") else None)
            if colour:
                self.framelist.itemconfig(tk.END, foreground=colour)
        self._cur_fr = None
        self._draw_bar()
        self._show_overview()

    # ---- Canvas: フレーム構成バー ----
    @staticmethod
    def _normalise_frame(frame):
        """Accept both the compact edu names and the decoder's original names."""
        mappings = {
            "rich": {"parityOK": "Parity_OK"},
            "sacch": {"crcOK": "CRC_OK", "msgType": "MsgType", "callStat": "CallStat",
                      "userCode": "UserCode", "makerCode": "MakerCode"},
            "pich": {"crcOK": "CRC_OK", "csm": "CSM"},
        }
        result = dict(frame)
        for section, aliases in mappings.items():
            data = dict(frame.get(section) or {})
            for canonical, original in aliases.items():
                if canonical not in data and original in data:
                    data[canonical] = data[original]
            result[section] = data
        return result

    @staticmethod
    def _valid_csm(value):
        return isinstance(value, str) and len(value) == 9 and value.isascii() and value.isdecimal()

    def _build_csm_context(self):
        """Carry only earlier, checked PICH identities; never use future frames."""
        metadata = None
        for data, source in ((self.header, "DEBUGヘッダ（録音共通情報）"),
                             (self.recording, "rawヘッダ（録音共通情報）")):
            value = data.get("csm") or data.get("CSM")
            if self._valid_csm(value):
                metadata = (value, source, None)
                break
        context, previous = [], None
        for index, frame in enumerate(self.frames):
            pich, rich = frame.get("pich") or {}, frame.get("rich") or {}
            value = pich.get("csm")
            if frame.get("F") == 0 and pich.get("crcOK") and rich.get("parityOK") and self._valid_csm(value):
                previous = (value, f"PICH フレーム #{index:03d}（CRC12・RICHパリティOK）", index)
                selected = previous
            else:
                value = frame.get("csm") or frame.get("CSM")
                selected = (value, "このフレームの記録内CSM（受信側の保持値）", None) if self._valid_csm(value) else previous or metadata
            context.append(selected)
        return context

    def _show_frame_context(self, index, frame):
        context = self.csm_context[index] if index < len(self.csm_context) else None
        self._ins("CSM（局識別）= ", "dim")
        if context:
            csm, source, origin = context
            self._ins(csm, "val")
            kind = {"2": "登録局", "1": "免許局"}.get(csm[:1], "種別不明")
            self._ins(f"  {kind}", "dim")
            if self.alias.get(csm):
                self._ins(f"  局別名: {self.alias[csm]}", "val")
            self._ins(f"\n取得元: {source}\n", "dim")
            if origin is not None:
                self._ins(f"無線上の位置: 参照フレーム #{origin:03d} の TCH1/PICH、フレームbit 96〜239 → PICH復号後bit 0〜35。\n", "dim")
                if origin != index:
                    self._ins("  選択フレーム自身のCSMビットではなく、先行する制御フレームを参照しています。\n", "note")
            else:
                self._ins("無線上では制御フレームのTCH1/PICH（フレームbit 96〜239）から、復号後bit 0〜35を取り出す情報です。\n", "dim")
                self._ins("  この表示値は録音の保持情報で、選択フレームからCSMビットを直接抽出した値ではありません。\n", "note")
                if "rawヘッダ" in source:
                    self._ins("  rawファイルの保存位置はbyte 32〜47（ASCII保存。無線上のBCDとは別）。\n", "dim")
        else:
            self._ins("不明（有効なCSMの記録なし）\n", "note")
        self._ins("CSMは局の識別子。通話フレーム自身にPICHがない場合は、先行する制御フレームまたは録音共通情報を表示します。\n", "dim")
        freq = self.header.get("freq_hz")
        if isinstance(freq, (int, float)) and freq:
            self._ins(f"周波数: {freq / 1e6:.5f} MHz  {frequency_label(freq)}\n", "dim")
        if self.header.get("baud") is not None:
            self._ins(f"シンボル速度: {self.header['baud']} baud（記録ヘッダの値）\n", "dim")
        if self.recording.get("raw_version"):
            self._ins(f"録音形式: {self.recording['raw_version']}\n", "dim")
        blocks, block_bytes = self.recording.get("blocks"), self.recording.get("block_bytes")
        if blocks and block_bytes:
            self._ins(f"rawヘッダの保存単位: {blocks}ブロック × {block_bytes}byte = {blocks * block_bytes}byte（TCH部分）\n", "dim")
        start_ms = self.header.get("start_ms", self.recording.get("start_ms"))
        if isinstance(start_ms, (int, float)) and start_ms > 0:
            try:
                started = datetime.datetime.fromtimestamp(start_ms / 1000).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
                self._ins(f"録音開始: {started}（ローカル時刻。選択フレーム自身の時刻ではありません）\n", "dim")
            except (ValueError, OverflowError, OSError):
                self._ins(f"録音開始 start_ms={start_ms}（日時変換できない記録値）\n", "dim")
        if "secret" in self.recording:
            self._ins(f"録音共通の秘話フラグ: {SECRET_LABEL[self.recording['secret']]}（rawヘッダ。下の選択フレームの通話識別とは別）\n", "dim")
        if frame.get("seq") is not None:
            self._ins(f"受信通番 seq={frame['seq']}\n", "val")
            self._ins("  seqは受信処理の全チャンネル共通番号。番号の飛びをこのチャンネルの欠落数とは扱いません。\n", "dim")
        if frame.get("missed") is not None:
            self._ins(f"直前の欠落 missed={frame['missed']} フレーム\n", "val")
            self._ins("  このチャンネルで記録された直前の欠落数。1フレームは約80msです。\n", "dim")
        if "recovered" in frame:
            self._ins(f"取りこぼし回収 recovered={'ON' if frame['recovered'] else 'OFF'}\n", "note")
            self._ins("  ONは通常の同期語検出で拾えず、補助探索で回収されたフレームです。\n", "dim")
        soft = frame.get("soft_fec")
        if soft:
            try:
                payload = bytes.fromhex(soft["blocks"])
                errors = soft["errors"]
                valid = len(payload) % 9 == 0 and len(payload) // 9 == len(errors)
                valid = valid and all(len(pair) == 2 and all(isinstance(v, int) and v >= 0 for v in pair)
                                      and pair[0] <= pair[1] for pair in errors)
                if not valid:
                    raise ValueError("unaligned soft FEC")
                self._ins(f"軟判定FEC: {len(errors)} 音声ブロック\n", "val")
                for block, (c0, total) in enumerate(errors, 1):
                    self._ins(f"  ブロック{block}: C0変更 {c0} / 合計変更 {total}\n", "val")
                self._ins("  ハード判定から軟判定後データへの情報ビット変更数。音声デコーダの訂正距離や実際のビット誤り率とは別の指標です。\n", "dim")
            except (KeyError, TypeError, ValueError):
                self._ins("軟判定FEC: 記録の形式が不正で表示できません。\n", "ng")
        self._ins("\n")

    def _show_control_checks(self, data):
        fields = (("訂正指標 BitErrors", ("BitErrors", "bitErrors")),
                  ("受信CRC", ("CRC_Recv", "crcRecv")),
                  ("算出CRC", ("CRC_Calc", "crcCalc")))
        for label, keys in fields:
            value = next((data[key] for key in keys if key in data), None)
            if value is not None:
                self._ins(f"  {label}=", "dim")
                self._ins(f"{value}\n", "val" if data.get("crcOK") else "dim" if data.get("crcOK") is None else "ng")
        if any(key in data for key in ("BitErrors", "bitErrors")):
            self._ins("  → 訂正指標は復号器の記録値。CRCは残留誤りの検査で、訂正指標とは役割が異なります。\n", "dim")



    def _show_bit_locations(self):
        self._ins("── ビット位置と色付きの対応 ──\n", "title")
        self._ins("番号は0始まり・両端を含みます。フレーマが切り出した384bit（デホワイトニング後）が基準です。\n", "dim")
        offset = 0
        for name, length, _color in self.LAYOUT:
            self._ins(f"  {name:5s} フレームbit {offset}〜{offset + length - 1}（{length}bit）\n", "dim")
            offset += length
        self._ins("RICH: F=20〜21 / 予約1=22〜23 / 予約2=24〜25 / M=26〜31 / D=32〜33 / パリティ=34〜35。2bit単位から情報1bitを取り出します。\n", "dim")
        self._ins("SACCHとPICHは符号化・パンクチャ・インタリーブで分散しています。以下の色付きビット列は復号後の情報位置で、受信フレームの連続した範囲ではありません。\n", "note")
        self._ins("CSMは制御フレームのTCH1/PICHを復号した後のbit 0〜35です。受信ビットの確認はTCH1の領域ダンプで行えます。\n", "dim")
        self._ins("付加情報: 周波数・時刻・seq・missed・recovered・訂正指標・別名は受信/保存側の情報で、無線フレーム内の専用bitではありません。CRC_OK/parityOKも検査結果です。\n\n", "dim")

    def _show_sacch_bit_fields(self, data):
        if not data:
            return
        self._ins("  色付きビット図: SACCH復号後（記録値から再構成した参考図）\n", "title")
        trusted = bool(data.get("crcOK") and ((self._cur_fr or {}).get("rich") or {}).get("parityOK"))
        if not trusted:
            self._ins("  CRC / RICHパリティ未確認の値です。ビット図も参考として表示します。\n", "ng")
        for label, key, start, end, tag in self.SACCH_FIELDS:
            value = data.get(key, data.get("wr") if key == "Wr" else None)
            length = end - start + 1
            known = isinstance(value, int) and 0 <= value < 2 ** length
            bits = f"{value:0{length}b}" if known else "?" * length
            self._ins(f"  {label}: ", "dim")
            self._ins(bits, tag if known and trusted else "bit_other")
            self._ins(f" ← 復号後bit {start}〜{end}（{length}bit）\n", "dim")
        self._ins("  ? は未記録。受信CRC6は復号後bit 26〜31、Tailは32〜35です。算出CRCと訂正指標は受信側で計算します。\n", "dim")

    @classmethod
    def _region_bounds(cls, name):
        start = 0
        for field, length, _ink in cls.LAYOUT:
            if field == name:
                return start, start + length - 1
            start += length
        raise ValueError(f"Unknown frame region: {name}")

    def _section_bits(self, index, name):
        start, end = self._region_bounds(name)
        length = end - start + 1
        key = {"SW": "sw", "RICH": "rich_bits", "SACCH": "sacch_bits", "TCH1": "tch1_bits", "TCH2": "tch2_bits"}[name]
        value = self.frames[index].get(key)
        if isinstance(value, str) and len(value) == length and set(value) <= {"0", "1"}:
            return value
        whole = self._saved_frame_bits(index, "frame_dw_hex")
        if whole:
            return whole[start:end + 1]
        if name == "SW":
            original = self._saved_frame_bits(index, "frame_rx_hex")
            if original:
                return original[:20]  # SW is not whitened.
        if name in ("TCH1", "TCH2") and index < len(self._raw_tch):
            offset = 0 if name == "TCH1" else 144
            value = self._raw_tch[index][offset:offset + 144]
            if len(value) == 144 and set(value) <= {"0", "1"}:
                return value
        return ""

    def _saved_frame_bits(self, index, key):
        value = self.frames[index].get(key)
        if isinstance(value, str) and len(value) == 96 and set(value) <= set("0123456789abcdefABCDEF"):
            return f"{int(value, 16):0384b}"
        return ""

    def _section_source(self, index, name):
        if not self._section_bits(index, name):
            return "未記録 / 完全なビット列なし"
        key = {"SW": "sw", "RICH": "rich_bits", "SACCH": "sacch_bits", "TCH1": "tch1_bits", "TCH2": "tch2_bits"}[name]
        value = self.frames[index].get(key)
        if isinstance(value, str) and len(value) == self._region_bounds(name)[1] - self._region_bounds(name)[0] + 1 and set(value) <= {"0", "1"}:
            return "DEBUGフレームの記録"
        if self._saved_frame_bits(index, "frame_dw_hex"):
            return "全フレーム記録（デホワイトニング後の384bit）"
        if name == "SW" and self._saved_frame_bits(index, "frame_rx_hex"):
            return "全フレーム記録（復調直後。SWはホワイトニング対象外）"
        return "対応するraw録音（フレーム数一致を確認）"

    def _on_bar_click(self, event):
        self.bar.focus_set()
        for name, (left, top, right, bottom) in self._bar_regions.items():
            if left <= event.x < right and top <= event.y <= bottom:
                self._select_region(name)
                break

    def _select_region(self, name):
        self._region_bounds(name)
        if not self.framelist.curselection():
            self.region_status.configure(text="先に左側のフレームを選択してください。")
            return
        self._selected_region = name
        self._on_frame(None)

    def _cycle_region(self, direction):
        names = [field for field, _length, _ink in self.LAYOUT]
        current = names.index(self._selected_region) if self._selected_region in names else (-1 if direction > 0 else 0)
        self._select_region(names[(current + direction) % len(names)])
        return "break"

    def _show_full_frame(self):
        self._selected_region = None
        self.region_status.configure(text="上のボックスをクリックすると、その領域のダンプを表示します。")
        if self.framelist.curselection():
            self._on_frame(None)
        else:
            self._draw_bar()

    @staticmethod
    def _dump_rows(bits, start=0, end=None):
        """Byte-aligned MSB-first rows; unknown and absent bits stay ? and -."""
        end = len(bits) - 1 if end is None else end
        rows = []
        for byte in range(start // 8, end // 8 + 1):
            chunk = bits[byte * 8:byte * 8 + 8].ljust(8, "-")
            hexadecimal = ""
            for half in (chunk[:4], chunk[4:]):
                hexadecimal += "?" if "?" in half else "-" if "-" in half else f"{int(half, 2):X}"
            rows.append({"byte": byte, "hex": hexadecimal, "bits": chunk,
                         "start": byte * 8, "selected": [start <= byte * 8 + i <= end for i in range(8)]})
        return rows

    def _show_byte_dump(self, bits, start=0, end=None, spans=(), tags=None, received=False, target=None):
        end = len(bits) - 1 if end is None else end
        write = self._ins if target is None else lambda text, tag: target.insert(tk.END, text, tag)
        write(" BYTE  HEX  b7....b0  ASCII  ビット位置\n", "bits")
        for row in self._dump_rows(bits, start, end):
            write(f" 0x{row['byte']:02X}  {row['hex']:2s}   ", "bits")
            for i, bit in enumerate(row["bits"]):
                position = row["start"] + i
                tag = "dim"
                if row["selected"][i] and bit != "-":
                    tag = tags.get(position, "bit_other") if tags is not None else next((style for _label, first, last, style in spans if first <= position <= last), "bit_other")
                elif target is not None and bit in "01":
                    tag = next((style for _label, first, last, style in spans if first <= position <= last), "dim")
                write(bit, tag)
            word = "フレームbit" if received else "この列のbit"
            value = int(row["bits"], 2) if set(row["bits"]) <= {"0", "1"} else None
            ascii_char = ("-" if "-" in row["bits"] else "?") if value is None else chr(value) if 32 <= value <= 126 else "."
            write(f"    {ascii_char}    {word} {row['start']}〜{min(row['start'] + 7, len(bits) - 1)}\n", "dim")
        write(" ? = 未記録 / 不明、- = その領域に存在しない末尾bit。0で埋めません。\n", "dim")

    def _change_dump_stage(self, _event=None):
        self._dump_stage = "rx" if self.dump_stage.get().startswith("復調直後") else "dw"
        selection = self.framelist.curselection()
        if selection and self._selected_region:
            self._show_received_dump(selection[0], self._selected_region)

    def _copy_dump(self, hexadecimal=False):
        bits = getattr(self, "_visible_dump_bits", "")
        if bits:
            value = f"{int(bits, 2):0{(len(bits) + 3) // 4}X}" if hexadecimal else bits
            self.clipboard_clear()
            self.clipboard_append(value)

    def _show_received_dump(self, index, name):
        start, end = self._region_bounds(name)
        original = self._saved_frame_bits(index, "frame_rx_hex")
        choices = (["復調直後（元ビット）"] if original else []) + ["デホワイトニング後（解析用）"]
        self.dump_stage_menu.configure(values=choices, state="readonly" if original else "disabled")
        use_original = bool(original and self._dump_stage == "rx")
        self.dump_stage.set(choices[0] if use_original else choices[-1])
        bits = original[start:end + 1] if use_original else self._section_bits(index, name)
        self._visible_dump_bits = bits
        for button in (self.copy_bits, self.copy_hex):
            button.configure(state="normal" if bits else "disabled")
        self.dump.configure(state="normal")
        self.dump.delete("1.0", tk.END)
        write = lambda text, tag="dim": self.dump.insert(tk.END, text, tag)
        write(f"{name} / {end - start + 1}bit / フレーム #{index:03d}\n", "title")
        if not bits:
            write("元のバイナリは、この記録には保存されていません。\n", "ng")
            write("解釈値から元ビットを復元することはできません。\n")
            write("Multi Receiver の「音声設定…」→「音声・録音」で\n")
            write("「SW・RICH・SACCHも保存」をオンにして、新たに受信・録音してください。\n")
            write("取得元: 未記録 / 完全なビット列なし\n")
        else:
            write("BIN  ", "val")
            for i in range(0, len(bits), 8):
                write(bits[i:i + 8] + (" " if i + 8 < len(bits) else "\n"), "original")
            write(f"HEX  {int(bits, 2):0{(len(bits) + 3) // 4}X}  / 選択領域だけの値\n", "val")
            write(f"取得元: {'全フレーム記録（復調直後の硬判定384bit）' if use_original else self._section_source(index, name)}\n")
            whole = original if use_original else "".join(self._section_bits(index, field) or "?" * length for field, length, _ink in self.LAYOUT)
            spans = [(field, *self._region_bounds(field), "wire_" + field) for field, _length, _ink in self.LAYOUT]
            tags = None
            if not use_original:
                if name == "RICH":
                    spans += [(label, start + first, start + last, tag) for label, first, last, tag in self.RICH_FIELDS]
                    spans = spans[len(self.LAYOUT):] + spans[:len(self.LAYOUT)]
                tags = self._voice_received_tags(index, name) if name in ("TCH1", "TCH2") else None
            write("\n受信フレームに沿ったバイト表示（色で領域を区別）\n", "val")
            write("色: ")
            for field, _length, _ink in self.LAYOUT:
                first, last = self._region_bounds(field)
                if first <= (end // 8) * 8 + 7 and last >= (start // 8) * 8:
                    write(field + "  ", "wire_" + field)
            write("\n")
            self._show_byte_dump(whole, start, end, spans, tags, received=True, target=self.dump)
        self.dump.configure(state="disabled")
        self.dump.yview_moveto(0)
        self.dump.xview_moveto(0)

    @staticmethod
    def _byte_location(start, end):
        return f"byte 0x{start // 8:02X}:b{7 - start % 8}〜0x{end // 8:02X}:b{7 - end % 8}"

    def _show_value_map(self, bits, spans, values=None, base=0):
        values = values or {}
        self._ins("\n項目 ↔ 色付きビット ↔ 値\n", "title")
        for label, first, last, tag in spans:
            fragment = bits[first:last + 1]
            self._ins(f" {label}: ", "dim")
            self._ins(fragment, tag)
            value = values.get(label)
            if value is None:
                value = int(fragment, 2) if set(fragment) <= {"0", "1"} else "不明"
            self._ins(f" → {value}\n", "val" if value != "不明" else "dim")
            self._ins(f"   bit {base + first}〜{base + last} / {self._byte_location(base + first, base + last)}\n", "dim")

    def _show_region_dump(self, index, name):
        start, end = self._region_bounds(name)
        bits = self._section_bits(index, name)
        self.region_status.configure(text=f"選択領域: {name} / フレーム #{index:03d}（左右キーで領域切替）")
        self.detail.delete("1.0", tk.END)
        self.detail.yview_moveto(0)
        if str(self.dump_host) not in self.pages.panes():
            self.pages.add(self.dump_host, before=self.detail_host, height=240, minsize=140, stretch="never")
        self._show_received_dump(index, name)
        self._ins(f"フレーム #{index:03d}  {name} バイナリダンプ\n", "title")
        self._ins("読み方・解説\n", "title")
        self._ins(f"受信領域: フレームbit {start}〜{end}（{end - start + 1}bit）\n{self._byte_location(start, end)}\n", "dim")
        self._ins(f"取得元: {self._section_source(index, name)}\n", "dim")
        self._ins("① 上段のBINは選択領域の保存ビットそのものです。8bitごとの空白は読みやすくするための区切りです。HEXは同じ値を16進数で表します。コピーすると空白のない元ビット列を取得できます。\n", "dim")
        self._ins("② BYTEはフレーム先頭からの0始まりのアドレス。各バイトは左からb7→b0です。HEXの1桁は4bitに対応します。ASCIIの「.」は印字できない値です。\n", "dim")
        self._ins("③ 下段の解釈はデホワイトニング後の保存ビットを使います。復調直後は硬判定した元ビット、デホワイトニング後はホワイトニングを除いた解析用ビットです。SWの20bitはこの処理で変化しません。\n", "dim")
        if not bits:
            self._ins("解析用ビット（デホワイトニング後）は未記録です。復調直後の元ビットは上段で確認できます。\n" if self._saved_frame_bits(index, "frame_rx_hex") else
                      "この領域の受信ビットは未記録です。解釈値から受信ダンプを作ったようには表示しません。\n", "note")
            if name in ("SW", "RICH", "SACCH"):
                self._ins("raw録音はTCH部分のみで、この領域の受信ビットは含まれません。\n", "dim")
        if start % 8:
            self._ins("領域先頭はbyte境界に一致しません。BINの8bit区切りとBYTE行の位置は異なります。色付きビットと位置番号で対応を確認してください。\n", "note")
        if name == "SW":
            if bits:
                self._ins(f"SW値: 0x{int(bits, 2):05X}（20bit。最後の4bitを0埋めしません）\n", "val")
            self._ins("同期語はフレーム先頭を見つける固定パターン。20bit全体で10シンボルを表します。\n", "dim")
            self._ins("配置: byte 0x00と0x01の全ビット、byte 0x02の上位4bit（b7〜b4）がSWです。0x02の下位4bit（b3〜b0）はRICHで、SWには含めません。上段のBINの末尾4bitは半バイトであり、欠けたデータではありません。\n", "note")
        elif name == "RICH":
            self._show_rich_dump(index, bits)
        elif name == "SACCH":
            self._show_sacch_dump(index, bits)
        else:
            self._show_tch_dump(index, name, bits)

    def _show_rich_dump(self, index, bits):
        if bits:
            result = decode_rich(bits)
            values = {"F": result["F"], "予約1": result["Res1"], "予約2": result["Res2"],
                      "M": result["M"], "D": result["D"], "パリティ": result["Parity"]}
            self._show_value_map(bits, self.RICH_FIELDS, values, base=20)
            self._ins("2bit組の先頭ビットを取り出します。例えばMの受信6bitから3bitの数値を作ります。\n", "dim")
            self._ins(f"再解析パリティ: {'OK' if result['Parity_OK'] else 'NG（解釈値は参考）'}\n", "ok" if result["Parity_OK"] else "ng")
            self._ins(f"F: {'制御' if result['F'] == 0 else '通話'} / M: {self._rich_m_desc(result['F'], result['M'])} / D: {'直接通信' if result['D'] == 0 else '予約'}\n", "dim")
            recorded = self.frames[index].get("rich") or {}
            if any(key in recorded and recorded[key] != result[key] for key in ("F", "M", "D")):
                self._ins("記録された解釈値と受信ビットの再解析結果は異なります。この表は受信ビットの再解析結果です。\n", "note")
        else:
            self._ins("\n記録されたRICH解釈値のみ（受信ビット未記録）\n", "title")
            for key in ("F", "M", "D", "parityOK"):
                value = (self.frames[index].get("rich") or {}).get(key)
                self._ins(f" {key} = {value if value is not None else '未記録'}\n", "dim")

    @staticmethod
    def _info_bits(data, fields):
        parts = []
        for _label, key, first, last, _tag in fields:
            width = last - first + 1
            value = data.get(key, data.get("wr") if key == "Wr" else None)
            parts.append(f"{value:0{width}b}" if isinstance(value, int) and 0 <= value < 2 ** width else "?" * width)
        return "".join(parts)

    def _show_sacch_dump(self, index, bits):
        if bits:
            original = decode_sacch(bits)
            data = self._normalise_frame({"sacch": original})["sacch"]
            decoded = self._info_bits(data, self.SACCH_FIELDS) + original["CRC_Recv"] + "0000"
            self._ins("\nSACCH復号後（受信60bitを硬判定で再解析）\n", "title")
            self._ins(f"CRC6: {'OK' if data['crcOK'] else 'NG（復号候補の値は参考）'} / 訂正指標: {original['BitErrors']}\n", "ok" if data["crcOK"] else "ng")
            self._ins("Tailは復号器が0終端として扱う4bitです。受信4bitをそのまま読んだものではありません。\n", "dim")
        else:
            data = self.frames[index].get("sacch") or {}
            crc = data.get("CRC_Recv", data.get("crcRecv", ""))
            crc = crc if isinstance(crc, str) and len(crc) == 6 and set(crc) <= {"0", "1"} else "?" * 6
            decoded = self._info_bits(data, self.SACCH_FIELDS) + crc + "?" * 4
            self._ins("\nSACCH復号後の参考図（記録された解釈値から再構成）\n", "title")
            self._ins("受信SACCHは未記録です。?を含むこの列を、受信したビット列とは扱いません。\n", "note")
        spans = [(label, first, last, tag) for label, _key, first, last, tag in self.SACCH_FIELDS]
        spans += [("CRC6", 26, 31, "bit_crc"), ("Tail", 32, 35, "bit_other")]
        self._ins("このbyte/bit番号は復号後データの番号で、受信フレームのbyte番号とは別です。\n", "note")
        self._show_byte_dump(decoded, spans=spans)
        self._show_value_map(decoded, spans)
        self._ins("FはSACCH情報の先頭1bit、Wrは2bitの記録フィールド、種別は制御メッセージの種類です。\n通話識別: 0=平文 / 1=秘話 / その他=予約。ユーザはグループ番号、メーカはメーカー番号です。\n", "dim")

    def _frame_role(self, index):
        bits = self._section_bits(index, "RICH")
        if bits:
            data = decode_rich(bits)
            return data["F"], data["M"], data["Parity_OK"], "受信RICHの再解析"
        data = self.frames[index].get("rich") or {}
        return self.frames[index].get("F"), data.get("M"), bool(data.get("parityOK")), "RICHの記録値（受信RICH未記録）"

    def _voice_received_tags(self, index, name):
        F, mode, valid, _source = self._frame_role(index)
        voice = valid and F == 1 and ((name == "TCH1" and mode in (2, 3)) or (name == "TCH2" and mode in (1, 3)))
        if not voice:
            return None
        from vendor.ambe2 import bitio
        start, _end = self._region_bounds(name)
        return {start + block * 72 + 2 * symbol + k: f"voice_C{word}"
                for block in range(2) for symbol, cells in enumerate(bitio.T.INTERLEAVE)
                for k, (word, _bit) in enumerate(cells)}

    def _show_tch_dump(self, index, name, bits):
        F, mode, valid, source = self._frame_role(index)
        self._ins(f"\n割当ての判断: {source}\n", "dim")
        if self._section_source(index, name).startswith("対応するraw"):
            header = {"T98RAW01": 32, "T98RAW02": 48, "T98RAW03": 52}.get(self.recording.get("raw_version"))
            if header is not None:
                offset = header + index * 36 + (18 if name == "TCH2" else 0)
                self._ins(f"rawファイルでの保存位置: byte 0x{offset:X}〜0x{offset + 17:X}（上のフレームbyte番号とは別）\n", "dim")
        if F == 0 and name == "TCH1":
            if not valid:
                self._ins("RICHパリティNG / 未記録のため、PICHとしての解釈も参考です。\n", "ng")
            self._show_coded_tch_dump(index, name, bits, pich=True)
        elif not valid:
            self._ins("RICHパリティNG / 未記録のため、音声・データの割当ては確定できません。受信ダンプのみ表示します。\n", "note")
        elif F == 1 and mode in DATA_TCH and name in DATA_TCH[mode]:
            self._show_coded_tch_dump(index, name, bits, pich=False)
        elif F == 1 and ((name == "TCH1" and mode in (2, 3)) or (name == "TCH2" and mode in (1, 3))):
            if bits:
                self._show_voice_dump(name, bits)
            else:
                self._ins("音声割当てですが、このTCHの受信ビットは未記録です。\n", "note")
        else:
            self._ins("この割当ての内容分解は未対応、またはアイドルです。ビット値を特定の意味へ推測しません。\n", "dim")

    def _show_coded_tch_dump(self, index, name, bits, pich):
        if bits:
            decoded, errors = decode_coded_tch(bits)
            crc_ok, calculated = crc12_check(decoded[:80], decoded[80:92])
            sequence = "".join(map(str, decoded))
            self._ins(f"\n{name} {'PICH' if pich else '非音声データ'}復号後（受信144bitを硬判定で再解析）\n", "title")
            self._ins(f"CRC12: {'OK' if crc_ok else 'NG（復号候補の値は参考）'} / 訂正指標: {errors}\n", "ok" if crc_ok else "ng")
            self._ins("算出CRC12: " + "".join(map(str, calculated)) + "（受信側で計算）\n", "dim")
        else:
            self._ins("このTCHの受信ビットがなく、復号後ダンプは表示できません。CSMのビット列を記録値から再構成しません。\n" if pich else
                      "このTCHの受信ビットがなく、データの復号はできません。\n", "note")
            return
        self._ins("復号後のbyte/bit番号です。CSM・データ・CRCの受信上の位置は符号化・インタリーブで分散します。\n", "note")
        spans = ([("CSM", 0, 35, "bit_csm"), ("残りの情報", 36, 79, "bit_other")] if pich else [("データ", 0, 79, "bit_user")])
        spans += [("CRC12", 80, 91, "bit_crc"), ("Tail", 92, 95, "bit_other")]
        self._show_byte_dump(sequence, spans=spans)
        values = {}
        if pich and set(sequence[:36]) <= {"0", "1"}:
            csm = "".join(f"{int(sequence[i:i + 4], 2):X}" for i in range(0, 36, 4))
            values["CSM"] = csm + (f" ({self.alias[csm]})" if csm in self.alias else "")
            if not self._valid_csm(csm):
                self._ins("CSM候補は9桁BCDとして不正です。局の確定値には使えません。\n", "ng")
        elif not pich and bits:
            payload = bytes(int(sequence[i:i + 8], 2) for i in range(0, 80, 8))
            values["データ"] = payload.hex(" ")
            self._show_text_lines(payload)
        self._show_value_map(sequence, spans, values)
        self._ins("CSMは各4bitが1桁のBCD、先頭桁は局種別の解釈に使います。\n" if pich else "データはメーカー固有の内容もあり、この領域だけでは上位プロトコルの項目を断定できません。\n", "dim")

    def _show_voice_dump(self, name, bits):
        from vendor.ambe2 import bitio
        self._ins("\n音声ブロック: 9byte / 72bitずつの2ブロック\n", "title")
        self._ins("受信ダンプの色はC0/C1/C2/C3の符号語に対応します。各符号語はインタリーブで複数byteに分散しています。\n", "dim")
        for block in range(2):
            payload = int(bits[block * 72:(block + 1) * 72], 2).to_bytes(9, "big")
            words = bitio.dibit36_to_c(payload)
            self._ins(f"\nブロック{block + 1}: {name}内byte {block * 9}〜{block * 9 + 8}\n", "title")
            self._ins("インタリーブを戻したCODE72（受信byte順とは別）\n", "note")
            sequence = "".join(f"{value:0{width}b}" for value, width in zip(words, bitio.C_WIDTHS))
            spans, position = [], 0
            for word, width in enumerate(bitio.C_WIDTHS):
                spans.append((f"C{word}", position, position + width - 1, f"voice_C{word}"))
                position += width
            self._show_byte_dump(sequence, spans=spans)
            self._show_value_map(sequence, spans, {f"C{i}": f"0x{value:X} ({value})" for i, value in enumerate(words)})
            report = bitio.fec_decode(words)
            self._ins(f"FEC訂正距離: C0={report.e0} / C1={report.e1} / {'失敗・候補は参考' if report.failure else '失敗判定なし'}\n", "ng" if report.failure else "dim")
        self._ins("C0=24bit、C1=23bitは誤り訂正対象、C2=11bit、C3=14bitは無保護の部分です。値は音声の符号語で、振幅・周波数そのものではありません。\n", "dim")
        self._ins("「音声ビット解析・試聴…」で、試聴キーを使った49bitの秘話解除、b0〜b8の配置・音声パラメータ・復号履歴・波形を解析できます。\n", "note")

    def _has_voice_bits(self, index):
        F, mode, valid, _source = self._frame_role(index)
        return bool(valid and F == 1 and
                    ((mode in (2, 3) and self._section_bits(index, "TCH1")) or
                     (mode in (1, 3) and self._section_bits(index, "TCH2"))))

    def _open_voice_analysis(self):
        selected = self.framelist.curselection()
        if not selected or not self._has_voice_bits(selected[0]):
            self.region_status.configure(text="解析には、音声割当てを確認できる通話フレームと保存済みTCHビットが必要です。")
            return
        if self._voice_window is not None and self._voice_window.winfo_exists():
            self._voice_window.lift()
            self._voice_window._follow_frame()
            return
        from ambe_voice_window import AmbeVoiceWindow
        self._voice_window = AmbeVoiceWindow(self)

    def destroy(self):
        if self._voice_window is not None:
            self._voice_window.destroy()
            self._voice_window = None
        super().destroy()

    def _draw_bar(self):
        c = self.bar
        c.delete("all")
        w = c.winfo_width() or 900
        y, h = self._bar_geom
        x = 2.0; avail = w - 4; offset = 0
        total = sum(l for _, l, _ in self.LAYOUT)
        fr = self._cur_fr
        self._bar_regions = {}
        for name, length, col in self.LAYOUT:
            seg = avail * length / total
            lbl = name
            if fr and name == "TCH1" and fr.get("F") == 0:
                lbl = "TCH1=PICH"
            self._bar_regions[name] = (x, y, x + seg, y + h + 2 * self._bar_small.metrics("linespace") + 6)
            c.create_rectangle(x + 1, y, x + seg - 1, y + h, fill=self.FILL[name], outline=col,
                               width=3 if name == self._selected_region else 1, tags=("region_" + name,))
            font = next((f for f in (self._bar_font, self._bar_tight) if f.measure(lbl) + 6 < seg), None)
            if font is not None:
                c.create_text(x + seg / 2, y + h / 2, text=lbl, fill=col, font=font)
            c.create_text(x + seg / 2, y + h + 3, anchor="n", text=f"{offset}–{offset + length - 1}\n{length}b", fill=self.DIM, font=self._bar_small)
            offset += length
            x += seg
        caption_y = y + h + 2 * self._bar_small.metrics("linespace") + 8
        if fr is not None:
            F = fr.get("F")
            c.create_text(4, caption_y, anchor="nw",
                          text=("● 制御フレーム F=0" if F == 0 else "● 通話フレーム F=1" if F == 1 else "● フレーム種別不明"),
                          fill=(self.NOTE_INK if F == 0 else self.OK_INK), font=self._bar_font)
        else:
            c.create_text(4, caption_y, anchor="nw", text="STD-T98 1フレーム = 192シンボル(384bit) ≒ 80ms",
                          fill=self.DIM, font=("Segoe UI", 9))

    def _plain(self, text):
        self.pages.forget(self.dump_host)
        self.detail.delete("1.0", tk.END)
        self.detail.insert(tk.END, text, "dim")

    def _ins(self, text, *tags):
        self.detail.insert(tk.END, text, tags if tags else ())

    def _bits(self, label, bits):
        """ビット列の行。記録に無い(空)ときは行ごと出さない。"""
        if bits:
            self._ins(f"  {label}{bits}\n", "bits")

    # 略語の正式名は各所に散らさず、文末にまとめて一覧表示する(重複説明を避ける)。
    def _append_glossary(self):
        self._ins("\n── 略語 ──\n", "title")
        order = [
            ("SW",    "同期語"),
            ("RICH",  "無線制御"),
            ("SACCH", "付随制御"),
            ("TCH",   "通話ch"),
            ("PICH",  "パラメータ情報(制御時のTCH1)"),
            ("CSM",   "呼出名称記憶装置=局固有ID"),
            ("AMBE",  "音声コーデック"),
            ("FEC",   "前方誤り訂正=畳込符号"),
            ("CRC",   "巡回冗長検査=誤り検出"),
            ("FSK",   "周波数偏移変調"),
            ("PN",    "擬似雑音系列"),
        ]
        for ab, jp in order:
            self._ins(f"{ab:5s}", "abbr")
            self._ins(f"= {self.FULL.get(ab, '')}({jp})\n", "dim")

    def _show_text_lines(self, data, indent="    "):
        for label, encoding in TEXT_ENCODINGS:
            self._ins(f"{indent}{label:9s} ", "dim")
            self._ins(render_text(data, encoding) + "\n", "val")

    def _show_data_tch(self, decoded, M):
        """非音声 TCH: PICH と同じ符号化(9×16インタリーブ・3/4パンクチャ・K=5畳込+CRC12)で復号。"""
        self._ins(f"  → 非音声データ(M={M})。PICH と同じ符号化で復号: 80bit(10byte) + CRC12。\n", "dim")
        for name, result, bits in decoded:
            self._ins(f"  {name} データ  CRC12=", "dim"); self._ins("OK" if result["CRC_OK"] else "NG", "ok" if result["CRC_OK"] else "ng")
            self._ins(f"  (訂正 {result['BitErrors']}bit)\n", "dim")
            self._ins("    HEX       " + result["data"].hex(" ") + "\n", "bits")
            if result["CRC_OK"]:
                self._show_text_lines(result["data"])
            else:
                self._ins("    → CRC 不一致。この符号化ではない(非音声1 は全1の詰め物が多い)か、受信誤り。\n", "ng")
                raw = bytes(int(bits[i:i + 8], 2) for i in range(0, 144, 8))
                self._ins("    生ビット  " + raw.hex(" ") + "\n", "bits")
        payload = data_payload(decoded)
        if len(decoded) == 2 and len(payload) == 20:
            self._ins("  TCH1+TCH2 連結 (20byte)\n", "dim")
            self._show_text_lines(payload)
        self._ins("  ※テキストとは限らない(位置情報などメーカー独自のバイナリ形式の可能性)。表示できない文字は �/·。\n", "note")

    def _data_summary(self):
        """CRC OK の非音声ペイロードを TCH ごとに同一内容でまとめる。
        [(TCH名, bytes, [フレーム番号...])]、初出順。同じデータは繰り返し送られることが多い。"""
        seen = {}
        for i, decoded in enumerate(self.decoded):
            for name, result, _bits in decoded:
                if result["CRC_OK"]:
                    seen.setdefault((name, result["data"]), []).append(i)
        return [(name, data, frames) for (name, data), frames in seen.items()]

    @staticmethod
    def _frame_span(frames):
        """[1,2,3,5] → "#001–#003, #005"。"""
        parts, start = [], frames[0]
        for prev, cur in zip(frames, frames[1:] + [None]):
            if cur is None or cur != prev + 1:      # 連番が途切れた所で区切る
                parts.append(f"#{start:03d}" + (f"–#{prev:03d}" if prev > start else ""))
                start = cur
        return ", ".join(parts)

    @staticmethod
    def _rich_m_desc(F, M):
        """RICH の通信モード M の意味(本 表2.6/2.7)。F=0:同期バースト時, F=1:通信用ch時。"""
        if F == 0:
            return "同期バースト(SB0)" if M == 3 else "予約"
        return {
            0: "非音声1(TCH1/2ともデータ)",
            1: "TCH1=非音声2 / TCH2=音声",
            2: "TCH1=音声 / TCH2=非音声2",
            3: "TCH1/2とも音声",
            4: "非音声2(TCH1/2ともデータ)",
            5: "アイドル(終話)",
        }.get(M, "予約")

    def _show_overview(self):
        self.pages.forget(self.dump_host)
        self._visible_dump_bits = ""
        d = self.detail; d.delete("1.0", tk.END)
        freq = self.header.get("freq_hz", 0)
        self._ins("STD-T98 フレーム形式\n", "title")
        self._ins(f"周波数 {freq/1e6:.5f} MHz   変調 4値FSK {self.header.get('baud',2400)}baud "
                  f"(偏移 ±945Hz / 1ステップ315Hz)\n", "dim")
        self._ins("1フレーム = 192シンボル(384bit) ≒ 80ms。1シンボル=2bit(4値)。\n\n", "dim")
        for name, length, col in self.LAYOUT:
            self._ins(f"■ {name}", "h_" + name)
            self._ins(f"  {length}bit ({length//2}sym)\n", "dim")
        self._ins("\nSW", "h_SW"); self._ins("=同期語(固定パターン、相関で同期)  ", "dim")
        self._ins("RICH", "h_RICH"); self._ins("=無線制御(F/M/D・偶数パリティのみ)  ", "dim")
        self._ins("SACCH", "h_SACCH"); self._ins("=付随制御(識別・畳込符号+CRC6・★秘話でも平文)  ", "dim")
        self._ins("TCH", "h_TCH1"); self._ins("=通話ch(音声AMBE or 制御時はPICH=CSM)\n\n", "dim")

        self._ins("── 受信処理の流れ ──\n", "title")
        self._ins("4FSK復調 → シンボル判定 → デホワイトニング(PN(9,5)/初期値228, フレーム毎初期化) → \n"
                  "フィールド分解 → FEC(畳み込み符号)/CRC で誤り訂正・検査。\n", "dim")
        self._ins("誤り訂正符号: 拘束長5・符号化率1/2 の畳み込み符号 "
                  "G1(D)=1+D³+D⁴, G2(D)=1+D+D²+D⁴(SACCH/PICH共通)。\n", "dim")
        self._ins("CRC: SACCH=CRC6(1+X²+X⁵+X⁶)、PICH=CRC12。残留誤りの検査に使う。\n\n", "dim")

        self._ins("── 秘話(スクランブル)──\n", "title")
        self._ins("秘話コード(0–32767)から PN15 で 196bit の系列を生成し、通話(AMBE)の \n"
                  "196bit(49bit×4サブフレーム)だけに XOR。制御(SW/RICH/SACCH/PICH)は平文。\n", "dim")
        self._ins("スクランブルは誤り訂正の後段=エラーレートには影響しない。秘話ON/OFFは \n"
                  "SACCH の通話識別(00=通常/01=秘話)で分かる。\n", "dim")
        self._ins("※アルインコ独自の「強化秘話」(15種)は PN 生成法だけ変えた別パターン。\n\n", "dim")

        data_frames = sum(1 for fr in self.frames if data_halves(fr))
        if data_frames:
            runs = self._data_summary()
            self._ins("── 非音声データ ──\n", "title")
            self._ins(f"データを含むフレーム {data_frames} / CRC OK の内容 {len(runs)} 種類"
                      "(同じ内容は TCH ごとにまとめて表示)\n", "dim")
            for name, payload, frames in runs:
                self._ins(f"  {name}  ×{len(frames)}", "abbr")
                self._ins(f"  ({self._frame_span(frames)})  {len(payload)}byte\n", "dim")
                self._ins("    HEX       " + payload.hex(" ") + "\n", "bits")
                self._show_text_lines(payload)
            best = {}
            for name, payload, frames in runs:          # TCH ごとに最も多く受かった内容
                if len(frames) > len(best.get(name, (b"", []))[1]):
                    best[name] = (payload, frames)
            if len(best) == 2:
                joined = best["TCH1"][0] + best["TCH2"][0]
                self._ins("  TCH1+TCH2 連結(各TCHで最多の内容)  20byte\n", "abbr")
                self._ins("    HEX       " + joined.hex(" ") + "\n", "bits")
                self._show_text_lines(joined)
            if not runs:
                self._ins("  CRC OK のデータはありません(非音声1 の全1詰め物・受信誤りなど)。\n", "dim")
            if not any(self.tch):
                self._ins("  ※この記録に対応する raw が無いため TCH ビットを読めません。\n", "ng")
            self._ins("\n")
        self._ins(f"左からフレームを選ぶと各フィールドを解剖表示します({len(self.frames)}フレーム)。\n", "note")
        self._append_glossary()

    def _on_frame(self, _e):
        sel = self.framelist.curselection()
        if not sel:
            return
        fr = self.frames[sel[0]]; self._cur_fr = fr; self._draw_bar()
        self.voice_button.configure(state="normal" if self._has_voice_bits(sel[0]) else "disabled")
        if self._selected_region:
            self._show_region_dump(sel[0], self._selected_region)
            return
        self.pages.forget(self.dump_host)
        F = fr.get("F")
        d = self.detail; d.delete("1.0", tk.END)

        self._ins(f"フレーム #{sel[0]:03d}  ", "title")
        self._ins("制御 (F=0)\n" if F == 0 else "通話 (F=1)\n" if F == 1 else "種別不明 (F未記録)\n",
                  "h_RICH" if F == 0 else "h_TCH1")
        self._show_frame_context(sel[0], fr)
        self._ins(f"t={fr.get('t')}\n\n" if fr.get("t") is not None else "\n", "dim")
        self._show_bit_locations()

        def recorded(value):
            return "未記録" if value is None else str(value)

        def ok_ng(flag):
            if flag is None:
                self._ins("未記録", "dim")
            else:
                self._ins("OK" if flag else "NG", "ok" if flag else "ng")

        # SW
        self._ins("■ SW ", "h_SW"); self._ins("同期語 (20bit=10sym)\n", "dim")
        self._bits("", self._section_bits(sel[0], "SW"))
        self._ins("  → フレーム先頭の固定パターン。受信機の同期(相関)に使う。\n\n", "dim")
        # RICH
        r = fr.get("rich", {})
        M = r.get("M")
        self._ins("■ RICH ", "h_RICH"); self._ins("無線制御 (7bit→16bit, 偶数パリティ+ダイビットのみ・FEC/CRCなし)\n", "dim")
        self._bits("", self._section_bits(sel[0], "RICH"))
        self._ins("  構成: F(1) 予約(2) M(3) D(1)\n", "dim")
        self._ins("  F=", "dim"); self._ins(recorded(r.get('F')), "val")
        f_desc = {0: "制御=同期バースト", 1: "通話用チャネル"}.get(r.get("F"), "種別の記録なし")
        self._ins(f" ({f_desc})\n", "dim")
        self._ins("  M=", "dim"); self._ins(recorded(M) + " ", "val"); self._ins(f"({self._rich_m_desc(r.get('F'), M) if M is not None else '割当ての記録なし'})\n", "dim")
        self._ins("  D=", "dim"); self._ins(recorded(r.get('D')), "val")
        d_desc = "未記録" if r.get("D") is None else "直接通信" if r.get("D") == 0 else "予約"
        self._ins(f" ({d_desc})  parity=", "dim")
        if r.get("parityOK") is None:
            self._ins("未記録", "dim")
        else:
            ok_ng(r.get("parityOK"))
        self._ins("\n", "dim")
        for keys, label, explanation in (
                (("Res1", "res1"), "予約1", "RICH内の予約フィールド(1bit)。用途は解釈していません。"),
                (("Res2", "res2"), "予約2", "RICH内の予約フィールド(1bit)。用途は解釈していません。"),
                (("Parity", "parity"), "パリティビット", "情報7bitと合わせて偶数パリティを検査する1bit。")):
            value = next((r[key] for key in keys if key in r), None)
            if value is not None:
                self._ins(f"  {label}=", "dim"); self._ins(f"{value}", "val")
                self._ins(f"  → {explanation}\n", "dim")
        self._ins("  → RICHは軽い保護(パリティのみ)なので誤りやすい。M で音声/非音声・終話が分かる。\n\n", "dim")
        # SACCH
        s = fr.get("sacch")
        self._ins("■ SACCH ", "h_SACCH"); self._ins("付随制御 (情報26bit→符号化60bit, 畳込符号+CRC6, ★秘話でも平文)\n", "dim")
        self._bits("", self._section_bits(sel[0], "SACCH"))
        self._ins("  組立: 26bit(F/Wr/種別/通話識別/ユーザ/メーカ) +CRC6 +Tail4 → 畳込×2 → パンクチャ → インタリーブ\n", "dim")
        self._show_sacch_bit_fields(s)
        if s:
            self._ins("  CRC=", "dim"); ok_ng(s.get("crcOK"))
            if s.get("crcOK"):
                trust = bool(r.get("parityOK"))   # RICHも正常なら信頼できる
                cs = s.get("callStat")
                cs_desc = {0: "通常通信(平文)", 1: "秘話通信"}.get(cs, "予約")
                self._ins("  種別=", "dim"); self._ins(recorded(s.get('msgType')), "val")
                self._ins("  通話識別=", "dim"); self._ins(recorded(cs), "val"); self._ins(f"({cs_desc if cs is not None else '未記録'})", "dim" if cs in (None,0,1) else "ng")
                self._ins("\n  ユーザ(グループ)=", "dim"); self._ins(recorded(s.get('userCode')), "val" if trust else "ng")
                user_name = self.user_alias.get(s.get("userCode"))
                if user_name:
                    self._ins(f" ({user_name})", "dim" if trust else "ng")
                self._ins("  メーカ=", "dim"); self._ins(recorded(s.get('makerCode')), "val" if trust else "ng")
                maker_name = self.makers.get(s.get("makerCode"))
                if maker_name:
                    self._ins(f" ({maker_name})", "dim" if trust else "ng")
                self._ins("\n", "dim")
                self._ins("  → 種別は制御メッセージの種類(5bit)、通話識別は通信状態(2bit)。未記録は値0とは区別します。\n", "dim")
                if trust:
                    self._ins("  → ユーザ=グループ/選択呼出コード(0-511)、メーカ=無線機メーカー番号(0-127)。\n", "dim")
                    self._ins("  → 通話識別=01 なら秘話ON(TCHがスクランブルされ鍵が必要)。これは平文で読める。\n\n", "dim")
                else:
                    self._ins("  ⚠ RICHが誤り(parity NG)。SACCH CRC(6bit)はまぐれ合格しうるので、"
                              "この ユーザ/メーカ は偽陽性の疑い。連続フレームで値が一致するものだけ信用を。\n\n", "ng")
            else:
                # CRC NG のSACCHから取った値はビット誤りで“でたらめ”→有効値として出さない。
                reason = "CRC未記録。識別情報の検証不可" if s.get("crcOK") is None else "CRC不一致。この行の ユーザ/メーカ/種別 は壊れており無効"
                self._ins(f"  → {reason}"
                          f"(参考の生値: U={recorded(s.get('userCode'))} M={recorded(s.get('makerCode'))})。\n\n", "ng")
        else:
            self._ins("  (デコード不可)\n\n", "ng")
        self._show_control_checks(s or {})
        if s and s.get("F") is not None:
            self._ins(f"  SACCH F={s['F']} → 情報の先頭1bit。RICHのFとは別のフィールドです（記録値）。\n", "dim")
        if s and ("Wr" in s or "wr" in s):
            self._ins(f"  Wr={s.get('Wr', s.get('wr'))} → 2bitの記録値。用途の解釈は未実装です。\n", "dim")
        # TCH
        self._ins("■ TCH1/TCH2 ", "h_TCH1"); self._ins("通話ch (各144bit)\n", "dim")
        tch = self.tch[sel[0]] if sel[0] < len(self.tch) else ""
        source = self.tch_sources[sel[0]] if sel[0] < len(self.tch_sources) else "未記録"
        self._ins(f"  TCHビット取得元: {source}\n", "dim")
        for name, bits in (("TCH1", tch[:144]), ("TCH2", tch[144:288])):
            self._bits(f"{name} ", bits[:64] + ("…" if len(bits) > 64 else ""))
        if F == 0:
            p = fr.get("pich", {})
            self._ins("  制御フレーム → TCH1=PICH  CRC12=", "dim"); ok_ng(p.get("crcOK"))
            self._ins("\n", "dim")
            self._show_control_checks(p)
            if p.get("crcOK") and r.get("parityOK") and self._valid_csm(p.get("csm")):
                csm = p.get("csm", "")
                kind = "登録局" if csm[:1] == "2" else "免許局" if csm[:1] == "1" else "?"
                self._ins("  CSM=", "dim"); self._ins(f"{csm}", "val"); self._ins(f" ({kind})\n", "dim")
                self._ins("  → PICH=パラメータ情報。CSM=呼出名称記憶装置(局固有ID)=36bit=9桁BCD。\n", "dim")
                self._ins("  → 先頭桁 2=登録局 / 1=免許局。CSMは通話開始時(SB0)にのみ送信=取りこぼしやすい。\n", "dim")
            else:
                reason = "PICH CRC未記録" if p.get("crcOK") is None else "PICH CRC不一致" if not p.get("crcOK") else "RICHパリティNG / 未記録" if not r.get("parityOK") else "CSMが9桁BCDではない"
                self._ins(f"  → {reason}。当該CSMは確定値として扱いません(参考の生値: {p.get('csm') or '未記録'})。\n", "ng")
            reserve = p.get("Reserve", p.get("reserve"))
            if reserve is not None:
                self._ins(f"  CSM以外の残りのビット Reserve={reserve}\n", "dim")
                self._ins("  → デコーダがCSMの後に取り出した領域。局の識別には使いません。\n", "dim")
        elif F == 1 and self.decoded[sel[0]]:
            self._show_data_tch(self.decoded[sel[0]], M)
        elif F == 1 and data_halves(fr):
            self._ins(f"  → 非音声データ(M={M})。{self._rich_m_desc(F, M)}。\n", "dim")
            self._ins("  TCHビット未記録 / 対応するrawなしのため、データの中身は復号できません。\n", "note")
        elif F == 1 and r.get("parityOK") and M == 5:
            self._ins("  → アイドル(終話)。この割当てを音声とは扱いません。\n", "dim")
        elif F == 1 and r.get("parityOK") and M in (1, 2, 3):
            self._ins("  → AMBE+2 音声(2450bps)= 49bit×4サブフレーム(TCH1a/b, TCH2a/b)。", "dim")
            vtxt = self._rich_m_desc(1, M) if r.get("parityOK") else "M不明"
            self._ins(f" 音声割当: {vtxt}\n", "dim")
            self._ins("  ★秘話ONはこの音声ビット(196bit)だけを PN15 で XOR。制御は平文のまま。\n", "note")
        else:
            self._ins("  → フレーム種別 / RICH割当てが不明または不正。音声・データを断定できません。\n", "note")
        self._append_glossary()


class _AliasEditor(tk.Toplevel):
    """別名CSV の登録・編集・削除ダイアログ(共通部)。サブクラスがキーの種類を決める。"""
    TITLE = ""
    KEY_LABEL = ""
    KEY_HINT = ""
    CSV_PATH = ""

    def __init__(self, master, preset_key=""):
        super().__init__(master)
        self.title(self.TITLE)
        self.geometry("480x440")
        self.configure(bg=_ui_color("SystemButtonFace", "#f0f0f0"))
        self.transient(master)
        self.data = self._load()   # dict: key -> alias
        self.order = []

        tk.Label(self, text=f"登録済みの{self.KEY_LABEL}別名(選ぶと下欄で編集)", bg=_ui_color("SystemButtonFace", "#f0f0f0"), fg=_ui_color("SystemWindowText", "#222222"),
                 font=("", 9, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        self.lb = tk.Listbox(self, height=13, bg=_ui_color("SystemWindow", "#ffffff"), fg=_ui_color("SystemWindowText", "#222222"), selectbackground=_ui_color("SystemHighlight", "#0078d4"),
                             highlightthickness=0, borderwidth=0, activestyle="none", font=("Consolas", 10))
        self.lb.pack(fill=tk.BOTH, expand=True, padx=10)
        self.lb.bind("<<ListboxSelect>>", self._on_sel)

        form = tk.Frame(self, bg=_ui_color("SystemButtonFace", "#f0f0f0")); form.pack(fill=tk.X, padx=10, pady=(6, 0))
        tk.Label(form, text=self.KEY_LABEL, bg=_ui_color("SystemButtonFace", "#f0f0f0"), fg=_ui_color("SystemWindowText", "#222222")).grid(row=0, column=0, sticky="w")
        self.keyvar = tk.StringVar(value=preset_key)
        tk.Entry(form, textvariable=self.keyvar, width=14).grid(row=0, column=1, sticky="w", padx=4, pady=2)
        tk.Label(form, text=self.KEY_HINT, bg=_ui_color("SystemButtonFace", "#f0f0f0"), fg="gray").grid(row=0, column=2, sticky="w")
        tk.Label(form, text="別名", bg=_ui_color("SystemButtonFace", "#f0f0f0"), fg=_ui_color("SystemWindowText", "#222222")).grid(row=1, column=0, sticky="w")
        self.aliasvar = tk.StringVar()
        e = tk.Entry(form, textvariable=self.aliasvar, width=32)
        e.grid(row=1, column=1, columnspan=2, sticky="we", padx=4, pady=2)
        form.columnconfigure(2, weight=1)

        btns = tk.Frame(self, bg=_ui_color("SystemButtonFace", "#f0f0f0")); btns.pack(fill=tk.X, padx=10, pady=8)
        tk.Button(btns, text="追加 / 更新", command=self._save_one, bg="#2E86C1", fg="white").pack(side=tk.LEFT)
        tk.Button(btns, text="削除", command=self._delete_one).pack(side=tk.LEFT, padx=6)
        tk.Button(btns, text="閉じる", command=self.destroy).pack(side=tk.RIGHT)

        self.status = tk.Label(self, text=f"{self.CSV_PATH}", bg=_ui_color("SystemButtonFace", "#f0f0f0"), fg="#2E86C1",
                               anchor="w", font=("", 8))
        self.status.pack(fill=tk.X, padx=10, pady=(0, 8))

        self._refresh()
        k = self._parse_key(preset_key) if preset_key else None
        if k is not None and k in self.data:
            self.aliasvar.set(self.data[k])

    # --- サブクラスで実装 ---
    def _load(self):
        raise NotImplementedError

    def _save(self):
        raise NotImplementedError

    def _parse_key(self, text):
        """入力文字列→辞書キー。受け付けない入力は None。"""
        raise NotImplementedError

    def _warn(self, key):
        """保存は許すが注意したい形式なら注記文字列を返す。"""
        return ""

    # --- 共通処理 ---
    def _refresh(self):
        self.order = sorted(self.data)
        self.lb.delete(0, tk.END)
        for k in self.order:
            self.lb.insert(tk.END, f"{k}  →  {self.data[k]}")

    def _on_sel(self, _e):
        sel = self.lb.curselection()
        if not sel:
            return
        k = self.order[sel[0]]
        self.keyvar.set(str(k))
        self.aliasvar.set(self.data.get(k, ""))

    def _save_one(self):
        text = self.keyvar.get().strip()
        alias = self.aliasvar.get().strip()
        if not text:
            self.status.config(text=f"{self.KEY_LABEL} を入力してください", fg="#c0392b"); return
        k = self._parse_key(text)
        if k is None:
            self.status.config(text=f"{self.KEY_LABEL} が不正です ({self.KEY_HINT})", fg="#c0392b"); return
        if not alias:
            self.status.config(text="別名を入力してください", fg="#c0392b"); return
        self.data[k] = alias
        self._save()
        self._refresh()
        self.master._reload_aliases()
        self.status.config(text=f"保存: {k} → {alias}{self._warn(k)}", fg="#2E86C1")

    def _delete_one(self):
        k = self._parse_key(self.keyvar.get().strip())
        if k is not None and k in self.data:
            del self.data[k]
            self._save()
            self._refresh()
            self.master._reload_aliases()
            self.aliasvar.set("")
            self.status.config(text=f"削除: {k}", fg="#2E86C1")
        else:
            self.status.config(text=f"その{self.KEY_LABEL}は未登録です", fg="#c0392b")


class CsmAliasEditor(_AliasEditor):
    """CSM別名 (csm_alias.csv) の登録・編集・削除。SDR#プラグインと共有するCSV。
    別名を付けると受信ログや試聴ツールで CSM の代わりに局名が表示される。"""
    TITLE = "CSM別名の登録・編集・削除"
    KEY_LABEL = "CSM"
    KEY_HINT = "9桁 (先頭 2=登録局 / 1=免許局)"
    CSV_PATH = CSM_ALIAS_CSV

    def __init__(self, master, preset_csm=""):
        super().__init__(master, preset_key=preset_csm)

    def _load(self):
        return load_csm_alias()

    def _save(self):
        save_csm_alias(self.data)

    def _parse_key(self, text):
        return text or None

    def _warn(self, csm):
        ok = len(csm) == 9 and csm[:1] in ("1", "2") and csm.isdigit()
        return "" if ok else "  (※9桁BCD形式ではありません)"


class UserAliasEditor(_AliasEditor):
    """ユーザ番号別名 (user_alias.csv) の登録・編集・削除。
    別名を付けると試聴ツールの情報欄・絞り込みでユーザ番号に別名が併記される。"""
    TITLE = "ユーザ番号別名の登録・編集・削除"
    KEY_LABEL = "ユーザ番号"
    KEY_HINT = "0-511 (0=一斉)"
    CSV_PATH = USER_ALIAS_CSV

    def _load(self):
        return load_user_alias()

    def _save(self):
        save_user_alias(self.data)

    def _parse_key(self, text):
        try:
            uc = int(text)
        except ValueError:
            return None
        return uc if 0 <= uc <= 511 else None


class MakerAliasEditor(_AliasEditor):
    """メーカ名 (maker_codes.csv) の登録・編集・削除。メーカ番号(0-127)→名称。"""
    TITLE = "メーカ名の登録・編集・削除"
    KEY_LABEL = "メーカ番号"
    KEY_HINT = "0-127"
    CSV_PATH = MAKER_CODES_CSV

    def _load(self):
        return load_maker_codes()

    def _save(self):
        save_maker_codes(self.data)

    def _parse_key(self, text):
        try:
            c = int(text)
        except ValueError:
            return None
        return c if 0 <= c <= 127 else None


class KeyBindingEditor(tk.Toplevel):
    """秘話キーの紐づけ (manual_keys.csv) を登録・編集・削除。
    CSM / ユーザ番号 / 周波数(Hz) のいずれかに鍵を紐付ける。試聴ツールの復号は
    CSM優先 → ユーザ → 周波数 の順で鍵を解決する。"""
    BG = _ui_color("SystemButtonFace", "#f0f0f0"); FG = _ui_color("SystemWindowText", "#222222")
    KINDS = [("CSM", "csm"), ("ユーザ番号", "user"), ("周波数(Hz)", "freq")]

    def __init__(self, master, preset=None):
        super().__init__(master)
        self.master_app = master
        self.title("秘話キーの紐づけ")
        self.geometry("500x460")
        self.configure(bg=self.BG)
        self.transient(master)
        self.rows = load_key_bindings()

        tk.Label(self, text="登録済みの紐づけ(選ぶと下欄で編集)", bg=self.BG, fg=self.FG,
                 font=("", 9, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        self.lb = tk.Listbox(self, height=13, bg=_ui_color("SystemWindow", "#ffffff"), fg=self.FG, selectbackground=_ui_color("SystemHighlight", "#0078d4"),
                             highlightthickness=0, borderwidth=0, activestyle="none", font=("Consolas", 10))
        self.lb.pack(fill=tk.BOTH, expand=True, padx=10)
        self.lb.bind("<<ListboxSelect>>", self._on_sel)

        form = tk.Frame(self, bg=self.BG); form.pack(fill=tk.X, padx=10, pady=(6, 0))
        tk.Label(form, text="種別", bg=self.BG, fg=self.FG).grid(row=0, column=0, sticky="w")
        self.kindvar = tk.StringVar(value="CSM")
        ttk.Combobox(form, textvariable=self.kindvar, values=[k for k, _ in self.KINDS],
                     state="readonly", width=12).grid(row=0, column=1, sticky="w", padx=4, pady=2)
        tk.Label(form, text="値", bg=self.BG, fg=self.FG).grid(row=1, column=0, sticky="w")
        self.valvar = tk.StringVar()
        tk.Entry(form, textvariable=self.valvar, width=18).grid(row=1, column=1, sticky="w", padx=4, pady=2)
        tk.Label(form, text="CSM=9桁 / ユーザ=0-511 / 周波数=Hz", bg=self.BG, fg="gray").grid(
            row=1, column=2, sticky="w")
        tk.Label(form, text="鍵", bg=self.BG, fg=self.FG).grid(row=2, column=0, sticky="w")
        self.keyvar = tk.StringVar()
        tk.Entry(form, textvariable=self.keyvar, width=10).grid(row=2, column=1, sticky="w", padx=4, pady=2)
        tk.Label(form, text="1-32767", bg=self.BG, fg="gray").grid(row=2, column=2, sticky="w")

        btns = tk.Frame(self, bg=self.BG); btns.pack(fill=tk.X, padx=10, pady=8)
        tk.Button(btns, text="追加 / 更新", command=self._save_one, bg="#2E86C1", fg="white").pack(side=tk.LEFT)
        tk.Button(btns, text="削除", command=self._delete_one).pack(side=tk.LEFT, padx=6)
        tk.Button(btns, text="閉じる", command=self.destroy).pack(side=tk.RIGHT)
        self.status = tk.Label(self, text=str(MANUAL_KEYS_CSV), bg=self.BG, fg="#2E86C1",
                               anchor="w", font=("", 8))
        self.status.pack(fill=tk.X, padx=10, pady=(0, 8))

        self._refresh()
        if preset:
            self.kindvar.set(preset[0]); self.valvar.set(str(preset[1]))

    _KIND_JA = {"csm": "CSM", "user": "ユーザ", "freq": "周波数"}

    def _fmt(self, kind, val):
        if kind == "freq":
            return f"周波数 {int(val)/1e6:.5f}MHz"
        return f"{self._KIND_JA.get(kind, kind)} {val}"

    def _refresh(self):
        self.rows = load_key_bindings()
        self.lb.delete(0, tk.END)
        for kind, val, k in self.rows:
            self.lb.insert(tk.END, f"{self._fmt(kind, val)}  →  鍵 {k}")

    def _on_sel(self, _e):
        sel = self.lb.curselection()
        if not sel:
            return
        kind, val, k = self.rows[sel[0]]
        self.kindvar.set(dict((v, ja) for ja, v in self.KINDS).get(kind, "CSM"))
        self.valvar.set(str(val)); self.keyvar.set(str(k))

    def _kind(self):
        return dict(self.KINDS)[self.kindvar.get()]

    def _parse_value(self, kind, text):
        text = text.strip()
        if not text:
            return None
        if kind == "csm":
            return text if text.isdigit() and len(text) == 9 else None
        try:
            v = int(text)
        except ValueError:
            return None
        if kind == "user":
            return v if 0 <= v <= 511 else None
        return v if v > 0 else None   # freq(Hz)

    def _save_one(self):
        kind = self._kind()
        val = self._parse_value(kind, self.valvar.get())
        if val is None:
            self.status.config(text="値が不正です(CSM=9桁 / ユーザ=0-511 / 周波数=Hz)", fg="#c0392b"); return
        try:
            key = int(self.keyvar.get())
        except ValueError:
            key = 0
        if not (1 <= key <= 32767):
            self.status.config(text="鍵は 1-32767 で入力してください", fg="#c0392b"); return
        set_key_binding(kind, val, key)
        self._refresh()
        self._apply_to_app()
        self.status.config(text=f"保存: {self._fmt(kind, val)} → 鍵 {key}", fg="#2E86C1")

    def _delete_one(self):
        kind = self._kind()
        val = self._parse_value(kind, self.valvar.get())
        if val is None:
            self.status.config(text="削除する値を入力してください", fg="#c0392b"); return
        set_key_binding(kind, val, 0)
        self._refresh()
        self._apply_to_app()
        self.status.config(text=f"削除: {self._fmt(kind, val)}", fg="#2E86C1")

    def _apply_to_app(self):
        # 現在選択中ファイルの鍵表示を更新(CSM/ユーザ/周波数の解決結果を反映)。
        if self.master_app.filelist.curselection():
            self.master_app._on_file(None)


FILTER_TPL_PATH = os.path.join(_TOOL_DIR, "filter_templates.json")


def serialize_filters(filters, dur):
    """一覧フィルタを JSON 化(保存用)。field->(mode,set) と 長さ(op,sec) を辞書に。"""
    return {
        "filters": {f: {"mode": m, "values": list(vs)} for f, (m, vs) in filters.items()},
        "dur": [dur[0], dur[1]] if dur else None,
    }


def deserialize_filters(d):
    """serialize_filters の逆。(filters, dur) を返す。壊れていれば空フィルタ。"""
    filters = {}
    try:
        for f, spec in (d.get("filters") or {}).items():
            vals = set(spec.get("values") or [])
            if vals:
                filters[f] = ("exc" if spec.get("mode") == "exc" else "inc", vals)
        dur = d.get("dur")
        dur = (dur[0], float(dur[1])) if dur else None
    except Exception:
        return {}, None
    return filters, dur


def load_filter_templates():
    """フィルタテンプレート {name: {"filters": {...}, "dur": [op,sec]|None}} を読む。"""
    try:
        with open(FILTER_TPL_PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_filter_templates(d):
    try:
        with open(FILTER_TPL_PATH, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


class FilterDialog(tk.Toplevel):
    """周波数・CSM・ユーザ・メーカ・秘話を「含む/含まない」で組み合わせて絞り込むダイアログ。
    各項目は AND。値はカンマ区切りで複数指定可(その項目内は OR)。"""
    BG = _ui_color("SystemButtonFace", "#f0f0f0"); FG = _ui_color("SystemWindowText", "#222222")
    MODES = ["無指定", "含む", "含まない"]
    UNKNOWN_VALUES = {"freq": None, "csm": "", "user": None, "maker": None}

    def __init__(self, master):
        super().__init__(master)
        self.master_app = master
        self._apply_serial = 0
        self.title("詳細フィルタ")
        self.configure(bg=self.BG)
        self.transient(master)
        self.resizable(False, False)
        cur = master._filters

        tk.Label(self, text="各項目はAND、同じ項目の値はOR。値はカンマ区切り。不明値も選択できます。",
                 bg=self.BG, fg=self.FG).grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(10, 6))

        self.rows = {}   # field -> (mode_var, entry)
        self.unknown_vars = {}
        specs = [("freq", "周波数 (MHz)"), ("csm", "CSM (9桁)"), ("user", "ユーザ番号"), ("maker", "メーカ番号")]
        r = 1
        for field, label in specs:
            tk.Label(self, text=label, bg=self.BG, fg=self.FG).grid(row=r, column=0, sticky="w", padx=10, pady=3)
            mode = tk.StringVar(value=self._mode_of(cur, field))
            ttk.Combobox(self, textvariable=mode, values=self.MODES, state="readonly", width=7)\
                .grid(row=r, column=1, padx=4)
            ev = tk.StringVar(value=self._values_text(cur, field))
            entry_row = tk.Frame(self, bg=self.BG)
            entry_row.grid(row=r, column=2, sticky="we", padx=(4, 10))
            tk.Entry(entry_row, textvariable=ev, width=20).pack(side=tk.LEFT, fill=tk.X, expand=True)
            unknown = tk.BooleanVar(value=self.UNKNOWN_VALUES[field] in cur.get(field, (None, set()))[1])
            tk.Checkbutton(entry_row, text="CSMなし" if field == "csm" else "不明", variable=unknown,
                           bg=self.BG, fg=self.FG).pack(side=tk.LEFT, padx=(6, 0))
            self.unknown_vars[field] = unknown
            self.rows[field] = (mode, ev)
            r += 1

        # 秘話(状態選択)
        tk.Label(self, text="秘話", bg=self.BG, fg=self.FG).grid(row=r, column=0, sticky="nw", padx=10, pady=3)
        self.sec_mode = tk.StringVar(value=self._mode_of(cur, "secret"))
        ttk.Combobox(self, textvariable=self.sec_mode, values=self.MODES, state="readonly", width=7)\
            .grid(row=r, column=1, sticky="n", padx=4)
        secf = tk.Frame(self, bg=self.BG); secf.grid(row=r, column=2, sticky="w", padx=(4, 10))
        cur_secret = cur.get("secret", (None, set()))[1]
        self.sec_vars = {}
        for val, lab in [(False, "平文"), (True, "秘話"), (None, "不明")]:
            bv = tk.BooleanVar(value=(val in cur_secret))
            tk.Checkbutton(secf, text=lab, variable=bv, bg=self.BG, fg=self.FG, selectcolor=_ui_color("SystemWindow", "#ffffff"),
                           activebackground=self.BG, activeforeground=self.FG).pack(side=tk.LEFT)
            self.sec_vars[val] = bv
        r += 1

        # 音源の長さ(秒)
        tk.Label(self, text="音源の長さ (秒)", bg=self.BG, fg=self.FG).grid(row=r, column=0, sticky="w", padx=10, pady=3)
        df = master._dur_filter
        self.dur_op = tk.StringVar(value=(df[0] if df else "無指定"))
        ttk.Combobox(self, textvariable=self.dur_op, values=["無指定", ">=", "<=", "=="], state="readonly", width=7)\
            .grid(row=r, column=1, padx=4)
        self.dur_val = tk.StringVar(value=(f"{df[1]:g}" if df else ""))
        tk.Entry(self, textvariable=self.dur_val, width=28).grid(row=r, column=2, sticky="we", padx=(4, 10))
        r += 1

        # 日時範囲(YYYY-MM-DD HH:MM。一部省略可)。開始/終了どちらか空でも可(片側開放)。
        tk.Label(self, text="日時 開始", bg=self.BG, fg=self.FG).grid(row=r, column=0, sticky="w", padx=10, pady=3)
        tr = master._time_filter
        self.tfrom = tk.StringVar(value=(self._dt_to_text(tr[0]) if tr and tr[0] else ""))
        tk.Entry(self, textvariable=self.tfrom, width=28).grid(row=r, column=1, columnspan=2, sticky="we", padx=(4, 10))
        r += 1
        tk.Label(self, text="日時 終了", bg=self.BG, fg=self.FG).grid(row=r, column=0, sticky="w", padx=10, pady=3)
        self.tto = tk.StringVar(value=(self._dt_to_text(tr[1]) if tr and tr[1] else ""))
        tk.Entry(self, textvariable=self.tto, width=28).grid(row=r, column=1, columnspan=2, sticky="we", padx=(4, 10))
        r += 1
        tk.Label(self, text="秒も指定可: 2026-09-30 14:00:30", bg=self.BG, fg="gray").grid(row=r, column=0, columnspan=3, sticky="e", padx=(4, 10), pady=(0, 3))
        r += 1

        # 別名/チャンネルから選んで、上の各項目に追加(値を打たずに選べる)
        tk.Label(self, text="別名から追加", bg=self.BG, fg=self.FG,
                 font=("", 9, "bold")).grid(row=r, column=0, columnspan=3, sticky="w", padx=10, pady=(8, 2))
        r += 1
        pf = tk.Frame(self, bg=self.BG); pf.grid(row=r, column=0, columnspan=3, sticky="we", padx=10)
        self._pick_ch = self._make_picker(pf, "チャンネル", self._channel_choices(), "freq")
        self._pick_csm = self._make_picker(pf, "CSM", self._csm_choices(), "csm")
        self._pick_user = self._make_picker(pf, "ユーザ", self._user_choices(), "user")
        r += 1

        # テンプレート(名前を付けて保存/読込/削除)
        tk.Label(self, text="テンプレート", bg=self.BG, fg=self.FG).grid(row=r, column=0, sticky="w", padx=10, pady=(8, 3))
        tf = tk.Frame(self, bg=self.BG); tf.grid(row=r, column=1, columnspan=2, sticky="we", padx=(4, 10))
        self.tpl_name = tk.StringVar()
        self.tpl_cb = ttk.Combobox(tf, textvariable=self.tpl_name, width=18)
        self.tpl_cb.pack(side=tk.LEFT)
        tk.Button(tf, text="読込", command=self._tpl_load, width=4).pack(side=tk.LEFT, padx=2)
        tk.Button(tf, text="保存", command=self._tpl_save, width=4).pack(side=tk.LEFT, padx=2)
        tk.Button(tf, text="削除", command=self._tpl_delete, width=4).pack(side=tk.LEFT, padx=2)
        self._refresh_tpl_list()
        r += 1

        self.status = tk.Label(self, text="", bg=self.BG, fg="#e06c75"); self.status.grid(
            row=r, column=0, columnspan=3, sticky="w", padx=10); r += 1
        btns = tk.Frame(self, bg=self.BG); btns.grid(row=r, column=0, columnspan=3, sticky="e", padx=10, pady=10)
        tk.Button(btns, text="クリア", command=self._clear).pack(side=tk.LEFT, padx=4)
        tk.Button(btns, text="適用", command=self._apply, bg="#2E86C1", fg="white").pack(side=tk.LEFT, padx=4)
        tk.Button(btns, text="閉じる", command=self.destroy).pack(side=tk.LEFT, padx=4)
        self.columnconfigure(2, weight=1)

    @staticmethod
    def _mode_of(cur, field):
        if field not in cur:
            return "無指定"
        return "含む" if cur[field][0] == "inc" else "含まない"

    def _values_text(self, cur, field):
        if field not in cur:
            return ""
        return self._vals_to_text(field, cur[field][1])

    def _clear(self):
        for mode, ev in self.rows.values():
            mode.set("無指定"); ev.set("")
        for variable in self.unknown_vars.values():
            variable.set(False)
        self.sec_mode.set("無指定")
        for bv in self.sec_vars.values():
            bv.set(False)
        self.dur_op.set("無指定"); self.dur_val.set("")
        self.tfrom.set(""); self.tto.set("")
        self.master_app._apply_filter_spec({}, dur=None, time_range=None)
        self.status.config(text="全解除しました", fg="#2E86C1")

    @staticmethod
    def _dt_to_text(key):
        """Preserve seconds when editing or loading a saved condition."""
        if not key or len(key) != 14:
            return ""
        return KeyTool._fmt_dt_key(key)

    # ---- 別名/チャンネルからの選択追加 ----
    _PICK_HINT = "― 選択 ―"

    def _make_picker(self, parent, label, choices, field):
        """ラベル+コンボボックス。選ぶとその値を該当項目の入力欄へ追記する。
        choices: [(表示, 追記する文字列)]。"""
        tk.Label(parent, text=label, bg=self.BG, fg=self.FG).pack(side=tk.LEFT)
        if not hasattr(self, "_pick_vars"):
            self._pick_vars = []      # StringVar の GC 防止に参照を保持
        var = tk.StringVar(value=self._PICK_HINT)
        self._pick_vars.append(var)
        cb = ttk.Combobox(parent, textvariable=var, state="readonly", width=16,
                          values=[self._PICK_HINT] + [c[0] for c in choices])
        cb.pack(side=tk.LEFT, padx=(2, 10))
        cb._map = {c[0]: c[1] for c in choices}   # 表示→追記文字列
        cb._var = var
        cb.bind("<<ComboboxSelected>>", lambda e, c=cb, f=field: self._pick_add(c, f))
        return cb

    def _pick_add(self, cb, field):
        val = cb._map.get(cb.get())
        if val is None:
            return
        mode, ev = self.rows[field]
        # 「別名から追加」は"含む"(このチャンネル/局/ユーザを見たい)として扱う。
        # 除外モード中に別名を選んだら「含む」へ切り替える(除外値は矛盾するので破棄)。
        # 除外したい場合は録音ファイルの右クリック「含まない に追加」を使う。
        if mode.get() != "含む":
            mode.set("含む"); ev.set("")
            self.unknown_vars[field].set(False)
        cur = [t.strip() for t in ev.get().replace("、", ",").split(",") if t.strip()]
        if val not in cur:
            cur.append(val)
        ev.set(", ".join(cur))
        # 選んだ項目はそのまま表示に残す(何を追加したか分かるように)。別の項目を選べば追加される。
        self._apply()   # 右クリックと同様、選んだ瞬間に反映する

    def _csm_choices(self):
        al = self.master_app.alias or {}
        return [(f"{name} ({csm})", csm) for csm, name in sorted(al.items(), key=lambda kv: kv[1])]

    def _user_choices(self):
        ua = self.master_app.user_alias or {}
        return [(f"{name} ({uc})", str(uc)) for uc, name in sorted(ua.items(), key=lambda kv: kv[1])]

    def _channel_choices(self):
        """標準チャンネルグリッド(登録局351 / 免許局467 / 免許局154)を ch名→MHz で列挙。"""
        out = []
        def add(base, count, start, air=False):
            for i in range(count):
                f = base + i * 6250
                lab = channel_label(f)
                out.append((f"{lab}  {f/1e6:.5f}MHz", f"{f/1e6:.5f}"))
        # 登録局(DCR)351
        add(351_200_000, 30, 1); add(351_387_500, 40, 31); add(351_031_250, 12, 71)
        add(351_168_750, 5, 1, True); add(351_106_250, 10, 6, True)
        # 免許局467(ch1..65)
        add(467_000_000, 65, 1)
        # 免許局154(ch1..19 + D1..9)
        add(154_443_750, 28, 1)
        # 重複表示を除き、周波数順に
        seen = {}
        for disp, mhz in out:
            seen.setdefault(mhz, disp)
        return [(seen[mhz], mhz) for mhz in sorted(seen, key=float)]

    def _collect(self):
        """現在のウィジェット値から (spec, dur, bad) を作る。spec は field->(mode,set)。"""
        spec = {}
        bad = []
        for field, (mode, ev) in self.rows.items():
            if mode.get() == "無指定":
                continue
            vals = set()
            unknown = self.unknown_vars.get(field)
            if unknown is not None and unknown.get():
                vals.add(self.UNKNOWN_VALUES[field])
            for tok in ev.get().replace("、", ",").split(","):
                tok = tok.strip()
                if not tok:
                    continue
                try:
                    if field == "freq":
                        value = float(tok)
                        if not math.isfinite(value) or value <= 0:
                            raise ValueError("Invalid frequency")
                        vals.add(round(value * 1e6))
                    elif field in ("user", "maker"):
                        value = int(tok)
                        if value < 0:
                            raise ValueError("Invalid identifier")
                        vals.add(value)
                    else:
                        vals.add(tok)
                except (ValueError, OverflowError):
                    bad.append(f"{self.master_app._FIELD_LABEL[field]}:{tok}")
            if vals:
                spec[field] = ("inc" if mode.get() == "含む" else "exc", vals)
        if self.sec_mode.get() != "無指定":
            svals = {v for v, bv in self.sec_vars.items() if bv.get()}
            if svals:
                spec["secret"] = ("inc" if self.sec_mode.get() == "含む" else "exc", svals)
        dur = None
        if self.dur_op.get() != "無指定":
            t = self.dur_val.get().strip()
            try:
                value = float(t)
                if not math.isfinite(value) or value < 0:
                    raise ValueError("Invalid duration")
                dur = (self.dur_op.get(), value)
            except ValueError:
                bad.append(f"長さ:{t}")
        # 日時範囲
        tfrom = self.tfrom.get().strip(); tto = self.tto.get().strip()
        lo = KeyTool.parse_dt_key(tfrom, is_end=False) if tfrom else None
        hi = KeyTool.parse_dt_key(tto, is_end=True) if tto else None
        if tfrom and lo is None:
            bad.append(f"日時開始:{tfrom}")
        if tto and hi is None:
            bad.append(f"日時終了:{tto}")
        if lo and hi and lo > hi:
            bad.append("日時範囲: 開始は終了以前にしてください")
        time_range = (lo, hi) if (lo or hi) else None
        return spec, dur, bad, time_range

    def _apply(self, message="適用しました"):
        self._apply_serial += 1
        serial = self._apply_serial
        spec, dur, bad, tr = self._collect()
        if bad:
            self.status.config(text="無効な値: " + ", ".join(bad), fg="#e06c75")
            return False
        self.status.config(text="絞り込み中...", fg="#2E86C1")
        def complete(count):
            if not self.winfo_exists() or serial != self._apply_serial:
                return
            text = "他の操作で条件が変更されました" if count is None else f"{message}({count}件)"
            self.status.config(text=text, fg="#2E86C1")
        self.master_app._apply_filter_spec(spec, dur=dur, time_range=tr, on_complete=complete)
        return True

    # ---- テンプレート ----
    def _refresh_tpl_list(self):
        self.tpl_cb["values"] = sorted(load_filter_templates().keys())

    @staticmethod
    def _vals_to_text(field, vals):
        known = [value for value in vals if value is not None and value != ""]
        if field == "freq":
            return ", ".join(f"{value / 1e6:.6f}".rstrip("0").rstrip(".") for value in sorted(known))
        return ", ".join(str(value) for value in sorted(known))

    def _tpl_save(self):
        name = self.tpl_name.get().strip()
        if not name:
            self.status.config(text="テンプレート名を入力してください", fg="#e06c75"); return
        spec, dur, bad, tr = self._collect()
        if bad:
            self.status.config(text="無効な値: " + ", ".join(bad), fg="#e06c75"); return
        tpls = load_filter_templates()
        tpls[name] = {
            "filters": {f: {"mode": m, "values": list(vs)} for f, (m, vs) in spec.items()},
            "dur": [dur[0], dur[1]] if dur else None,
            "time_range": list(tr) if tr else None,
        }
        save_filter_templates(tpls)
        self._refresh_tpl_list()
        self.status.config(text=f"保存しました: {name}", fg="#2E86C1")

    def _tpl_delete(self):
        name = self.tpl_name.get().strip()
        tpls = load_filter_templates()
        if name in tpls:
            del tpls[name]
            save_filter_templates(tpls)
            self._refresh_tpl_list()
            self.status.config(text=f"削除しました: {name}", fg="#2E86C1")
        else:
            self.status.config(text="そのテンプレートはありません", fg="#e06c75")

    def _tpl_load(self):
        name = self.tpl_name.get().strip()
        tpl = load_filter_templates().get(name)
        if not tpl:
            self.status.config(text="そのテンプレートはありません", fg="#e06c75"); return
        # ウィジェットを初期化してからテンプレ値を反映
        for field, (mode, ev) in self.rows.items():
            mode.set("無指定"); ev.set("")
            self.unknown_vars[field].set(False)
        self.sec_mode.set("無指定")
        for bv in self.sec_vars.values():
            bv.set(False)
        self.dur_op.set("無指定"); self.dur_val.set("")
        self.tfrom.set(""); self.tto.set("")
        for field, d in (tpl.get("filters") or {}).items():
            m = "含む" if d.get("mode") == "inc" else "含まない"
            vals = d.get("values") or []
            if field == "secret":
                self.sec_mode.set(m)
                for v in vals:
                    if v in self.sec_vars:
                        self.sec_vars[v].set(True)
            elif field in self.rows:
                self.rows[field][0].set(m)
                self.rows[field][1].set(self._vals_to_text(field, vals))
                self.unknown_vars[field].set(self.UNKNOWN_VALUES[field] in vals)
        dur = tpl.get("dur")
        if dur:
            self.dur_op.set(dur[0]); self.dur_val.set(f"{dur[1]:g}")
        tr = tpl.get("time_range")
        if tr and len(tr) == 2:
            if tr[0]: self.tfrom.set(self._dt_to_text(tr[0]))
            if tr[1]: self.tto.set(self._dt_to_text(tr[1]))
        # 読み込んだら即適用する
        self._apply(message=f"読込・適用: {name}")


if __name__ == "__main__":
    if "--frame-anatomy" in sys.argv[1:]:
        root = tk.Tk()
        root.withdraw()
        window = FrameAnatomy(root)
        window.protocol("WM_DELETE_WINDOW", root.destroy)
        root.mainloop()
    else:
        KeyTool().mainloop()
