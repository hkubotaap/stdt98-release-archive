"""データ解析ウィンドウ: データフレームで運ばれたユーザデータ(RTCM3 / NMEA / UBX)を解析する。

録音・再生ツール(key_tool.py)の「📡 データ解析」から開く。解析処理は
core.analysis.data_stream / core.analysis.rtcm にあり、ここは表示と書き出しだけを受け持つ。
学習用に、各項目の意味(core.analysis.rtcm の MESSAGE_NOTES / FIELD_NOTES)を値の横に出す。
"""
import csv
import datetime
import math
import os
import queue
import statistics
import threading
import tkinter as tk
import webbrowser
from tkinter import filedialog, ttk

from core.analysis.data_stream import (FRAME_SECONDS, MIN_ASCII_RUN, analyse, base_positions, segments, survival,
                                       type_table)
from core.analysis.rtcm import FIELD_NOTES, SAT_NOTES, message_note

FRAME_ROW_LIMIT = 20000
ASCII_ROW_LIMIT = 20000
SAT_ROW_LIMIT = 20000
DUMP_WIDTH = 64
DUMP_LINE_LIMIT = 20000
STATUS_TEXT = {"ok": "完全", "incomplete": "途切れ", "crc_ng": "CRC NG"}
SYSTEM_PREFIX = {"GPS": "G", "GLONASS": "R", "Galileo": "E", "QZSS": "J", "BeiDou": "C", "SBAS": "S", "NavIC": "I"}
LEGAL_NOTE = ("※電波法59条は対象通信の存在・内容の漏えい・窃用を規制します。権限のない補正データの利用・共有に注意してください。"
              "暗号通信の復元は109条の2の目的要件も確認してください。研究・解析でも一律免除にはなりません（LEGAL_NOTICE.md）。")
DAMAGED_NOTE = ("CRC NG = 長さは中身と合っているのにCRCが合わないメッセージ。どこかのビットが誤っているので、"
                "値は参考にしかなりません(局番号・時刻・座標が明らかにおかしいものも混ざります)。")

GUIDE = """\
■ RTK(リアルタイム・キネマティック)とは
GNSS(GPS・GLONASSなど)の単独測位は数mの誤差があります。誤差の大部分(衛星の時計・軌道、電離層、対流圏)は
近くの受信機どうしでほぼ同じなので、位置の分かっている「基準局」の観測量を「移動局」に送り、差を取ると打ち消せます。
さらに搬送波(波長約19cm)の位相を使い、波の数(整数アンビギュイティ)を解くとcm級になります。これがRTKです。
この録音のデータは、基準局がその補正データ(RTCM 3形式)をデジタル簡易無線で送っているものです。

■ 基準局が送るもの(RTCM 3 のメッセージ番号)
  1004 / 1012  GPS / GLONASS の観測量(擬似距離・搬送波位相・C/N0)。RTKの本体で毎秒送られます。
  MSM(1074, 1084 など)  新しい形式の観測量。全衛星系・全信号を同じ形式で扱えます。
  1005 / 1006  基準局アンテナの位置(地球中心座標 ECEF)。移動局の位置はこの点からのベクトルとして求まります。
  1007 / 1008 / 1033  アンテナ・受信機の型式。アンテナ位相中心の補正に使います。
  1013  送信スケジュール(どのメッセージを何秒ごとに送るか)、日付・UTC・うるう秒。
  1019 / 1020  GPS / GLONASS の衛星軌道(エフェメリス)。
  1021 / 1022  座標変換パラメータ(世界測地系 → 各国の測地系)。
  1014-1017  ネットワークRTK(複数の基準局を組み合わせて広い範囲を補正する方式)の情報。
  4001-4095  メーカー独自。

■ よく出てくる言葉
  エポック      観測した瞬間。GPS時刻は「週の始め(日曜0時)からの秒」で表します。
  GPS時刻(GPST) うるう秒を入れない時刻。UTCより18秒進んでいます(2017年以降)。GLONASSはモスクワ時刻(UTC+3時間)。
  C/N0          衛星の電波の強さ(dB-Hz)。40以上で良好、30未満は弱い。空が開けているほど高くなります。
  ロック時間    搬送波を途切れず追尾できている時間。途切れる(サイクルスリップ)とアンビギュイティを解き直します。
  擬似距離      電波の伝搬時間×光速。受信機時計の誤差を含むので「擬似」。衛星までは約2万km。
  ECEF          地球中心を原点とする直交座標。緯度経度・楕円体高に変換して表示しています。
  楕円体高      地球楕円体からの高さ。日本の標高(海面から)とは約30-40m違います(ジオイド高)。
  遅れ          観測した瞬間から無線で受け取るまでの時間。補正データは古くなるほど精度が落ち、数秒以内が目安です。

■ なぜCRCが通らないメッセージが多いのか
STD-T98のデータフレームには誤り訂正がありません(音声やSACCHには誤り訂正があるので、そちらはCRCが100%でも)。
受信のビット誤り率が1%でも、200バイトのメッセージがどこも誤らずに届く確率は約1割です。短いメッセージ(1005, 1008)は
通りやすく、観測量(1004, 1012)のような長いものほど通りにくくなります。「概要」の推定ビット誤り率と比べてみてください。

■ 各タブ
  概要         受信状態・メッセージ種別ごとの件数。種別を選ぶとその説明が出ます。
  メッセージ   1件ずつの中身。選ぶと各項目の値と意味、16進が出ます。
  衛星         観測量から衛星ごとのC/N0・ロック時間・遅れ。「衛星ごとにまとめる」で平均も見られます。
  フレーム     無線の1フレーム(80ms・36バイト)ごとの生データと送信局。
  ASCII        データの中の読める文字列(独自形式のヘッダーなど)。
  基地局・設定 基準局位置、送信スケジュール、座標変換、ネットワークRTK、衛星軌道のまとめ。
"""


def _clock(start_ms, seconds):
    return (datetime.datetime.fromtimestamp(start_ms / 1000) + datetime.timedelta(seconds=seconds)).strftime("%H:%M:%S.%f")[:-4]


def _hexdump(data, width=16):
    lines = []
    for offset in range(0, len(data), width):
        chunk = data[offset:offset + width]
        text = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        lines.append(f"{offset:04X}  {chunk.hex(' '):<{width * 3}} {text}")
    return "\n".join(lines)


def _is_idle(chunk):
    """All bytes 0xFF or one bit off: the idle fill between transmissions."""
    return all(bin(b).count("1") >= 7 for b in chunk)


def _ascii_dump(parts, starts):
    """Lines of the whole data as text; runs of idle-fill lines collapse into one."""
    lines, idle = [], 0
    for header, segment in parts:
        if segment.gap_before:
            lines.append(f"── {segment.gap_before} フレーム欠落 ──")
        for offset in range(0, len(segment.data), DUMP_WIDTH):
            chunk = segment.data[offset:offset + DUMP_WIDTH]
            if _is_idle(chunk):
                idle += 1
                continue
            if idle:
                lines.append(f"   (0xFF の空き埋め {idle} 行)")
                idle = 0
            frame = segment.frame_of_byte[offset]
            clock = _clock(starts[header["path"]], segment.time_s + (frame - segment.start_frame) * FRAME_SECONDS)
            text = "".join(chr(b) if 32 <= b < 127 else "·" for b in chunk)
            lines.append(f"{clock} {frame:>6}  {text}")
            if len(lines) >= DUMP_LINE_LIMIT:
                lines.append(f"… 以降は省略({DUMP_LINE_LIMIT} 行まで表示)")
                return lines
    if idle:
        lines.append(f"   (0xFF の空き埋め {idle} 行)")
    return lines


def _sat_name(system, sat):
    entry = sat.get("sat")
    name = f"{SYSTEM_PREFIX.get(system, '?')}{entry:02d}" if entry is not None else "?"
    return name + (f" (ch{sat['freq_ch']:+d})" if "freq_ch" in sat else "")


def _num(value, digits=1):
    return "-" if value is None else f"{value:.{digits}f}"


def _value_text(value):
    if isinstance(value, bool):
        return "はい" if value else "いいえ"
    if isinstance(value, float):
        return f"{value:.6g}" if abs(value) < 1e6 else f"{value:.3f}"
    return str(value)


def field_lines(fields, notes=True):
    """Field lines for the detail view: value, then (optionally) what it means."""
    lines = []
    for key, value in fields.items():
        if key in ("type", "name", "sats", "sat_ids", "schedule"):
            continue
        label, note = FIELD_NOTES.get(key, (key, ""))
        lines.append(f"  {label}: {_value_text(value)}" + (f"\n      └ {note}" if notes and note else ""))
    sats = fields.get("sats")
    if sats and any(len(s) > 1 for s in sats):
        system = fields.get("system", "")
        lines.append("\n  衛星ごとの値:")
        lines.append("    衛星          L1 C/N0  L2 C/N0  L1ロック[s]  L2ロック[s]  擬似距離[km]")
        for sat in sats:
            distance = sat.get("pseudorange_m")
            lines.append(f"    {_sat_name(system, sat):<13} {_num(sat.get('cnr_l1')):>7}  {_num(sat.get('cnr_l2')):>7}  "
                         f"{sat.get('lock_l1_s', '-'):>11}  {sat.get('lock_l2_s', '-'):>11}  "
                         f"{_num(distance / 1000 if distance else None, 3):>12}")
        if notes:
            lines += [f"      └ {SAT_NOTES['cnr']}", f"      └ {SAT_NOTES['lock']}", f"      └ {SAT_NOTES['pseudorange']}"]
    elif fields.get("sat_ids"):
        lines.append("  衛星番号: " + ", ".join(str(s) for s in fields["sat_ids"]))
    if fields.get("schedule"):
        lines.append("\n  送信予定:")
        for item in fields["schedule"]:
            lines.append(f"    {item['type']:>5}  {item['name']:<28} {item['interval_s']:g} 秒ごと"
                         + ("  (同期)" if item["sync"] else ""))
    return lines


class DataAnalysisWindow(tk.Toplevel):
    """paths: [(raw_path, edu_path)]; expand: callable returning a wider path list, or None.

    sender_label(user_code, maker_code) -> str names the sending station (key_tool's aliases).
    """

    def __init__(self, master, paths, expand=None, sender_label=None):
        super().__init__(master)
        self.title("データ解析 (RTCM3 / NMEA / UBX)")
        self.geometry("1240x840")
        self.minsize(900, 560)
        self.paths, self.expand = list(paths), expand
        self.sender_label = sender_label or (lambda user, maker: f"ユーザ {user} / メーカ {maker}")
        self.analysis = None
        self.starts = {}
        self.frame_iids = {}
        self._message_rows = {}
        self._message_iids = {}
        self._positions = {}
        self._results = queue.Queue()   # worker thread -> Tk thread (Tk calls are not thread-safe)
        self.use_damaged = tk.BooleanVar(value=False)   # shared by the satellite and base tabs

        top = tk.Frame(self); top.pack(fill=tk.X, padx=8, pady=(8, 4))
        self.source = tk.Label(top, anchor="w"); self.source.pack(side=tk.LEFT, fill=tk.X, expand=True)
        if expand is not None:
            tk.Button(top, text="同じ周波数・同じ日の全録音に広げる", command=self._expand).pack(side=tk.RIGHT)

        self.tabs = ttk.Notebook(self); self.tabs.pack(fill=tk.BOTH, expand=True, padx=8)
        self._build_summary()
        self._build_messages()
        self._build_satellites()
        self._build_frames()
        self._build_ascii()
        self._build_base()
        self._build_guide()

        bottom = tk.Frame(self); bottom.pack(fill=tk.X, padx=8, pady=(4, 2))
        tk.Label(bottom, text="書き出し:").pack(side=tk.LEFT)
        tk.Button(bottom, text="データのバイト列 (.bin)", command=self._export_bin).pack(side=tk.LEFT, padx=2)
        tk.Button(bottom, text="完全なRTCM3 (.rtcm3)", command=self._export_rtcm).pack(side=tk.LEFT, padx=2)
        tk.Button(bottom, text="メッセージ一覧 (.csv)", command=self._export_csv).pack(side=tk.LEFT, padx=2)
        self.status = tk.Label(bottom, anchor="w", fg="gray"); self.status.pack(side=tk.LEFT, padx=10)
        tk.Label(self, text=LEGAL_NOTE, fg="#8a5a00", anchor="w", wraplength=1180, justify=tk.LEFT).pack(
            fill=tk.X, padx=8, pady=(0, 8))
        self._run()

    # --- layout -----------------------------------------------------------------
    def _tree(self, parent, columns, widths):
        frame = tk.Frame(parent)
        tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
        self._set_columns(tree, columns, widths)
        bar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=bar.set)
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True); bar.pack(side=tk.LEFT, fill=tk.Y)
        return frame, tree

    @staticmethod
    def _set_columns(tree, columns, widths):
        tree.configure(columns=columns)
        for column, width in zip(columns, widths):
            tree.heading(column, text=column)
            tree.column(column, width=width, anchor="w", stretch=column == columns[-1])

    @staticmethod
    def _text(parent, **options):
        frame = tk.Frame(parent)
        text = tk.Text(frame, relief=tk.FLAT, **options)
        bar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=text.yview)
        text.configure(yscrollcommand=bar.set)
        text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True); bar.pack(side=tk.LEFT, fill=tk.Y)
        return frame, text

    @staticmethod
    def _set_text(widget, text):
        widget.config(state=tk.NORMAL); widget.delete("1.0", tk.END)
        widget.insert(tk.END, text); widget.config(state=tk.DISABLED)

    def _build_summary(self):
        page = tk.Frame(self.tabs); self.tabs.add(page, text="概要")
        self.summary = tk.Text(page, height=13, font=("Consolas", 10), wrap=tk.WORD, relief=tk.FLAT)
        self.summary.pack(fill=tk.X, padx=4, pady=4)
        frame, self.types = self._tree(page, ("プロトコル", "種別", "名前", "完全", "途切れ", "CRC NG", "平均間隔"),
                                       (90, 70, 260, 70, 70, 70, 120))
        frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.types.bind("<<TreeviewSelect>>", self._on_type)
        self.type_note = tk.Label(page, anchor="w", justify=tk.LEFT, fg="#1d4ed8", wraplength=1160,
                                  text="種別を選ぶと、そのメッセージの説明をここに表示します。")
        self.type_note.pack(fill=tk.X, padx=4, pady=(0, 4))

    def _build_messages(self):
        page = tk.Frame(self.tabs); self.tabs.add(page, text="メッセージ")
        bar = tk.Frame(page); bar.pack(fill=tk.X, padx=4, pady=4)
        self.show_incomplete = tk.BooleanVar(value=False)
        tk.Checkbutton(bar, text="途切れ・CRC NG のメッセージも表示", variable=self.show_incomplete,
                       command=self._fill_messages).pack(side=tk.LEFT)
        self.show_notes = tk.BooleanVar(value=True)
        tk.Checkbutton(bar, text="項目の説明を表示", variable=self.show_notes,
                       command=self._on_message).pack(side=tk.LEFT, padx=8)
        tk.Label(bar, text="選択するとフィールドと16進を表示し、フレームタブの位置も選びます", fg="gray").pack(side=tk.LEFT, padx=8)
        pane = ttk.PanedWindow(page, orient=tk.VERTICAL); pane.pack(fill=tk.BOTH, expand=True, padx=4)
        frame, self.messages = self._tree(pane, ("時刻", "フレーム", "プロトコル", "種別", "名前", "状態", "バイト", "内容"),
                                          (100, 70, 70, 60, 200, 60, 50, 480))
        self.messages.tag_configure("crc_ng", foreground="#b45309")
        self.messages.tag_configure("incomplete", foreground="#6b7280")
        pane.add(frame, weight=2)
        frame, self.detail = self._text(pane, height=14, font=("Consolas", 9), wrap=tk.WORD)
        pane.add(frame, weight=3)
        self.messages.bind("<<TreeviewSelect>>", self._on_message)

    def _build_satellites(self):
        page = tk.Frame(self.tabs); self.tabs.add(page, text="衛星")
        bar = tk.Frame(page); bar.pack(fill=tk.X, padx=4, pady=4)
        self.sat_group = tk.BooleanVar(value=True)
        tk.Checkbutton(bar, text="衛星ごとにまとめる", variable=self.sat_group,
                       command=self._fill_satellites).pack(side=tk.LEFT)
        tk.Checkbutton(bar, text="CRC NG の値も参考に使う", variable=self.use_damaged,
                       command=self._fill_damaged_views).pack(side=tk.LEFT, padx=8)
        tk.Label(bar, fg="gray", text="観測量(1001-1004, 1009-1012, MSM)の衛星ごとの値。行を選ぶとメッセージタブで開きます").pack(
            side=tk.LEFT, padx=8)
        frame, self.sats = self._tree(page, ("-",), (100,))
        frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.sats.tag_configure("crc_ng", foreground="#b45309")
        self.sats.bind("<<TreeviewSelect>>", self._on_satellite)
        tk.Label(page, anchor="w", justify=tk.LEFT, fg="#1d4ed8", wraplength=1160,
                 text=f"{SAT_NOTES['cnr']}\n{SAT_NOTES['lock']}\n遅れ: {FIELD_NOTES['delay_s'][1]}").pack(
            fill=tk.X, padx=4, pady=(0, 4))
        self._sat_rows = {}

    def _build_frames(self):
        page = tk.Frame(self.tabs); self.tabs.add(page, text="フレーム")
        tk.Label(page, anchor="w", fg="gray",
                 text="1フレーム=80ms・36バイト(9バイト×4スロット)。RICHのモードMでデータのスロットが決まります。"
                      "送信局はSACCHのユーザ/メーカコード(SACCHのCRCが通ったときだけ)。"
                      "欠落したフレームは「── 欠落 ──」行で示します。").pack(fill=tk.X, padx=4, pady=4)
        frame, self.frames = self._tree(page, ("時刻", "フレーム", "seq", "M", "データslot", "SACCH", "送信局", "データ (16進)"),
                                        (100, 70, 60, 40, 80, 60, 90, 640))
        frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.frames.tag_configure("gap", foreground="#b42318")

    def _build_ascii(self):
        page = tk.Frame(self.tabs); self.tabs.add(page, text="ASCII")
        bar = tk.Frame(page); bar.pack(fill=tk.X, padx=4, pady=4)
        tk.Label(bar, text="最小の長さ").pack(side=tk.LEFT)
        self.ascii_min = tk.IntVar(value=6)
        tk.Spinbox(bar, from_=MIN_ASCII_RUN, to=64, width=4, textvariable=self.ascii_min,
                   command=self._fill_ascii).pack(side=tk.LEFT, padx=(2, 10))
        self.ascii_group = tk.BooleanVar(value=True)
        tk.Checkbutton(bar, text="同じ文字列をまとめる", variable=self.ascii_group,
                       command=self._fill_ascii).pack(side=tk.LEFT)
        tk.Label(bar, fg="gray", text="印字できるASCII(0x20-0x7E)が続く部分。誤り訂正がないので、"
                                     "ビット誤りで1文字違う文字列も別に数えます").pack(side=tk.LEFT, padx=8)
        pane = ttk.PanedWindow(page, orient=tk.VERTICAL); pane.pack(fill=tk.BOTH, expand=True, padx=4)
        frame, self.ascii_tree = self._tree(pane, ("時刻", "フレーム", "回数", "長さ", "文字列"), (100, 70, 60, 50, 700))
        pane.add(frame, weight=2)
        self.ascii_tree.bind("<<TreeviewSelect>>", self._on_ascii)
        dump = tk.Frame(pane)
        tk.Label(dump, anchor="w", fg="gray",
                 text=f"データ全体の文字表示(1行{DUMP_WIDTH}バイト、印字できないバイトは「·」、0xFF の空き埋めは省略)"
                 ).pack(fill=tk.X)
        frame, self.ascii_dump = self._text(dump, font=("Consolas", 9), wrap=tk.NONE)
        frame.pack(fill=tk.BOTH, expand=True)
        pane.add(dump, weight=3)
        self._ascii_rows = {}

    def _build_base(self):
        page = tk.Frame(self.tabs); self.tabs.add(page, text="基地局・設定")
        bar = tk.Frame(page); bar.pack(fill=tk.X, padx=4, pady=4)
        tk.Label(bar, text="基準局位置・アンテナ、送信スケジュール(1013)、座標変換(1021/1022)、"
                           "ネットワークRTK(1014-1017)、衛星軌道(1019/1020)、観測の概況", fg="gray").pack(side=tk.LEFT)
        self.map_button = tk.Button(bar, text="地図で開く (OpenStreetMap)", command=self._open_map, state=tk.DISABLED)
        self.map_button.pack(side=tk.RIGHT)
        tk.Checkbutton(bar, text="CRC NG の値も参考に使う", variable=self.use_damaged,
                       command=self._fill_damaged_views).pack(side=tk.RIGHT, padx=8)
        frame, self.base = self._text(page, font=("Consolas", 10), wrap=tk.WORD)
        frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

    def _build_guide(self):
        page = tk.Frame(self.tabs); self.tabs.add(page, text="解説")
        frame, text = self._text(page, font=("Meiryo UI", 10), wrap=tk.WORD)
        frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self._set_text(text, GUIDE)

    # --- analysis -----------------------------------------------------------------
    def _run(self):
        self.source.config(text=f"対象: {len(self.paths)} 件の録音  解析中...")
        self.status.config(text="")

        def work(paths):
            try:
                self._results.put((analyse(paths), None))
            except Exception as exc:   # shown in the window, not lost on a console
                self._results.put((None, exc))
        threading.Thread(target=work, args=(list(self.paths),), daemon=True).start()
        self.after(100, self._poll)

    def _poll(self):
        try:
            result, error = self._results.get_nowait()
        except queue.Empty:
            if self.winfo_exists():
                self.after(100, self._poll)
            return
        self._show(result, error)

    def _expand(self):
        wider = self.expand()
        if wider:
            self.paths = wider
            self._run()

    def _show(self, analysis, error):
        if error is not None:
            self.source.config(text=f"解析できませんでした: {error}")
            return
        self.analysis = analysis
        self.starts = {r["path"]: r["start_ms"] for r in analysis.recordings}
        recs = analysis.recordings
        freqs = sorted({r["freq_hz"] for r in recs})
        self.source.config(text=f"対象: {len(recs)} 件の録音  " + " / ".join(f"{f / 1e6:.5f} MHz" for f in freqs))
        self._fill_summary()
        self._fill_messages()
        self._fill_frames()
        self._fill_satellites()
        self._fill_ascii()
        self._fill_base()

    def _used(self, message):
        return message.status == "ok" or (message.status == "crc_ng" and self.use_damaged.get())

    def _fill_damaged_views(self):
        if self.analysis is not None:
            self._fill_satellites()
            self._fill_base()

    # --- 概要 ---------------------------------------------------------------------
    def _fill_summary(self):
        a = self.analysis
        ok = [m for m in a.messages if m.status == "ok"]
        damaged = sum(1 for m in a.messages if m.status == "crc_ng")
        cut = len(a.messages) - len(ok) - damaged
        protocols = {}
        for message in ok:
            protocols[message.protocol] = protocols.get(message.protocol, 0) + 1
        if a.missing_frames is None:
            loss = "欠落フレーム 記録なし(古い録音はチャンネルごとの欠落数を保存していません)"
        else:
            expected = a.frames + a.missing_frames
            loss = f"欠落フレーム {a.missing_frames} ({100 * a.missing_frames / expected:.1f}%)" if expected else "欠落フレーム 0"
        text = (f"録音 {len(a.recordings)} 件  /  受信フレーム {a.frames}  (うちデータを含む {a.data_frames})\n"
                f"{loss}  /  データのバイト数 {a.data_bytes}\n")
        if a.senders:
            total = sum(a.senders.values())
            text += "送信局(データフレームのSACCH): " + "  ".join(
                f"{self.sender_label(user, maker)} {100 * n / total:.1f}%" for (user, maker), n in a.senders.most_common(3)) + "\n"
        text += (f"完全なメッセージ {len(ok)}  " + "  ".join(f"{p} {n}" for p, n in sorted(protocols.items())) +
                 f"  /  CRC NG {damaged}(壊れて届いた)  /  途中で途切れ {cut}(録音の終わりか欠落)\n")
        delays = [m.fields["delay_s"] for m in ok if "delay_s" in m.fields]
        if delays:
            text += (f"観測から受信までの遅れ(中央値) {statistics.median(delays):.2f} 秒"
                     f"(PCの時計基準。GPS時刻とUTCの差 {a.leap_seconds} 秒で換算)\n")
        ber = a.bit_error_rate
        if ber is not None:
            text += (f"推定ビット誤り率 {100 * ber:.2f}%(空き時間の 0xFF 埋めで反転していたビットの割合。"
                     f"誤り訂正なしのデータなので、この誤りがそのまま残ります。実データの誤りはこれより多いことがあります)\n"
                     f"  誤りなく届く確率の目安:  25バイト {100 * survival(ber, 25):.0f}%  /  "
                     f"100バイト {100 * survival(ber, 100):.0f}%  /  200バイト {100 * survival(ber, 200):.1f}%\n")
        text += "\n"
        if ber is not None and ber > 0.002:
            text += ("観測量や衛星軌道のような長いメッセージは、数百バイトのどこか1ビットでも誤るとCRCで捨てられます。"
                     "完全に取れるのが短いメッセージばかりなのは、主にこのビット誤りのためです。"
                     "受信状態(アンテナ・ゲイン・周波数補正)が良くなると、取れる長さが伸びます。\n")
        if damaged:
            text += DAMAGED_NOTE + "\n"
        if not a.messages:
            text += "既知の形式(RTCM3 / NMEA / UBX)のデータは見つかりませんでした。フレームタブやASCIIタブで中身を確認できます。\n"
        self._set_text(self.summary, text)
        self.types.delete(*self.types.get_children())
        for protocol, msg_type, name, n_ok, n_cut, n_damaged, interval in type_table(a.messages):
            self.types.insert("", tk.END, values=(protocol, msg_type, name, n_ok, n_cut, n_damaged,
                                                 f"{interval:.1f} 秒" if interval else "-"))

    def _on_type(self, _event=None):
        selection = self.types.selection()
        if not selection:
            return
        protocol, msg_type, name = (str(v) for v in self.types.item(selection[0], "values")[:3])
        note = message_note(int(msg_type)) if protocol == "RTCM3" and msg_type.isdigit() else ""
        self.type_note.config(text=f"{msg_type} {name}: {note or '説明はありません。'}")

    # --- メッセージ ------------------------------------------------------------------
    def _fill_messages(self):
        if self.analysis is None:
            return
        self.messages.delete(*self.messages.get_children())
        self._message_rows, self._message_iids = {}, {}
        for index, message in enumerate(self.analysis.messages):
            if message.status != "ok" and not self.show_incomplete.get():
                continue
            iid = str(index)
            self._message_rows[iid] = message
            self._message_iids[id(message)] = iid
            self.messages.insert("", tk.END, iid=iid, tags=(message.status,), values=(
                _clock(self.starts[message.recording], message.time_s), message.frame, message.protocol,
                message.msg_type, message.name, STATUS_TEXT.get(message.status, message.status), message.length,
                message.summary))

    def _on_message(self, _event=None):
        selection = self.messages.selection()
        if not selection:
            return
        message = self._message_rows[selection[0]]
        notes = self.show_notes.get()
        status = {"ok": "完全", "incomplete": "途中で途切れ", "crc_ng": "CRC NG・値は参考"}.get(message.status, message.status)
        text = (f"{message.protocol} {message.msg_type}  {message.name}  ({status})\n"
                f"録音 {os.path.basename(str(message.recording))}  フレーム {message.frame}  +{message.time_s:.2f} 秒\n")
        if message.status == "crc_ng":
            text += DAMAGED_NOTE + "\n"
        if notes and message.protocol == "RTCM3" and message.msg_type.isdigit():
            note = message_note(int(message.msg_type))
            if note:
                text += f"\n説明: {note}\n"
        text += "\nフィールド:\n" + "\n".join(field_lines(message.fields, notes))
        text += f"\n\n16進 ({message.length} バイト):\n{_hexdump(message.raw)}"
        self._set_text(self.detail, text)
        self._select_frame(message.recording, message.frame)

    def _select_frame(self, recording, frame):
        iid = self.frame_iids.get((recording, frame))
        if iid:
            self.frames.selection_set(iid); self.frames.see(iid)

    # --- 衛星 ----------------------------------------------------------------------
    def _observations(self):
        return [m for m in self.analysis.messages
                if m.protocol == "RTCM3" and m.fields.get("sats") and self._used(m)]

    def _fill_satellites(self):
        if self.analysis is None:
            return
        tree = self.sats
        tree.delete(*tree.get_children())
        self._sat_rows = {}
        observations = self._observations()
        if self.sat_group.get():
            self._set_columns(tree, ("衛星", "系", "回数", "L1 C/N0 平均", "L2 C/N0 平均", "L1 C/N0 最小-最大",
                                     "最長ロック[s]", "最後の受信"),
                              (110, 80, 60, 100, 100, 130, 100, 200))
            groups = {}
            for message in observations:
                for sat in message.fields["sats"]:
                    groups.setdefault((message.fields.get("system", ""), sat.get("sat")), []).append((message, sat))
            for (system, _number), rows in sorted(groups.items(), key=lambda item: (item[0][0], item[0][1] or 0)):
                l1 = [s["cnr_l1"] for _, s in rows if s.get("cnr_l1")]
                l2 = [s["cnr_l2"] for _, s in rows if s.get("cnr_l2")]
                locks = [s["lock_l1_s"] for _, s in rows if s.get("lock_l1_s") is not None]
                last, sat = rows[-1]
                tag = "crc_ng" if all(m.status == "crc_ng" for m, _ in rows) else ""
                iid = tree.insert("", tk.END, tags=(tag,), values=(
                    _sat_name(system, sat), system, len(rows), _num(statistics.mean(l1)) if l1 else "-",
                    _num(statistics.mean(l2)) if l2 else "-", f"{min(l1):.1f} - {max(l1):.1f}" if l1 else "-",
                    max(locks) if locks else "-", _clock(self.starts[last.recording], last.time_s)))
                self._sat_rows[iid] = last
        else:
            self._set_columns(tree, ("受信時刻", "種別", "状態", "エポック", "遅れ[s]", "衛星", "L1 C/N0", "L2 C/N0",
                                     "L1ロック[s]", "L2ロック[s]"),
                              (100, 60, 60, 260, 70, 110, 70, 70, 90, 90))
            count = 0
            for message in observations:
                fields = message.fields
                for sat in fields["sats"]:
                    if count >= SAT_ROW_LIMIT:
                        break
                    count += 1
                    iid = tree.insert("", tk.END, tags=(message.status,), values=(
                        _clock(self.starts[message.recording], message.time_s), message.msg_type,
                        STATUS_TEXT[message.status], fields.get("epoch_text", "-"), _num(fields.get("delay_s"), 2),
                        _sat_name(fields.get("system", ""), sat), _num(sat.get("cnr_l1")), _num(sat.get("cnr_l2")),
                        sat.get("lock_l1_s", "-"), sat.get("lock_l2_s", "-")))
                    self._sat_rows[iid] = message
            if count >= SAT_ROW_LIMIT:
                tree.insert("", tk.END, values=("", "", "", f"… {SAT_ROW_LIMIT} 行より後は省略"))
        if not observations:
            tree.insert("", tk.END, values=("観測量なし" + ("" if self.use_damaged.get()
                                                          else "(「CRC NG の値も参考に使う」で壊れたものも表示できます)"),))

    def _on_satellite(self, _event=None):
        """Open the satellite row's message in the message tab."""
        selection = self.sats.selection()
        message = self._sat_rows.get(selection[0]) if selection else None
        if message is None:
            return
        if message.status != "ok" and not self.show_incomplete.get():
            self.show_incomplete.set(True)
            self._fill_messages()
        iid = self._message_iids.get(id(message))
        if iid:
            self.messages.selection_set(iid); self.messages.see(iid)

    # --- フレーム --------------------------------------------------------------------
    def _fill_frames(self):
        self.frames.delete(*self.frames.get_children())
        self.frame_iids = {}
        rows = self.analysis.frame_rows
        for header, frame, gap in rows[:FRAME_ROW_LIMIT]:
            if frame is None:
                self.frames.insert("", tk.END, values=("", "", "", "", "", "", "", f"── {gap} フレーム欠落 ──"), tags=("gap",))
                continue
            iid = f"{header['path']}#{frame.index}"
            self.frame_iids[(header["path"], frame.index)] = iid
            sender = f"{frame.user_code}/{frame.maker_code}" if frame.user_code is not None else "-"
            self.frames.insert("", tk.END, iid=iid, values=(
                _clock(header["start_ms"], frame.time_s), frame.index, frame.seq, frame.mode,
                ",".join(str(s) for s in frame.slots) or "-", "OK" if frame.sacch_ok else "NG", sender,
                frame.data.hex(" ") if frame.data else "(音声のみ)"))
        if len(rows) > FRAME_ROW_LIMIT:
            self.frames.insert("", tk.END, values=("", "", "", "", "", "", "",
                                                    f"… 残り {len(rows) - FRAME_ROW_LIMIT} 行は省略(書き出しには全部含まれます)"))

    # --- ASCII ---------------------------------------------------------------------
    def _fill_ascii(self):
        if self.analysis is None:
            return
        try:
            minimum = max(MIN_ASCII_RUN, int(self.ascii_min.get()))
        except (tk.TclError, ValueError):
            return
        runs = [r for r in self.analysis.ascii if len(r.text) >= minimum]
        if self.ascii_group.get():
            groups = {}
            for run in runs:
                groups.setdefault(run.text, []).append(run)
            rows = [(group[0], len(group)) for group in sorted(groups.values(), key=lambda g: -len(g))]
        else:
            rows = [(run, 1) for run in runs]
        self.ascii_tree.delete(*self.ascii_tree.get_children())
        self._ascii_rows = {}
        for index, (run, count) in enumerate(rows[:ASCII_ROW_LIMIT]):
            iid = str(index)
            self._ascii_rows[iid] = run
            text = run.text.replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t")
            self.ascii_tree.insert("", tk.END, iid=iid, values=(
                _clock(self.starts[run.recording], run.time_s), run.frame, count, len(run.text), text))
        if len(rows) > ASCII_ROW_LIMIT:
            self.ascii_tree.insert("", tk.END, values=("", "", "", "", f"… 残り {len(rows) - ASCII_ROW_LIMIT} 行は省略"))
        self._set_text(self.ascii_dump, "\n".join(_ascii_dump(self.analysis.segments, self.starts)))

    def _on_ascii(self, _event=None):
        """Select the string's first frame in the frame tab."""
        selection = self.ascii_tree.selection()
        run = self._ascii_rows.get(selection[0]) if selection else None
        if run:
            self._select_frame(run.recording, run.frame)

    # --- 基地局・設定 ------------------------------------------------------------------
    def _latest(self, key_of):
        """Latest used RTCM message per key: {key: message}. A complete one wins over a CRC NG one."""
        chosen = {}
        for message in self.analysis.messages:
            if message.protocol != "RTCM3" or not self._used(message):
                continue
            key = key_of(message)
            if key is None:
                continue
            previous = chosen.get(key)
            if previous is None or previous.status != "ok" or message.status == "ok":
                chosen[key] = message
        return chosen

    @staticmethod
    def _mark(message):
        return "  [CRC NG・参考値]" if message.status != "ok" else ""

    def _base_lines(self, positions):
        antennas = {}
        for message in self.analysis.messages:
            if message.status == "ok" and "antenna" in message.fields:
                antennas[message.fields.get("station")] = message.fields
        lines = ["■ 基準局位置 (1005/1006) とアンテナ (1007/1008/1033)  ※位置は完全なメッセージだけを使います"]
        for station, p in sorted(positions.items()):
            lines += [f"基準局 {station}",
                      f"  緯度 {p['lat']:.8f}°  経度 {p['lon']:.8f}°  楕円体高 {p['height_m']:.3f} m",
                      f"  ECEF  X {p['ecef_x']:.4f}  Y {p['ecef_y']:.4f}  Z {p['ecef_z']:.4f} m",
                      f"  ITRF年 {p['itrf_year']}  対応システム {p['systems']}"
                      + (f"  アンテナ高 {p['antenna_height_m']:.4f} m" if "antenna_height_m" in p else "")]
            info = antennas.get(station)
            if info:
                lines.append(f"  アンテナ '{info.get('antenna') or '-'}'  セットアップID {info.get('setup_id')}"
                             + (f"  シリアル '{info['antenna_serial']}'" if info.get("antenna_serial") else ""))
                if info.get("receiver"):
                    lines.append(f"  受信機 '{info['receiver']}'  ファームウェア '{info.get('firmware', '')}'")
        if not positions:
            lines.append("基準局位置(RTCM 1005/1006)は見つかりませんでした。")
        lines.append(f"  └ {message_note(1005)}")
        return lines

    def _schedule_lines(self):
        lines = ["■ 送信スケジュール (1013)"]
        schedules = self._latest(lambda m: m.fields.get("station") if "schedule" in m.fields else None)
        for station, message in sorted(schedules.items()):
            f = message.fields
            lines.append(f"基準局 {station}  {f['date']} {f['utc_time']} UTC  うるう秒 {f['leap_seconds']}{self._mark(message)}")
            lines += [f"  {item['type']:>5}  {item['name']:<28} {item['interval_s']:g} 秒ごと" + ("  (同期)" if item["sync"] else "")
                      for item in f["schedule"]]
        if not schedules:
            lines.append("見つかりませんでした。")
        lines.append(f"  └ {message_note(1013)}")
        return lines

    def _transform_lines(self):
        lines = ["■ 座標変換 (1021/1022)"]
        transforms = self._latest(lambda m: (m.fields.get("source_name"), m.fields.get("target_name"))
                                  if "source_name" in m.fields else None)
        for message in transforms.values():
            f = message.fields
            if "ds_ppm" not in f:
                lines.append(f"{f['source_name'] or '?'} → {f['target_name'] or '?'}  (途中まで){self._mark(message)}")
                continue
            lines += [f"{f['source_name'] or '?'} → {f['target_name'] or '?'}  ({message.msg_type}){self._mark(message)}",
                      f"  平行移動 dX {f['dx_m']:+.3f}  dY {f['dy_m']:+.3f}  dZ {f['dz_m']:+.3f} m   "
                      f"回転 R1 {f['r1_arcsec']:+.5f}  R2 {f['r2_arcsec']:+.5f}  R3 {f['r3_arcsec']:+.5f} 秒角   "
                      f"縮尺 {f['ds_ppm']:+.5f} ppm",
                      f"  適用範囲 緯度 {f['origin_lat_deg']:.4f}° +{f['ext_lat_deg']:.4f}°  経度 {f['origin_lon_deg']:.4f}° "
                      f"+{f['ext_lon_deg']:.4f}°  高さの種類 {f['height_type']}  プレート {f['plate_number']}"]
        if not transforms:
            lines.append("見つかりませんでした。")
        lines.append(f"  └ {message_note(1021)}")
        return lines

    def _network_lines(self, positions):
        lines = ["■ ネットワークRTK (1014-1017)"]
        aux = self._latest(lambda m: (m.fields["network_id"], m.fields["master_station"], m.fields["aux_station"])
                           if m.msg_type == "1014" and "dh_m" in m.fields else None)
        base_lat = next(iter(positions.values()))["lat"] if positions else 35.0
        for (network, master, auxiliary), message in sorted(aux.items()):
            f = message.fields
            km = math.hypot(f["dlat_deg"] * 111.32, f["dlon_deg"] * 111.32 * math.cos(math.radians(base_lat)))
            lines.append(f"網 {network}/{f['subnetwork_id']}  主局 {master} → 補助局 {auxiliary}  "
                         f"Δ緯度 {f['dlat_deg']:+.5f}°  Δ経度 {f['dlon_deg']:+.5f}°  Δh {f['dh_m']:+.3f} m  "
                         f"距離 約 {km:.1f} km{self._mark(message)}")
        corrections = {}
        for message in self.analysis.messages:
            if message.msg_type in ("1015", "1016", "1017") and self._used(message):
                corrections[message.msg_type] = corrections.get(message.msg_type, 0) + 1
        if corrections:
            lines.append("補正差: " + "  ".join(f"{t} {n} 件" for t, n in sorted(corrections.items())))
        if not aux and not corrections:
            lines.append("見つかりませんでした。")
        lines += [f"  └ {message_note(1014)}", f"  └ {message_note(1016)}"]
        return lines

    def _orbit_lines(self):
        lines = ["■ 衛星軌道 (1019 GPS / 1020 GLONASS)"]
        orbits = self._latest(lambda m: (m.msg_type, m.fields["satellite"])
                              if m.msg_type in ("1019", "1020") and "health" in m.fields
                              and (m.msg_type == "1019" or "radius_km" in m.fields) else None)
        for (msg_type, sat), message in sorted(orbits.items()):
            f = message.fields
            if msg_type == "1019":
                lines.append(f"G{sat:02d}  週 {f['week']}  IODE {f['iode']}  toe {f['toe_s']} s  a {f['semi_major_km']:.1f} km  "
                             f"e {f['eccentricity']:.5f}  i {f['inclination_deg']:.2f}°  健康 {f['health']}{self._mark(message)}")
            else:
                lines.append(f"R{sat:02d}  ch {f['freq_ch']:+d}  tb {f['tb']}  地心距離 {f['radius_km']:.0f} km  "
                             f"(X {f['x_km']:.1f}, Y {f['y_km']:.1f}, Z {f['z_km']:.1f} km)  健康 {f['health']}{self._mark(message)}")
        if not orbits:
            lines.append("見つかりませんでした。")
        lines += [f"  └ {message_note(1019)}", f"  └ {message_note(1020)}"]
        return lines

    def _observation_lines(self):
        lines = ["■ 観測の概況"]
        summary = {}
        for message in self._observations():
            summary.setdefault((message.msg_type, message.name), []).append(message)
        for (msg_type, name), group in sorted(summary.items()):
            sats = [m.fields.get("satellites", 0) for m in group]
            cnrs = [s["cnr_l1"] for m in group for s in m.fields["sats"] if s.get("cnr_l1")]
            delays = [m.fields["delay_s"] for m in group if "delay_s" in m.fields]
            damaged = sum(1 for m in group if m.status != "ok")
            lines.append(f"{msg_type} {name}: {len(group)} 件" + (f"(うちCRC NG {damaged})" if damaged else "")
                         + f"  衛星数 平均 {statistics.mean(sats):.1f}"
                         + (f"  L1 C/N0 平均 {statistics.mean(cnrs):.1f} dB-Hz" if cnrs else "")
                         + (f"  遅れ 中央値 {statistics.median(delays):.2f} 秒" if delays else ""))
        if not summary:
            lines.append("観測量はありません。")
        return lines

    def _fill_base(self):
        positions = base_positions(self.analysis.messages)
        lines = []
        for part in (self._base_lines(positions), self._schedule_lines(), self._transform_lines(),
                     self._network_lines(positions), self._orbit_lines(), self._observation_lines()):
            lines += part + [""]
        if self.use_damaged.get():
            lines.append(DAMAGED_NOTE)
        self._set_text(self.base, "\n".join(lines))
        self._positions = positions
        self.map_button.config(state=tk.NORMAL if positions else tk.DISABLED)

    def _open_map(self):
        station, p = next(iter(sorted(self._positions.items())))
        webbrowser.open(f"https://www.openstreetmap.org/?mlat={p['lat']:.7f}&mlon={p['lon']:.7f}#map=17/{p['lat']:.6f}/{p['lon']:.6f}")

    # --- export ---------------------------------------------------------------------
    def _save_path(self, title, extension, kinds):
        if self.analysis is None:
            return None
        return filedialog.asksaveasfilename(parent=self, title=title, defaultextension=extension, filetypes=kinds)

    def _export_bin(self):
        path = self._save_path("データのバイト列を保存", ".bin", [("バイナリ", "*.bin")])
        if not path:
            return
        from core.analysis.data_stream import read_recording
        size = 0
        with open(path, "wb") as out:
            for raw, edu in self.paths:
                _, frames = read_recording(raw, edu)
                for segment in segments(frames):
                    out.write(segment.data); size += len(segment.data)
        self.status.config(text=f"{size} バイトを書き出しました(欠落箇所はつなげてあります)")

    def _export_rtcm(self):
        path = self._save_path("完全なRTCM3メッセージを保存", ".rtcm3", [("RTCM3", "*.rtcm3")])
        if not path:
            return
        complete = [m for m in self.analysis.messages if m.protocol == "RTCM3" and m.status == "ok"]
        with open(path, "wb") as out:
            for message in complete:
                out.write(message.raw)
        self.status.config(text=f"RTCM3 メッセージ {len(complete)} 件を書き出しました")

    def _export_csv(self):
        path = self._save_path("メッセージ一覧を保存", ".csv", [("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as out:
            writer = csv.writer(out)
            writer.writerow(["時刻", "録音", "フレーム", "プロトコル", "種別", "名前", "状態", "バイト", "遅れ[s]", "内容"])
            for m in self.analysis.messages:
                writer.writerow([_clock(self.starts[m.recording], m.time_s), os.path.basename(str(m.recording)), m.frame,
                                 m.protocol, m.msg_type, m.name, STATUS_TEXT.get(m.status, m.status), m.length,
                                 m.fields.get("delay_s", ""), m.summary])
        self.status.config(text=f"{len(self.analysis.messages)} 件を書き出しました")
