"""
onnxruntime port of SecretCracker (see cracker.py). Behaviourally identical --
same staged search, same cache -- but runs the two classifiers under
onnxruntime instead of torch, so the real-time key-search worker imports
onnxruntime (~0.36s) instead of torch (~2.0s). No torch dependency here.

Requires the ONNX models produced by export_secret_models_onnx.py
(ambe2_ffnn.onnx, ambe2_hybrid.onnx) next to the .safetensors files.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import onnxruntime as ort

from ipc.message_schema import (
    SECRET_BURST_BYTES_AMBE_2450,
    SECRET_RESULT_CURRENT_KEY,
    SECRET_RESULT_FULL_SEARCH,
    SECRET_RESULT_GLOBAL_CACHE,
    SECRET_RESULT_NONE,
)

BITS_PER_FRAME = 49
FRAMES_PER_BURST = 4
BURSTS_PER_BLOCK = 5
FRAMES_PER_BLOCK = FRAMES_PER_BURST * BURSTS_PER_BLOCK
INPUT_DIM = BITS_PER_FRAME * FRAMES_PER_BLOCK
LABEL_PLAIN = 0
LABEL_ENCRYPTED = 1
MAX_KEY = 32767
HYBRID_BATCH_SIZE = 512

_THUMBDV_MAP = np.array(
    [
        0, 18, 36, 1, 19, 37, 2, 20, 38,
        3, 21, 39, 4, 22, 40, 5, 23, 41,
        6, 24, 42, 7, 25, 43, 8, 26, 44,
        9, 27, 45, 10, 28, 46, 11, 29, 47,
        12, 30, 48, 13, 31, 14, 32, 15, 33,
        16, 34, 17, 35,
    ],
    dtype=np.intp,
)


@dataclass(frozen=True)
class SecretResolution:
    resolved_key: int
    result_source: int
    cache_keys: tuple[int, ...]


def _generate_all_pn_sequences() -> np.ndarray:
    states = np.arange(1, MAX_KEY + 1, dtype=np.uint32)
    all_pn = np.empty((MAX_KEY, 196), dtype=np.uint8)
    for i in range(196):
        all_pn[:, i] = (states & 1).astype(np.uint8)
        feedback = (states & 1) ^ ((states >> 1) & 1)
        states >>= 1
        states |= feedback << 14
    return all_pn


def _burst_payload_to_raw_bits(burst_payload: bytes) -> np.ndarray:
    frames = np.zeros((FRAMES_PER_BURST, BITS_PER_FRAME), dtype=np.uint8)
    for frame_index in range(FRAMES_PER_BURST):
        offset = frame_index * 7
        payload = burst_payload[offset : offset + 7]
        bits = []
        for byte_val in payload:
            for shift in range(7, -1, -1):
                bits.append((byte_val >> shift) & 1)
        frames[frame_index] = bits[:BITS_PER_FRAME]
    return frames


def _payload_to_blocks(payload: bytes, burst_count: int) -> list[np.ndarray]:
    bursts = [
        payload[index * SECRET_BURST_BYTES_AMBE_2450 : (index + 1) * SECRET_BURST_BYTES_AMBE_2450]
        for index in range(burst_count)
    ]
    raw_bursts = [_burst_payload_to_raw_bits(burst_payload) for burst_payload in bursts]

    # Take blocks tail-first: the freshest 5 bursts, then the preceding 5.
    # A short transmission often follows other traffic still sitting in the
    # rolling buffer; the live signal is at the tail, so a tail-aligned block is
    # far more likely to be a clean single-station block than a head-aligned one.
    # Result is [freshest, older] (<=2, non-overlapping); [] if <5 bursts.
    blocks = []
    end = len(raw_bursts)
    while end >= BURSTS_PER_BLOCK and len(blocks) < 2:
        blocks.append(np.vstack(raw_bursts[end - BURSTS_PER_BLOCK : end]))
        end -= BURSTS_PER_BLOCK
    return blocks


def _descramble_block_batch(raw_frames_block: np.ndarray, all_pn: np.ndarray) -> np.ndarray:
    num_keys = all_pn.shape[0]
    result = np.empty((num_keys, FRAMES_PER_BLOCK, BITS_PER_FRAME), dtype=np.uint8)
    for frame_index in range(raw_frames_block.shape[0]):
        pn_frame_index = frame_index % FRAMES_PER_BURST
        key_slice = all_pn[:, pn_frame_index * 49 : (pn_frame_index + 1) * 49]
        key_mapped = key_slice[:, _THUMBDV_MAP]
        result[:, frame_index, :] = raw_frames_block[frame_index][np.newaxis, :] ^ key_mapped
    return result


def _softmax_plain(logits: np.ndarray) -> np.ndarray:
    m = logits.max(axis=1, keepdims=True)
    e = np.exp(logits - m)
    return (e / e.sum(axis=1, keepdims=True))[:, LABEL_PLAIN]


class SecretCracker:
    def __init__(
        self,
        ffnn_model_path,
        hybrid_model_path,
        *,
        batch_size: int = 4096,
        global_cache_limit: int = 16,
        cache_verify_limit: int = 2,
    ):
        self.batch_size = batch_size
        self.global_cache_limit = global_cache_limit
        self.cache_verify_limit = cache_verify_limit

        so = ort.SessionOptions()
        # Cap threads so a search does not saturate every core and starve SDR#'s
        # real-time audio/DSP that shares this machine (half the cores, >=1).
        so.intra_op_num_threads = max(1, (os.cpu_count() or 4) // 2)
        providers = ["CPUExecutionProvider"]
        self.ffnn = ort.InferenceSession(_onnx_path(ffnn_model_path), sess_options=so, providers=providers)
        self.hybrid = ort.InferenceSession(_onnx_path(hybrid_model_path), sess_options=so, providers=providers)
        self.ffnn_in = self.ffnn.get_inputs()[0].name
        self.hybrid_in = self.hybrid.get_inputs()[0].name

        self.all_pn = _generate_all_pn_sequences()
        self.global_cache: list[int] = []

    # ---- model helpers ----
    def _ffnn_logits(self, x: np.ndarray) -> np.ndarray:
        return self.ffnn.run(None, {self.ffnn_in: np.ascontiguousarray(x, dtype=np.float32)})[0]

    def _hybrid_logits(self, x: np.ndarray) -> np.ndarray:
        return self.hybrid.run(None, {self.hybrid_in: np.ascontiguousarray(x, dtype=np.float32)})[0]

    def resolve_key(self, current_key: int, burst_payload: bytes, burst_count: int) -> SecretResolution:
        raise RuntimeError("Privacy-key analysis is disabled in this distribution")

    def _remember_key(self, key: int) -> None:
        if key <= 0:
            return
        self.global_cache = [cached for cached in self.global_cache if cached != key]
        self.global_cache.insert(0, key)
        del self.global_cache[self.global_cache_limit :]

    def _verify_cached_candidates(self, blocks_raw, candidate_keys) -> int:
        raise RuntimeError("Privacy-key analysis is disabled in this distribution")

    def _score_candidate_with_ffnn(self, blocks_raw, candidate_key: int):
        raise RuntimeError("Privacy-key analysis is disabled in this distribution")

    def _full_search(self, blocks_raw) -> int:
        raise RuntimeError("Privacy-key analysis is disabled in this distribution")

    def _batched_argmax(self, session, input_name, samples: np.ndarray, batch_size: int) -> np.ndarray:
        predictions = np.empty(samples.shape[0], dtype=np.int64)
        for start in range(0, samples.shape[0], batch_size):
            end = min(start + batch_size, samples.shape[0])
            logits = session.run(None, {input_name: np.ascontiguousarray(samples[start:end], dtype=np.float32)})[0]
            predictions[start:end] = np.argmax(logits, axis=1)
        return predictions

    def _batched_plain_scores(self, samples: np.ndarray, batch_size: int):
        if samples.shape[0] == 0:
            return np.empty(0, dtype=np.float32), np.empty(0, dtype=np.float32)
        parts = []
        for start in range(0, samples.shape[0], batch_size):
            end = min(start + batch_size, samples.shape[0])
            parts.append(self._hybrid_logits(samples[start:end]))
        logits = np.concatenate(parts, axis=0)
        probs = _softmax_plain(logits)
        scores = (logits[:, LABEL_PLAIN] - logits[:, LABEL_ENCRYPTED]).astype(np.float32)
        return scores, probs


def _onnx_path(model_path) -> str:
    # Accept either the .safetensors path (swap suffix) or the .onnx path.
    p = Path(model_path)
    return str(p if p.suffix == ".onnx" else p.with_suffix(".onnx"))
