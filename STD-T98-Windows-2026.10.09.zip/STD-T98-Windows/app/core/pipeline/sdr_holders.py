"""Find and stop processes that may already hold the SDR device.

Only process listing and termination; no SDR is opened. Uses the OS process
table (Windows: CIM via PowerShell, Linux: /proc) so no extra package is needed.
"""
from dataclasses import dataclass, field
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

# Receiver scripts that open the radio themselves. A backend fed by an IP
# server (--rf-remote) or a recording (--replay) does not.
_SDR_SCRIPTS = {
    "std_t98_30ch_multi_rf_backend.py": "RF受信処理",
    "std_t98_rf_server.py": "RFデータ配信サーバ",
    "std_t98_channel_scope.py": "チャンネルスコープ",
    "std_t98_record_iq.py": "IQ録音ツール",
    "std_t98_fsk4800_monitor.py": "4800sym/s 4FSKモニタ",
}
_NO_SDR_ARGS = ("--rf-remote", "--replay")
# Front-ends that own a whole receiver stack (the backend is their child).
_STACK_ROOTS = {
    "std_t98_gui.py": "STD-T98 Multi Receiver",
    "std_t98_multi_service_launcher.py": "STD-T98 受信（ターミナル版）",
}
_STACK_SERVICES = ("std_t98_multi_protocol_service.py", "std_t98_multi_audio_service.py",
                   "std_t98_multi_secret_service.py")
# Other SDR software that commonly keeps the device open.
_EXTERNAL = {
    "sdrsharp.exe": "SDR#", "sdrpp.exe": "SDR++", "sdrpp": "SDR++", "gqrx": "Gqrx", "gqrx.exe": "Gqrx",
    "cubicsdr.exe": "CubicSDR", "cubicsdr": "CubicSDR", "hdsdr.exe": "HDSDR", "sdruno.exe": "SDRuno",
    "sdrconsole.exe": "SDR Console", "hackrf_transfer.exe": "hackrf_transfer", "hackrf_transfer": "hackrf_transfer",
    "hackrf_sweep.exe": "hackrf_sweep", "hackrf_sweep": "hackrf_sweep",
    "rtl_tcp.exe": "rtl_tcp", "rtl_tcp": "rtl_tcp", "rtl_fm.exe": "rtl_fm", "rtl_fm": "rtl_fm",
    "rtl_sdr.exe": "rtl_sdr", "rtl_sdr": "rtl_sdr", "rtl_power.exe": "rtl_power", "rtl_power": "rtl_power",
    "soapysdrserver.exe": "SoapyRemote", "soapysdrserver": "SoapyRemote",
    "dump1090.exe": "dump1090", "dump1090": "dump1090",
}


@dataclass(frozen=True)
class Proc:
    pid: int
    ppid: int
    name: str
    cmdline: str
    created: float  # seconds since the epoch, 0 when unknown


@dataclass
class Holder:
    """One stoppable unit: a process and everything it started."""
    root: Proc
    members: list = field(default_factory=list)
    label: str = ""
    detail: str = ""
    external: bool = False


def list_processes():
    if sys.platform == "win32":
        return _list_windows()
    return _list_proc()


def _list_windows():
    command = ("Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CommandLine,"
               "CreationDate | ConvertTo-Json -Compress")
    result = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", command],
                            capture_output=True, timeout=30,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    rows = json.loads(result.stdout.decode("utf-8", errors="replace") or "[]")
    processes = []
    for row in rows if isinstance(rows, list) else [rows]:
        created = re.search(r"Date\((\d+)", str(row.get("CreationDate") or ""))
        processes.append(Proc(int(row["ProcessId"]), int(row.get("ParentProcessId") or 0), str(row.get("Name") or ""),
                              str(row.get("CommandLine") or ""), int(created.group(1)) / 1000 if created else 0))
    return processes


def _list_proc():
    processes = []
    boot = _boot_time()
    ticks = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            stat = (entry / "stat").read_text()
            cmdline = (entry / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace").strip()
        except OSError:
            continue
        # comm may contain spaces/parentheses: split after the last ')'.
        name = stat[stat.index("(") + 1:stat.rindex(")")]
        fields = stat[stat.rindex(")") + 2:].split()
        processes.append(Proc(int(entry.name), int(fields[1]), name, cmdline, boot + int(fields[19]) / ticks if boot else 0))
    return processes


def _boot_time():
    try:
        for line in Path("/proc/stat").read_text().splitlines():
            if line.startswith("btime "):
                return float(line.split()[1])
    except OSError:
        pass
    return 0


def _script_in(cmdline, scripts):
    lowered = cmdline.replace("\\", "/").lower()
    return next((script for script in scripts if f"/{script}" in lowered or lowered.startswith(script)
                 or f" {script}" in lowered or f'"{script}' in lowered), None)


def _holds_sdr(proc):
    script = _script_in(proc.cmdline, _SDR_SCRIPTS)
    if script is None:
        return None
    if script == "std_t98_30ch_multi_rf_backend.py" and any(arg in proc.cmdline for arg in _NO_SDR_ARGS):
        return None
    if script == "std_t98_rf_server.py" and "--replay" in proc.cmdline:
        return None
    return script


def find_holders(processes=None, own_pid=None):
    """Processes that may hold the SDR, grouped by the receiver stack they belong to."""
    processes = list_processes() if processes is None else processes
    own_pid = os.getpid() if own_pid is None else own_pid
    by_pid = {proc.pid: proc for proc in processes}
    children = {}
    for proc in processes:
        if proc.ppid != proc.pid:
            children.setdefault(proc.ppid, []).append(proc)

    def ancestors(proc):
        seen = set()
        while proc.ppid in by_pid and proc.ppid not in seen:
            seen.add(proc.ppid)
            parent = by_pid[proc.ppid]
            # A recycled PID can look like a parent that started after its child.
            if parent.created and proc.created and parent.created > proc.created + 1:
                return
            proc = parent
            yield proc

    def descendants(proc):
        result, stack = [], [proc]
        while stack:
            current = stack.pop()
            for child in children.get(current.pid, ()):
                if child.created and current.created and child.created + 1 < current.created:
                    continue  # recycled PID
                result.append(child)
                stack.append(child)
        return result

    own = by_pid.get(own_pid)
    protected = {own_pid}
    if own is not None:
        protected |= {proc.pid for proc in ancestors(own)} | {proc.pid for proc in descendants(own)}

    holders = {}
    for proc in processes:
        if proc.pid in protected:
            continue
        script = _holds_sdr(proc)
        if script is not None:
            root = next((parent for parent in ancestors(proc) if _script_in(parent.cmdline, _STACK_ROOTS)), proc)
            if root.pid in protected or root.pid in holders:
                continue
            front = _script_in(root.cmdline, _STACK_ROOTS)
            label = _STACK_ROOTS[front] if front else _SDR_SCRIPTS[script]
            detail = _SDR_SCRIPTS[script] + ("を含む受信一式" if front else "")
            members = [root, *descendants(root)]
            if not front and root.ppid not in by_pid:
                # Its window is gone: the stack's other services were left
                # behind with it and still hold the local IPC ports.
                orphans = [other for other in processes if other.ppid == root.ppid and other.pid != root.pid
                           and other.pid not in protected and _script_in(other.cmdline, _STACK_SERVICES)]
                for orphan in orphans:
                    members += [orphan, *descendants(orphan)]
                if orphans:
                    detail += "（終了したウィンドウの残り）"
            holders[root.pid] = Holder(root, members, label, detail)
        elif proc.name.lower() in _EXTERNAL:
            holders.setdefault(proc.pid, Holder(proc, [proc, *descendants(proc)], _EXTERNAL[proc.name.lower()],
                                                "外部のSDRソフト", external=True))
    return sorted(holders.values(), key=lambda holder: (holder.external, holder.root.created))


def stop_holders(holders, timeout=5.0):
    """Stop each holder with its children; returns the holders still running."""
    for holder in holders:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/PID", str(holder.root.pid), "/T", "/F"], capture_output=True,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            for member in reversed(holder.members):
                try:
                    os.kill(member.pid, signal.SIGTERM)
                except OSError:
                    pass
    deadline = time.monotonic() + timeout
    remaining = list(holders)
    while remaining and time.monotonic() < deadline:
        time.sleep(.2)
        alive = {proc.pid: proc for proc in list_processes()}
        remaining = [holder for holder in remaining if any(_same(alive.get(m.pid), m) for m in holder.members)]
    if remaining and sys.platform != "win32":
        for holder in remaining:
            for member in holder.members:
                try:
                    os.kill(member.pid, signal.SIGKILL)
                except OSError:
                    pass
        time.sleep(.5)
        alive = {proc.pid: proc for proc in list_processes()}
        remaining = [holder for holder in remaining if any(_same(alive.get(m.pid), m) for m in holder.members)]
    return remaining


def _same(current, original):
    # Same PID and start time: not a new process that reused the PID.
    return current is not None and (not original.created or abs(current.created - original.created) < 1)
