#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reusable supervisor for the split STD-T98 multi-channel stack.

This holds everything the terminal launcher and the desktop GUI share: locating
the two Python interpreters, building the process specs, spawning and tearing
down the children, and folding the status socket into the ChannelView /
ProcessView state both front-ends render. The front-ends differ only in how they
draw that state and drive the poll loop.
"""

import os
import json
import signal
import socket
import shutil
import subprocess
import tempfile
import sys
import time
from dataclasses import dataclass, replace
from pathlib import Path

from core.pipeline import child_job
from core.pipeline.multi_stack_dashboard import ChannelView, ProcessView
from ipc.message_schema import (
    STATUS_SOURCE_AUDIO,
    STATUS_SOURCE_PROTOCOL,
    STATUS_SOURCE_RF,
    STATUS_SOURCE_SECRET,
    ControlSquelchPacket,
    ControlGainPacket,
    ControlHackRFGainPacket,
    ControlCorrectIQPacket,
    ControlFreqAutoPacket,
    StatusPacket,
)
from ipc.transport.uds_seqpacket import (
    UdsSeqpacketReceiver,
    UdsSeqpacketServer,
    resolve_control_socket_path,
    resolve_status_socket_path,
)


BACKEND_IMPORT_CHECKS = ("from gnuradio import gr", "from gnuradio import soapy")
# Required for protocol/audio. torch/safetensors are NOT here: they are only
# needed by the optional secret (privacy-key) service, checked separately so a
# lighter install without torch still runs and plays clear voice.
# The AMBE+2 voice decoder is bundled at app/vendor/ambe2 (loaded by
# core.audio.independent_ambe); no separate import check is needed.
SERVICE_IMPORT_CHECKS = (
    "import sounddevice",
)
SECRET_IMPORT_CHECKS = (
    "import torch",
    "from safetensors.torch import load_file",
)
IMPORT_CHECK_CODE = (
    "import sys\n"
    "for statement in sys.argv[1:]:\n"
    "    try:\n"
    "        exec(statement, {})\n"
    "    except Exception:\n"
    "        sys.exit(1)\n"
    "sys.exit(0)\n"
)
IMPORT_CHECK_TIMEOUT_SEC = 5.0
SOURCE_PROCESS_NAMES = {
    STATUS_SOURCE_PROTOCOL: "protocol",
    STATUS_SOURCE_AUDIO: "audio",
    STATUS_SOURCE_SECRET: "secret",
    STATUS_SOURCE_RF: "backend",
}
# Processes that report continuously while working; silence = stalled.
# (The protocol/audio/secret services only report when there is traffic.)
STALL_WATCHED_PROCESSES = ("backend",)
STALL_SECONDS = 5.0


@dataclass(frozen=True)
class ProcessSpec:
    name: str
    python_executable: Path
    script_path: Path
    args: tuple[str, ...] = ()
    environment: tuple[tuple[str, str], ...] = ()


def _terminate_processes(processes):
    for process in processes:
        if process.poll() is None:
            # Windows' send_signal only accepts SIGTERM/CTRL_* and raises
            # ValueError for SIGINT, so terminate() there; POSIX gets a graceful
            # SIGINT so the child's handler can close sockets/audio cleanly.
            try:
                if os.name == "nt":
                    process.terminate()
                else:
                    process.send_signal(signal.SIGINT)
            except (ValueError, OSError):
                try:
                    process.terminate()
                except OSError:
                    pass

    for process in processes:
        if process.poll() is not None:
            continue
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass

    for process in processes:
        if process.poll() is not None:
            continue
        try:
            process.terminate()
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()


def _existing_candidates(candidate_paths):
    resolved = []
    seen = set()
    for candidate in candidate_paths:
        if not candidate:
            continue
        path = Path(candidate).expanduser()
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        if path.exists():
            resolved.append(path)
    return resolved


def _bundled_python_candidates(repo_root):
    """Interpreters shipped inside the distribution folder, for a portable
    "copy one folder and run" layout. Covers a bundled env next to the app
    (``<dist>/python``) whether the app lives at the dist root or under
    ``<dist>/app``, on both Windows (``python.exe``/``pythonw.exe``) and POSIX
    (``bin/python``).
    """
    root = Path(repo_root)
    bases = [root, root / "python", root.parent]
    candidates = []
    for base in bases:
        candidates.extend([
            base / "python" / "python.exe",
            base / "python" / "pythonw.exe",
            base / "python" / "bin" / "python",
        ])
    return candidates


def _python_supports_import_checks(python_executable, import_checks):
    for import_check in import_checks:
        try:
            # Run once per candidate and module; without CREATE_NO_WINDOW each
            # python.exe probe flashes a console window on Windows.
            result = subprocess.run(
                [str(python_executable), "-c", IMPORT_CHECK_CODE, import_check],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
                timeout=IMPORT_CHECK_TIMEOUT_SEC,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except subprocess.TimeoutExpired:
            return False

        if result.returncode != 0:
            return False

    return True


def _resolve_python(override, candidate_paths, import_checks, role_name):
    candidates = _existing_candidates(([override] if override else []) + list(candidate_paths))
    for candidate in candidates:
        if _python_supports_import_checks(candidate, import_checks):
            return candidate

    searched = ", ".join(str(candidate) for candidate in candidates) or "<none>"
    raise RuntimeError(
        f"Could not find a Python interpreter for {role_name} with required imports {import_checks}. "
        f"Searched: {searched}"
    )


def build_process_specs(repo_root, service_python, status_socket_path=None, backend_python=None, include_backend=True, backend_args=(), control_socket_path=None, include_secret=True, audio_args=()):
    service_python = Path(service_python)

    def _args():
        return ("--headless", "--status-socket", status_socket_path) if status_socket_path else ("--headless",)

    process_specs = [
        ProcessSpec(
            "protocol",
            service_python,
            repo_root / "std_t98_multi_protocol_service.py",
            args=_args(),
        ),
    ]
    # Privacy-key analysis service is excluded in this distribution.
    process_specs.append(ProcessSpec(
        "audio",
        service_python,
        repo_root / "std_t98_multi_audio_service.py",
        args=(*_args(), *audio_args),
    ))

    if include_backend:
        if backend_python is None:
            raise ValueError("backend_python is required when include_backend is True")
        control_args = ("--control-socket", control_socket_path) if control_socket_path else ()
        process_specs.append(ProcessSpec(
            "backend", Path(backend_python),
            repo_root / "std_t98_30ch_multi_rf_backend.py",
            args=(*backend_args, *control_args),
        ))

    return process_specs


def _spawn_process(process_spec, passthrough_output=False, announce_start=False):
    child_env = os.environ.copy()
    child_env["PYTHONUNBUFFERED"] = "1"
    child_env.update(process_spec.environment)
    log_file = None
    if passthrough_output:
        stdout = None
        stderr = None
    else:
        # Not DEVNULL: keep the output so a non-zero exit can be explained.
        log_file = tempfile.NamedTemporaryFile(
            mode="w+", prefix=f"std-t98-{process_spec.name}-", suffix=".log")
        stdout = log_file
        stderr = subprocess.STDOUT
    popen_kwargs = dict(
        cwd=process_spec.script_path.parent,
        env=child_env,
        stdout=stdout,
        stderr=stderr,
    )
    # On Windows, keep background workers (captured output) from each popping a
    # console window when the launcher itself runs under pythonw. Added only on
    # Windows so the POSIX call stays unchanged. Debug passthrough keeps the
    # inherited console.
    if os.name == "nt" and not passthrough_output:
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        if creationflags:
            popen_kwargs["creationflags"] = creationflags
    process = subprocess.Popen(
        [str(process_spec.python_executable), str(process_spec.script_path), *process_spec.args],
        **popen_kwargs,
    )
    # Ends with this process even if it crashes or is killed (Windows only).
    child_job.assign(process)
    if announce_start:
        print(
            f"Started {process_spec.name} with {process_spec.python_executable} "
            f"(pid {process.pid})"
        )
    return process, log_file


def _tail_log(log_file, max_lines=8):
    """Last few non-empty lines of a captured child log, for a crash message."""
    if log_file is None:
        return ""
    try:
        log_file.flush()
        log_file.seek(0)
        lines = [line.rstrip() for line in log_file if line.strip()]
    except Exception:
        return ""
    return "\n".join(lines[-max_lines:])


def _apply_status_payload(channels, source, channel_id, payload_dict):
    if payload_dict.get("event") != "channel_state":
        return False

    channel = channels.setdefault(channel_id, ChannelView(channel_id=channel_id))
    changed = False

    if source == STATUS_SOURCE_PROTOCOL:
        for field_name, payload_key in (
            ("rx_status", "rx_status"),
            ("protocol_status", "protocol_status"),
            ("csm", "csm"),
            ("sacch", "sacch"),
            ("protocol_debug", "protocol_debug"),
        ):
            new_value = payload_dict.get(payload_key, getattr(channel, field_name))
            if getattr(channel, field_name) != new_value:
                setattr(channel, field_name, new_value)
                changed = True

        if channel.rx_status == "CLOSE" or channel.protocol_status in ("Idle", "Sync Burst"):
            if channel.audio_status != "Idle":
                channel.audio_status = "Idle"
                changed = True
            if channel.secret_status != "Idle":
                channel.secret_status = "Idle"
                changed = True
    elif source == STATUS_SOURCE_AUDIO:
        if "playback_active" in payload_dict:
            channel.playback_active = bool(payload_dict["playback_active"])
            channel.playback_updated_at = time.monotonic()
            changed = True
        if "crc_percent" in payload_dict:
            value = payload_dict["crc_percent"]
            channel.crc_percent = None if value is None else max(0.0, min(100.0, float(value)))
            changed = True
        new_audio_status = payload_dict.get("audio_status", channel.audio_status)
        if channel.audio_status != new_audio_status:
            channel.audio_status = new_audio_status
            changed = True

        new_audio_debug = payload_dict.get("audio_debug", channel.audio_debug)
        if channel.audio_debug != new_audio_debug:
            channel.audio_debug = new_audio_debug
            changed = True

        new_secret_status = payload_dict.get("secret_status", channel.secret_status)
        if channel.secret_status != new_secret_status:
            channel.secret_status = new_secret_status
            changed = True

        new_secret_key = payload_dict.get("secret_key", channel.secret_key)
        if channel.secret_key != new_secret_key:
            channel.secret_key = new_secret_key
            changed = True
    elif source == STATUS_SOURCE_SECRET:
        new_secret_status = payload_dict.get("secret_status", channel.secret_status)
        if channel.secret_status != new_secret_status:
            channel.secret_status = new_secret_status
            changed = True

        new_secret_key = payload_dict.get("secret_key", channel.secret_key)
        if channel.secret_key != new_secret_key:
            channel.secret_key = new_secret_key
            changed = True

        new_secret_cache_keys = tuple(payload_dict.get("secret_cache_keys", channel.secret_cache_keys))
        if channel.secret_cache_keys != new_secret_cache_keys:
            channel.secret_cache_keys = new_secret_cache_keys
            changed = True
    elif source == STATUS_SOURCE_RF:
        new_rf_debug = payload_dict.get("rf_debug", channel.rf_debug)
        if channel.rf_debug != new_rf_debug:
            channel.rf_debug = new_rf_debug
            changed = True

    if changed:
        channel.last_update = time.time()
    return changed


def _apply_service_payload(process_views_by_name, source, payload_dict):
    if payload_dict.get("event") != "service_metrics":
        return False

    process_name = SOURCE_PROCESS_NAMES.get(source)
    if process_name is None:
        return False

    process_view = process_views_by_name.get(process_name)
    if process_view is None:
        return False

    summary = payload_dict.get("summary", "")
    if process_view.detail == summary:
        return False

    process_view.detail = summary
    return True


class StatusAggregator:
    """Owns the shared channel / process state and folds status packets into it.

    Both front-ends read ``channels`` and ``process_views`` to render; both feed
    decoded StatusPackets through ``apply_packet``. Keeping the mutation in one
    place is what lets the GUI and the terminal show identical state.
    """

    def __init__(self):
        self.channels: dict[int, ChannelView] = {}
        self.hackrf_gain = None
        self.rf_network = None
        self.spectrum = None
        self.freq_error = None
        self.dqpsk = {}
        self.process_views: list[ProcessView] = []
        self._process_views_by_name: dict[str, ProcessView] = {}

    def set_process_views(self, process_views):
        self.process_views = list(process_views)
        self._process_views_by_name = {view.name: view for view in self.process_views}

    def apply_packet(self, packet) -> bool:
        payload_dict = packet.to_dict()
        if packet.source == STATUS_SOURCE_RF and isinstance(payload_dict.get('dqpsk'), dict):
            state = payload_dict['dqpsk']
            frequency = state.get('frequency_hz')
            if isinstance(frequency, (int, float)) and frequency > 0:
                self.dqpsk[frequency] = state
                return True
            return False
        if packet.source == STATUS_SOURCE_RF and packet.channel_id == 0 and isinstance(payload_dict.get("spectrum"), dict):
            # Rendering only; does not change channel or process state.
            self.spectrum = payload_dict["spectrum"]
            return False
        if packet.source == STATUS_SOURCE_RF and packet.channel_id == 0 and isinstance(payload_dict.get("rf_network"), dict):
            self.rf_network = payload_dict["rf_network"]
            return True
        if packet.source == STATUS_SOURCE_RF and packet.channel_id == 0 and isinstance(payload_dict.get("freq_error"), dict):
            state = payload_dict["freq_error"]
            numbers = ("estimate_hz", "applied_hz", "suggested_hz", "spread_hz", "channels", "samples")
            if not all(isinstance(state.get(key), (int, float)) and not isinstance(state.get(key), bool) for key in numbers):
                return False
            changed = state != self.freq_error
            self.freq_error = state
            return changed
        if packet.source == STATUS_SOURCE_RF and packet.channel_id == 0 and isinstance(payload_dict.get("hackrf_gain"), dict):
            from core.rf.hackrf_gain import HackRFGains
            state = payload_dict["hackrf_gain"]
            try:
                HackRFGains(state.get("lna_gain"), state.get("vga_gain"), state.get("amp"))
                if not isinstance(state.get("auto"), bool):
                    raise ValueError("Invalid auto gain mode")
            except ValueError:
                return False
            changed = state != self.hackrf_gain
            self.hackrf_gain = state
            return changed
        changed = _apply_service_payload(self._process_views_by_name, packet.source, payload_dict)
        changed = _apply_status_payload(self.channels, packet.source, packet.channel_id, payload_dict) or changed
        return changed


class StackSupervisor:
    """Lifecycle of the split stack, independent of how it is rendered.

    Usage is the same from either front-end::

        supervisor = StackSupervisor(repo_root, ...)
        supervisor.resolve()          # locate interpreters, build specs
        supervisor.start()            # bind status socket, spawn children
        while supervisor.exit_message is None:
            supervisor.poll(timeout_ms)   # drain socket, watch for exits
            render(supervisor.process_views, supervisor.channels)
        supervisor.stop()

    The terminal launcher drives ``poll`` from a blocking while loop; the GUI
    drives it from a QTimer with ``timeout_ms=0`` so the event loop never stalls.
    """

    def __init__(
        self,
        repo_root,
        *,
        services_only=False,
        backend_args=(),
        service_python=None,
        backend_python=None,
        passthrough_output=False,
        channel_count=30,
        no_secret=False,
        audio_args=(),
        rf_mode="local",
        rf_token="",
    ):
        self.repo_root = Path(repo_root)
        self.services_only = services_only
        self.backend_args = tuple(backend_args)
        self.audio_args = tuple(audio_args)
        if rf_mode not in ("local", "client", "server"):
            raise ValueError("Invalid RF mode")
        if services_only and rf_mode != "local":
            raise ValueError("IP client/server requires a managed RF backend")
        self.rf_mode = rf_mode
        self.rf_token = rf_token
        self.service_python_override = service_python
        self.backend_python_override = backend_python
        self.passthrough_output = passthrough_output
        self.channel_count = channel_count
        # Secret (privacy-key) decode needs torch+safetensors. It is optional:
        # when disabled here or when the interpreter lacks torch, the secret
        # service is simply not spawned and audio plays clear voice only.
        self.no_secret = True  # Fixed for this distribution; no environment override.
        self.include_secret = False

        self.service_python: Path | None = None
        self.backend_python: Path | None = None
        self.status_socket_path: str | None = None
        self.control_socket_path: str | None = None
        self.process_specs: list[ProcessSpec] = []

        self.aggregator = StatusAggregator()
        self._status_receiver = None
        self._control_server = None
        self._processes: list[tuple[str, subprocess.Popen]] = []
        self._process_logs: dict[str, object] = {}
        self.exit_code = 0
        self.exit_message: str | None = None
        self._started = False
        self._audio_stop_directory = None
        self._rf_ipc_directory = None
        self._rf_ipc_environment = {}
        self._last_report = {}       # process name -> monotonic time of its last status packet

    @property
    def mode_label(self) -> str:
        if self.rf_mode != "local":
            return f"rf-{self.rf_mode}"
        return "services-only" if self.services_only else "full-stack"

    @property
    def channels(self):
        return self.aggregator.channels

    @property
    def process_views(self):
        return self.aggregator.process_views

    def resolve(self):
        """Locate interpreters and build the process specs and initial views.

        Raises RuntimeError if a required interpreter cannot be found, matching
        the launcher's previous behaviour of failing before anything is spawned.
        """
        self.service_python = _resolve_python(
            override=self.service_python_override or os.environ.get("STD_T98_SERVICE_PYTHON"),
            candidate_paths=[
                sys.executable,
                *_bundled_python_candidates(self.repo_root),
                self.repo_root / "env/bin/python",
                shutil.which("python3"),
                shutil.which("python"),
                "/usr/bin/python",
            ],
            import_checks=BACKEND_IMPORT_CHECKS if self.rf_mode == "server" else SERVICE_IMPORT_CHECKS,
            role_name="RF server" if self.rf_mode == "server" else "protocol/audio services",
        )

        # Privacy-key analysis is permanently disabled in this distribution.
        self.include_secret = False

        if not self.services_only:
            self.backend_python = _resolve_python(
                override=self.backend_python_override or os.environ.get("STD_T98_BACKEND_PYTHON"),
                candidate_paths=[
                    sys.executable,
                    *_bundled_python_candidates(self.repo_root),
                    shutil.which("python3"),
                    shutil.which("python"),
                    "/usr/bin/python",
                ],
                import_checks=BACKEND_IMPORT_CHECKS,
                role_name="RF backend",
            )

        self.status_socket_path = resolve_status_socket_path(channel_count=self.channel_count)
        self.control_socket_path = (
            None if self.services_only else resolve_control_socket_path()
        )
        if self.rf_mode != "local":
            # Keep a server and clients on the same PC from sharing local IPC.
            if not self._rf_ipc_environment:
                names = ("FRAME", "VOICE", "STATUS", "SECRET_REQUEST", "SECRET_RESULT", "CONTROL")
                if os.name == "nt" or os.environ.get("STD_T98_IPC", "").lower() == "tcp":
                    reservations = []
                    try:
                        for name in names:
                            listener = socket.socket()
                            reservations.append(listener)
                            listener.bind(("127.0.0.1", 0))
                            self._rf_ipc_environment[f"STD_T98_MULTI_{name}_SOCKET"] = f"127.0.0.1:{listener.getsockname()[1]}"
                    finally:
                        for listener in reservations:
                            listener.close()
                else:
                    self._rf_ipc_directory = tempfile.TemporaryDirectory(prefix="t98-rf-")
                    self._rf_ipc_environment = {f"STD_T98_MULTI_{name}_SOCKET":
                        str(Path(self._rf_ipc_directory.name) / f"{name.lower()}.sock") for name in names}
            self.status_socket_path = self._rf_ipc_environment["STD_T98_MULTI_STATUS_SOCKET"]
            self.control_socket_path = self._rf_ipc_environment["STD_T98_MULTI_CONTROL_SOCKET"]

        self.process_specs = build_process_specs(
            repo_root=self.repo_root,
            service_python=self.service_python,
            status_socket_path=self.status_socket_path,
            backend_python=self.backend_python,
            include_backend=not self.services_only,
            backend_args=self.backend_args,
            control_socket_path=self.control_socket_path,
            include_secret=self.include_secret,
            audio_args=self.audio_args,
        )
        if self.rf_mode == "server":
            self.process_specs = [ProcessSpec("backend", self.backend_python,
                self.repo_root / "std_t98_rf_server.py",
                (*self.backend_args, "--status-socket", self.status_socket_path,
                 "--control-socket", self.control_socket_path))]
        if self.rf_mode != "local":
            from core.rf.remote_iq import require_token, TOKEN_ENV
            require_token(self.rf_token)
            self.process_specs = [replace(spec, environment=tuple(self._rf_ipc_environment.items()) +
                                  (((TOKEN_ENV, self.rf_token),) if spec.name == "backend" else ()))
                                  for spec in self.process_specs]

        self.aggregator.set_process_views([
            ProcessView(
                name=spec.name,
                python_executable=str(spec.python_executable),
                script_name=spec.script_path.name,
            )
            for spec in self.process_specs
        ])
        return self.process_specs

    def dry_run_lines(self) -> list[str]:
        if not self.process_specs:
            self.resolve()
        lines = []
        for spec in self.process_specs:
            extra = " ".join(spec.args)
            if extra:
                lines.append(f"{spec.name}: {spec.python_executable} {spec.script_path} {extra}")
            else:
                lines.append(f"{spec.name}: {spec.python_executable} {spec.script_path}")
        return lines

    def start(self):
        if self._started:
            return
        if not self.process_specs:
            self.resolve()
        self._audio_stop_directory = tempfile.TemporaryDirectory(prefix="std-t98-audio-stop-")
        marker = str(Path(self._audio_stop_directory.name) / "stop")
        rf_args = ("--rf-args-json",json.dumps(self.backend_args)) if not self.services_only else ()
        self.process_specs = [replace(spec, args=(*spec.args, "--stop-file", marker, *rf_args))
                              if spec.name == "audio" else spec for spec in self.process_specs]
        if '--dqpsk-rtcm' in self.backend_args and self.rf_mode != 'server':
            self.process_specs = [replace(spec, args=(*spec.args, '--rf-stop-file', marker))
                                  if spec.name == 'backend' else spec for spec in self.process_specs]

        self._status_receiver = UdsSeqpacketReceiver(self.status_socket_path)
        if self.control_socket_path:
            self._control_server = UdsSeqpacketServer(self.control_socket_path)

        for spec in self.process_specs:
            process, log_file = _spawn_process(
                spec,
                passthrough_output=self.passthrough_output,
                announce_start=False,
            )
            self._processes.append((spec.name, process))
            self._process_logs[spec.name] = log_file
            process_view = self.aggregator._process_views_by_name[spec.name]
            process_view.pid = process.pid
            # STARTING until the process actually reports in over the status
            # socket -- for the backend that means the SDR is open and the
            # flowgraph is pulling samples, not just that the OS process
            # exists. A slow/contended device bring-up (e.g. a B210 on USB2
            # competing with the secret service's model load) can leave the
            # process alive but silent for a while; a bare "RUNNING" badge
            # would hide exactly that.
            process_view.state = "STARTING"

        self._started = True

    def poll(self, timeout_ms=100) -> bool:
        """Drain the status socket and check the children once.

        Returns True if the rendered state changed. Sets ``exit_message`` and
        ``exit_code`` when a child exits; the caller should stop looping then.
        """
        if not self._started:
            return False

        changed = False

        payload = self._status_receiver.recv(timeout_ms=timeout_ms)
        while payload is not None:
            packet = StatusPacket.decode(payload)
            changed = self.aggregator.apply_packet(packet) or changed

            # Any status packet at all proves this process has gotten far
            # enough to report in (for the backend, that its status publisher
            # is running inside a live work() call -- i.e. actually streaming).
            name = SOURCE_PROCESS_NAMES.get(packet.source)
            process_view = self.aggregator._process_views_by_name.get(name)
            if process_view is not None:
                self._last_report[name] = time.monotonic()
                if process_view.state in ("STARTING", "STALLED"):
                    process_view.state = "RUNNING"
                    process_view.silent_seconds = 0.0
                    changed = True

            payload = self._status_receiver.recv(timeout_ms=0)

        changed = self._check_stalls(time.monotonic()) or changed

        for name, process in self._processes:
            return_code = process.poll()
            process_view = self.aggregator._process_views_by_name[name]
            if return_code is not None:
                process_view.state = "EXITED"
                self.exit_code = return_code or 1
                self.exit_message = f"{name} service exited with status {return_code}"
                tail = _tail_log(self._process_logs.get(name))
                if tail:
                    self.exit_message += f"\n{tail}"
                changed = True
                break

        return changed

    def _check_stalls(self, now) -> bool:
        """A live RF process that stops reporting has a stopped flowgraph.

        Its status reports come from inside the running graph (spectrum ~8/s,
        sync statistics 1/s, IP delivery state 0.5-1/s), so silence means no
        samples are being processed even though the process is alive.
        """
        changed = False
        for name in STALL_WATCHED_PROCESSES:
            process_view = self.aggregator._process_views_by_name.get(name)
            last = self._last_report.get(name)
            if process_view is None or last is None or process_view.state not in ("RUNNING", "STALLED"):
                continue
            silent = now - last
            if silent >= STALL_SECONDS:
                if process_view.state != "STALLED" or int(silent) != int(process_view.silent_seconds):
                    changed = True
                process_view.state = "STALLED"
                process_view.silent_seconds = silent
        return changed

    def set_squelch(self, threshold_db: float) -> bool:
        """Push a live squelch threshold to the running backend, if any.

        Returns False harmlessly if there is no managed backend or it has not
        connected to the control socket yet (e.g. services-only mode, or the
        stack was just started).
        """
        if self._control_server is None:
            return False
        return self._control_server.send(ControlSquelchPacket(threshold_db=threshold_db).encode())

    def set_gain(self, auto: bool, gain_db: float) -> bool:
        if self._control_server is None:
            return False
        return self._control_server.send(ControlGainPacket(auto, gain_db).encode())

    def set_hackrf_gain(self, auto: bool, lna_gain: int, vga_gain: int, amp: bool) -> bool:
        if self._control_server is None:
            return False
        return self._control_server.send(ControlHackRFGainPacket(auto, lna_gain, vga_gain, amp).encode())

    def set_correct_iq(self, enabled: bool) -> bool:
        if self._control_server is None:
            return False
        return self._control_server.send(ControlCorrectIQPacket(bool(enabled)).encode())

    def set_freq_auto(self, enabled: bool) -> bool:
        if self._control_server is None:
            return False
        return self._control_server.send(ControlFreqAutoPacket(bool(enabled)).encode())

    def stop(self):
        # Drain voice recordings and patch WAV headers before Windows terminates
        # the other children. A stalled audio service still has a bounded stop.
        if self._audio_stop_directory is not None:
            (Path(self._audio_stop_directory.name) / "stop").touch()
            for name, process in self._processes:
                if (name == "audio" or name == "backend" and "--dqpsk-rtcm" in self.backend_args) and process.poll() is None:
                    try:
                        process.wait(timeout=10 if name == "backend" else 3)
                    except subprocess.TimeoutExpired:
                        pass
        if self._status_receiver is not None:
            self._status_receiver.close()
            self._status_receiver = None
        if self._control_server is not None:
            self._control_server.close()
            self._control_server = None
        _terminate_processes([process for _, process in self._processes])
        self._processes = []
        self._started = False
        self._last_report = {}
        if self._audio_stop_directory is not None:
            self._audio_stop_directory.cleanup()
            self._audio_stop_directory = None
        if self._rf_ipc_directory is not None:
            self._rf_ipc_directory.cleanup()
            self._rf_ipc_directory = None
        if self.rf_mode != "local":
            self._rf_ipc_environment = {}
            self.process_specs = []
