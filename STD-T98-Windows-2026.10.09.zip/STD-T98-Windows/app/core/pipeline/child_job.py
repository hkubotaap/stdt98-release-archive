"""Windows: end the stack's service processes when this process ends, however it ends.

StackSupervisor.stop() already terminates its children on a normal exit, but
Windows does not take children down with a parent that crashes or is killed
(e.g. after a freeze): orphaned secret services were found still running.
Each spawned service joins one kill-on-close Job Object owned by this process;
when the process ends the handle closes and Windows ends every member,
including processes the services start themselves.

Only processes passed to ``assign`` are members. An RF server this receiver
merely connects to as an IP client, or a playback tool it opened, is never
assigned and keeps running.
"""
import ctypes
import os
from ctypes import wintypes

_JOB_OBJECT_EXTENDED_LIMIT_INFORMATION = 9
_JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000


class _BasicLimits(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD),
                ("SchedulingClass", wintypes.DWORD)]


class _IoCounters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in ("ReadOperationCount", "WriteOperationCount",
                                                    "OtherOperationCount", "ReadTransferCount",
                                                    "WriteTransferCount", "OtherTransferCount")]


class _ExtendedLimits(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", _BasicLimits), ("IoInfo", _IoCounters),
                ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]


_job = None


def _create_job():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateJobObjectW.restype = wintypes.HANDLE
    kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    # NULL security attributes: the handle is not inheritable, so no child can
    # keep the job (and itself) alive after this process is gone.
    job = kernel.CreateJobObjectW(None, None)
    if not job:
        return None
    limits = _ExtendedLimits()
    limits.BasicLimitInformation.LimitFlags = _JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not kernel.SetInformationJobObject(job, _JOB_OBJECT_EXTENDED_LIMIT_INFORMATION,
                                          ctypes.byref(limits), ctypes.sizeof(limits)):
        kernel.CloseHandle(job)
        return None
    return kernel, job


def assign(process) -> bool:
    """Tie ``process`` (a subprocess.Popen) to this process's lifetime; False if not possible."""
    global _job
    handle = getattr(process, "_handle", None)       # Popen's process handle on Windows
    if os.name != "nt" or handle is None:
        return False
    if _job is None:
        _job = _create_job() or False
    if not _job:
        return False
    kernel, job = _job
    return bool(kernel.AssignProcessToJobObject(job, int(handle)))
