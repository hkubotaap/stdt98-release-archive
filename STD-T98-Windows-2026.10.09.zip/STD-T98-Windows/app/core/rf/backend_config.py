"""RF backend configuration and channelizer rate derivation.

This module keeps device-specific settings (which SDR, at what sample rate,
gains, calibration) out of the GNU Radio flowgraph so the same backend can
drive RTL-SDR, USRP, HackRF and other SoapySDR devices without editing the
flowgraph source.

Two responsibilities live here:

1. :class:`BackendConfig` and its sub-configs describe *what* to receive with.
   They can be built from defaults, a TOML file, and/or argparse overrides.
   The defaults reproduce the historical RTL-SDR / 1.2 MHz behaviour exactly.

2. :func:`derive_rates` computes the resampling / channelizer parameters from
   the input sample rate instead of hard-coding them. STD-T98 uses a 6.25 kHz
   channel raster, so every PFB output bin must be exactly one channel wide;
   given that invariant the stage-1 resampler ratio follows from the input
   rate, and the channel-to-bin map follows from the channel counts.

None of this imports GNU Radio, so it is unit-testable on any machine.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, replace
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Optional
from core.rf.hackrf_gain import HackRFGains
from core.rf.channel_plan import BANDS, BANDS_BY_KEY, FULL_351_PFB_CHANNELS, FULL_351_SPACING_HZ

try:  # Python 3.11+
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - exercised only on old runtimes
    tomllib = None


# ---------------------------------------------------------------------------
# STD-T98 physical-layer constants (protocol-defined, not device-specific).
# ---------------------------------------------------------------------------
CHANNEL_SPACING_HZ = 6250            # 6.25 kHz channel raster
DEFAULT_NUM_CHANNELS = 30
DEFAULT_CENTER_FREQ_HZ = 351_293_750  # 351.29375 MHz
BAUD_RATE = 2400

CONFIG_ENV_VAR = "STD_T98_BACKEND_CONFIG"

# SoapySDR validates stream arguments against what the device advertises and
# raises for anything it does not know, so a stream arg that helps one driver
# is fatal on another. "bufflen" is an rtlsdr/osmosdr-specific knob: passing it
# to e.g. uhd or hackrf aborts source construction with
# "Unsupported stream argument bufflen". Keep the historical RTL-SDR buffer
# size as that driver's default and send nothing to drivers we have no reason
# to tune, while still letting the config file or CLI override either way.
DRIVER_DEFAULT_STREAM_ARGS = {
    "rtlsdr": "bufflen=16384",
}

# Drivers that already track the analog filter to the sample rate, so touching
# the bandwidth would only change long-standing behaviour. Everything else can
# leave its front end wide open -- a USRP B210 sits at its full 56 MHz no
# matter how slowly you sample, folding megahertz of spectrum onto the 187.5
# kHz this actually cares about -- so those get the bandwidth set for them.
DRIVERS_WITH_AUTOMATIC_BANDWIDTH = {"rtlsdr"}

# Frequency error is a property of one physical radio, not of a driver, so a
# value measured on one device is meaningless on another and actively harmful:
# the demodulator turns it into a DC level on the symbol stream, and the sync
# correlator compares against absolute levels with no DC removal. The historical
# -340 Hz was measured on one RTL-SDR; on any other radio it is 1.24 symbol
# units of error, enough on its own to push the sync SSE past its threshold.
# So it stays attached to the driver it was measured on, and every other device
# starts from zero and must be calibrated (or corrected) for itself.
DRIVER_DEFAULT_FREQ_ERR_OFFSET = {
    "rtlsdr": -340.0,
}

# Minimum/native sample rate differs per device: RTL-SDR happily runs at
# 1.2 MHz, but HackRF cannot sample below 2 MHz and simply refuses (or rounds,
# which the open path then rejects so the channelizer stays correct). When the
# user has not chosen a rate, pick one the driver can actually serve.
DRIVER_DEFAULT_SAMPLE_RATE = {
    "hackrf": 2_000_000.0,
}

# Legacy total-gain default per driver. HackRF now applies named stage values,
# distributing this value across LNA/VGA with AMP initially off when no stages
# are specified. The RTL-SDR default 30 is too quiet on this receiver setup.
DRIVER_DEFAULT_GAIN = {
    "hackrf": 80.0,
}

# Resampler ratio search cap. Keeps GNU Radio's rational_resampler taps sane
# when the input rate is not an exact multiple of the channelizer rate; the
# resulting rate error is well under 1 ppm for any realistic SDR rate.
_MAX_RESAMP_DENOMINATOR = 10_000


@dataclass(frozen=True)
class SdrConfig:
    """Device-facing settings passed to the SoapySDR source."""

    driver: str = "rtlsdr"           # SoapySDR driver key, e.g. rtlsdr / uhd / hackrf
    device_args: str = ""            # extra device selection, e.g. "serial=123,type=b200"
    sample_rate: float = 1_200_000.0
    center_freq: float = float(DEFAULT_CENTER_FREQ_HZ)
    freq_offset: float = 0.0          # deliberate tuning offset (Hz)
    # None asks for this driver's default (see above); 0 means no correction.
    freq_err_offset: Optional[float] = None
    freq_correction: float = 0.0      # frequency correction in ppm
    # Follow the live estimate by retuning (core.rf.freq_error.AutoFrequencyCorrector).
    freq_auto: bool = False
    tuner_gain: float = 30.0
    agc: bool = True
    # Software level control for radios without usable hardware AGC.
    # Existing HackRF profiles default to automatic adjustment.
    auto_gain: Optional[bool] = None
    lna_gain: Optional[int] = None    # HackRF IF: 0..40 dB, steps of 8
    vga_gain: Optional[int] = None    # HackRF baseband: 0..62 dB, steps of 2
    amp: Optional[bool] = None       # HackRF RF amplifier (independent of bias tee)
    bias_tee: bool = False
    gain_element: str = "TUNER"       # SoapySDR gain element; "" => overall gain
    stream_args: Optional[str] = None  # None => this driver's default (see above)
    # RX port. None leaves whatever the driver selects, which is the only
    # sensible default: single-input devices like RTL-SDR have nothing to pick,
    # while a B210 exposes TX/RX and RX2 and defaults to RX2.
    antenna: Optional[str] = None
    # Analog front-end bandwidth in Hz. None asks for the driver-aware default
    # (see above); 0 explicitly leaves whatever the device came up with.
    bandwidth: Optional[float] = None

    def __post_init__(self):
        if self.driver == "hackrf":
            self.resolved_hackrf_gains()  # Reject unsupported steps before opening USB.

    def resolved_hackrf_gains(self) -> HackRFGains:
        legacy_gain = self.tuner_gain
        if legacy_gain == 30:  # Same driver-aware default as load_config.
            legacy_gain = DRIVER_DEFAULT_GAIN["hackrf"]
        defaults = HackRFGains.from_total(legacy_gain)
        return HackRFGains(
            defaults.lna if self.lna_gain is None else self.lna_gain,
            defaults.vga if self.vga_gain is None else self.vga_gain,
            defaults.amp if self.amp is None else self.amp,
        )

    def device_string(self) -> str:
        """Build the SoapySDR device string.

        ``device_args`` is appended verbatim so a specific unit can be picked
        out of several identical ones (``serial=...``) or a driver can be told
        what it is talking to (``type=b200``).
        """
        device = f"driver={self.driver}"
        if self.device_args:
            device = f"{device},{self.device_args}"
        return device

    def resolved_auto_gain(self) -> bool:
        return self.auto_gain if self.auto_gain is not None else self.driver == "hackrf"

    def resolved_stream_args(self) -> str:
        """Stream args actually handed to SoapySDR.

        An explicit setting always wins, including an empty string, which is
        how a user suppresses a driver default.
        """
        if self.stream_args is not None:
            return self.stream_args
        return DRIVER_DEFAULT_STREAM_ARGS.get(self.driver, "")

    def resolved_freq_err_offset(self) -> float:
        """Frequency error correction actually applied, in Hz."""
        if self.freq_err_offset is not None:
            return self.freq_err_offset
        return DRIVER_DEFAULT_FREQ_ERR_OFFSET.get(self.driver, 0.0)

    def tuned_freq(self) -> float:
        """The frequency the SDR is actually told to tune to."""
        return self.center_freq + self.freq_offset + self.resolved_freq_err_offset()

    def resolved_bandwidth(self) -> Optional[float]:
        """Analog bandwidth to request, or None to leave the device alone."""
        if self.bandwidth is not None:
            return self.bandwidth or None
        if self.driver in DRIVERS_WITH_AUTOMATIC_BANDWIDTH:
            return None
        # Matching the sample rate keeps the whole digitised span usable while
        # filtering out everything that would alias into it.
        return self.sample_rate


@dataclass(frozen=True)
class ChannelizerConfig:
    """Channelizer geometry. Spacing is fixed by the protocol; the rest tune
    how much margin the PFB has and the per-channel demod rate."""

    channel_spacing: int = CHANNEL_SPACING_HZ
    num_channels: int = DEFAULT_NUM_CHANNELS
    pfb_num_channels: int = 48        # >= num_channels; sets the pre-PFB rate
    resamp2_interp: int = 10          # per-channel upsample before demod


@dataclass(frozen=True)
class DemodConfig:
    """Per-channel demodulation settings that depend on signal level.

    The squelch compares absolute channel power against a threshold, but how
    much power a given field strength turns into depends entirely on the SDR's
    gain and scaling -- the same signal that sits at -25 dB on one radio sits
    at -40 dB on another. A fixed threshold is therefore no more portable than
    a fixed frequency correction, and it fails the same silent way: the
    flowgraph runs, the squelch mutes every channel, and nothing decodes.
    """

    squelch_threshold: float = -25.0   # dB, historical RTL-SDR value
    squelch_alpha: float = 1.0


@dataclass(frozen=True)
class BackendConfig:
    sdr: SdrConfig = SdrConfig()
    channelizer: ChannelizerConfig = ChannelizerConfig()
    demod: DemodConfig = DemodConfig()


@dataclass(frozen=True)
class DerivedRates:
    """Everything the flowgraph needs that used to be hard-coded constants."""

    resamp1_interp: int
    resamp1_decim: int
    samp_rate_post_resamp1: float
    pfb_num_channels: int
    samp_rate_post_pfb: float
    resamp2_interp: int
    resamp2_decim: int
    demod_samp_rate: float
    channel_map: list[int]
    # The stage-1 ratio is a rational approximation, so the rate actually
    # reaching the channelizer can miss the 6.25 kHz raster. Anything but a
    # tiny error mistunes every channel, which looks like a dead receiver
    # rather than a configuration mistake, so it is reported explicitly.
    bin_width_error_hz: float = 0.0


def build_channel_map(pfb_num_channels: int, num_channels: int) -> list[int]:
    """Map flowgraph channel ports to PFB bins, then append unused bins.

    Channels below centre land in the top FFT bins (negative frequencies),
    the centre channel is the DC bin, and channels above centre take the low
    positive bins. Any remaining bins are appended so the caller can attach
    null sinks. For pfb=48, num=30 this reproduces the original hand-written
    map (33..47, 0, 1..14, then 15..32).
    """
    if pfb_num_channels < num_channels:
        raise ValueError(
            f"pfb_num_channels ({pfb_num_channels}) must be >= "
            f"num_channels ({num_channels})"
        )

    neg_count = num_channels // 2
    pos_count = num_channels - neg_count - 1

    mapping = list(range(pfb_num_channels - neg_count, pfb_num_channels))
    mapping.append(0)
    mapping.extend(range(1, pos_count + 1))

    used = set(mapping)
    mapping.extend(bin_index for bin_index in range(pfb_num_channels) if bin_index not in used)
    return mapping


def derive_rates(sdr: SdrConfig, channelizer: ChannelizerConfig) -> DerivedRates:
    """Compute resampling / channelizer rates from the SDR sample rate.

    Invariant: PFB output bin width == channel spacing (6.25 kHz). The rate
    feeding the channelizer is therefore ``pfb_num_channels * channel_spacing``,
    and the stage-1 resampler ratio is whatever gets there from the input rate.
    """
    if channelizer.pfb_num_channels < channelizer.num_channels:
        raise ValueError(
            f"pfb_num_channels ({channelizer.pfb_num_channels}) must be >= "
            f"num_channels ({channelizer.num_channels})"
        )
    if sdr.sample_rate <= 0:
        raise ValueError(f"sample_rate must be positive, got {sdr.sample_rate}")

    samp_rate_post_resamp1 = channelizer.pfb_num_channels * channelizer.channel_spacing

    ratio = Fraction(
        int(round(samp_rate_post_resamp1)),
        int(round(sdr.sample_rate)),
    ).limit_denominator(_MAX_RESAMP_DENOMINATOR)
    resamp1_interp = ratio.numerator
    resamp1_decim = ratio.denominator

    samp_rate_post_pfb = samp_rate_post_resamp1 / channelizer.pfb_num_channels
    demod_samp_rate = samp_rate_post_pfb * channelizer.resamp2_interp

    achieved_post_resamp1 = sdr.sample_rate * resamp1_interp / resamp1_decim
    achieved_bin_width = achieved_post_resamp1 / channelizer.pfb_num_channels
    bin_width_error_hz = achieved_bin_width - channelizer.channel_spacing

    return DerivedRates(
        resamp1_interp=resamp1_interp,
        resamp1_decim=resamp1_decim,
        samp_rate_post_resamp1=float(samp_rate_post_resamp1),
        pfb_num_channels=channelizer.pfb_num_channels,
        samp_rate_post_pfb=float(samp_rate_post_pfb),
        resamp2_interp=channelizer.resamp2_interp,
        resamp2_decim=1,
        demod_samp_rate=float(demod_samp_rate),
        channel_map=build_channel_map(
            channelizer.pfb_num_channels, channelizer.num_channels
        ),
        bin_width_error_hz=bin_width_error_hz,
    )


def nearest_sample_rates(
    available: "list[float]",
    near: float,
    count: int = 5,
) -> list[float]:
    """The device's supported rates closest to ``near``.

    Only proximity is used. The stage-1 ratio is a bounded-denominator
    approximation, and measuring it across the plausible rate range puts the
    worst raster error near 0.1 Hz on a 6250 Hz bin, so there is no second
    criterion worth filtering on.
    """
    return sorted(
        (rate for rate in available if rate > 0),
        key=lambda rate: (abs(rate - near), rate),
    )[:count]


# ---------------------------------------------------------------------------
# Loading: defaults -> TOML file -> CLI overrides
# ---------------------------------------------------------------------------
def _coerce_section(cls, defaults, values: Mapping[str, Any]):
    known = {f.name for f in defaults.__dataclass_fields__.values()}
    unknown = set(values) - known
    if unknown:
        raise ValueError(
            f"Unknown {cls.__name__} keys in config: {sorted(unknown)}"
        )
    return replace(defaults, **{key: values[key] for key in values})


def load_config_file(path: os.PathLike | str) -> BackendConfig:
    """Load a TOML config file into a :class:`BackendConfig`.

    Missing sections/keys fall back to the RTL-SDR defaults. Unknown keys are
    rejected so typos surface immediately instead of being silently ignored.
    """
    if tomllib is None:  # pragma: no cover
        raise RuntimeError(
            "Reading a TOML config requires Python 3.11+ (tomllib). "
            "Use CLI overrides instead, or upgrade Python."
        )

    with open(path, "rb") as config_file:
        raw = tomllib.load(config_file)

    unknown_sections = set(raw) - {"sdr", "channelizer", "demod"}
    if unknown_sections:
        raise ValueError(f"Unknown config sections: {sorted(unknown_sections)}")

    return BackendConfig(
        sdr=_coerce_section(SdrConfig, SdrConfig(), raw.get("sdr", {})),
        channelizer=_coerce_section(
            ChannelizerConfig, ChannelizerConfig(), raw.get("channelizer", {})
        ),
        demod=_coerce_section(DemodConfig, DemodConfig(), raw.get("demod", {})),
    )


def add_config_arguments(parser) -> None:
    """Register the backend's CLI options on an argparse parser."""
    parser.add_argument(
        "--config",
        default=os.environ.get(CONFIG_ENV_VAR),
        help=(
            "Path to a TOML backend config. Defaults to the "
            f"{CONFIG_ENV_VAR} environment variable if set."
        ),
    )
    parser.add_argument("--driver", help="SoapySDR driver key (e.g. rtlsdr, uhd, hackrf).")
    parser.add_argument(
        "--device-args",
        help='Extra SoapySDR device selection appended to the device string, '
        'e.g. "serial=00000001" or "type=b200". Use this to pick one of '
        "several identical SDRs.",
    )
    parser.add_argument(
        "--stream-args",
        help="SoapySDR stream arguments. Defaults to the driver's own default ("
        + ", ".join(f"{k}: {v}" for k, v in DRIVER_DEFAULT_STREAM_ARGS.items())
        + "; none for other drivers). Pass an empty string to send none. "
        "Unsupported args make the device refuse to open.",
    )
    parser.add_argument("--sample-rate", type=float, help="SDR sample rate in Hz.")
    parser.add_argument("--freq", type=float, help="Center frequency in Hz.")
    parser.add_argument("--gain", type=float, help="Tuner gain (used when AGC is off).")
    parser.add_argument("--gain-element", help='SoapySDR gain element name ("" for overall gain).')
    parser.add_argument("--lna-gain", type=int, choices=range(0, 41, 8), help="HackRF LNA gain in dB.")
    parser.add_argument("--vga-gain", type=int, choices=range(0, 63, 2), help="HackRF VGA gain in dB.")
    amp_group = parser.add_mutually_exclusive_group()
    amp_group.add_argument("--amp", dest="amp", action="store_true", default=None, help="Enable HackRF RF amplifier.")
    amp_group.add_argument("--no-amp", dest="amp", action="store_false", default=None, help="Disable HackRF RF amplifier.")
    agc_group = parser.add_mutually_exclusive_group()
    agc_group.add_argument("--agc", dest="agc", action="store_true", default=None, help="Enable hardware AGC.")
    agc_group.add_argument("--no-agc", dest="agc", action="store_false", default=None, help="Disable hardware AGC.")
    auto_group = parser.add_mutually_exclusive_group()
    auto_group.add_argument("--auto-gain", dest="auto_gain", action="store_true", default=None, help="Adjust software gain from wideband IQ level.")
    auto_group.add_argument("--manual-gain", dest="auto_gain", action="store_false", default=None, help="Use fixed gain (HackRF: --lna-gain/--vga-gain/--amp).")
    bias_group = parser.add_mutually_exclusive_group()
    bias_group.add_argument("--bias-tee", dest="bias_tee", action="store_true", default=None, help="Enable bias tee if supported.")
    bias_group.add_argument("--no-bias-tee", dest="bias_tee", action="store_false", default=None, help="Disable bias tee.")
    freq_auto_group = parser.add_mutually_exclusive_group()
    freq_auto_group.add_argument("--freq-auto", dest="freq_auto", action="store_true", default=None,
                                 help="Retune automatically to follow the measured receiver frequency error.")
    freq_auto_group.add_argument("--no-freq-auto", dest="freq_auto", action="store_false", default=None,
                                 help="Keep the frequency correction fixed.")
    parser.add_argument(
        "--bandwidth",
        type=float,
        help="Analog front-end bandwidth in Hz. Defaults to the sample rate on "
        "devices that do not track it themselves (RTL-SDR does). Pass 0 to "
        "leave the device's own setting alone.",
    )
    parser.add_argument(
        "--antenna",
        help="RX antenna port to select (e.g. RX2 or TX/RX on a USRP B210). "
        "Omit to leave the driver's own default. Devices with a single input "
        "ignore this.",
    )
    parser.add_argument(
        "--freq-err-offset", type=float,
        help="Per-device frequency error correction in Hz, added to the tuned "
        "frequency. This is calibration for one specific radio: it is applied "
        "only to the driver it was measured on (rtlsdr: -340), and any other "
        "device starts from 0 and must be measured for itself. Pass 0 to "
        "disable it explicitly.",
    )
    parser.add_argument("--freq-correction", type=float, help="Frequency correction in ppm.")
    parser.add_argument("--pfb-channels", type=int, help="Number of PFB channels (>= num_channels).")
    parser.add_argument(
        "--band", choices=list(BANDS_BY_KEY),
        help="Receive band: retunes to that band's raster ("
        + ", ".join(f"{band.key}: {band.name}" for band in BANDS)
        + "). The profile's freq_err_offset is taken as measured at the "
        "profile's own center and scaled to the band (a crystal error is ppm).",
    )
    parser.add_argument(
        "--squelch", type=float,
        help="Per-channel squelch threshold in dB (default -25). This is an "
        "absolute level, so it depends on the SDR's gain and scaling and must "
        "be checked on an unfamiliar radio: too high and every channel is "
        "muted with no indication why.",
    )


def apply_cli_overrides(config: BackendConfig, args) -> BackendConfig:
    """Return a new config with any provided CLI overrides applied."""
    sdr_overrides: dict[str, Any] = {}
    for attr, field_name in (
        ("driver", "driver"),
        ("device_args", "device_args"),
        ("stream_args", "stream_args"),
        ("sample_rate", "sample_rate"),
        ("freq", "center_freq"),
        ("gain", "tuner_gain"),
        ("gain_element", "gain_element"),
        ("antenna", "antenna"),
        ("bandwidth", "bandwidth"),
        ("agc", "agc"),
        ("auto_gain", "auto_gain"),
        ("lna_gain", "lna_gain"),
        ("vga_gain", "vga_gain"),
        ("amp", "amp"),
        ("bias_tee", "bias_tee"),
        ("freq_err_offset", "freq_err_offset"),
        ("freq_correction", "freq_correction"),
        ("freq_auto", "freq_auto"),
    ):
        value = getattr(args, attr, None)
        if value is not None:
            sdr_overrides[field_name] = value

    demod_overrides: dict[str, Any] = {}
    squelch = getattr(args, "squelch", None)
    if squelch is not None:
        demod_overrides["squelch_threshold"] = squelch

    channelizer_overrides: dict[str, Any] = {}
    pfb_channels = getattr(args, "pfb_channels", None)
    if pfb_channels is not None:
        channelizer_overrides["pfb_num_channels"] = pfb_channels

    config = BackendConfig(
        sdr=replace(config.sdr, **sdr_overrides) if sdr_overrides else config.sdr,
        channelizer=replace(config.channelizer, **channelizer_overrides)
        if channelizer_overrides
        else config.channelizer,
        demod=replace(config.demod, **demod_overrides)
        if demod_overrides
        else config.demod,
    )
    band = getattr(args, "band", None)
    return apply_band(config, band) if band else config


def band_freq_scale(config: BackendConfig, band_key: Optional[str]) -> float:
    """Factor from the config's own frequency to ``band_key``'s center.

    Hz of crystal error measured at one frequency become this many times
    as many Hz at the band (1.0 for no band).
    """
    reference = config.sdr.center_freq + config.sdr.freq_offset
    if not band_key or reference <= 0:
        return 1.0
    return (BANDS_BY_KEY[band_key].center_hz + config.sdr.freq_offset) / reference


def apply_band(config: BackendConfig, band_key: str) -> BackendConfig:
    """Retune ``config`` to a receive band from :data:`BANDS`.

    The center and channel count come from the band; the PFB keeps the
    profile's bin count when it is wide enough. The calibration stays in ppm:
    an RTL-SDR's +1500 Hz at 351 MHz is about +2000 Hz at 467 MHz and +660 Hz
    at 154 MHz, and missing that by 500 Hz is already a large DC error on the
    symbol stream.
    """
    band = BANDS_BY_KEY[band_key]
    scale = band_freq_scale(config, band_key)
    sdr = replace(config.sdr, center_freq=float(band.center_hz),
                  freq_err_offset=config.sdr.resolved_freq_err_offset() * scale)
    pfb = config.channelizer.pfb_num_channels
    if pfb < band.count:
        pfb = FULL_351_PFB_CHANNELS
    channelizer = replace(config.channelizer, channel_spacing=FULL_351_SPACING_HZ,
                          num_channels=band.count, pfb_num_channels=pfb)
    return replace(config, sdr=sdr, channelizer=channelizer)


def load_config(args=None) -> BackendConfig:
    """Resolve the effective config: defaults, then TOML file, then CLI."""
    config = BackendConfig()

    config_path: Optional[str] = getattr(args, "config", None) if args is not None else None
    if config_path:
        if not Path(config_path).exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")
        config = load_config_file(config_path)

    if args is not None:
        config = apply_cli_overrides(config, args)

    # Driver-aware default sample rate: when nobody set one (still the generic
    # default), use a rate this driver can actually serve -- e.g. HackRF's 2 MHz
    # floor instead of the 1.2 MHz RTL-SDR default, which HackRF would reject.
    if config.sdr.sample_rate == SdrConfig().sample_rate:
        driver_rate = DRIVER_DEFAULT_SAMPLE_RATE.get(config.sdr.driver)
        if driver_rate:
            config = replace(config, sdr=replace(config.sdr, sample_rate=driver_rate))

    # Likewise a driver-aware default gain when the user left the generic one.
    if config.sdr.tuner_gain == SdrConfig().tuner_gain:
        driver_gain = DRIVER_DEFAULT_GAIN.get(config.sdr.driver)
        if driver_gain is not None:
            config = replace(config, sdr=replace(config.sdr, tuner_gain=driver_gain))

    return config
