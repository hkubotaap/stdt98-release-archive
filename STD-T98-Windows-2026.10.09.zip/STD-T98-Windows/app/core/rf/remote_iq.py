"""Authenticated TCP broadcast of post-resampler IQ with selectable precision.

The RF producer never waits for the network. Each client has a bounded queue;
an overrun disconnects that client instead of silently skipping sample buffers.
"""
from dataclasses import asdict
from collections import deque
import hashlib
import hmac
import json
import math
import queue
import secrets
import socket
import struct
import sys
import threading
import time
import numpy as np

from core.rf.backend_config import BackendConfig, SdrConfig, ChannelizerConfig, DemodConfig, derive_rates

MAGIC = b"T98IQ\x00\x01\x00"
HEADER = struct.Struct("!cIQ")
BLOCK_BYTES = 65536
MAX_METADATA = 8192
DEFAULT_PORT = 9850
TOKEN_ENV = "STD_T98_RF_TOKEN"
FORMATS = {"cf32-le": 8, "cs16-scaled-le": 4}
# Demodulated sync-word frames (FramePacket bytes) instead of wideband IQ.
FRAME_FORMAT = "frames-v1"
MAX_FRAME_BYTES = 4096
KEEPALIVE_SECONDS = 1.0
IQ_SCALE = struct.Struct("<f")


def encode_iq(data, wire_format):
    if wire_format == "cf32-le":
        return bytes(data)
    if wire_format != "cs16-scaled-le":
        raise ValueError("Unsupported remote IQ format")
    values = np.frombuffer(data, dtype="<f4")
    if not np.all(np.isfinite(values)):
        raise ValueError("Non-finite RF IQ samples")
    peak = float(np.max(np.abs(values))) if len(values) else 0
    # Per-packet scaling preserves receiver gain and avoids fixed full-scale
    # clipping, including filter overshoot and very small input amplitudes.
    scale = np.float32(max(peak / 32767, np.finfo(np.float32).tiny) if peak else 1)
    quantized = np.clip(np.rint(values / scale), -32767, 32767).astype("<i2")
    return IQ_SCALE.pack(float(scale)) + quantized.tobytes()


def decode_iq(data, wire_format):
    if wire_format == "cf32-le":
        return data
    if wire_format != "cs16-scaled-le" or len(data) <= IQ_SCALE.size or (len(data) - IQ_SCALE.size) % 4:
        raise ValueError("Invalid compact RF IQ packet")
    scale, = IQ_SCALE.unpack_from(data)
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError("Invalid RF IQ scale")
    values = np.frombuffer(data, dtype="<i2", offset=IQ_SCALE.size).astype("<f4")
    values *= np.float32(scale)
    if not np.all(np.isfinite(values)):
        raise ValueError("Non-finite decoded RF IQ samples")
    return values.tobytes()


def require_token(token):
    if not isinstance(token, str) or len(token.encode("utf-8")) < 16:
        raise ValueError("RF access token must contain at least 16 bytes")
    return token.encode("utf-8")


def recv_exact(sock, count):
    result = bytearray(count)
    view = memoryview(result)
    offset = 0
    while offset < count:
        received = sock.recv_into(view[offset:])
        if not received:
            raise ConnectionError("RF IQ connection closed")
        offset += received
    return bytes(result)


def stream_metadata(config, wire_format="cf32-le"):
    if wire_format not in FORMATS and wire_format != FRAME_FORMAT:
        raise ValueError("Unsupported remote IQ format")
    return {"format": wire_format, "sample_rate": derive_rates(config.sdr, config.channelizer).samp_rate_post_resamp1,
            "center_freq": config.sdr.center_freq + config.sdr.freq_offset,
            "channelizer": asdict(config.channelizer), "demod": asdict(config.demod)}


def client_config(metadata, demod=None):
    if (not isinstance(metadata, dict) or not isinstance(metadata.get("format"), str)
            or (metadata["format"] not in FORMATS and metadata["format"] != FRAME_FORMAT)):
        raise ValueError("Unsupported remote IQ format")
    rate = metadata.get("sample_rate")
    frequency = metadata.get("center_freq")
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0
           for v in (rate, frequency)):
        raise ValueError("Invalid remote IQ rate or frequency")
    geometry = metadata.get("channelizer", {})
    if not isinstance(geometry, dict) or set(geometry) != set(ChannelizerConfig.__dataclass_fields__):
        raise ValueError("Invalid remote channelizer metadata")
    for name in ("num_channels", "pfb_num_channels", "resamp2_interp", "channel_spacing"):
        value = geometry[name]
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("Remote channelizer values must be integers")
    channelizer = ChannelizerConfig(**geometry)
    if not (1 <= channelizer.num_channels <= 256 and
            channelizer.num_channels <= channelizer.pfb_num_channels <= 512 and
            1 <= channelizer.resamp2_interp <= 32 and channelizer.channel_spacing == 6250):
        raise ValueError("Remote channelizer geometry exceeds supported limits")
    if rate != channelizer.pfb_num_channels * channelizer.channel_spacing:
        raise ValueError("Remote IQ sample rate does not match channelizer geometry")
    if demod is None:
        settings = metadata.get("demod", {})
        if not isinstance(settings, dict) or set(settings) != set(DemodConfig.__dataclass_fields__):
            raise ValueError("Invalid remote demodulation metadata")
        demod = DemodConfig(**settings)
    if not (math.isfinite(demod.squelch_threshold) and -100 <= demod.squelch_threshold <= 0 and
            math.isfinite(demod.squelch_alpha) and 0 < demod.squelch_alpha <= 1):
        raise ValueError("Invalid remote squelch configuration")
    return BackendConfig(SdrConfig(driver="remote", sample_rate=rate, center_freq=frequency,
                                  freq_err_offset=0, agc=False, auto_gain=False), channelizer, demod)


def write_client_profile(path, metadata):
    config = client_config(metadata)
    text = '[sdr]\ndriver = "remote"\nfreq_err_offset = 0\nagc = false\nauto_gain = false\n'
    text += f"sample_rate = {config.sdr.sample_rate}\ncenter_freq = {config.sdr.center_freq}\n"
    for section, values in (("channelizer", asdict(config.channelizer)), ("demod", asdict(config.demod))):
        text += f"\n[{section}]\n" + "".join(f"{key} = {value}\n" for key, value in values.items())
    path.write_text(text, encoding="utf-8")
    return config


def _proof(key, *parts):
    return hmac.new(key, b"".join(parts), hashlib.sha256).digest()


def close_socket(sock):
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except OSError:
        pass
    sock.close()


class IQBuffer:
    """Bound memory by bytes, independently of scheduler packet sizes."""
    def __init__(self, max_bytes):
        self.max_bytes = int(max_bytes)
        self.buffers = deque()
        self.bytes = 0
        self.failure = None
        self.condition = threading.Condition()

    def put_nowait(self, data):
        with self.condition:
            if self.failure is not None:
                raise ConnectionError(self.failure)
            if self.bytes + len(data) > self.max_bytes:
                raise queue.Full
            self.buffers.append(data)
            self.bytes += len(data)
            self.condition.notify()

    def get(self, timeout=None):
        with self.condition:
            if not self.condition.wait_for(lambda: self.buffers or self.failure is not None, timeout):
                raise queue.Empty
            if self.buffers:
                data = self.buffers.popleft()
                self.bytes -= len(data)
                return data
            raise ConnectionError(self.failure)

    def fail(self, reason, discard=False):
        with self.condition:
            self.failure = reason
            if discard:
                self.buffers.clear()
                self.bytes = 0
            self.condition.notify_all()

    def queued_bytes(self):
        with self.condition:
            return self.bytes


class IQClient:
    def __init__(self, host, port, token, metadata_only=False, timeout=5.0, defer_stream=False):
        self.key = require_token(token)
        self.address = (host, int(port))
        self.timeout = timeout
        self.metadata_only = metadata_only
        self.connection_lock = threading.Lock()
        self.closed = threading.Event()
        self.sock = None
        self.next_sample = None
        self.bytes_received = 0
        self.samples_received = 0
        self.sock, self.metadata = self._connect(metadata_only or defer_stream)
        if defer_stream and not metadata_only:
            # No subscription while the 97ch graph is being constructed. The
            # first scheduler read opens the stream using the existing protocol.
            close_socket(self.sock)
            self.sock = None

    def _connect(self, metadata_only):
        sock = socket.create_connection(self.address, timeout=self.timeout)
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            greeting = recv_exact(sock, len(MAGIC) + 32)
            if greeting[:len(MAGIC)] != MAGIC:
                raise ValueError("Unsupported RF server protocol")
            challenge = greeting[len(MAGIC):]
            nonce = secrets.token_bytes(32)
            command = b"M" if metadata_only else b"S"
            sock.sendall(command + nonce + _proof(self.key, MAGIC, challenge, nonce, command))
            kind, size, sequence = HEADER.unpack(recv_exact(sock, HEADER.size))
            if kind != b"M" or not 32 < size <= MAX_METADATA:
                raise ValueError("Invalid RF metadata response")
            payload = recv_exact(sock, size)
            if not hmac.compare_digest(payload[-32:], _proof(self.key, challenge, nonce, payload[:-32])):
                raise PermissionError("RF server authentication failed")
            metadata = json.loads(payload[:-32])
            client_config(metadata)
            return sock, metadata
        except Exception:
            close_socket(sock)
            raise

    def start_stream(self):
        with self.connection_lock:
            if self.closed.is_set():
                raise ConnectionError("RF IQ client closed")
            if self.metadata_only:
                raise ValueError("Metadata-only RF connection cannot receive IQ")
            if self.sock is None:
                sock, metadata = self._connect(False)
                if self.closed.is_set() or metadata != self.metadata:
                    close_socket(sock)
                    if self.closed.is_set():
                        raise ConnectionError("RF IQ client closed")
                    raise ValueError("RF server configuration changed while preparing the receiver; reconnect")
                self.sock = sock

    def receive(self):
        if self.sock is None:
            self.start_stream()
        kind, size, sequence = HEADER.unpack(recv_exact(self.sock, HEADER.size))
        if kind == b"E" and 0 < size <= 1024:
            raise ConnectionError(recv_exact(self.sock, size).decode("utf-8", errors="replace"))
        wire_format = getattr(self, "metadata", {}).get("format", "cf32-le")
        sample_bytes = FORMATS[wire_format]
        scale_bytes = IQ_SCALE.size if wire_format == "cs16-scaled-le" else 0
        if kind != b"I" or not scale_bytes < size <= BLOCK_BYTES or (size - scale_bytes) % sample_bytes:
            raise ValueError("Invalid RF IQ packet")
        if self.next_sample is not None and sequence != self.next_sample:
            raise ValueError("RF IQ sample discontinuity")
        data = decode_iq(recv_exact(self.sock, size), wire_format)
        count = (size - scale_bytes) // sample_bytes
        self.next_sample = sequence + count
        self.samples_received = getattr(self, "samples_received", 0) + count
        self.bytes_received += size
        return data

    def receive_frame(self):
        """Next FramePacket payload from a frame server; keepalives are consumed."""
        if self.sock is None:
            self.start_stream()
        while True:
            kind, size, sequence = HEADER.unpack(recv_exact(self.sock, HEADER.size))
            if kind == b"E" and 0 < size <= 1024:
                raise ConnectionError(recv_exact(self.sock, size).decode("utf-8", errors="replace"))
            if kind == b"K" and size == 0:
                continue
            if kind != b"F" or not 0 < size <= MAX_FRAME_BYTES:
                raise ValueError("Invalid RF frame packet")
            if self.next_sample is not None and sequence != self.next_sample:
                raise ValueError("RF frame discontinuity")
            data = recv_exact(self.sock, size)
            self.next_sample = sequence + 1
            self.bytes_received += size
            return data

    def close(self):
        self.closed.set()
        with self.connection_lock:
            if self.sock is not None:
                close_socket(self.sock)


def fetch_metadata(host, port, token):
    client = IQClient(host, port, token, metadata_only=True)
    try:
        return client.metadata
    finally:
        client.close()


class IQServer:
    def __init__(self, host, port, metadata, token, max_clients=4, queue_blocks=16):
        client_config(metadata)
        self.key = require_token(token)
        self.metadata = dict(metadata)
        self.max_clients = max_clients
        self.queue_blocks = queue_blocks
        self.lock = threading.Lock()
        self.clients = {}
        self.pending = set()
        self.closing = set()
        self.stopped = threading.Event()
        self.sample_index = 0
        self.bytes_sent = 0
        self.overruns = 0
        self.last_disconnect = ""
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.listener.bind((host, int(port)))
            self.listener.listen(max_clients)
            self.listener.settimeout(.25)
        except Exception:
            self.listener.close()
            raise
        self.port = self.listener.getsockname()[1]
        self.thread = threading.Thread(target=self._accept, daemon=True)
        self.thread.start()

    def _accept(self):
        while not self.stopped.is_set():
            try:
                sock, address = self.listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with self.lock:
                if len(self.pending) + len(self.clients) + len(self.closing) >= self.max_clients:
                    sock.close()
                    continue
                self.pending.add(sock)
            threading.Thread(target=self._serve, args=(sock,), daemon=True).start()

    def _serve(self, sock):
        command = None
        try:
            sock.settimeout(3)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, BLOCK_BYTES * 2)
            challenge = secrets.token_bytes(32)
            sock.sendall(MAGIC + challenge)
            request = recv_exact(sock, 65)
            command, nonce, proof = request[:1], request[1:33], request[33:]
            if command not in (b"M", b"S") or not hmac.compare_digest(proof, _proof(self.key, MAGIC, challenge, nonce, command)):
                return
            raw = json.dumps(self.metadata, separators=(",", ":"), allow_nan=False).encode("utf-8")
            payload = raw + _proof(self.key, challenge, nonce, raw)
            sock.sendall(HEADER.pack(b"M", len(payload), 0) + payload)
            if command == b"M":
                return
            buffers = IQBuffer(self.queue_blocks * (BLOCK_BYTES + HEADER.size))
            with self.lock:
                if self.stopped.is_set():
                    return
                self.pending.discard(sock)
                self.clients[sock] = buffers
            frames = self.metadata["format"] == FRAME_FORMAT
            last_sent = time.monotonic()
            while not self.stopped.is_set():
                try:
                    packet = buffers.get(timeout=.25)
                except queue.Empty:
                    # Also notice a peer that disconnected before the next IQ.
                    import select
                    readable, _, _ = select.select([sock], [], [], 0)
                    if readable and not sock.recv(1, socket.MSG_PEEK):
                        break
                    # Frames stop while every channel is idle; keep the
                    # client's 5 s receive timeout for real outages only.
                    if frames and time.monotonic() - last_sent >= KEEPALIVE_SECONDS:
                        sock.sendall(HEADER.pack(b"K", 0, 0))
                        last_sent = time.monotonic()
                    continue
                except ConnectionError as exc:
                    # The sending thread is the only writer on this socket;
                    # send the reason at a packet boundary before closing.
                    reason = str(exc).encode("utf-8")[:1024]
                    sock.sendall(HEADER.pack(b"E", len(reason), self.sample_index) + reason)
                    break
                sock.sendall(packet)
                last_sent = time.monotonic()
                with self.lock:
                    self.bytes_sent += len(packet) - HEADER.size
        except (OSError, ValueError, ConnectionError) as exc:
            if command == b"S" and not self.stopped.is_set():
                with self.lock:
                    self.last_disconnect = f"RF IQ socket error: {exc}"
                print(self.last_disconnect, file=sys.stderr, flush=True)
        finally:
            with self.lock:
                self.pending.discard(sock)
                self.clients.pop(sock, None)
                self.closing.discard(sock)
            close_socket(sock)

    def publish(self, data):
        """Called by the RF scheduler; bounded copies, never socket writes."""
        view = memoryview(data).cast("B")
        if len(view) % 8:
            raise ValueError("IQ buffers must contain complete complex64 samples")
        with self.lock:
            if not self.clients:
                self.sample_index += len(view) // 8
                return  # No encoding, buffering or history while nobody listens.
        for offset in range(0, len(view), BLOCK_BYTES):
            chunk = view[offset:offset + BLOCK_BYTES]
            payload = encode_iq(chunk, self.metadata["format"])
            packet = HEADER.pack(b"I", len(payload), self.sample_index) + payload
            self.sample_index += len(chunk) // 8
            self._broadcast(packet)

    def send(self, payload):
        """Frame-mode transport for the sync-word correlator (FramePacket bytes)."""
        if not 0 < len(payload) <= MAX_FRAME_BYTES:
            raise ValueError("Invalid RF frame size")
        with self.lock:
            if not self.clients:
                return False
            packet = HEADER.pack(b"F", len(payload), self.sample_index) + payload
            self.sample_index += 1
        return self._broadcast(packet)

    def _broadcast(self, packet):
        dropped = []
        with self.lock:
            for sock, buffers in list(self.clients.items()):
                try:
                    buffers.put_nowait(packet)
                except queue.Full:
                    self.clients.pop(sock, None)
                    self.overruns += 1
                    self.last_disconnect = ("RF IQ server send buffer full: "
                        "client/network cannot keep up "
                        f"(limit {self.queue_blocks * (BLOCK_BYTES + HEADER.size)} bytes)")
                    self.closing.add(sock)
                    buffers.fail(self.last_disconnect, discard=True)
                    dropped.append(sock)
            delivered = bool(self.clients)
        if dropped:
            print(f"Remote IQ client disconnected: {self.last_disconnect}", file=sys.stderr, flush=True)
        return delivered

    def snapshot(self):
        with self.lock:
            return {"clients": len(self.clients), "bytes": self.bytes_sent, "overruns": self.overruns,
                    "last_disconnect": self.last_disconnect}

    def close(self):
        self.stopped.set()
        self.listener.close()
        with self.lock:
            sockets = list(self.clients) + list(self.pending) + list(self.closing)
        for sock in sockets:
            close_socket(sock)
        self.thread.join(1)
