"""STD-T98 channel plans: the 97-channel 351 MHz plan and the other receive bands.

The SDR and IPC use a contiguous, one-based slot id.  The published channel
numbers are not contiguous in frequency order, and the airborne 3S/3U numbers
overlap the ground 3R numbers, so the group is part of the display label.
"""

from dataclasses import dataclass


FULL_351_FIRST_HZ = 351_031_250
FULL_351_CENTER_HZ = 351_331_250
FULL_351_SPACING_HZ = 6_250
FULL_351_CHANNEL_COUNT = 97
FULL_351_PFB_CHANNELS = 128


@dataclass(frozen=True)
class ChannelInfo:
    slot_id: int
    group: str
    channel_number: int
    frequency_hz: int
    note: str = ""
    usage: str = ""   # 地上用 / 上空用
    era: str = ""     # 従来 / 増波

    @property
    def block(self) -> str:
        """Block description, e.g. "上空用・増波"."""
        return "・".join(part for part in (self.usage, self.era) if part)

    @property
    def label(self) -> str:
        return f"{self.group} CH{self.channel_number:02d}"

    @property
    def display(self) -> str:
        """Label plus the published note, e.g. "3R CH15（呼出）"."""
        return f"{self.label}（{self.note}）" if self.note else self.label


def full_351_channels() -> tuple[ChannelInfo, ...]:
    """Return 3T/3U/3S/3R/3T slots from 351.03125 to 351.63125 MHz."""
    # Blocks in frequency order: (group, first ch, last ch, usage, era).
    sections = (
        ("3T", 71, 82, "地上用", "増波"),   # 351.03125–351.10000 MHz, 12 ch
        ("3U", 6, 15, "上空用", "増波"),    # 351.10625–351.16250 MHz, 10 ch
        ("3S", 1, 5, "上空用", "従来"),     # 351.16875–351.19375 MHz,  5 ch
        ("3R", 1, 30, "地上用", "従来"),    # 351.20000–351.38125 MHz, 30 ch
        ("3T", 31, 70, "地上用", "増波"),   # 351.38750–351.63125 MHz, 40 ch
    )
    # Published notes per (group, channel): 3R CH15 is the calling channel.
    notes = {("3R", 15): "呼出"}
    channels = []
    for group, first, last, usage, era in sections:
        for number in range(first, last + 1):
            slot_id = len(channels) + 1
            channels.append(ChannelInfo(
                slot_id=slot_id,
                group=group,
                channel_number=number,
                frequency_hz=FULL_351_FIRST_HZ + (slot_id - 1) * FULL_351_SPACING_HZ,
                note=notes.get((group, number), ""),
                usage=usage,
                era=era,
            ))
    return tuple(channels)


FULL_351_CHANNELS = full_351_channels()


def uses_full_351_plan(center_freq: float, spacing: int, num_channels: int) -> bool:
    return (
        num_channels == FULL_351_CHANNEL_COUNT
        and spacing == FULL_351_SPACING_HZ
        and abs(center_freq - FULL_351_CENTER_HZ) < 1
    )


FULL_351_BY_FREQUENCY = {info.frequency_hz: info for info in FULL_351_CHANNELS}


# ---------------------------------------------------------------------------
# Receive bands. Every band below is STD-T98 digital simple radio on the same
# 6.25 kHz raster, so the decoder is identical; only the tuning changes. Each
# fits one channelizer span (FULL_351_PFB_CHANNELS bins = 800 kHz), so a band
# is a center frequency plus a channel count.
#
#   351 MHz  registered stations (登録局)   351.03125–351.63125 MHz, 97 ch
#   467 MHz  licensed stations (免許局)     467.00000–467.40000 MHz, 65 ch
#   465/468  licensed repeater pairs        465.096875–465.153125 /
#            (2023 増波, 二周波半複信)        468.796875–468.853125 MHz, 10 pairs;
#            either group may be the repeater's transmit side.
#   154 MHz  licensed stations (免許局)     154.44375–154.55625 MHz (19 ch voice)
#                                          154.56250–154.61250 MHz (9 ch data)
#
# The 467/465/468/154 channel numbers are slot order from the low edge, not a
# published numbering (radio makers number them differently).
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Band:
    key: str
    name: str
    channels: tuple[ChannelInfo, ...]

    @property
    def count(self) -> int:
        return len(self.channels)

    @property
    def center_hz(self) -> int:
        """Center of the raster: slot n//2 sits on the DC bin (see build_channel_map)."""
        return self.channels[self.count // 2].frequency_hz


def _uniform_channels(group, first_hz, count, usage, notes=None) -> tuple[ChannelInfo, ...]:
    notes = notes or {}
    return tuple(ChannelInfo(
        slot_id=index + 1,
        group=group,
        channel_number=index + 1,
        frequency_hz=first_hz + index * FULL_351_SPACING_HZ,
        note=notes.get(index + 1, ""),
        usage=usage,
    ) for index in range(count))


BANDS = (
    Band("351", "351MHz 登録局（97ch）", FULL_351_CHANNELS),
    Band("467", "467MHz 免許局（65ch）", _uniform_channels("467", 467_000_000, 65, "免許局")),
    Band("468", "468MHz 免許局 中継用（10ch）", _uniform_channels("468中継", 468_796_875, 10, "免許局・中継用")),
    Band("465", "465MHz 免許局 中継用（10ch）", _uniform_channels("465中継", 465_096_875, 10, "免許局・中継用")),
    Band("154", "154MHz 免許局（28ch）", _uniform_channels(
        "154", 154_443_750, 28, "免許局", {number: "データ" for number in range(20, 29)})),
)
BANDS_BY_KEY = {band.key: band for band in BANDS}

PLAN_BY_FREQUENCY = {info.frequency_hz: info for band in BANDS for info in band.channels}


def call_stat_verified(frequency_hz) -> bool:
    """Whether SACCH CallStat (plain/secret) is known to mean the same here.

    Its meaning was established on 351 MHz registered-station radios. On the
    licensed bands a call marked plain has been seen decoding to non-speech
    (467.1125 MHz, 2026-10-05), so there it is shown as unconfirmed.
    """
    info = PLAN_BY_FREQUENCY.get(round(frequency_hz)) if frequency_hz else None
    return not (info is not None and info.usage.startswith("免許局"))


def band_for_raster(center_freq: float, spacing: int, num_channels: int):
    """The band whose published raster this geometry is, or None."""
    if spacing != FULL_351_SPACING_HZ:
        return None
    return next((band for band in BANDS
                 if band.count == num_channels and abs(center_freq - band.center_hz) < 1), None)


def channel_labels(frequencies) -> dict[int, str]:
    """Display labels for a ``{slot_id: frequency_hz}`` raster, matching the channel cards.

    A known band's raster uses its group/channel labels; any other raster
    keeps the contiguous slot number.
    """
    slots = {int(slot): int(freq) for slot, freq in frequencies.items()}
    for band in BANDS:
        if len(slots) == band.count and all(
                slots.get(info.slot_id) == info.frequency_hz for info in band.channels):
            return {info.slot_id: info.display for info in band.channels}
    return {slot: f"CH{slot:02d}" for slot in slots}
