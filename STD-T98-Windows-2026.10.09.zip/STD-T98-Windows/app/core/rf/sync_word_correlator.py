import os
import time

import numpy as np
from gnuradio import gr

from core.pipeline.runtime_status import StatusPublisher
from core.protocol.frame_layout import encode_soft_symbols
from ipc.message_schema import (FRAME_FLAG_FLYWHEEL, FRAME_FLAG_SOFT_SYMBOLS, FRAME_FLAG_SYNC_DETECTED,
                                STATUS_SOURCE_RF, FramePacket)
from ipc.transport.uds_seqpacket import UdsSeqpacketServer, resolve_frame_socket_path, resolve_status_socket_path


RF_DEBUG_REPORT_INTERVAL_SEC = 1.0
RF_DEBUG_ACTIVE_WINDOW_SEC = 2.0
# Longest run of undetected frame slots still counted as the same
# transmission (12 x 80 ms); a longer gap starts a new one (missed = 0).
MAX_TRACKED_MISSED_FRAMES = 12
# Flywheel probe: symbols either side of the expected next-frame start.
FLYWHEEL_SLACK = 2


class SyncWordCorrelator(gr.basic_block):
    """Sync-word scanner for every channel; consumes each input independently.

    Each channel's symbol timing loop runs at a slightly different rate
    (~10 symbols/s apart on open-squelch noise). A sync block consumes the same
    count from every input, so the fastest channel's surplus piled up until its
    buffer filled and the whole flowgraph stopped (~20-30 min, CPU idle, no
    reception). Here every call takes everything each input has.
    """

    def __init__(
        self,
        channel_count,
        sync_word=None,
        packet_len=192,
        socket_path=None,
        abs_limit=None,
        threshold_ratio=None,
        error_threshold_ratio=None,
        input_gain=1.0,
        batch_symbols=1,
    ):
        self.channel_count = int(channel_count)
        self.input_gain = float(input_gain)
        # Called once input 0 holds this many symbols; the Python gateway's
        # per-call cost with 97 inputs (~0.4 core at ~140 calls/s) drops with
        # the call rate. Other inputs never wait: whatever they hold is taken.
        self.batch_symbols = max(1, int(batch_symbols))
        gr.basic_block.__init__(
            self,
            name="Sync Word Correlator",
            in_sig=[np.float32] * self.channel_count,
            out_sig=None,
        )

        if threshold_ratio is None and error_threshold_ratio is None:
            raise ValueError("Either threshold_ratio or error_threshold_ratio must be provided.")
        if threshold_ratio is not None and error_threshold_ratio is not None:
            raise ValueError("threshold_ratio and error_threshold_ratio are mutually exclusive.")

        if sync_word is None:
            sync_word = [-3.0, +1.0, -3.0, +3.0, -3.0, -3.0, +3.0, +3.0, -1.0, +3.0]
        self.sync_word = np.asarray(sync_word, dtype=np.float32)
        self.sync_word_length = len(self.sync_word)

        self.packet_len = int(packet_len)
        if self.packet_len < self.sync_word_length:
            raise ValueError("packet_len must be >= length of sync_word")

        sync_word_energy = float(np.dot(self.sync_word, self.sync_word))
        self.sync_word_energy = sync_word_energy
        if threshold_ratio is not None:
            self.detection_mode = "correlation"
            self.match_threshold = sync_word_energy * float(threshold_ratio)
            self.abs_limit = float(abs_limit if abs_limit is not None else 4.0)
        else:
            self.detection_mode = "sse"
            self.threshold_ratio = float(error_threshold_ratio)
            self.match_threshold = sync_word_energy * float(error_threshold_ratio)
            self.abs_limit = None

        # One row per channel; shift_registers[ch] are views into it, so the
        # per-channel path and the all-channel fast path share the same state.
        self.shift_matrix = np.zeros((self.channel_count, self.sync_word_length), dtype=np.float32)
        self.shift_registers = [self.shift_matrix[channel] for channel in range(self.channel_count)]
        # False runs every channel through the per-channel scan (reference behaviour).
        self.vectorized = True
        self.collecting = [False] * self.channel_count
        self.packet_bufs = [None] * self.channel_count
        self.samples_collected = [0] * self.channel_count
        # Per-channel symbol clock: absolute index of each detected sync start,
        # so a skipped frame slot is counted exactly, independent of timing jitter.
        self.symbols_seen = [0] * self.channel_count
        self.last_frame_start = [None] * self.channel_count
        self.frame_missed = [0] * self.channel_count
        self.sequence = 0

        resolved_socket_path = resolve_frame_socket_path(channel_count=self.channel_count, socket_path=socket_path)
        self.transport = UdsSeqpacketServer(resolved_socket_path)
        self.status_publisher = StatusPublisher(
            socket_path=resolve_status_socket_path(channel_count=self.channel_count),
            source=STATUS_SOURCE_RF,
        )
        self.next_debug_report_at = time.monotonic() + RF_DEBUG_REPORT_INTERVAL_SEC
        self.sync_detect_count = [0] * self.channel_count
        self.frame_send_ok = [0] * self.channel_count
        self.frame_send_fail = [0] * self.channel_count
        self.last_metric = [None] * self.channel_count
        self.best_metric = [None] * self.channel_count
        self.last_detect_metric = [None] * self.channel_count
        self.last_detect_at = [0.0] * self.channel_count
        # Flywheel probe: after each frame, the next MAX_TRACKED_MISSED_FRAMES
        # slots of a channel are cut out (best sync offset within
        # FLYWHEEL_SLACK) whenever no sync word was detected there, and sent
        # with FRAME_FLAG_FLYWHEEL so the protocol service can count how many
        # would have decoded. Only channels in a call keep a symbol history.
        self.flywheel_probe = os.environ.get("STD_T98_FLYWHEEL_PROBE", "1") != "0"
        self.fly_next = [None] * self.channel_count
        self.fly_left = [0] * self.channel_count
        self.fly_hist = [None] * self.channel_count
        self.fly_hist_start = [0] * self.channel_count
        self.fly_sent = [0] * self.channel_count
        self.fly_chunk = [((), 0)] * self.channel_count  # this work call's (symbols, absolute start)

    def stop(self):
        self.transport.close()
        self.status_publisher.close()
        return True

    def _start_collection(self, channel_index, initial_window):
        self.packet_bufs[channel_index] = np.empty(self.packet_len, dtype=np.float32)
        self.packet_bufs[channel_index][: self.sync_word_length] = initial_window
        self.samples_collected[channel_index] = self.sync_word_length
        self.collecting[channel_index] = True

    def set_threshold_ratio(self, ratio):
        if not np.isfinite(ratio) or ratio <= 0:
            raise ValueError("Sync threshold ratio must be positive and finite")
        self.threshold_ratio = float(ratio)
        self.match_threshold = float(np.dot(self.sync_word, self.sync_word)) * self.threshold_ratio

    def _sync_metric(self, channel_index):
        if self.detection_mode == "correlation":
            return float(np.dot(self.shift_registers[channel_index], self.sync_word))

        return float(np.sum((self.shift_registers[channel_index] - self.sync_word) ** 2))

    def _update_metric_stats(self, channel_index, metric):
        self.last_metric[channel_index] = metric
        best_metric = self.best_metric[channel_index]
        if best_metric is None:
            self.best_metric[channel_index] = metric
            return

        if self.detection_mode == "correlation":
            if metric > best_metric:
                self.best_metric[channel_index] = metric
            return

        if metric < best_metric:
            self.best_metric[channel_index] = metric

    def _sync_detected(self, channel_index, metric=None):
        if metric is None:
            metric = self._sync_metric(channel_index)

        if self.detection_mode == "correlation":
            return metric >= self.match_threshold

        return metric <= self.match_threshold

    def _format_metric(self, metric):
        if metric is None:
            return "n/a"
        return f"{metric:.1f}"

    def _channel_debug_summary(self, channel_index):
        metric_name = "corr" if self.detection_mode == "correlation" else "sse"
        return (
            f"sync={self.sync_detect_count[channel_index]} ipc={self.frame_send_ok[channel_index]}/{self.frame_send_fail[channel_index]} "
            f"{metric_name}={self._format_metric(self.last_detect_metric[channel_index])} "
            f"thr={self.match_threshold:.1f} best={self._format_metric(self.best_metric[channel_index])}"
        )

    def _maybe_publish_debug_metrics(self):
        current_time = time.monotonic()
        if current_time < self.next_debug_report_at:
            return

        active_channels = sum(
            1
            for last_detect_at in self.last_detect_at
            if last_detect_at and (current_time - last_detect_at) <= RF_DEBUG_ACTIVE_WINDOW_SEC
        )
        self.status_publisher.publish(
            payload_dict={
                "event": "service_metrics",
                "summary": (
                    f"sync={sum(self.sync_detect_count)} ipc={sum(self.frame_send_ok)}/{sum(self.frame_send_fail)} "
                    f"mode={self.detection_mode} thr={self.match_threshold:.1f} active={active_channels}"
                ),
            }
        )

        for channel_index in range(self.channel_count):
            if self.sync_detect_count[channel_index] <= 0 and self.frame_send_fail[channel_index] <= 0:
                continue
            if self.last_detect_at[channel_index] and (current_time - self.last_detect_at[channel_index]) > RF_DEBUG_ACTIVE_WINDOW_SEC:
                if self.frame_send_fail[channel_index] <= 0:
                    continue
            self.status_publisher.publish(
                channel_id=channel_index + 1,
                payload_dict={
                    "event": "channel_state",
                    "rf_debug": self._channel_debug_summary(channel_index),
                },
            )

        self.next_debug_report_at = current_time + RF_DEBUG_REPORT_INTERVAL_SEC

    def _append_symbol(self, channel_index, symbol):
        if not self.collecting[channel_index]:
            return

        collected = self.samples_collected[channel_index]
        if collected < self.packet_len:
            self.packet_bufs[channel_index][collected] = float(symbol)
            self.samples_collected[channel_index] += 1

        if self.samples_collected[channel_index] < self.packet_len:
            return

        self._finish_collection(channel_index)

    def _count_missed(self, channel_index, sync_start):
        previous = self.last_frame_start[channel_index]
        self.last_frame_start[channel_index] = sync_start
        missed = 0
        if previous is not None:
            missed = int(round((sync_start - previous) / self.packet_len)) - 1
            if not 0 < missed <= MAX_TRACKED_MISSED_FRAMES:
                missed = 0
        self.frame_missed[channel_index] = missed

    def _finish_collection(self, channel_index):
        start = self.last_frame_start[channel_index]
        if self.flywheel_probe and start is not None:
            if self.fly_next[channel_index] is not None:
                # Slots missed before this frame; the history may still lack
                # this work call's symbols if the probe was armed during it.
                self._flywheel_extend(channel_index, *self.fly_chunk[channel_index])
                self._flywheel_slots(channel_index, before=start)
            self.fly_next[channel_index] = start + self.packet_len
            self.fly_left[channel_index] = MAX_TRACKED_MISSED_FRAMES
            self.fly_hist[channel_index] = self.packet_bufs[channel_index][-FLYWHEEL_SLACK:].copy()
            self.fly_hist_start[channel_index] = start + self.packet_len - FLYWHEEL_SLACK

        packet = FramePacket(
            sequence=self.sequence,
            monotonic_ns=time.monotonic_ns(),
            channel_id=channel_index + 1,
            flags=FRAME_FLAG_SYNC_DETECTED | FRAME_FLAG_SOFT_SYMBOLS,
            symbols=encode_soft_symbols(self.packet_bufs[channel_index]),
            missed=self.frame_missed[channel_index],
        )
        self.sequence += 1
        if self.transport.send(packet.encode()):
            self.frame_send_ok[channel_index] += 1
        else:
            self.frame_send_fail[channel_index] += 1

        self.collecting[channel_index] = False
        self.packet_bufs[channel_index] = None
        self.samples_collected[channel_index] = 0

    def forecast(self, noutput_items, ninputs):
        # Wait only on input 0; every other input is taken as it is.
        required = [0] * ninputs
        required[0] = self.batch_symbols
        return required

    def general_work(self, input_items, output_items):
        self.work(input_items, output_items)
        for channel_index in range(self.channel_count):
            self.consume(channel_index, len(input_items[channel_index]))
        return 0

    def work(self, input_items, output_items):
        """Scan every channel's available symbols (lengths may differ per channel)."""
        counts = [len(input_items[channel_index]) for channel_index in range(self.channel_count)]
        bases = list(self.symbols_seen) if self.flywheel_probe else None
        if self.flywheel_probe:
            self.fly_chunk = [(input_items[index][:counts[index]], bases[index]) for index in range(self.channel_count)]
            for channel_index in range(self.channel_count):
                if self.fly_next[channel_index] is not None and counts[channel_index]:
                    self._flywheel_extend(channel_index, input_items[channel_index][:counts[channel_index]], bases[channel_index])
        scan_individually = range(self.channel_count)
        if self.vectorized:
            scan_individually = self._scan_all_channels(input_items, counts)

        for channel_index in scan_individually:
            if counts[channel_index]:
                self._scan_channel(channel_index, input_items, counts[channel_index])

        if self.flywheel_probe:
            for channel_index in range(self.channel_count):
                if self.fly_next[channel_index] is not None and counts[channel_index]:
                    # A frame finished in this chunk re-armed with a short history.
                    self._flywheel_extend(channel_index, input_items[channel_index][:counts[channel_index]], bases[channel_index])
                    self._flywheel_slots(channel_index)

        self._maybe_publish_debug_metrics()

        return counts[0]

    def _flywheel_extend(self, channel_index, chunk, base):
        """Append the part of this chunk (starting at absolute ``base``) that
        the channel's flywheel history does not hold yet."""
        history_end = self.fly_hist_start[channel_index] + len(self.fly_hist[channel_index])
        new = np.asarray(chunk[max(0, history_end - base):], dtype=np.float32)
        if not len(new):
            return
        if self.input_gain != 1.0:
            new = new * self.input_gain
        if self.abs_limit is not None:
            new = np.clip(new, -self.abs_limit, self.abs_limit)
        self.fly_hist[channel_index] = np.concatenate((self.fly_hist[channel_index], new))

    def _flywheel_slots(self, channel_index, before=None):
        """Send each due slot the history covers. A slot belongs to a frame
        being collected (or, with ``before``, the frame just finished) when
        its window reaches that frame's start; it is left to that frame."""
        limit = before
        if limit is None and self.collecting[channel_index]:
            limit = self.last_frame_start[channel_index]
        history = self.fly_hist[channel_index]
        start = self.fly_hist_start[channel_index]
        while self.fly_next[channel_index] is not None:
            expected = self.fly_next[channel_index]
            if limit is not None and expected + FLYWHEEL_SLACK >= limit:
                return
            if start + len(history) < expected + FLYWHEEL_SLACK + self.packet_len:
                return
            offsets = range(-FLYWHEEL_SLACK, FLYWHEEL_SLACK + 1)
            errors = [float(np.sum((history[expected + o - start:expected + o - start + self.sync_word_length]
                                    - self.sync_word) ** 2)) for o in offsets]
            offset = offsets[int(np.argmin(errors))]
            frame = history[expected + offset - start:expected + offset - start + self.packet_len]
            slot = MAX_TRACKED_MISSED_FRAMES - self.fly_left[channel_index] + 1
            if np.any(frame):  # a closed squelch outputs exact zeros: nothing to count
                packet = FramePacket(
                    sequence=self.sequence,
                    monotonic_ns=time.monotonic_ns(),
                    channel_id=channel_index + 1,
                    flags=FRAME_FLAG_FLYWHEEL | FRAME_FLAG_SOFT_SYMBOLS,
                    symbols=encode_soft_symbols(frame),
                    missed=slot,  # probe frames: slots after the last detected frame (1..12)
                )
                self.sequence += 1
                self.transport.send(packet.encode())
                self.fly_sent[channel_index] += 1
            self.fly_next[channel_index] = expected = expected + offset + self.packet_len
            self.fly_left[channel_index] -= 1
            history = self.fly_hist[channel_index] = history[expected - FLYWHEEL_SLACK - start:]
            start = self.fly_hist_start[channel_index] = expected - FLYWHEEL_SLACK
            if self.fly_left[channel_index] <= 0:
                self.fly_next[channel_index] = None
                self.fly_hist[channel_index] = None
                return

    def _scan_all_channels(self, input_items, counts):
        """One NumPy pass over every channel that is scanning (not collecting).

        Channels whose whole chunk has no sync match are fully updated here,
        exactly as the per-channel scan would (last/best metric, shift
        register). Returns the channels that still need the per-channel scan:
        those collecting a frame and those with a match in this chunk.
        Calling NumPy per channel on ~20-symbol chunks cost ~0.85 core at 97ch.
        Shorter inputs are padded with NaN, which never matches and is ignored
        by the minimum/maximum.
        """
        scanning = [index for index in range(self.channel_count) if not self.collecting[index] and counts[index]]
        individual = [index for index in range(self.channel_count) if self.collecting[index]]
        if not scanning:
            return individual
        rows = np.asarray(scanning)
        lengths = np.asarray([counts[index] for index in scanning])
        data = np.full((len(scanning), int(lengths.max())), np.nan, dtype=np.float32)
        for row, channel_index in enumerate(scanning):
            data[row, :lengths[row]] = input_items[channel_index][:lengths[row]]
        if self.input_gain != 1.0:
            data = data * self.input_gain
        if self.abs_limit is not None:
            data = np.clip(data, -self.abs_limit, self.abs_limit)
        joined = np.concatenate((self.shift_matrix[rows, 1:], data), axis=1)
        windows = np.lib.stride_tricks.sliding_window_view(joined, self.sync_word_length, axis=1)
        if self.detection_mode == "correlation":
            metrics = np.einsum("cij,j->ci", windows, self.sync_word)
            matched = np.any(metrics >= self.match_threshold, axis=1)
            best = np.nanmax(metrics, axis=1)
        else:
            errors = windows - self.sync_word
            metrics = np.sum(errors * errors, axis=2)
            matched = np.any(metrics <= self.match_threshold, axis=1)
            best = np.nanmin(metrics, axis=1)
        quiet = np.flatnonzero(~matched)
        ends = lengths - 1                       # each channel's last complete window
        self.shift_matrix[rows[quiet]] = windows[quiet, ends[quiet]]
        last = metrics[np.arange(len(scanning)), ends]
        for row in quiet:
            channel_index = scanning[row]
            self._update_metric_stats(channel_index, float(best[row]))
            self.last_metric[channel_index] = float(last[row])
            self.symbols_seen[channel_index] += int(lengths[row])
        individual += [scanning[row] for row in np.flatnonzero(matched)]
        return sorted(individual)

    def _scan_channel(self, channel_index, input_items, sample_count):
        """Per-channel scan and frame collection (the reference behaviour)."""
        base = self.symbols_seen[channel_index]
        self.symbols_seen[channel_index] += sample_count
        in_data = np.asarray(input_items[channel_index][:sample_count], dtype=np.float32)
        # Closed squelches settle to exact zero. Most of the 97 channels
        # are idle: their all-zero scan windows cannot match this sync word.
        if (sample_count and not self.collecting[channel_index]
                and not np.count_nonzero(in_data)
                and not np.count_nonzero(self.shift_registers[channel_index])):
            metric = 0.0 if self.detection_mode == "correlation" else self.sync_word_energy
            if not self._sync_detected(channel_index, metric):
                self._update_metric_stats(channel_index, metric)
                return
        if self.input_gain != 1.0:
            in_data = in_data * self.input_gain
        if self.abs_limit is not None:
            in_data = np.clip(in_data, -self.abs_limit, self.abs_limit)
        position = 0
        while position < sample_count:
            if self.collecting[channel_index]:
                collected = self.samples_collected[channel_index]
                count = min(self.packet_len - collected, sample_count - position)
                self.packet_bufs[channel_index][collected:collected + count] = in_data[position:position + count]
                self.samples_collected[channel_index] += count
                position += count
                if self.samples_collected[channel_index] == self.packet_len:
                    self._finish_collection(channel_index)
                continue

            # Batch the short sliding-window calculations. Calling NumPy
            # once per symbol per channel blocked 97ch IQ processing below
            # realtime. Keep precisely the same detection/collection rules,
            # including the scan history retained while collecting a frame.
            joined = np.concatenate((self.shift_registers[channel_index][1:], in_data[position:]))
            windows = np.lib.stride_tricks.sliding_window_view(joined, self.sync_word_length)
            if self.detection_mode == "correlation":
                metrics = np.einsum("ij,j->i", windows, self.sync_word)
                matches = np.flatnonzero(metrics >= self.match_threshold)
            else:
                errors = windows - self.sync_word
                metrics = np.sum(errors * errors, axis=1)
                matches = np.flatnonzero(metrics <= self.match_threshold)
            last_index = int(matches[0]) if len(matches) else len(metrics) - 1
            observed = metrics[:last_index + 1]
            self.last_metric[channel_index] = float(observed[-1])
            best = float(np.max(observed) if self.detection_mode == "correlation" else np.min(observed))
            self._update_metric_stats(channel_index, best)
            self.last_metric[channel_index] = float(observed[-1])
            self.shift_registers[channel_index][:] = windows[last_index]
            # Window i ends at in_data[position + i] (it starts with the
            # sync_word_length - 1 symbols of history).
            sync_start = base + position + last_index - (self.sync_word_length - 1)
            position += last_index + 1
            if not len(matches):
                break
            self._count_missed(channel_index, sync_start)
            self.sync_detect_count[channel_index] += 1
            self.last_detect_metric[channel_index] = float(observed[-1])
            self.last_detect_at[channel_index] = time.monotonic()
            self._start_collection(channel_index, windows[last_index].copy())
