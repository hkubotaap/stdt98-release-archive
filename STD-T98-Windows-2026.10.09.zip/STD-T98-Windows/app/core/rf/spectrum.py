"""Low-rate wideband spectrum for the GUI, measured on the channelizer input."""
import base64
import time

import numpy as np

# 195 Hz bins at 800 kS/s: 32 points per 6.25 kHz channel for zoomed table columns.
FFT_SIZE = 4096
UPDATE_SECONDS = 0.1
MAX_SEGMENTS = 8


def measure(samples, fft_size=FFT_SIZE, max_segments=MAX_SEGMENTS):
    """Welch-averaged power per bin in dBFS, DC centred; None if too few samples."""
    segments = min(len(samples) // fft_size, max_segments)
    if not segments:
        return None
    window = np.blackman(fft_size).astype(np.float32)
    block = np.asarray(samples[-segments * fft_size:], dtype=np.complex64).reshape(segments, fft_size)
    power = np.mean(np.abs(np.fft.fft(block * window, axis=1)) ** 2, axis=0)
    # A full-scale complex tone in one bin reads 0 dBFS.
    power /= float(np.sum(window)) ** 2
    return np.fft.fftshift(10 * np.log10(np.maximum(power, 1e-20))).astype(np.float32)


def encode(db, sequence, center_hz, sample_rate):
    return {"seq": sequence, "center_hz": float(center_hz), "rate": float(sample_rate),
            "bins": base64.b64encode(db.astype("<f2").tobytes()).decode("ascii")}


def decode(state):
    """dB array from a published spectrum state; ValueError when malformed."""
    try:
        db = np.frombuffer(base64.b64decode(state["bins"], validate=True), dtype="<f2").astype(np.float32)
        center, rate = float(state["center_hz"]), float(state["rate"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("Invalid spectrum state") from exc
    if not 16 <= len(db) <= 65536 or not np.all(np.isfinite(db)) or not rate > 0:
        raise ValueError("Invalid spectrum state")
    return db, center, rate


def make_tap(center_hz, sample_rate, publisher):
    """GNU Radio sink publishing ``{"spectrum": ...}`` status every UPDATE_SECONDS."""
    from gnuradio import gr

    class SpectrumTap(gr.sync_block):
        def __init__(self):
            gr.sync_block.__init__(self, name="spectrum_tap", in_sig=[np.complex64], out_sig=[])
            self.next_at = 0.0
            self.sequence = 0
            self.publisher = publisher
            self.pending = []
            self.pending_count = 0

        def work(self, input_items, output_items):
            samples = input_items[0]
            now = time.monotonic()
            # Most calls only count samples; the FFT runs ~10 times a second.
            # Collect across calls when the scheduler hands over small buffers.
            if now >= self.next_at:
                self.pending.append(samples[-FFT_SIZE * MAX_SEGMENTS:].copy())
                self.pending_count += len(self.pending[-1])
                if self.pending_count >= FFT_SIZE * MAX_SEGMENTS or (
                        self.pending_count >= FFT_SIZE and now >= self.next_at + UPDATE_SECONDS):
                    db = measure(np.concatenate(self.pending))
                    self.pending, self.pending_count = [], 0
                    self.publisher.publish(payload_dict={"spectrum": encode(db, self.sequence, center_hz, sample_rate)})
                    self.sequence += 1
                    self.next_at = now + UPDATE_SECONDS
            return len(samples)

        def stop(self):
            self.publisher.close()
            return True

    return SpectrumTap()
