"""Conservative input-level controller for SDRs without hardware AGC.

The wideband IQ level is a headroom indicator, not a measure of decoded voice
quality. Reduce gain quickly on overload and raise it slowly when the input is
consistently quiet, so short transmissions do not make the receiver pump.

A strong nearby transmitter is the exception to "raise slowly": the gain it
forced down was fine before it keyed up, so FastRestore returns to that gain
as soon as the level shows the strong signal has gone, instead of climbing
back 2 dB every 3 s (about 30 s for a 20 dB dip, with weak stations lost).
"""

import math

OVERLOAD_CLIP_FRACTION = 0.001
OVERLOAD_RMS_DBFS = -18.0
# Return to the pre-overload gain only if the level, re-scaled to that gain,
# would sit at least 6 dB below the overload line.
FAST_RESTORE_MAX_DBFS = OVERLOAD_RMS_DBFS - 6.0
FAST_RESTORE_CALM_WINDOWS = 2      # measured 1 s windows in a row
RESTORE_FAIL_WINDOWS = 3           # an overload this soon after a restore means it failed
RESTORE_BLOCK_WINDOWS = 30         # then climb back slowly for a while instead


class FastRestore:
    """Remember the gain from before an overload and go back to it quickly.

    ``total`` maps a gain value to dB (identity for a single gain stage,
    ``HackRFGains.total_db`` for HackRF) so the same logic serves both.
    """

    def __init__(self, total=float):
        self._total = total
        self._block = 0
        self._watch = 0
        self.clear()

    def clear(self):
        self.saved = None
        self._calm = 0

    def tick(self):
        """Call once per measured window."""
        self._block = max(0, self._block - 1)
        self._watch = max(0, self._watch - 1)

    def on_overload(self, gains):
        if self._watch:
            # The restored gain overloaded straight away: the strong signal is
            # still around (e.g. a pause mid-transmission). Stop bouncing.
            self._block = RESTORE_BLOCK_WINDOWS
            self._watch = 0
        if self.saved is None:
            self.saved = gains
        self._calm = 0

    def check(self, gains, rms_dbfs, clipped_fraction):
        """The gain to restore now, or None."""
        if self.saved is None:
            return None
        if self._total(gains) >= self._total(self.saved):
            self.clear()   # the slow climb already got back
            return None
        predicted = rms_dbfs + self._total(self.saved) - self._total(gains)
        if self._block or clipped_fraction > 0 or predicted > FAST_RESTORE_MAX_DBFS:
            self._calm = 0
            return None
        self._calm += 1
        if self._calm < FAST_RESTORE_CALM_WINDOWS:
            return None
        target = self.saved
        self.clear()
        self._watch = RESTORE_FAIL_WINDOWS
        return target


class AutoGainController:
    def __init__(self, gain_db, minimum_db=0.0, maximum_db=100.0):
        self.minimum_db = float(minimum_db)
        self.maximum_db = float(maximum_db)
        self.gain_db = self._clamp(gain_db)
        self._quiet_windows = 0
        self._restore = FastRestore()

    def _clamp(self, gain_db):
        return max(self.minimum_db, min(self.maximum_db, float(gain_db)))

    def reset(self, gain_db):
        # Only called for a manual change or a failed write: forget the episode.
        self.gain_db = self._clamp(gain_db)
        self._quiet_windows = 0
        self._restore.clear()

    def update(self, rms_dbfs, clipped_fraction):
        """Return a new gain only when a measured one-second window calls for it."""
        if not math.isfinite(rms_dbfs) or not math.isfinite(clipped_fraction):
            return None
        if clipped_fraction < 0 or clipped_fraction > 1:
            return None
        self._restore.tick()

        if clipped_fraction >= OVERLOAD_CLIP_FRACTION:
            self._quiet_windows = 0
            self._restore.on_overload(self.gain_db)
            step = -8.0
        elif rms_dbfs > OVERLOAD_RMS_DBFS:
            self._quiet_windows = 0
            self._restore.on_overload(self.gain_db)
            step = -4.0
        else:
            restored = self._restore.check(self.gain_db, rms_dbfs, clipped_fraction)
            if restored is not None:
                self._quiet_windows = 0
                self.gain_db = restored
                return restored
            if rms_dbfs < -36.0:
                self._quiet_windows += 1
                if self._quiet_windows < 3:
                    return None
                self._quiet_windows = 0
                step = 2.0
            else:
                self._quiet_windows = 0
                return None

        next_gain = self._clamp(self.gain_db + step)
        if next_gain == self.gain_db:
            return None
        self.gain_db = next_gain
        return next_gain
