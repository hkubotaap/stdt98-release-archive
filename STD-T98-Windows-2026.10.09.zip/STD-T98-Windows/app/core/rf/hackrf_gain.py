"""HackRF RX stages and conservative software level control (no GNU Radio)."""
from dataclasses import dataclass
import math

from core.rf.auto_gain import OVERLOAD_CLIP_FRACTION, OVERLOAD_RMS_DBFS, FastRestore


@dataclass(frozen=True)
class HackRFGains:
    lna: int = 40
    vga: int = 40
    amp: bool = False

    def __post_init__(self):
        for name, maximum, step in (("lna", 40, 8), ("vga", 62, 2)):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f"HackRF {name.upper()} must be a finite gain in dB")
            if value < 0 or value > maximum or value % step:
                raise ValueError(f"HackRF {name.upper()}: 0..{maximum} dB in {step} dB steps")
        if not isinstance(self.amp, bool):
            raise ValueError("HackRF AMP must be true or false")

    @property
    def total_db(self):
        # RF amplifier nominal gain is ~11 dB; some Soapy versions advertise
        # 14 instead. This is only a headroom/squelch estimate, not calibration.
        return float(self.lna + self.vga + (11 if self.amp else 0))

    @classmethod
    def from_total(cls, total_db, amp=False):
        if not math.isfinite(total_db):
            raise ValueError("HackRF gain must be finite")
        analog = int(max(0, min(102, total_db - (11 if amp else 0))) // 2) * 2
        candidates = [(lna, analog - lna) for lna in range(0, 41, 8)
                      if 0 <= analog - lna <= 62]
        # Share gain between the IF and baseband stages; prefer LNA on ties.
        lna, vga = min(candidates, key=lambda pair: (abs(pair[0] - pair[1]), -pair[0]))
        return cls(lna, vga, amp)

    def to_dict(self):
        return {"lna_gain": int(self.lna), "vga_gain": int(self.vga), "amp": self.amp}


class HackRFAutoGainController:
    """Slow gain rises, immediate overload reductions, AMP hysteresis.

    AMP comes on only after both analog stages reach their limits and input
    remains quiet. After overload switches it off, wait 15 measured windows
    before allowing it back on. No wideband algorithm can infer voice quality.
    After a strong signal forced the gain down, FastRestore returns to the
    pre-overload stages within ~2 s of it going away instead of the slow climb.
    """
    def __init__(self, gains):
        self._amp_cooldown = 0
        self._restore = FastRestore(total=lambda g: g.total_db)
        self.reset(gains)

    def reset(self, gains, reset_cooldown=False):
        # The backend calls this after every gain write (with the read-back
        # gains), so only a manual change (reset_cooldown) forgets the
        # pre-overload gain that FastRestore is waiting to return to.
        self.gains = gains
        self._quiet_windows = 0
        if reset_cooldown:
            self._amp_cooldown = 0
            self._restore.clear()

    def update(self, rms_dbfs, clipped_fraction):
        if not math.isfinite(rms_dbfs) or not math.isfinite(clipped_fraction) or not 0 <= clipped_fraction <= 1:
            return None
        self._amp_cooldown = max(0, self._amp_cooldown - 1)
        self._restore.tick()
        gains = self.gains
        overloaded = clipped_fraction >= OVERLOAD_CLIP_FRACTION
        restored = None
        if not overloaded and rms_dbfs <= OVERLOAD_RMS_DBFS:
            saved = self._restore.check(gains, rms_dbfs, clipped_fraction)
            if saved is not None:
                # Strong signal gone: straight back to the pre-overload LNA/VGA.
                # AMP keeps its own overload cooldown and hysteresis.
                restored = HackRFGains(saved.lna, saved.vga, saved.amp and self._amp_cooldown == 0)
                if restored == gains:
                    restored = None   # nothing to change: let the normal rules use this window
        if overloaded or rms_dbfs > OVERLOAD_RMS_DBFS:
            self._quiet_windows = 0
            self._restore.on_overload(gains)
            if gains.amp:
                next_gains = HackRFGains(gains.lna, gains.vga, False)
                self._amp_cooldown = 15
            else:
                next_gains = HackRFGains.from_total(gains.total_db - (8 if overloaded else 4))
        elif restored is not None:
            self._quiet_windows = 0
            next_gains = restored
        elif rms_dbfs < -36:
            self._quiet_windows += 1
            if self._quiet_windows < 3:
                return None
            self._quiet_windows = 0
            if gains.lna + gains.vga < 102:
                next_gains = HackRFGains.from_total(gains.total_db + 2, gains.amp)
            elif not gains.amp and self._amp_cooldown == 0:
                next_gains = HackRFGains(gains.lna, gains.vga, True)
            else:
                return None
        else:
            self._quiet_windows = 0
            return None
        if next_gains == gains:
            return None
        self.gains = next_gains
        return next_gains
