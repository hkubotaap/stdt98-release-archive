"""Receiver frequency error, estimated from live STD-T98 transmissions.

Every station is off frequency by its own small amount, but the receiver's
error shifts all of them equally. The median over several channels therefore
estimates the receiver's correction (freq_err_offset); with one or two
stations it still contains their own error, which the summary reports.

A 2026-10-03 RTL-SDR Blog V4 read about +1490 Hz (4.2 ppm) at 351 MHz on four
channels and drifted ~25 Hz within an hour, so a fixed hand calibration ages.

AutoFrequencyCorrector can retune the SDR to follow the estimate. Each retune
interrupts every channel for a few tens of ms, and the demodulator's DC blocker
already absorbs a few tens of Hz, so it acts rarely and only on a confident,
sizeable error; see its constants.
"""
import collections

import numpy as np

ESTIMATE_SAMPLES = 1 << 18          # 0.33 s at 800 kS/s
MAX_AGE_SECONDS = 1800.0
SAMPLES_PER_CHANNEL = 20
# A channel counts once it has this many estimates: live, a single stray
# reading (-551 Hz on one channel) otherwise widened the reported spread.
MIN_CHANNEL_SAMPLES = 3


def channel_offsets(iq, rate, channel_freqs, spacing):
    """FM-demodulated mean frequency (Hz) of each channel in one IQ block.

    One FFT for all channels; each channel's bins are moved to baseband at a
    low rate and the mean instantaneous frequency is measured. Whitened
    STD-T98 symbols average to the carrier over a few hundred symbols.
    """
    samples = np.asarray(iq, dtype=np.complex64)
    size = len(samples)
    spectrum = np.fft.fft(samples)
    half = int(spacing / 2 * size / rate)
    small = 1 << int(np.ceil(np.log2(2 * half + 1)))
    small_rate = rate * small / size
    offsets = []
    for frequency in channel_freqs:
        centre = int(round(frequency * size / rate))
        bins = np.arange(centre - half, centre + half + 1)
        baseband = np.zeros(small, dtype=np.complex128)
        baseband[(bins - centre) % small] = spectrum[bins % size]
        signal = np.fft.ifft(baseband)
        trim = small // 20                       # the block wraps around at its ends
        signal = signal[trim:small - trim]
        mean = np.mean(np.angle(signal[1:] * np.conj(signal[:-1]))) * small_rate / (2 * np.pi)
        offsets.append(float(mean + centre * rate / size - frequency))
    return offsets


class FrequencyErrorTracker:
    """Recent per-channel estimates and their median across channels."""

    def __init__(self, samples_per_channel=SAMPLES_PER_CHANNEL, max_age=MAX_AGE_SECONDS,
                 min_samples=MIN_CHANNEL_SAMPLES):
        self.max_age = float(max_age)
        self.min_samples = int(min_samples)
        self._samples_per_channel = int(samples_per_channel)
        self._estimates = {}

    def add(self, channel, offset_hz, now):
        history = self._estimates.setdefault(channel, collections.deque(maxlen=self._samples_per_channel))
        history.append((float(now), float(offset_hz)))

    def shift(self, delta_hz):
        """The applied correction moved by ``delta_hz``: residuals measured
        before the retune are now ``delta_hz`` smaller, so keep them usable."""
        for history in self._estimates.values():
            for index, (at, offset) in enumerate(history):
                history[index] = (at, offset - float(delta_hz))

    def summary(self, now, applied_hz=0.0):
        """None until a channel has enough estimates, else a JSON-ready dict.

        ``estimate_hz`` is the residual seen with ``applied_hz`` in effect, so
        the suggested freq_err_offset is their sum.
        """
        medians = {}
        samples = 0
        for channel, history in self._estimates.items():
            recent = [offset for at, offset in history if now - at <= self.max_age]
            if len(recent) >= self.min_samples:
                medians[channel] = float(np.median(recent))
                samples += len(recent)
        if not medians:
            return None
        values = np.array(list(medians.values()))
        estimate = float(np.median(values))
        return {
            "estimate_hz": round(estimate, 1),
            "applied_hz": float(applied_hz),
            "suggested_hz": round(float(applied_hz) + estimate),
            "channels": len(medians),
            "samples": samples,
            "spread_hz": round(float(values.max() - values.min()), 1),
            "per_channel": {str(channel + 1): round(value, 1) for channel, value in sorted(medians.items())},
        }


# Automatic correction (AutoFrequencyCorrector). Conservative on purpose:
AUTO_DEADBAND_HZ = 30.0          # smaller errors are absorbed by the demod DC blocker
AUTO_MIN_CHANNELS = 3            # fewer channels still carry the transmitters' own error
AUTO_MAX_SPREAD_HZ = 80.0        # channels must agree
AUTO_MIN_INTERVAL_SECONDS = 180.0
AUTO_QUIET_MAX_ACTIVE = 1        # retune when at most this many channels are in a call...
AUTO_MAX_DEFER_SECONDS = 600.0   # ...but do not wait longer than this for a quiet moment
AUTO_MAX_STEP_HZ = 1500.0        # one step never moves further than this
AUTO_LIMIT_HZ = 20000.0          # never apply a correction beyond this
RETUNE_SETTLE_SECONDS = 1.0      # discard IQ captured around a retune


class AutoFrequencyCorrector:
    """Decide when to move the applied correction to the estimate."""

    def __init__(self, applied_hz=0.0, now=0.0):
        self.applied_hz = float(applied_hz)
        self.last_change_at = float(now)
        self.corrections = 0
        self._waiting_since = None

    def decide(self, summary, active_channels, now):
        """The new correction to apply now, or None."""
        if summary is None or summary["channels"] < AUTO_MIN_CHANNELS or summary["spread_hz"] > AUTO_MAX_SPREAD_HZ:
            self._waiting_since = None
            return None
        error = float(summary["suggested_hz"]) - self.applied_hz
        if abs(error) < AUTO_DEADBAND_HZ or now - self.last_change_at < AUTO_MIN_INTERVAL_SECONDS:
            self._waiting_since = None
            return None
        if self._waiting_since is None:
            self._waiting_since = now
        if active_channels > AUTO_QUIET_MAX_ACTIVE and now - self._waiting_since < AUTO_MAX_DEFER_SECONDS:
            return None   # busy: wait for a quieter moment (up to AUTO_MAX_DEFER_SECONDS)
        step = max(-AUTO_MAX_STEP_HZ, min(AUTO_MAX_STEP_HZ, error))
        target = max(-AUTO_LIMIT_HZ, min(AUTO_LIMIT_HZ, round(self.applied_hz + step)))
        if target == self.applied_hz:
            return None
        self.applied_hz = float(target)
        self.last_change_at = now
        self.corrections += 1
        self._waiting_since = None
        return self.applied_hz


CHECK_SECONDS = 1.0
PUBLISH_SECONDS = 5.0
# A transmission carries 12.5 frames/s; at least half of them must have been
# detected in the last check, and one very recently, so noise (with squelch
# open) and calls that just ended are not measured.
MIN_SYNC_RATE = 6.0
MAX_SYNC_AGE = 0.3
MAX_CHANNELS_PER_CHECK = 4


def make_monitor(rate, spacing, num_channels, correlator, publisher, applied_hz, retune=None, auto=False):
    """GNU Radio sink estimating the receiver's frequency error once a second.

    Reads the channelizer input and the sync correlator's per-channel
    detection counters; publishes ``{"freq_error": summary}`` status.
    With ``auto`` (switchable live via ``.auto``) and a ``retune(offset_hz)``
    callback, it also moves the SDR to follow the estimate.
    """
    import time

    from gnuradio import gr

    class FrequencyErrorMonitor(gr.sync_block):
        def __init__(self):
            gr.sync_block.__init__(self, name="freq_error_monitor", in_sig=[np.complex64], out_sig=[])
            self.ring = np.zeros(ESTIMATE_SAMPLES, dtype=np.complex64)
            self.position = 0
            self.filled = 0
            self.tracker = FrequencyErrorTracker()
            self.publisher = publisher
            self.last_counts = list(correlator.sync_detect_count)
            self.checked_at = time.monotonic()
            self.published_at = self.checked_at
            self.auto = bool(auto) and retune is not None
            self.corrector = AutoFrequencyCorrector(applied_hz, self.checked_at)
            self.active_channels = 0
            self.settle_until = 0.0

        def _store(self, samples):
            size = len(self.ring)
            if len(samples) >= size:
                self.ring[:] = samples[-size:]
                self.position = 0
            else:
                first = min(len(samples), size - self.position)
                self.ring[self.position:self.position + first] = samples[:first]
                self.ring[:len(samples) - first] = samples[first:]
                self.position = (self.position + len(samples)) % size
            self.filled = min(size, self.filled + len(samples))

        def _check(self, now):
            counts = list(correlator.sync_detect_count)
            elapsed = max(now - self.checked_at, 1e-3)
            rates = [(new - old) / elapsed for new, old in zip(counts, self.last_counts)]
            self.last_counts, self.checked_at = counts, now
            if self.filled < len(self.ring):
                return
            detect_at = time.monotonic()
            active = [channel for channel, rate_ in enumerate(rates)
                      if rate_ >= MIN_SYNC_RATE and detect_at - correlator.last_detect_at[channel] <= MAX_SYNC_AGE]
            self.active_channels = len(active)
            if now < self.settle_until:
                return   # the ring still holds IQ from around the retune
            active = sorted(active, key=lambda channel: -rates[channel])[:MAX_CHANNELS_PER_CHECK]
            if not active:
                return
            block = np.roll(self.ring, -self.position)
            freqs = [(channel - num_channels // 2) * spacing for channel in active]
            for channel, offset in zip(active, channel_offsets(block, rate, freqs, spacing)):
                self.tracker.add(channel, offset, now)

        def work(self, input_items, output_items):
            samples = input_items[0]
            self._store(samples)
            now = time.monotonic()
            if now - self.checked_at >= CHECK_SECONDS:
                self._check(now)
            if now - self.published_at >= PUBLISH_SECONDS:
                self.published_at = now
                summary = self.tracker.summary(now, self.corrector.applied_hz)
                if self.auto:
                    self._maybe_retune(summary, now)
                    summary = self.tracker.summary(now, self.corrector.applied_hz)
                if summary is not None:
                    summary["auto"] = self.auto
                    summary["corrections"] = self.corrector.corrections
                    self.publisher.publish(payload_dict={"freq_error": summary})
            return len(samples)

        def _maybe_retune(self, summary, now):
            before = self.corrector.applied_hz
            target = self.corrector.decide(summary, self.active_channels, now)
            if target is None:
                return
            try:
                retune(target)
            except Exception as exc:   # keep receiving on the old tuning
                print(f"Automatic frequency correction failed: {exc}", flush=True)
                self.corrector.applied_hz = before
                return
            self.tracker.shift(target - before)
            self.filled = 0
            self.settle_until = now + RETUNE_SETTLE_SECONDS
            print(f"Automatic frequency correction: {before:+.0f} -> {target:+.0f} Hz", flush=True)

        def stop(self):
            self.publisher.close()
            return True

    return FrequencyErrorMonitor()
