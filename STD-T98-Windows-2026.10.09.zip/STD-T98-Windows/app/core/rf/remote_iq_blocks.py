"""GNU Radio adapters for the bounded TCP IQ transport."""
import sys
import time
import queue
import threading
import numpy as np
from gnuradio import gr
from core.rf.remote_iq import BLOCK_BYTES, IQBuffer


class IQNetworkSink(gr.sync_block):
    def __init__(self, server):
        gr.sync_block.__init__(self, name="rf_iq_broadcast", in_sig=[np.complex64], out_sig=[])
        self.server = server

    def work(self, input_items, output_items):
        # Explicit wire endianness; native Windows/Linux complex64 is little endian.
        self.server.publish(input_items[0].astype("<c8", copy=False))
        return len(input_items[0])


class IQNetworkSource(gr.sync_block):
    def __init__(self, client, status_publisher=None, endpoint=""):
        gr.sync_block.__init__(self, name="rf_iq_remote", in_sig=[], out_sig=[np.complex64])
        self.client = client
        self.publisher = status_publisher
        self.endpoint = endpoint
        self.pending = np.empty(0, dtype="<c8")
        self.failure = None
        self.closed = False
        self.report_at = 0
        # Receive TCP independently of the hundreds of decoder scheduler
        # threads. The buffer fills only during temporary decoder stalls.
        self.buffers = IQBuffer(max(BLOCK_BYTES, int(client.metadata["sample_rate"] * 8)))
        self.reader = None

    def _receive(self):
        try:
            while not self.closed:
                data = self.client.receive()
                try:
                    self.buffers.put_nowait(data)
                except queue.Full:
                    raise ConnectionError("RF IQ client decode buffer full: decoding cannot keep up "
                                          "with the incoming stream (1 second limit)")
        except (OSError, ValueError, ConnectionError) as exc:
            if not self.closed:
                self.failure = str(exc)
                print(f"Remote IQ stopped: {exc}", file=sys.stderr, flush=True)
            self.buffers.fail(str(exc))
        finally:
            self.client.close()

    def work(self, input_items, output_items):
        if self.closed:
            return -1
        if self.reader is None:
            # First actual scheduler read, after graph construction; no IQ
            # subscription or history collection before the receiver is ready.
            self.reader = threading.Thread(target=self._receive, name="rf-iq-reader", daemon=True)
            self.reader.start()
        if not len(self.pending):
            try:
                self.pending = np.frombuffer(self.buffers.get(), dtype="<c8")
            except ConnectionError:
                return -1
        output = output_items[0]
        count = min(len(output), len(self.pending))
        output[:count] = self.pending[:count]
        self.pending = self.pending[count:]
        now = time.monotonic()
        if self.publisher is not None and now >= self.report_at:
            self.publisher.publish(payload_dict={"rf_network": {
                "mode": "client", "endpoint": self.endpoint, "bytes": self.client.bytes_received,
                "metadata": self.client.metadata, "clients": 1,
                "buffer_ms": self.buffers.queued_bytes() * 125 / self.client.metadata["sample_rate"]}})
            self.report_at = now + 1
        return count

    def close(self):
        self.closed = True
        self.buffers.fail("RF IQ client stopped", discard=True)
        self.client.close()
        if self.reader is not None and self.reader is not threading.current_thread():
            self.reader.join(1)
        if self.publisher is not None:
            self.publisher.close()

    def stop(self):
        self.close()
        return True
