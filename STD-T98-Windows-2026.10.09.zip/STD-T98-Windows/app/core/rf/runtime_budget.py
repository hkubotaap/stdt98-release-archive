"""Allow wide channel banks enough Windows CPUs for open-squelch decoding."""
import ctypes
import os
import sys


class _ProcessorInformation(ctypes.Structure):
    # SYSTEM_LOGICAL_PROCESSOR_INFORMATION; the 16-byte union is not needed.
    _fields_ = [("mask", ctypes.c_size_t), ("relationship", ctypes.c_int),
                ("union", ctypes.c_ulonglong * 2)]


def _physical_cores(kernel):
    """Logical processor masks per physical core, or None when unavailable."""
    size = ctypes.c_uint32(0)
    kernel.GetLogicalProcessorInformation(None, ctypes.byref(size))
    count = size.value // ctypes.sizeof(_ProcessorInformation)
    if not count:
        return None
    entries = (_ProcessorInformation * count)()
    if not kernel.GetLogicalProcessorInformation(entries, ctypes.byref(size)):
        return None
    return [entry.mask for entry in entries if entry.relationship == 0]  # RelationProcessorCore


def _spread(processors, cores):
    # One logical processor per physical core before any SMT sibling, so an
    # 8-CPU budget on 6C/12T uses all six cores instead of four core pairs.
    groups = [[bit for bit in processors if core & (1 << bit)] for core in cores or ()]
    groups = [group for group in groups if group]
    grouped = {bit for group in groups for bit in group}
    groups += [[bit] for bit in processors if bit not in grouped]
    ordered = []
    for depth in range(max(map(len, groups), default=0)):
        ordered += [group[depth] for group in groups if depth < len(group)]
    return ordered


def limit_rf_cpu(channel_count):
    # A 97ch TPB graph has hundreds of native block threads. Four logical CPUs
    # were sufficient for quiet/closed squelches, but opening the whole bank
    # exhausted that budget (only two physical cores on common SMT layouts).
    # Eight sustained full-rate noisy reception on the 6-core/12-thread host.
    # Preserve the parent's affinity and the explicit environment override.
    if sys.platform != "win32":
        return None
    default = 8 if channel_count >= 64 else 0
    try:
        limit = max(0, int(os.environ.get("STD_T98_RF_CPU_LIMIT", str(default))))
    except ValueError:
        limit = default
    if not limit:
        return None
    kernel = ctypes.windll.kernel32
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
    kernel.SetProcessAffinityMask.argtypes = [ctypes.c_void_p,ctypes.c_size_t]
    kernel.GetLogicalProcessorInformation.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
    process = kernel.GetCurrentProcess()
    allowed, system = ctypes.c_size_t(), ctypes.c_size_t()
    if not kernel.GetProcessAffinityMask(process, ctypes.byref(allowed), ctypes.byref(system)):
        return None
    processors = [bit for bit in range(ctypes.sizeof(allowed)*8) if allowed.value & (1 << bit)]
    selected = _spread(processors, _physical_cores(kernel))[:limit]
    if len(selected) < len(processors):
        mask = sum(1 << bit for bit in selected)
        if not kernel.SetProcessAffinityMask(process, mask):
            return None
    return len(selected)
