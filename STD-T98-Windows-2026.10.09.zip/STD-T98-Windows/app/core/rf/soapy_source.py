"""Opening and configuring the SoapySDR source.

Kept out of :mod:`core.rf.backend_config`, which stays importable without GNU
Radio, and shared by the backend flowgraph and the diagnostic scope so both get
identical device handling: the driver-aware defaults, the capability fallbacks
for devices without named gains / AGC / bias tee, and above all the sample-rate
checks. A tool that configures the device slightly differently from the backend
is a tool that cannot be trusted to diagnose the backend.
"""

from __future__ import annotations

import sys

from gnuradio import soapy

from core.rf.backend_config import nearest_sample_rates
from core.rf.hackrf_gain import HackRFGains


class ConfiguredSource:
    """A SoapySDR source plus the runtime setters that depend on its
    capabilities."""

    def __init__(self, source, gain_element, driver=None):
        self.source = source
        self.gain_element = gain_element
        self.is_hackrf = driver == "hackrf"
        self.hackrf_gains = None

        self.setting_keys = [a.key for a in source.get_setting_info()]
        try:
            self.gain_names = list(source.list_gains(0))
        except Exception:
            self.gain_names = []
        try:
            self.has_agc = bool(source.has_gain_mode(0))
        except Exception:
            self.has_agc = True

        self._gain_value = 0.0
        if self.is_hackrf:
            self.has_agc = False
            if not {"LNA", "VGA", "AMP"}.issubset(self.gain_names):
                raise RuntimeError("HackRF driver must expose LNA, VGA and AMP gain controls")
            self._amp_on_value = source.get_gain_range(0, "AMP").maximum()
            if self._amp_on_value <= 0:
                raise RuntimeError("HackRF driver does not advertise an AMP on value")

    # -- runtime controls ---------------------------------------------------
    def apply_manual_gain(self, channel, gain):
        """Prefer a named gain element when the device (and config) name one;
        fall back to the overall gain otherwise."""
        if self.is_hackrf:
            self.set_hackrf_gains(channel, HackRFGains.from_total(gain))
        elif self.gain_element and self.gain_element in self.gain_names:
            self.source.set_gain(channel, self.gain_element, gain)
        else:
            self.source.set_gain(channel, gain)

    def read_hackrf_gains(self, channel=0):
        return HackRFGains(
            int(self.source.get_gain(channel, "LNA")),
            int(self.source.get_gain(channel, "VGA")),
            bool(self.source.get_gain(channel, "AMP") > 0),
        )

    def set_hackrf_gains(self, channel, gains):
        if not self.is_hackrf:
            raise ValueError("Individual LNA/VGA/AMP controls require HackRF")
        old = self.read_hackrf_gains(channel)
        requested = {"LNA": gains.lna, "VGA": gains.vga,
                     "AMP": self._amp_on_value if gains.amp else 0}
        previous = {"LNA": old.lna, "VGA": old.vga,
                    "AMP": self._amp_on_value if old.amp else 0}
        # Apply reductions before increases, with AMP off first / on last.
        order = [name for name in ("AMP", "VGA", "LNA") if requested[name] < previous[name]]
        order += [name for name in ("LNA", "VGA", "AMP") if requested[name] > previous[name]]
        for name in order:
            self.source.set_gain(channel, name, requested[name])
        actual = self.read_hackrf_gains(channel)
        self.hackrf_gains = actual
        self._gain_value = actual.total_db
        if actual != gains:
            raise RuntimeError(f"HackRF gain readback differs: requested {gains}, driver reports {actual}")
        return actual

    def set_gain_mode(self, channel, agc):
        # Not every SoapySDR device exposes an automatic gain mode.
        if not self.has_agc:
            return
        self.source.set_gain_mode(channel, agc)
        if not agc:
            self.apply_manual_gain(channel, self._gain_value)

    def set_gain(self, channel, gain):
        self._gain_value = gain
        if self.has_agc and self.source.get_gain_mode(channel):
            return
        self.apply_manual_gain(channel, gain)

    def set_bias(self, enabled):
        # Same switch, driver-specific names: SoapyRTLSDR "biastee",
        # SoapyHackRF "bias_tx" (antenna port power).
        keys = [key for key in ("biastee", "bias_tx") if key in self.setting_keys]
        for key in keys:
            self.source.write_setting(key, enabled)
        if enabled and not keys:
            print("Bias tee requested but this device has no bias-tee setting.", file=sys.stderr, flush=True)


def _resolve_sample_rate(source, requested):
    """Return the rate to actually ask the device for.

    Devices advertise exact values such as 8e6/7 = 1230769.230769 and refuse
    anything else, so a user typing the rounded figure is snapped onto the
    advertised one rather than rejected. If nothing matches, the error names
    the nearest supported rates -- the raw device list runs to hundreds of
    entries, which is no answer to "what should I use?".
    """
    try:
        ranges = source.get_sample_rate_range(0)
    except Exception:
        return requested  # Driver does not advertise its rates.

    if not ranges:
        return requested

    tolerance = max(1.0, requested * 1e-6)
    discrete = []
    for entry in ranges:
        low, high = entry.minimum(), entry.maximum()
        if low == high:
            discrete.append(low)
            if abs(requested - low) <= tolerance:
                return low
        elif low <= requested <= high:
            return requested

    if not discrete:
        return requested  # Continuous ranges only; let Soapy complain.

    suggestions = nearest_sample_rates(discrete, requested)
    raise ValueError(
        f"This device cannot sample at {requested:.0f} Hz. "
        "Nearest rates this device supports: "
        + ", ".join(f"{rate:.0f}" for rate in suggestions)
    )


def _set_antenna(source, antenna):
    """Select an RX port, refusing an unavailable name up front.

    Getting this wrong produces no error and no warning at runtime -- just a
    receiver that never hears anything -- so it is worth failing loudly.
    """
    try:
        available = list(source.list_antennas(0))
    except Exception:
        available = []
    if available and antenna not in available:
        raise ValueError(
            f"Antenna {antenna!r} is not available on this device. "
            f"Choose one of: {available}"
        )
    source.set_antenna(0, antenna)


def open_source(sdr_cfg) -> ConfiguredSource:
    """Open and fully configure the source described by ``sdr_cfg``."""
    try:
        source = soapy.source(
            sdr_cfg.device_string(), "fc32", 1, "",
            sdr_cfg.resolved_stream_args(), [""], [""],
        )
    except RuntimeError as exc:
        # SoapySDR only says e.g. "no hackrf device matches"; name what was asked for.
        raise RuntimeError(
            f"Cannot open SDR '{sdr_cfg.device_string()}': {exc}. "
            "Check that it is connected, that no other program is using it, "
            "and (if the profile names a serial) that it is the assigned unit."
        ) from exc
    configured = ConfiguredSource(
        source,
        sdr_cfg.gain_element,
        sdr_cfg.driver,
    )
    source = configured.source

    # Only touch the antenna when asked: single-input devices have nothing to
    # select, and the driver's own default is right for most others.
    if sdr_cfg.antenna:
        _set_antenna(source, sdr_cfg.antenna)

    requested = sdr_cfg.sample_rate
    source.set_sample_rate(0, _resolve_sample_rate(source, requested))
    # Some drivers round instead of refusing. The channelizer geometry is
    # derived from the requested rate, so a silent substitution would mistune
    # every channel.
    actual = source.get_sample_rate(0)
    if abs(actual - requested) > max(1.0, requested * 1e-6):
        raise ValueError(
            f"Device serves {actual:.0f} Hz, not the requested "
            f"{requested:.0f} Hz. Re-run with --sample-rate {actual:.0f} so "
            "the channelizer matches, or pick a rate the device supports "
            "exactly."
        )

    bandwidth = sdr_cfg.resolved_bandwidth()
    if bandwidth:
        try:
            source.set_bandwidth(0, bandwidth)
        except Exception:
            # Not every device exposes a tunable analog filter.
            pass

    source.set_frequency(0, sdr_cfg.tuned_freq())
    if sdr_cfg.freq_correction:
        try:
            source.set_frequency_correction(0, sdr_cfg.freq_correction)
        except Exception:
            pass

    configured.set_bias(bool(sdr_cfg.bias_tee))
    if configured.is_hackrf:
        configured.set_hackrf_gains(0, sdr_cfg.resolved_hackrf_gains())
    else:
        configured._gain_value = sdr_cfg.tuner_gain
        configured.set_gain_mode(0, bool(sdr_cfg.agc))
        configured.set_gain(0, sdr_cfg.tuner_gain)

    return configured
