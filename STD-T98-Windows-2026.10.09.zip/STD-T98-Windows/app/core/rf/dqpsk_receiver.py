"""Optional GNU Radio IQ branch with a bounded, independent analysis worker."""
from fractions import Fraction
import argparse
import queue
import threading
import time
import numpy as np


def add_arguments(parser):
    parser.add_argument('--dqpsk-rtcm', action='store_true', help='Enable observed pi/4-DQPSK / PN9 / RTCM3 profile')
    parser.add_argument('--dqpsk-frequencies', default='351.200', help='1–8 target frequencies in MHz, comma separated')
    parser.add_argument('--dqpsk-dir', default='std98_data/dqpsk', help='Distribution-relative data directory')
    parser.add_argument('--dqpsk-no-iq', action='store_true', help='Disable channel IQ recording')
    parser.add_argument('--dqpsk-no-save', action='store_true', help='Analyse only; disable all recordings')
    parser.add_argument('--rf-stop-file', help=argparse.SUPPRESS)


def attach(tb, args):
    if not args.dqpsk_rtcm:
        return []
    from gnuradio import gr, filter
    from core.analysis.dqpsk_rtcm import FS, BurstReceiver, SessionRecorder, parse_frequencies
    from core.audio.data_paths import resolve_data_dir
    from core.pipeline.runtime_status import StatusPublisher
    from ipc.message_schema import STATUS_SOURCE_RF
    from ipc.transport.uds_seqpacket import resolve_status_socket_path

    frequencies = parse_frequencies(args.dqpsk_frequencies)
    rate = tb.samp_rate_post_resamp1
    center = tb.rf_freq + tb.freq_offset
    from core.rf.dqpsk_options import validate_bandwidth
    validate_bandwidth(frequencies, center, rate)
    directory = resolve_data_dir(args.dqpsk_dir)
    branches = []

    class Sink(gr.sync_block):
        def __init__(self, frequency):
            gr.sync_block.__init__(self, name='dqpsk_rtcm', in_sig=[np.complex64], out_sig=[])
            self.queue = queue.Queue(maxsize=24)
            self.stopping = threading.Event()
            self.offset = 0
            self.expected = 0
            sdr = tb.config.sdr
            self.record = SessionRecorder(directory, frequency, save_iq=not args.dqpsk_no_iq and not args.dqpsk_no_save,
                save_data=not args.dqpsk_no_save, metadata=dict(center_hz=center, input_sample_rate_hz=rate,
                gain_db=sdr.tuner_gain, auto_gain=sdr.resolved_auto_gain(), ppm=sdr.freq_correction,
                frequency_correction_hz=tb.freq_err_offset, driver=sdr.driver,
                source='replay' if tb.replay else 'remote_iq' if tb.remote_iq else 'SDR'))
            self.receiver = BurstReceiver(self.record.consume)
            self.publisher = StatusPublisher(resolve_status_socket_path(channel_count=tb.num_channels), STATUS_SOURCE_RF)
            self.thread = threading.Thread(target=self.run, name='DQPSK analysis', daemon=True)
            self.thread.start()

        def work(self, inputs, outputs):
            z = inputs[0]
            if not self.stopping.is_set():
                try:
                    self.queue.put_nowait((self.offset, z.copy()))
                except queue.Full:
                    pass  # the next accepted offset explicitly records the gap
            self.offset += len(z)
            return len(z)

        def run(self):
            last_publish = 0
            try:
                while not self.stopping.is_set() or not self.queue.empty():
                    try:
                        offset, z = self.queue.get(timeout=.1)
                    except queue.Empty:
                        continue
                    gap = offset - self.expected
                    self.expected = offset + len(z)
                    if gap:
                        self.receiver.reset()
                        self.receiver.sample_offset = offset
                    self.record.feed_iq(z, gap)
                    self.receiver.feed(z)
                    if time.monotonic() - last_publish >= 1:
                        self.record._write_metadata()
                        self.publisher.publish(payload_dict={'dqpsk': self.record.snapshot()})
                        last_publish = time.monotonic()
                if self.offset > self.expected:
                    self.receiver.reset()
                    self.record.feed_iq(np.empty(0, np.complex64), self.offset - self.expected)
                self.receiver.close()
            except Exception as exc:
                self.record.error = str(exc)
                self.stopping.set()
                print(f'DQPSK analysis failed: {exc}', flush=True)
            finally:
                try:
                    self.record.close()
                finally:
                    self.publisher.publish(payload_dict={'dqpsk': self.record.snapshot()})
                    self.publisher.close()

        def close(self):
            self.stopping.set()
            self.thread.join(timeout=15)
            if self.thread.is_alive():
                print('DQPSK worker did not finish within 15 seconds', flush=True)

    try:
        for frequency in frequencies:
            decimation = max(1, int(rate // 96000))
            taps = filter.firdes.low_pass(1, rate, 9000, 3000)
            translator = filter.freq_xlating_fir_filter_ccc(decimation, taps, frequency - center, rate)
            ratio = Fraction(FS * decimation / rate).limit_denominator(100000)
            resampler = filter.rational_resampler_ccc(interpolation=ratio.numerator, decimation=ratio.denominator)
            sink = Sink(frequency)
            branches.append((translator, resampler, sink))
            tb.connect(tb._correct_iq, translator, resampler, sink)
    except Exception:
        close(branches)
        raise
    print('DQPSK/RTCM enabled: ' + ', '.join(f'{f / 1e6:.6f} MHz' for f in frequencies), flush=True)
    return branches


def close(branches):
    for _, _, sink in branches:
        sink.stopping.set()
    for _, _, sink in branches:
        sink.close()
