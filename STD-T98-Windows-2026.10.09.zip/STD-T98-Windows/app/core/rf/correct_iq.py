"""Native DC correction with a live bypass, independent of RF lifecycle."""
from gnuradio import blocks, gr


class CorrectIQ(gr.hier_block2):
    def __init__(self, enabled=True):
        gr.hier_block2.__init__(self, "correct_iq_switch",
            gr.io_signature(1, 1, gr.sizeof_gr_complex), gr.io_signature(1, 1, gr.sizeof_gr_complex))
        self.correction = blocks.correctiq()
        self.dc_estimate = blocks.sub_cc()
        self.scale = blocks.multiply_const_cc(1 if enabled else 0)
        self.output = blocks.sub_cc()
        # Synchronous arithmetic keeps both paths at the same sample index.
        # A selector can consume its unselected input at a different pace,
        # creating a time jump when the selected port is changed live.
        self.connect(self, (self.dc_estimate, 0))
        self.connect(self, self.correction, (self.dc_estimate, 1))
        self.connect(self.dc_estimate, self.scale, (self.output, 1))
        self.connect(self, (self.output, 0))
        self.connect(self.output, self)
        self.enabled = bool(enabled)

    def set_enabled(self, enabled):
        self.enabled = bool(enabled)
        self.scale.set_k(1 if self.enabled else 0)
