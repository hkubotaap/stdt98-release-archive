"""Lightweight frequency validation, also usable without optional RF DSP."""
import math


def parse_frequencies(text):
    values = tuple(dict.fromkeys(float(x.strip()) * 1e6 for x in text.split(',') if x.strip()))
    if not values or len(values) > 8 or any(not math.isfinite(x) or x <= 0 for x in values):
        raise ValueError('対象周波数をMHzで1～8件指定してください（カンマ区切り）。')
    return values


def validate_bandwidth(frequencies, center, rate):
    for frequency in frequencies:
        if abs(frequency - center) + 12000 >= rate / 2:
            raise ValueError(f'対象 {frequency / 1e6:.6f} MHz はIQ受信範囲外です（中心 {center / 1e6:.6f} MHz、帯域幅 {rate / 1e6:.6f} MHz）。SDRの中心周波数または対象周波数を変更してください。')
