"""AMBE 3600x2450 FEC/bit helpers, backed by the independent AMBE+2 decoder.

mbelib is no longer used. The Golay(24,12)/Golay(23,12)+PN de-FEC and the ThumbDV
(2450) bit ordering come from the bundled ``ambe2`` package (core.audio.independent_ambe),
verified bit-identical to the old mbelib path on random blocks.
"""
from dataclasses import dataclass

from core.audio.independent_ambe import _load as _ambe2_module, load_error


@dataclass(frozen=True)
class FecResult:
    payload: bytes        # 7-byte AMBE2450 (ThumbDV / T49 order)
    c0_errors: int
    total_errors: int

    @property
    def bad(self):
        return self.c0_errors >= 4 or (self.c0_errors >= 2 and self.total_errors >= 6)


def _bitio():
    module = _ambe2_module()
    if module is None:
        raise ImportError(load_error() or "independent AMBE+2 decoder not available")
    return module.bitio


def bits_to_bytes(bits):
    result = []
    for index in range(0, len(bits), 8):
        byte_val = 0
        chunk_len = min(8, len(bits) - index)
        for bit_offset in range(chunk_len):
            byte_val = (byte_val << 1) | bits[index + bit_offset]
        if chunk_len < 8:
            byte_val <<= 8 - chunk_len
        result.append(byte_val)
    return result


def fec_demod_to_2450_payload(payload_3600: bytes) -> bytes:
    """9-byte 3600 block (DIBIT36 order) -> 7-byte 2450 parameters (ThumbDV order)."""
    try:
        bitio = _bitio()
        u = bitio.fec_decode(bitio.dibit36_to_c(bytes(payload_3600))).u
        return bitio.info49_to_t49(bitio.u_to_info49(u))
    except Exception:
        return b"\x00" * 7


def fec_demod_with_errors(payload: bytes) -> FecResult:
    """Golay de-FEC of a 9-byte 3600 block: 2450 payload plus the hard-decision
    error distances (c0 = e0, total = e0 + e1) from FEC-HARD-P23-v1."""
    if len(payload) != 9:
        raise ValueError("AMBE3600 payload must be 9 bytes.")
    bitio = _bitio()
    res = bitio.fec_decode(bitio.dibit36_to_c(bytes(payload)))
    payload_2450 = bitio.info49_to_t49(bitio.u_to_info49(res.u))
    return FecResult(payload_2450, res.e0, res.e0 + res.e1)


def payloads_3600_to_2450(payloads_3600):
    return [fec_demod_to_2450_payload(payload) for payload in payloads_3600]
