"""Portable data settings, resolved against the distribution rather than cwd."""
import os
from pathlib import Path

DEFAULT_DATA_DIRECTORY = "std98_data"


def distribution_root(repo_root=None):
    app = Path(repo_root) if repo_root is not None else Path(__file__).parents[2]
    return Path(os.path.abspath(app)).parent


def resolve_data_dir(value=None, repo_root=None):
    directory = Path(value or DEFAULT_DATA_DIRECTORY).expanduser()
    if directory.drive and not directory.is_absolute():
        raise ValueError("Use a full drive path or a distribution-relative path")
    if not directory.is_absolute():
        directory = distribution_root(repo_root)/directory
    return Path(os.path.abspath(directory))


def data_dir_setting(value, repo_root=None):
    directory = resolve_data_dir(value, repo_root)
    try:
        relative = directory.relative_to(distribution_root(repo_root))
    except ValueError:
        return str(directory)  # An explicitly selected external library stays external.
    return os.path.join(".", str(relative)) if str(relative) != "." else "."


def restore_data_dir(value=None, repo_root=None, mode=None):
    """Migrate the old default absolute path, preserving marked custom locations."""
    directory = Path(value or DEFAULT_DATA_DIRECTORY).expanduser()
    if (mode not in ("relative", "absolute") and directory.is_absolute()
            and directory.name.lower() == DEFAULT_DATA_DIRECTORY
            and directory.parent.name.lower() in
                {distribution_root(repo_root).name.lower(), "std-t98_grport_win"}):
        return resolve_data_dir(DEFAULT_DATA_DIRECTORY, repo_root)
    return resolve_data_dir(directory, repo_root)
