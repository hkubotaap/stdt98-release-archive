"""Pitch-based packet loss concealment for 8 kHz decoded speech ("pitch_plc").

After G.711 Appendix I: a gap is filled by repeating the last pitch period(s)
of the speech already played (1 period, then 2 and 3 to avoid a buzz). The
filler starts one period back so it continues
the waveform's phase; it holds full level briefly and then fades out. When
speech resumes, its first samples are cross-faded from the filler's
continuation, so neither edge of the gap clicks. Unlike repeating 20 ms
blocks with faded edges, this adds no 50 Hz amplitude modulation.
"""
import numpy as np


RATE = 8000
MIN_PITCH = 20          # 400 Hz
MAX_PITCH = 140         # ~57 Hz
CORRELATION_WINDOW = 160
HISTORY = 3 * MAX_PITCH + CORRELATION_WINDOW
HOLD_SAMPLES = 320      # full level for the first 40 ms
FADE_SAMPLES = 640      # then a linear fade to silence 80 ms later
PERIOD_STEPS = (80, 160)  # use 2 periods after 10 ms, 3 after 20 ms
RECOVERY_SAMPLES = 40   # 5 ms cross-fade into the resumed speech


def estimate_pitch(history):
    """Lag in MIN_PITCH..MAX_PITCH with the highest normalised correlation
    of the last CORRELATION_WINDOW samples."""
    x = np.asarray(history, dtype=np.float64)
    target = x[-CORRELATION_WINDOW:]
    best_lag, best = MIN_PITCH, -np.inf
    target_energy = float(target @ target) + 1e-9
    for lag in range(MIN_PITCH, MAX_PITCH + 1):
        past = x[-CORRELATION_WINDOW - lag:-lag]
        score = float(target @ past) / np.sqrt(target_energy * (float(past @ past) + 1e-9))
        if score > best:
            best_lag, best = lag, score
    return best_lag


class PitchConcealer:
    def __init__(self):
        self.reset()

    def reset(self):
        self.history = np.zeros(0)
        self.lost = 0          # samples concealed in the current gap
        self.period = None
        self.position = 0
        self.periods = 1

    @property
    def ready(self):
        return len(self.history) >= HISTORY

    def push(self, pcm):
        """Record decoded speech; right after a gap, cross-fade its start
        from the filler. Returns the PCM to play."""
        pcm = np.asarray(pcm, dtype=np.float64)
        if self.lost and self.period and len(pcm):
            n = min(RECOVERY_SAMPLES, len(pcm))
            tail = self._synthesize(n, advance=False)
            ramp = (np.arange(n) + 1) / (n + 1)
            pcm = pcm.copy()
            pcm[:n] = pcm[:n] * ramp + tail * (1 - ramp)
        self.lost = 0
        self.period = None
        self.history = np.concatenate((self.history, pcm))[-HISTORY:]
        return pcm

    def conceal(self, count):
        """``count`` samples of filler (silence without enough history)."""
        if not self.ready:
            return np.zeros(count)
        if self.period is None:
            self.period = estimate_pitch(self.history)
            self.position = 0
            self.periods = 1
        return self._synthesize(count, advance=True)

    def _buffer(self, periods):
        return self.history[-periods * self.period:]

    def _synthesize(self, count, advance):
        out = np.empty(count)
        lost, position, periods = self.lost, self.position, self.periods
        for k in range(count):
            want = 1 + sum(lost >= step for step in PERIOD_STEPS)
            if want != periods:
                # The longer buffer ends with the same last period, so this
                # keeps the current sample; only later cycles reach further back.
                position = (want - 1) * self.period + position % self.period
                periods = want
            buffer = self._buffer(periods)
            gain = 1.0 if lost < HOLD_SAMPLES else max(0.0, 1.0 - (lost - HOLD_SAMPLES) / FADE_SAMPLES)
            out[k] = buffer[position % len(buffer)] * gain
            position += 1
            lost += 1
        if advance:
            self.lost, self.position, self.periods = lost, position, periods
        return out
