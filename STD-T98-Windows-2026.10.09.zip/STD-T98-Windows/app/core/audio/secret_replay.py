"""Disk-backed encrypted-call history, decoded at speaker speed after key search."""
import struct
import tempfile
import threading

from core.audio.voice_playback import VoicePlayback
from ipc.message_schema import VoiceBurstPacket


class SecretReplayCall:
    def __init__(self, channel_id, session_id, decoder_factory=VoicePlayback):
        self.channel_id = channel_id
        self.session_id = session_id
        self.key = 0
        self.secret = False
        self.finished = False
        self.pending_search = False
        self.closed = False
        self.options = {}
        self.written = self.read_count = 0
        self._read_offset = 0
        self._stream = tempfile.TemporaryFile(prefix="std98-secret-replay-")
        self._lock = threading.RLock()
        self._decoder_factory = decoder_factory
        self._decoder = None

    @property
    def queued(self):
        with self._lock:
            return self.written - self.read_count

    @property
    def ready(self):
        with self._lock:
            return not self.closed and self.secret and self.key > 0 and self.written > self.read_count

    def append(self, packet, options):
        payload = packet.encode()
        with self._lock:
            if self.closed or self.finished:
                return
            self._stream.seek(0, 2)
            self._stream.write(struct.pack("<I", len(payload)))
            self._stream.write(payload)
            self.written += 1
            self.options = dict(options)

    def set_key(self, key):
        with self._lock:
            if 0 < key <= 32767:
                self.key = key

    def finish(self):
        with self._lock:
            self.finished = True

    def close(self):
        with self._lock:
            if not self.closed:
                self.closed = True
                self._stream.close()

    def pop(self):
        with self._lock:
            if not self.ready:
                return None
            self._stream.seek(self._read_offset)
            size = struct.unpack("<I", self._stream.read(4))[0]
            packet = VoiceBurstPacket.decode(self._stream.read(size))
            self._read_offset = self._stream.tell()
            self.read_count += 1
            return packet, self.key, dict(self.options)

    def render(self, item):
        # Only the output thread constructs/uses this native decoder. It is
        # separate from the live recording decoder and keeps history in order.
        if self._decoder is None:
            self._decoder = self._decoder_factory()
            self._decoder.secret = True
        packet, key, options = item
        pcm, _ = self._decoder.decode(packet, key, options)
        return self._decoder.upsample(pcm, hq=options.get("hq_resampler", True))
