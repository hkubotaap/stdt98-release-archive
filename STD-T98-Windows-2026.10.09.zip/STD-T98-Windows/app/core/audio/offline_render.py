"""Re-render a saved recording through the live voice chain (listening tool).

The listening tool decodes .t98raw files with its own simple path. This
renders them the way the audio service plays them live: VoicePlayback with
the user's audio settings, lost-frame fill, the recovered-burst gate and the
8 -> 48 kHz upsampler, so the live options can be switched on a recording
and compared. Each render creates a fresh independent AMBE+2 decoder with
deterministic synthesis noise, so two renders differ only by their options.

Per-frame side data comes from the recording's edu (.jsonl) rows: SACCH CRC,
RICH parity/mode, "missed" (lost slots before the frame) and, for recordings
made since 2026-10-04, "soft_fec" and "recovered". Without those, the
soft-decision and recovery options cannot change anything (see available()).
"""
import json

import numpy as np

from core.audio.recovery import gate_recovered
from core.audio.voice_playback import INITIAL_SPEECH_AGC_GAIN, VoicePlayback
from core.protocol.voice_gaps import MAX_FILLED_FRAMES
from ipc.message_schema import VOICE_FORMAT_RAW_3600, VoiceBurstPacket

FRAME_SEC = 0.08
UPSAMPLE_FACTOR = 6
# (option, short label) of the live options the listening tool can switch.
LIVE_OPTIONS = (
    ("hq_resampler", "高品質変換"),
    ("soft_voice_fec", "軟判定"),
    ("pitch_plc", "周期補間"),
    ("flywheel_recovery", "取りこぼし再生"),
)
# Options that are off unless chosen (the rest default on, like the live settings).
LIVE_OPTION_DEFAULTS = {}


def load_edu_rows(edu_path):
    """The edu rows of the recorded (F=1) frames, in .t98raw order."""
    rows = []
    try:
        with open(edu_path, encoding="utf-8-sig") as stream:
            for line in stream:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if row.get("type") == "frame" and row.get("F") == 1:
                    rows.append(row)
    except OSError:
        return None
    return rows


def available(edu_rows):
    """Which data-dependent options this recording can show: soft-decision
    blocks and recovered frames exist only in recordings made with them."""
    rows = edu_rows or []
    return {
        "soft_voice_fec": any(row.get("soft_fec") for row in rows),
        "flywheel_recovery": any(row.get("recovered") for row in rows),
        "pitch_plc": any(row.get("missed") or not (row.get("sacch") or {}).get("crcOK", True) for row in rows),
    }


def _seed(seed):
    # The independent decoder is deterministic (fixed-seed LCG noise per fresh
    # decoder), so renders are already repeatable; nothing to reseed.
    pass


def _packet(index, payload, row, secret):
    if row is None:
        quality = {"crc_ok": True, "parity_ok": True, "mode": 3}
        call_stat = 1 if secret else 0
    else:
        rich, sacch = row.get("rich") or {}, row.get("sacch") or {}
        quality = {"crc_ok": bool(sacch.get("crcOK", True)), "parity_ok": bool(rich.get("parityOK", True)),
                   "mode": rich.get("M", 3), "missed": int(row.get("missed", 0) or 0)}
        if row.get("soft_fec"):
            quality["soft_fec"] = row["soft_fec"]
        if row.get("recovered"):
            quality["recovered"] = True
        call_stat = 1 if secret is True else 0 if secret is False else int(sacch.get("callStat") or 0)
    return VoiceBurstPacket(index, 1, call_stat, 0, index, VOICE_FORMAT_RAW_3600, payload, quality)


def render(frames, edu_rows, key, options, secret=None, seed=1):
    """Render ``frames`` (post_decode.read_raw: [[payload9 x 4], ...]) with
    ``options`` (audio settings incl. the live options). ``edu_rows`` must be
    1:1 with ``frames`` or None. Returns (pcm 8 kHz, pcm 48 kHz) as int16."""
    out8, out48 = [], []
    for pcm8, pcm48 in render_chunks(frames, edu_rows, key, options, secret, seed):
        out8.append(pcm8)
        out48.append(pcm48)
    if not out8:
        return np.zeros(0, dtype=np.int16), np.zeros(0, dtype=np.int16)
    return np.concatenate(out8), np.concatenate(out48)


def max_frames(frames, edu_rows):
    """Upper bound of the 80 ms frames render() outputs (received + filled lost)."""
    if edu_rows is None or len(edu_rows) != len(frames):
        return len(frames)
    filled = sum(min(MAX_FILLED_FRAMES, int(row.get("missed", 0) or 0)) for row in edu_rows)
    return len(frames) + filled + sum(1 for row in edu_rows if row.get("recovered")) + 1


def render_chunks(frames, edu_rows, key, options, secret=None, seed=1, chunk_frames=25,
                  first_chunk_frames=None):
    """render() in pieces of about ``chunk_frames`` frames (2 s), yielding
    (pcm 8 kHz, pcm 48 kHz) as each piece is ready, so playback can start early.
    The concatenated output is identical to render(). ``first_chunk_frames``
    can shorten the first piece for interactive playback."""
    limit = max(1, int(first_chunk_frames or chunk_frames))
    if edu_rows is not None and len(edu_rows) != len(frames):
        edu_rows = None  # not aligned: no per-frame quality
    _seed(seed)
    decoder = VoicePlayback(agc_gain=INITIAL_SPEECH_AGC_GAIN)
    hq = options.get("hq_resampler", True)
    unplayed = {}
    out8, out48 = [], []

    def emit(pcm):
        if len(pcm):
            out8.append(np.asarray(pcm, dtype=np.int16))
            out48.append(np.frombuffer(decoder.upsample(pcm, UPSAMPLE_FACTOR, hq), dtype="<i2"))

    for index, blocks in enumerate(frames):
        payload = b"".join(blocks)
        if len(payload) != 36:
            continue
        packet = _packet(index, payload, edu_rows[index] if edu_rows else None, secret)
        packet = gate_recovered(packet, options, unplayed, index * FRAME_SEC)
        if packet is None:
            continue
        if options.get("fill_lost_frames", True):
            missed = min(MAX_FILLED_FRAMES, int(packet.quality.get("missed", 0) or 0))
            if missed:
                emit(decoder.conceal_missing(missed, options))
        pcm, _ = decoder.decode(packet, key, options)
        emit(pcm)
        if len(out8) >= limit:
            yield np.concatenate(out8), np.concatenate(out48)
            out8, out48 = [], []
            limit = max(1, int(chunk_frames))
    if out8:
        yield np.concatenate(out8), np.concatenate(out48)
