"""The independent AMBE+2 voice decoder: the only codec for STD-T98 voice.

The decoder is bundled at app/vendor/ambe2 (built from AMBE2_DECODER_SPEC.md,
profile HR-PUBLIC-ALLFRAMES-v1). STD_T98_AMBE2_PATH overrides the location;
D:\\ai\\ambe\\impl is a development fallback. If the codec cannot be imported,
VoicePlayback reports "Decoder unavailable" and preserves timing with silence.

The C port (ambe2.fast, built with tools/build_c.py) is used when present; it is
output-identical to the Python reference and about 15x faster. STD_T98_AMBE2_BACKEND
=python forces the Python reference.

The codec keeps its own repeat/mute state across frames, so it must
see every 20 ms of the call in order: lost bursts go in as MISSING_20MS events
before the burst that follows them. Channel quality is always the codec's own hard
FEC distance of the received 72-bit block (spec §4.1.1), never mbelib's counts.
"""
import importlib
import os
import sys

import numpy as np

# The decoder is bundled at app/vendor/ambe2 (synced from its reference source by
# D:\ai\ambe\impl\tools\sync_to_app.py). The app imports that copy, so it is
# self-contained. STD_T98_AMBE2_PATH overrides the location (e.g. to the reference
# source for development).
_APP = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BUNDLED_PATH = os.path.join(_APP, "vendor")
REFERENCE_PATH = r"D:\ai\ambe\impl"
_module = None
_load_error = None


def _load():
    global _module, _load_error
    if _module is None and _load_error is None:
        override = os.environ.get("STD_T98_AMBE2_PATH")
        # Override, else the bundled copy, else the reference source.
        paths = [override] if override else [BUNDLED_PATH, REFERENCE_PATH]
        for path in reversed(paths):             # first entry ends up first on sys.path
            if path and path not in sys.path:
                sys.path.insert(0, path)
        try:
            _module = importlib.import_module("ambe2")
        except ImportError as exc:
            _load_error = f"{type(exc).__name__}: {exc}"
    return _module


def available():
    return _load() is not None


def load_error():
    _load()
    return _load_error


def backend():
    """"c" when the C port is used, "python" for the reference, None if unavailable."""
    module = _load()
    if module is None:
        return None
    return "c" if _decoder_class(module).__module__.endswith(".fast") else "python"


def _decoder_class(module):
    if os.environ.get("STD_T98_AMBE2_BACKEND", "").lower() != "python":
        try:
            fast = importlib.import_module("ambe2.fast")
            if fast.available():
                return fast.Decoder
        except (ImportError, OSError):
            pass
    return module.Decoder


class IndependentAmbe:
    """One call's codec stream. Every method returns (int16[160], action)."""

    def __init__(self):
        module = _load()
        if module is None:
            raise ImportError(_load_error)
        self._mod = module
        self.decoder = _decoder_class(module)()
        self.input_errors = 0
        self.soft_rejects = 0
        self.last_meta = None       # metadata of the last frame (action, b, quality ...)

    def _run_strict(self, **kwargs):
        r = self.decoder.decode(**kwargs)
        self.last_meta = r.meta
        return r.pcm, r.meta["action"]

    def _run(self, **kwargs):
        try:
            r = self.decoder.decode(**kwargs)
        except (self._mod.InputInvalid, self._mod.NumericInvalid):
            # The frame is unusable; keep the 20 ms timing as an explicit loss.
            self.input_errors += 1
            r = self.decoder.decode(missing=True)
        self.last_meta = r.meta
        return r.pcm, r.meta["action"]

    def decode_raw(self, block, soft_block=None):
        """A received 72-bit block (9 bytes, DIBIT36 order as recorded in .t98raw).
        ``soft_block``: the soft-decision codeword of it (protocol service "soft_fec");
        the codec then takes the parameters from it and rates the frame by its
        distance to the received bits (HR-PUBLIC-ALLFRAMES-SOFT-v1)."""
        if soft_block is not None:
            try:
                return self._run_strict(data=bytes(block), fmt="DIBIT36", soft_codeword=bytes(soft_block))
            except self._mod.InputInvalid:
                self.soft_rejects += 1          # not a codeword of this block: use the hard bits
        return self._run(data=bytes(block), fmt="DIBIT36")

    def _quality(self, raw_block, soft_block):
        bitio = self._mod.bitio
        c = bitio.dibit36_to_c(bytes(raw_block))
        if soft_block is not None:
            try:
                return bitio.soft_fec_decode(c, bitio.dibit36_to_c(bytes(soft_block)))
            except self._mod.InputInvalid:
                self.soft_rejects += 1
        return self._mod.fec_decode(c)

    def decode_info(self, payload_t49, raw_block, soft_block=None):
        """49 parameter bits in ThumbDV (T49) order, e.g. after secret descrambling,
        with the channel quality of the 72-bit block they came from (distance to the
        soft codeword when ``soft_block`` is given)."""
        report = self._quality(raw_block, soft_block)
        payload = bytes(payload_t49[:6]) + bytes([payload_t49[6] & 0x80])
        return self._run(data=payload, fmt="T49", quality=(report.e0, report.e1, report.failure))

    def decode_clean(self, payload_t49):
        """49 bits with no channel quality (2450 packets): declared error-free."""
        payload = bytes(payload_t49[:6]) + bytes([payload_t49[6] & 0x80])
        return self._run(data=payload, fmt="T49", declared_clean=True)

    def missing(self, frames20):
        """`frames20` lost 20 ms frames -> PCM (repeat, then comfort noise)."""
        out = [self._run(missing=True)[0] for _ in range(int(frames20))]
        return np.concatenate(out) if out else np.zeros(0, dtype=np.int16)
