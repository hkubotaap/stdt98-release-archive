"""Gate for flywheel-recovered voice bursts (quality["recovered"]).

Shared by the live audio service and the offline renderer of the listening
tool, so both treat "flywheel_recovery" off the same way.
"""
import dataclasses

from core.protocol.voice_gaps import MAX_FILLED_FRAMES

# Dropped flywheel-recovered bursts this recent belong to the same call as the
# next burst (the protocol service's VoiceGapTracker same-call window).
RECOVERED_SAME_CALL_SEC = 1.1


def gate_recovered(packet, options, unplayed, now):
    """Flywheel-recovered bursts play only with "flywheel_recovery" (None:
    drop). Dropped ones go back into the next burst's lost count, so playback,
    fill and recordings stay as without them; ``unplayed`` keeps per channel
    (slots, time of the last dropped burst)."""
    quality = packet.quality or {}
    if quality.get("recovered"):
        if options.get("flywheel_recovery", True):
            return packet
        slots, _ = unplayed.get(packet.channel_id, (0, 0.0))
        unplayed[packet.channel_id] = (slots + 1 + int(quality.get("missed", 0) or 0), now)
        return None
    if packet.channel_id in unplayed:
        slots, at = unplayed.pop(packet.channel_id)
        # A call's dropped tail must not become the next call's gap.
        if now - at <= RECOVERED_SAME_CALL_SEC:
            restored = int(quality.get("missed", 0) or 0) + slots
            packet = dataclasses.replace(packet, quality={**quality, "missed": min(MAX_FILLED_FRAMES, restored)})
    return packet
