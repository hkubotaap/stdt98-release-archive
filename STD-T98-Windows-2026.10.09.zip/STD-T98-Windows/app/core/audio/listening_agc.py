"""Volume following for listening PCM; no codec changes or extra samples."""
import math

import numpy as np


class ListeningAgc:
    """One recording's gain state, shared across its sequential render chunks.

    Input is mono PCM16. Streaming calls end on a 20 ms boundary; the final
    call may contain a shorter tail. 8/48 kHz renderer chunks already align.
    Gain remains continuous across low-level blocks and chunk boundaries.
    """

    def __init__(self, sample_rate=8000, target_rms=4000.0, peak_limit=30000.0):
        if isinstance(sample_rate, bool) or not isinstance(sample_rate, (int, np.integer)) or not 1000 <= sample_rate <= 192000:
            raise ValueError("Invalid sample rate")
        if not math.isfinite(target_rms) or not math.isfinite(peak_limit) or not 0 < target_rms < peak_limit <= 32767:
            raise ValueError("Invalid listening level")
        self.sample_rate = int(sample_rate)
        self.frame_samples = max(1, round(self.sample_rate*.02))
        self.target_rms = float(target_rms)
        self.peak_limit = float(peak_limit)
        self.gain = 1.0
        self.started = False
        self.speech_floor = 200.0
        self.level_power = 0.0
        self.quiet_seconds = 0.0
        self.max_gain = 16.0
        self.min_gain = .125

    def process(self, pcm):
        source = np.asarray(pcm)
        if source.ndim != 1 or not np.isfinite(source).all():
            raise ValueError("Expected finite mono PCM")
        source = source.astype(np.int16, copy=False)
        output = source.copy()
        for begin in range(0, len(source), self.frame_samples):
            block = source[begin:begin+self.frame_samples].astype(np.float64)
            rms = float(np.sqrt(np.mean(block*block)))
            peak = float(np.max(np.abs(block)))
            seconds = len(block)/self.sample_rate
            if rms >= self.speech_floor:
                self.quiet_seconds = 0.0
                if not self.started:
                    self.level_power = rms*rms
                    self.started = True
                blend = 1-math.exp(-seconds/.12)
                self.level_power += blend*(rms*rms-self.level_power)
                level = math.sqrt(self.level_power)
                wanted = min(self.max_gain, max(self.min_gain, self.target_rms/level))
                tau = .08 if wanted < self.gain else .18
            else:
                self.quiet_seconds += seconds
                # Weak consonants/word endings keep the speech gain briefly.
                # Quiet background never requests more gain; after the hold,
                # return gently to unity instead of switching at a threshold.
                wanted = self.gain if self.started and self.quiet_seconds <= .25 else 1.0
                tau = .30
            # Peak protection also slews, rather than jumping at a 20 ms edge.
            if peak and self.gain*peak > .9*self.peak_limit:
                wanted = min(wanted, .9*self.peak_limit/peak)
                tau = .001
            start_log = math.log(self.gain)
            target_log = math.log(max(wanted, 1e-9))
            times = np.arange(len(block), dtype=np.float64)/self.sample_rate
            gain = np.exp(target_log+(start_log-target_log)*np.exp(-times/tau))
            adjusted = block*gain
            # Only exceptional peaks reach the soft safety limiter while the
            # fast gain reduction settles; no hard framewise gain discontinuity.
            knee = .9*self.peak_limit
            high = np.abs(adjusted) > knee
            adjusted[high] = np.sign(adjusted[high])*(knee+(self.peak_limit-knee)*np.tanh(
                (np.abs(adjusted[high])-knee)/(self.peak_limit-knee)))
            output[begin:begin+len(block)] = np.clip(np.rint(adjusted), -self.peak_limit, self.peak_limit).astype(np.int16)
            self.gain = math.exp(target_log+(start_log-target_log)*math.exp(-seconds/tau))
        return output


def adjust_listening_volume(pcm, sample_rate=8000):
    """A fresh recording starts from its first audible block, not another call."""
    return ListeningAgc(sample_rate).process(pcm)
