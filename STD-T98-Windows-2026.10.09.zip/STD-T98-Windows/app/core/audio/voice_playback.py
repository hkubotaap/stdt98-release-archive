"""Live voice reproduction using the SDR# decoder's quality/AGC rules."""
from collections import deque
import math

import numpy as np

from core.audio import independent_ambe
from core.audio.plc import PitchConcealer
from core.audio.ambe_adapter import fec_demod_with_errors
from core.crypto.pn_sequence import generate_pn_sequence_196
from core.crypto.secret_voice import descramble_burst
from core.protocol.voice_gaps import MAX_FILLED_FRAMES


# Starting gain for a channel's first call: the median speech gain measured on
# real STD-T98 calls (about +10 dB). Later calls continue the channel's gain.
INITIAL_SPEECH_AGC_GAIN = 3.2

# 8 -> 48 kHz interpolation filter ("hq_resampler"): Kaiser-windowed sinc,
# 32 taps per phase, cutoff 4 kHz. Flat to ~3.4 kHz, the 8k-f images from
# ~4.5 kHz up are ~70 dB down (linear interpolation leaves them 9-19 dB down
# for 2-3 kHz speech). Delay 2 ms.
UPSAMPLE_TAPS_PER_PHASE = 32


def _interpolation_filter(factor, taps_per_phase=UPSAMPLE_TAPS_PER_PHASE, cutoff_hz=4000.0, rate_hz=48000.0, beta=7.0):
    n = factor * taps_per_phase
    t = np.arange(n) - (n - 1) / 2
    h = 2 * cutoff_hz / rate_hz * np.sinc(2 * cutoff_hz / rate_hz * t) * np.kaiser(n, beta)
    h *= factor / h.sum()
    # phases[p][k] = h[p + factor*k]: output sample n*factor+p = sum_k phases[p][k] * x[n-k]
    return np.stack([h[p::factor] for p in range(factor)])


_INTERPOLATION_FILTERS = {}


def _soft_fec(quality, block_count):
    """(blocks, [(c0, total)]) from a voice packet's "soft_fec", or None."""
    soft = quality.get("soft_fec")
    try:
        payload = bytes.fromhex(soft["blocks"])
        errors = [(int(c0), int(total)) for c0, total in soft["errors"]]
    except (TypeError, KeyError, ValueError):
        return None
    if len(payload) != 9 * block_count or len(errors) != block_count:
        return None
    return [payload[i:i+9] for i in range(0, len(payload), 9)], errors


class SpeechAgc:
    """SDR# SpeechAgc: 50ms envelope, 20ms attack, 800ms release."""
    def __init__(self, gain=1.0):
        self.gain = float(gain)
        self.new_segment()

    def new_segment(self):
        self.env = 0.0
        self.fast_left = 4000

    def process(self, pcm):
        out = np.empty(len(pcm), dtype=np.int16)
        env_a, attack, release, fast = [1-math.exp(-1/(s*8000)) for s in (.05, .02, .8, .1)]
        for i, sample in enumerate(pcm):
            x = float(sample) / 32768
            self.env += env_a * (x*x - self.env)
            rms = math.sqrt(self.env)
            if rms > .01:
                want = min(11.2, max(.25, .12 / rms))
                a = attack if want < self.gain else (fast if self.fast_left > 0 else release)
                self.gain += a * (want - self.gain)
            self.fast_left = max(0, self.fast_left - 1)
            y = x * self.gain
            if abs(y) > .85:
                y = math.copysign(.85 + .15 * math.tanh((abs(y)-.85)/.15), y)
            out[i] = min(32767, max(-32768, int(y * 32768)))
        return out


class VoicePlayback:
    def __init__(self, engine=None, fec=None, agc_gain=1.0):
        # Voice is decoded by the bundled independent AMBE+2 decoder only (no mbelib).
        # ``engine`` may be injected for tests; otherwise it is created on first use.
        self.engine = engine
        self.fec = fec or fec_demod_with_errors
        self.crc_window = deque(maxlen=25)
        self.secret = None
        self.data_run = 0
        self.in_data = False
        self.last_good = None
        self.conceal_run = 0
        # "pitch_plc": pitch-period concealment; always fed, used only when on.
        self.plc = PitchConcealer()
        # A new call continues the channel's speech gain (SDR# keeps one AGC per
        # channel); restarting at 1x left every call's first ~0.5 s ~4 dB quiet.
        self.agc = SpeechAgc(agc_gain)
        self.previous_sample = 0
        self.key = None
        self.pn = None
        self.last_reason = "Playing"
        self.voice_quality = deque(maxlen=80)
        self.key_mismatch = False
        self.analysis_key = None
        # The codec keeps repeat/mute state across frames, so lost bursts are fed to
        # it as missing frames before the next burst; their PCM waits here for
        # conceal_missing(). None engine (decoder unavailable) plays silence.
        self.ambe2_lost_pcm = None
        self.ambe2_prefed = 0
        self._engine_unavailable = False

    @property
    def ambe2(self):
        return self.engine

    def _engine(self):
        if self.engine is None and not self._engine_unavailable:
            if independent_ambe.available():
                self.engine = independent_ambe.IndependentAmbe()
            else:
                self._engine_unavailable = True
                self.last_reason = "Decoder unavailable"
        return self.engine

    def decode(self, packet, key=0, options=None, payloads_2450=None):
        options = options or {}
        engine = self._engine()
        self.ambe2_lost_pcm = None
        if key != self.analysis_key:
            self.analysis_key = key
            self.voice_quality.clear()
            self.key_mismatch = False
            self.last_good = None
            self.conceal_run = 0
            self.plc.reset()
        quality = packet.quality or {}
        # Listening explicitly selects plaintext or a candidate key. Receiver
        # key-wait/CRC-rate heuristics must not silently override that choice.
        listening = bool(options.get("listen_preserve_audio", False))
        crc = quality.get("crc_ok", True)
        parity = quality.get("parity_ok", True)
        if listening:
            self.secret = bool(key)
            self.key_mismatch = False
        elif crc and parity:
            self.secret = packet.call_stat == 1
        mode = quality.get("mode", 3)
        mask = [mode in (2,3)]*2 + [mode in (1,3)]*2 if parity else [True]*4
        if parity:
            self.data_run = self.data_run + 1 if not any(mask) else 0
            if any(mask):
                self.in_data = False
            elif self.data_run >= 3:
                self.in_data = True
        self.crc_window.append(bool(crc))
        dead = not listening and len(self.crc_window) >= 5 and not any(self.crc_window)
        minimum = options.get("crc_min_percent", 0)
        low = not listening and len(self.crc_window) >= 5 and sum(self.crc_window)*100 < minimum*len(self.crc_window)
        squelch = not listening and options.get("noise_suppression", True)
        # Until a healthy SACCH identifies plain/secret, decoding raw AMBE can
        # play encrypted data as noise. Legacy packets still identify the call
        # immediately because their quality defaults to trusted above.
        unknown_call = self.secret is None
        locked = unknown_call or (self.secret is True and not key) or self.key_mismatch
        # Key waiting is mandatory, including when noise suppression is off.
        key_wait = unknown_call or (self.secret is True and not key)
        mute = dead or low or self.in_data or key_wait or (squelch and self.key_mismatch)
        self.last_reason = "Data" if self.in_data or not any(mask) else "CRC muted" if dead or low else "Key mismatch" if squelch and self.key_mismatch else "Call state pending" if unknown_call else "Key required" if key_wait else "Playing"
        if dead or low or self.in_data or locked:
            self.last_good = None
            self.conceal_run = 0
            self.plc.reset()
        # CRC-dead/data/key-wait audio has no speaker output in the plugin.
        # Keep time in recordings without spending native decoder/AGC work on it.
        # A rejected key still needs healthy decoded samples so it can recover.
        if (mute and not self.key_mismatch) or not any(mask):
            if engine is not None:
                # Muted: the codec skips this time and the lost bursts play as silence.
                lost = min(MAX_FILLED_FRAMES, max(0, int(quality.get("missed", 0) or 0)))
                self.ambe2_lost_pcm = np.zeros(lost * 640, dtype=np.int16)
            self.ambe2_prefed = 0
            size = 9 if packet.payload_format == 1 else 7
            return np.zeros((len(packet.payload)//size)*160,dtype=np.int16), payloads_2450 or []
        if engine is not None:
            # Lost bursts before this one, unless conceal_missing() already fed them.
            lost = min(MAX_FILLED_FRAMES, max(0, int(quality.get("missed", 0) or 0))) - self.ambe2_prefed
            if lost > 0:
                self.ambe2_lost_pcm = engine.missing(4 * lost)
            self.ambe2_prefed = 0
        raw_blocks = [packet.payload[i:i+9] for i in range(0, len(packet.payload), 9)] if packet.payload_format == 1 else []
        # "soft_voice_fec": the protocol service's soft-decision C0/C1 codewords.
        # The codec takes its parameters from them and rates the frame by their
        # distance to the received bits (HR-PUBLIC-ALLFRAMES-SOFT-v1).
        soft_fec = _soft_fec(quality, len(raw_blocks)) if (raw_blocks and options.get("soft_voice_fec", True)
                                                           and engine is not None) else None
        soft_blocks = soft_fec[0] if soft_fec else None
        # Secret calls descramble the received (hard) 2450 parameters; the codec then
        # decodes those with the frame's channel quality.
        packed = [self.fec(b).payload for b in raw_blocks] if raw_blocks else payloads_2450
        if packed is None:
            packed = [packet.payload[i:i+7] for i in range(0, len(packet.payload), 7)]
        if self.secret is True and key:
            if self.key != key:
                self.key, self.pn = key, generate_pn_sequence_196(key)
            decoded_payloads = descramble_burst(packed, self.pn)
        else:
            decoded_payloads = packed
        descrambled = self.secret is True and key
        output = []
        for i, payload in enumerate(decoded_payloads):
            if not mask[i % 4]:
                output.append(np.zeros(160, dtype=np.int16))
                continue
            action = None
            if engine is None:
                pcm = np.zeros(160, dtype=np.int16)      # no decoder: silence, timing kept
            else:
                soft_block = soft_blocks[i] if soft_blocks else None
                if raw_blocks and not descrambled:
                    pcm, action = engine.decode_raw(raw_blocks[i], soft_block)
                elif raw_blocks:
                    pcm, action = engine.decode_info(payload, raw_blocks[i], soft_block)
                else:
                    pcm, action = engine.decode_clean(payload)
            pcm = np.asarray(pcm, dtype=np.int16)
            if len(pcm) != 160:
                raise ValueError("AMBE decoder must return 160 samples.")
            if crc and parity:
                values = pcm.astype(np.float64)
                rms = math.sqrt(float(np.mean(values*values)))
                zcr = np.count_nonzero(np.diff(np.signbit(values)))/160
                self.voice_quality.append((rms,zcr))
            # The codec reports REPEAT/MUTED for frames it concealed itself.
            bad = action in ("REPEAT", "MUTED")
            pitch_plc = options.get("pitch_plc", True) and options.get("crc_concealment", True)
            if mute:
                pcm = np.zeros(160, dtype=np.int16)
                self.plc.reset()
            elif not squelch:
                self.plc.push(pcm)
            elif not bad:
                pcm = self.plc.push(pcm).astype(np.int16)  # cross-fades out of a gap
                self.last_good = pcm.copy()
                self.conceal_run = 0
            else:
                self.conceal_run += 1
                if options.get("crc_concealment", True) and self.conceal_run <= 3:
                    pcm = self.plc.push(pcm).astype(np.int16)  # keep the codec's repeat/comfort waveform
                elif pitch_plc:
                    pcm = self.plc.conceal(160).astype(np.int16)
                elif options.get("crc_concealment", True) and self.last_good is not None and self.conceal_run <= 6:
                    pcm = self.last_good.astype(np.float64) * (.8 ** self.conceal_run)
                    pcm[:32] *= np.arange(32)/32
                    pcm[-32:] *= np.arange(31,-1,-1)/32
                    pcm = pcm.astype(np.int16)
                else:
                    pcm = np.zeros(160, dtype=np.int16)
            output.append(pcm)
        # SACCH plaintext is authoritative. Only reject a candidate key based on
        # a sufficient healthy voice window, using the plugin's RMS/ZCR thresholds.
        if self.secret is False:
            self.key_mismatch = False
        elif not listening and len(self.voice_quality) >= 30:
            maximum = max(rms for rms,_ in self.voice_quality)
            active = [zcr for rms,zcr in self.voice_quality if rms > maximum*.20]
            if len(active) >= 30:
                self.key_mismatch = sum(zcr < .18 for zcr in active)/len(active) < .15
        pcm = np.concatenate(output) if output else np.zeros(0, dtype=np.int16)
        if options.get("speaker_agc", True):
            pcm = self.agc.process(pcm)
        return pcm, packed

    def conceal_missing(self, frames, options=None):
        """8 kHz PCM standing in for ``frames`` lost bursts (4 x 20 ms each).

        Same concealment as a CRC-bad block: the last good speech fades over at
        most six blocks, then silence. Keeps the call's timing on the speaker.
        """
        options = options or {}
        output = []
        engine = self._engine()
        if engine is not None and frames > 0:
            # The codec conceals lost frames itself (repeat, then comfort noise).
            # Live: decode() already fed them. Offline render calls this first.
            if self.ambe2_lost_pcm is not None:
                pcm = self.ambe2_lost_pcm[:int(frames) * 640]
                self.ambe2_lost_pcm = None
            else:
                pcm = engine.missing(4 * int(frames))
                self.ambe2_prefed = int(frames)
            self.conceal_run += int(frames) * 4
            output.append(pcm)
            frames = 0
        if options.get("pitch_plc", True) and options.get("crc_concealment", True) and frames > 0:
            self.conceal_run += int(frames) * 4
            output.append(self.plc.conceal(int(frames) * 640).astype(np.int16))
            frames = 0
        for _ in range(max(0, int(frames)) * 4):
            if options.get("crc_concealment", True) and self.last_good is not None and self.conceal_run < 6:
                self.conceal_run += 1
                pcm = self.last_good.astype(np.float64) * (.8 ** self.conceal_run)
                pcm[:32] *= np.arange(32)/32
                pcm[-32:] *= np.arange(31,-1,-1)/32
                output.append(pcm.astype(np.int16))
            else:
                output.append(np.zeros(160, dtype=np.int16))
        pcm = np.concatenate(output) if output else np.zeros(0, dtype=np.int16)
        if options.get("speaker_agc", True) and np.any(pcm):
            pcm = self.agc.process(pcm)
        return pcm

    def upsample(self, pcm, factor=6, hq=False):
        """Continuous linear interpolation instead of zero-order hold, or with
        ``hq`` the polyphase FIR interpolator (history kept across calls)."""
        if not len(pcm):
            return b""
        history = getattr(self, "fir_history", None)
        if hq:
            phases = _INTERPOLATION_FILTERS.get(factor)
            if phases is None:
                phases = _INTERPOLATION_FILTERS[factor] = _interpolation_filter(factor)
            taps = phases.shape[1]
            if history is None or len(history) != taps - 1:
                history = np.full(taps - 1, float(self.previous_sample))
            samples = np.concatenate((history, np.asarray(pcm, dtype=np.float64)))
            self.fir_history = samples[-(taps - 1):]
            self.previous_sample = int(pcm[-1])
            out = np.empty((len(pcm), factor))
            for p in range(factor):
                out[:, p] = np.convolve(samples, phases[p], "valid")
            return np.clip(np.rint(out.ravel()), -32768, 32767).astype("<i2").tobytes()
        self.fir_history = None
        samples = np.concatenate(([self.previous_sample], pcm)).astype(np.float64)
        self.previous_sample = int(pcm[-1])
        positions = np.arange(len(pcm)*factor, dtype=np.float64)/factor
        return np.interp(positions, np.arange(len(samples)), samples).astype("<i2").tobytes()
