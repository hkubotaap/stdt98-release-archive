"""SDR# compatible per-call T98RAW03/quality/WAV recordings."""
import csv
import argparse
from datetime import datetime
from decimal import Decimal, ROUND_CEILING
import json
import math
import os
from pathlib import Path
import queue
import struct
import threading
import time
import wave
import uuid
from core.audio.data_paths import resolve_data_dir, restore_data_dir


MAX_MIN_RECORDING_SECONDS = 3600.0


def maximum_recordings(value):
    if isinstance(value, bool):
        return 0
    try:
        return min(97, max(0, int(value)))
    except (TypeError, ValueError, OverflowError):
        return 0


def excluded_frequencies(value):
    """Normalize persisted excluded channel frequencies (Hz) to a sorted list."""
    if not isinstance(value, (list, tuple)):
        return []
    result = set()
    for item in value:
        if isinstance(item, bool):
            continue
        try:
            frequency = int(round(float(item)))
        except (TypeError, ValueError, OverflowError):
            continue
        if frequency > 0:
            result.add(frequency)
    return sorted(result)


DEFAULT_PRIORITY_DUCK_PERCENT = 25
DEFAULT_CRC_MIN_PERCENT = 85
DEFAULT_MIN_RECORDING_SECONDS = 1.0
DEFAULT_RECORD_CRC_MIN_PERCENT = 50
DEFAULT_MAX_RECORDINGS = 4
DEFAULT_MAX_PLAYBACK_CHANNELS = 2
# Live playback jitter buffer: voice bursts (80 ms each) queued per channel
# before its speech starts.
DEFAULT_PLAYBACK_BUFFER_FRAMES = 4
MAX_PLAYBACK_BUFFER_FRAMES = 10


def maximum_playback_channels(value):
    """Normalize the simultaneous-playback limit; 0 means no limit."""
    return maximum_recordings(value)


def playback_buffer_frames(value):
    """Normalize the live-playback prefill to 1..MAX_PLAYBACK_BUFFER_FRAMES bursts."""
    if isinstance(value, bool):
        return DEFAULT_PLAYBACK_BUFFER_FRAMES
    try:
        return min(MAX_PLAYBACK_BUFFER_FRAMES, max(1, int(value)))
    except (TypeError, ValueError, OverflowError):
        return DEFAULT_PLAYBACK_BUFFER_FRAMES


def priority_duck_percent(value):
    """Normalize the level (%) of other channels while a priority channel talks."""
    if isinstance(value, bool):
        return DEFAULT_PRIORITY_DUCK_PERCENT
    try:
        return min(100, max(0, int(value)))
    except (TypeError, ValueError, OverflowError):
        return DEFAULT_PRIORITY_DUCK_PERCENT


def channel_ids_for(options, name):
    """Channel ids whose configured frequency is listed in ``options[name]``."""
    wanted = options.get(name)
    if not wanted:
        return frozenset()
    return frozenset(int(ch) for ch, freq in options.get("frequencies", {}).items() if int(freq) in wanted)


def is_excluded_channel(options, channel_id):
    """True when the channel's configured frequency is excluded from playback and recording."""
    excluded = options.get("excluded_frequencies")
    if not excluded:
        return False
    frequency = options.get("frequencies", {}).get(str(channel_id))
    return frequency is not None and int(frequency) in excluded


def minimum_recording_seconds(value):
    """Normalize a persisted threshold; 0 disables the duration filter."""
    if isinstance(value, bool):
        return 0.0
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return 0.0
    return min(MAX_MIN_RECORDING_SECONDS, max(0.0, seconds)) if math.isfinite(seconds) else 0.0


def recording_crc_percent(value):
    """Normalize the per-call CRC success threshold; 0 disables the filter."""
    if isinstance(value, bool):
        return 0
    try:
        return min(100, max(0, int(value)))
    except (TypeError, ValueError, OverflowError):
        return 0


def default_data_dir(repo_root):
    return resolve_data_dir("std98_data", repo_root)


def channel_frequencies(backend_args=()):
    from core.rf.backend_config import add_config_arguments, load_config
    parser = argparse.ArgumentParser(add_help=False)
    add_config_arguments(parser)
    args,_ = parser.parse_known_args(backend_args)
    config = load_config(args)
    n = config.channelizer.num_channels
    centre = config.sdr.center_freq + config.sdr.freq_offset
    return {str(i+1):round(centre + (i-n//2)*config.channelizer.channel_spacing) for i in range(n)}


class AudioSettings:
    def __init__(self, path=None, data_dir=None, repo_root=None):
        self.path = Path(path) if path else None
        self.repo_root = Path(repo_root) if repo_root is not None else Path(__file__).parents[2]
        self.values = {"speaker_agc": True, "noise_suppression": True,
                       "crc_concealment": True, "fill_lost_frames": True, "crc_min_percent": DEFAULT_CRC_MIN_PERCENT,
                       "hq_resampler": True,
                       "soft_voice_fec": True, "pitch_plc": True,
                       "flywheel_recovery": True,
                       "voice_output": True, "recording": True, "record_frame_bits": False,
                       "min_recording_seconds": DEFAULT_MIN_RECORDING_SECONDS, "record_crc_min_percent": DEFAULT_RECORD_CRC_MIN_PERCENT,
                       "max_recordings": DEFAULT_MAX_RECORDINGS, "excluded_frequencies": frozenset(),
                       "solo_frequencies": frozenset(), "priority_frequencies": frozenset(),
                       "mute_frequencies": frozenset(),
                       "priority_duck_percent": DEFAULT_PRIORITY_DUCK_PERCENT,
                       "playback_buffer_frames": DEFAULT_PLAYBACK_BUFFER_FRAMES,
                       "max_playback_channels": DEFAULT_MAX_PLAYBACK_CHANNELS,
                       "volume": 1.0, "data_dir": str(resolve_data_dir(data_dir, self.repo_root))}
        self.next_check = 0.0
        self.keys = ({}, {}, {})

    def poll(self, now):
        if now < self.next_check:
            return self.values
        self.next_check = now + .5
        if self.path:
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                for name in ("speaker_agc", "noise_suppression", "crc_concealment", "fill_lost_frames",
                             "voice_output", "recording", "record_frame_bits", "hq_resampler",
                             "soft_voice_fec", "pitch_plc", "flywheel_recovery"):
                    if isinstance(data.get(name), bool):
                        self.values[name] = data[name]
                for name, lo, hi in (("volume",0,2),("crc_min_percent",0,100)):
                    if isinstance(data.get(name), (int,float)):
                        self.values[name] = min(hi, max(lo, data[name]))
                minimum = data.get("min_recording_seconds")
                if "record_crc_min_percent" in data:
                    self.values["record_crc_min_percent"] = recording_crc_percent(data["record_crc_min_percent"])
                if "max_recordings" in data:
                    self.values["max_recordings"] = maximum_recordings(data["max_recordings"])
                for name in ("excluded_frequencies", "solo_frequencies", "priority_frequencies", "mute_frequencies"):
                    if name in data:
                        self.values[name] = frozenset(excluded_frequencies(data[name]))
                if "priority_duck_percent" in data:
                    self.values["priority_duck_percent"] = priority_duck_percent(data["priority_duck_percent"])
                if "max_playback_channels" in data:
                    self.values["max_playback_channels"] = maximum_playback_channels(data["max_playback_channels"])
                if "playback_buffer_frames" in data:
                    self.values["playback_buffer_frames"] = playback_buffer_frames(data["playback_buffer_frames"])
                if isinstance(minimum, (int, float)) and not isinstance(minimum, bool) and math.isfinite(minimum):
                    self.values["min_recording_seconds"] = minimum_recording_seconds(minimum)
                if isinstance(data.get("data_dir"), str) and data["data_dir"]:
                    self.values["data_dir"] = str(restore_data_dir(data["data_dir"], self.repo_root, data.get("data_dir_mode")))
                if isinstance(data.get("frequencies"), dict):
                    self.values["frequencies"] = data["frequencies"]
            except (OSError, ValueError, TypeError):
                pass
        self.keys = load_keys(Path(self.values["data_dir"]) / "manual_keys.csv")
        return self.values

    def key_for(self, packet):
        csm = str((packet.quality or {}).get("csm", ""))
        quality = packet.quality or {}
        trusted = quality.get("crc_ok", True) and quality.get("parity_ok", True)
        # CRC-failed control bits are random and can select someone else's
        # manual key by user code. CSM/frequency mappings remain usable.
        user = quality.get("sacch", {}).get("UserCode") if trusted else None
        frequency = self.values.get("frequencies", {}).get(str(packet.channel_id), 0)
        by_csm, by_freq, by_user = self.keys
        return by_csm.get(csm, by_user.get(str(user), by_freq.get(str(frequency), 0)))


def load_keys(path):
    by_csm, by_freq, by_user = {}, {}, {}
    try:
        with open(path, encoding="utf-8-sig", newline="") as stream:
            for row in csv.reader(stream):
                if len(row) < 3:
                    continue
                try:
                    key = int(row[2])
                except ValueError:
                    continue
                if not 0 < key <= 32767:
                    continue
                csm, freq = row[0].strip(), row[1].strip()
                user = row[3].strip() if len(row) > 3 else ""
                if csm:
                    by_csm[csm] = key
                elif user:
                    by_user[user] = key
                elif freq:
                    by_freq[freq] = key
    except OSError:
        pass
    return by_csm, by_freq, by_user


class CallRecording:
    def __init__(self, data_dir, packet, frequency, now, min_duration_seconds=0.0, min_crc_percent=0,
                 record_frame_bits=False):
        date = datetime.fromtimestamp(now)
        day = date.strftime("%Y-%m-%d")
        base = date.strftime("%Y%m%d_%H%M%S_%f") + f"_ch{packet.channel_id:02d}_{frequency}_" + uuid.uuid4().hex[:12]
        root = Path(data_dir)
        seconds = minimum_recording_seconds(min_duration_seconds)
        self.minimum_samples = int((Decimal(str(seconds)) * 8000).to_integral_value(rounding=ROUND_CEILING))
        self.samples_written = 0
        self.min_crc_percent = recording_crc_percent(min_crc_percent)
        self.frames = self.crc_ok_frames = 0
        # Keep one policy for the entire call, even if settings change midway.
        self.record_frame_bits = record_frame_bits is True
        self._closed = False
        self._created_paths = []
        # Filtered calls stay out of raw/rec/edu until they pass at close().
        self.pending_dir = root/".pending"/base if self.minimum_samples or self.min_crc_percent else None
        self.final_paths = (root/"raw"/day/(base+".t98raw"),
                            root/"edu"/day/(base+".jsonl"),
                            root/"rec"/day/(base+"_live.wav"))
        for kind in ("raw", "rec", "edu"):
            (root/kind/day).mkdir(parents=True, exist_ok=True)
        if self.pending_dir:
            self.pending_dir.mkdir(parents=True, exist_ok=False)
        paths = tuple(self.pending_dir/path.name for path in self.final_paths) if self.pending_dir else self.final_paths
        self.raw = self.edu = self.wav = None
        self.path, self.edu_path, self.wav_path = paths
        self.header = bytearray(struct.pack("<8sqqII16sB3x", b"T98RAW03", int(frequency), int(now*1000), 4, 9, b"", 0))
        try:
            self.raw = open(self.path, "xb")
            self._created_paths.append(self.path)
            self.raw.write(self.header)
            self.edu = open(self.edu_path, "x", encoding="utf-8")
            self._created_paths.append(self.edu_path)
            # Exclusive creation prevents accidental replacement of an earlier call.
            self.wav_file = open(self.wav_path, "xb")
            self._created_paths.append(self.wav_path)
            self.wav = wave.open(self.wav_file, "wb")
            self.wav.setnchannels(1)
            self.wav.setsampwidth(2)
            self.wav.setframerate(8000)
        except Exception:
            self.close(discard=True)
            raise
        self.last_at = now
        self.data_dir = Path(data_dir)
        self.frequency = frequency

    def write(self, packet, pcm, now):
        if packet.payload_format != 1 or len(packet.payload) != 36:
            return
        q = packet.quality or {}
        csm = str(q.get("csm", "")).encode("utf-8")[:15]
        if csm:
            self.header[32:48] = csm.ljust(16, b"\0")
        if q.get("crc_ok", True) and q.get("parity_ok", True):
            self.header[48] = 2 if packet.call_stat == 1 else 1
        self.raw.seek(0)
        self.raw.write(self.header)
        self.raw.seek(0, os.SEEK_END)
        self.raw.write(packet.payload)
        self.raw.flush()
        sacch = q.get("sacch",{})
        # "missed": frames of this channel lost just before this one (per-channel
        # symbol clock). "seq" is a counter shared by all channels, so its jumps
        # also count other channels' frames and cannot show losses.
        self.edu.write(json.dumps({"type":"frame", "F":1, "seq":packet.sequence,
                                  "missed":int(q.get("missed", 0) or 0),
                                  "rich":{"F":1, "parityOK":q.get("parity_ok", True), "M":q.get("mode",3)},
                                  "sacch":{"crcOK":q.get("crc_ok",True), "userCode":sacch.get("UserCode"),
                                           "makerCode":sacch.get("MakerCode"), "callStat":sacch.get("CallStat")},
                                  # Full frames for the debugger, including the
                                  # fields absent from the raw audio recording.
                                  **{key:q[key] for key in ("frame_rx_hex", "frame_dw_hex")
                                     if self.record_frame_bits and isinstance(q.get(key), str) and len(q[key]) == 96
                                     and all(c in "0123456789abcdefABCDEF" for c in q[key])},
                                  # For re-rendering with options in the listening tool:
                                  # soft-decision blocks, and flywheel-recovered frames.
                                  **({"soft_fec":q["soft_fec"]} if q.get("soft_fec") else {}),
                                  **({"recovered":True} if q.get("recovered") else {})},
                                 ensure_ascii=False)+"\n")
        self.edu.flush()
        self.wav.writeframes(pcm.astype("<i2").tobytes())
        self.wav_file.flush()  # valid header even if Windows terminates the process
        self.samples_written += len(pcm)
        self.frames += 1
        self.crc_ok_frames += bool(q.get("crc_ok", True))
        self.last_at = now

    def close(self, discard=False):
        if self._closed:
            return
        self._closed = True
        for stream in (self.wav, getattr(self,"wav_file",None), self.edu, self.raw):
            if stream is not None:
                try:
                    stream.close()
                except OSError:
                    pass
        low_crc = self.min_crc_percent and self.crc_ok_frames * 100 < self.min_crc_percent * self.frames
        if discard or self.samples_written < self.minimum_samples or low_crc:
            # Only remove files exclusively created by this recording instance.
            for path in self._created_paths:
                path.unlink(missing_ok=True)
        elif self.pending_dir:
            # Windows requires closing the writers before publishing the files.
            # Short or low-CRC calls never appear in the raw/rec/edu library.
            for source, destination in zip((self.path, self.edu_path, self.wav_path), self.final_paths):
                source.rename(destination)
            self.path, self.edu_path, self.wav_path = self.final_paths
        if self.pending_dir:
            self.pending_dir.rmdir()


class RecordingWorker:
    """Keep file I/O off the decoder thread; report disk errors without killing audio."""
    def __init__(self, error_callback=None):
        self.queue = queue.Queue(maxsize=1000)
        self.error_callback = error_callback or (lambda message: None)
        self.sessions = {}
        self.rejected_calls = {}
        self.skipped_calls = 0
        self.error = None
        self.thread = threading.Thread(target=self._run, name="voice-recorder", daemon=True)
        self.thread.start()

    def submit(self, packet, pcm, options, now):
        if self.error:
            return
        try:
            self.queue.put_nowait((packet, pcm.copy(), dict(options), now))
        except queue.Full:
            self.error = "録音キューが満杯です。保存先の速度を確認してください。"
            self.error_callback(self.error)

    def _close_sessions(self):
        for session in self.sessions.values():
            session.close(discard=bool(self.error) and session.pending_dir is not None)
        self.sessions.clear()

    def _run(self):
        try:
            while True:
                try:
                    item = self.queue.get(timeout=.2)
                except queue.Empty:
                    item = ()
                if item is None:
                    break
                if self.error:
                    self._close_sessions()
                    continue
                if item:
                    packet, pcm, options, now = item
                    if not options.get("recording", True):
                        self._close_sessions()
                    elif packet.payload_format == 1 and len(packet.payload) == 36:
                        # Free ended slots before deciding whether this call can
                        # start. Rejected calls remain rejected until their own
                        # boundary, instead of starting halfway through a call.
                        for channel, session in tuple(self.sessions.items()):
                            if now - session.last_at > 2:
                                session.close()
                                del self.sessions[channel]
                        previous = self.sessions.get(packet.channel_id)
                        frequency = options.get("frequencies",{}).get(str(packet.channel_id),0)
                        quality = packet.quality or {}
                        csm = str(quality.get("csm", "")).encode("utf-8")[:15]
                        station_changed = previous and csm and previous.header[32:48].rstrip(b"\0") not in (b"", csm)
                        flag = 2 if packet.call_stat == 1 else 1
                        identity = (csm, flag if quality.get("crc_ok", True) and quality.get("parity_ok", True) else None)
                        rejected = self.rejected_calls.get(packet.channel_id)
                        if rejected and now - rejected[0] <= 2 and (not csm or not rejected[1][0] or csm == rejected[1][0]) and (identity[1] is None or rejected[1][1] is None or identity[1] == rejected[1][1]):
                            self.rejected_calls[packet.channel_id] = (now, identity)
                            continue
                        self.rejected_calls.pop(packet.channel_id, None)
                        mode_changed = previous and quality.get("crc_ok", True) and quality.get("parity_ok", True) and previous.header[48] not in (0,flag)
                        if previous and (now-previous.last_at > 2 or station_changed or mode_changed or
                                         previous.data_dir != Path(options["data_dir"]) or previous.frequency != frequency):
                            previous.close()
                            del self.sessions[packet.channel_id]
                        if packet.channel_id not in self.sessions:
                            limit = maximum_recordings(options.get("max_recordings", 0))
                            if limit and len(self.sessions) >= limit:
                                self.rejected_calls[packet.channel_id] = (now, identity)
                                self.skipped_calls += 1
                                continue
                            freq = options.get("frequencies",{}).get(str(packet.channel_id),0)
                            self.sessions[packet.channel_id] = CallRecording(
                                options["data_dir"], packet, freq, now, options.get("min_recording_seconds", 0.0),
                                options.get("record_crc_min_percent", 0),
                                record_frame_bits=options.get("record_frame_bits", False))
                        self.sessions[packet.channel_id].write(packet, pcm, now)
                now = time.time()
                for channel, session in list(self.sessions.items()):
                    if now - session.last_at > 2:
                        session.close()
                        del self.sessions[channel]
        except (OSError, ValueError) as exc:
            self.error = f"音声録音を停止しました: {exc}"
            self.error_callback(self.error)
        finally:
            self._close_sessions()

    def close(self):
        if self.thread.is_alive():
            try:
                self.queue.put(None, timeout=1)
            except queue.Full:
                self.error_callback("録音終了を待っています。保存先の応答がありません。")
            self.thread.join(timeout=5)
