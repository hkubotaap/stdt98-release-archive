"""Reader-facing explanations of the bundled AMBE reference profile.

Keep numerical rules aligned with vendor.ambe2; none of these helpers decode or
change audio. Candidate information is explicitly separated from used models.
"""

GUIDE_SECTIONS = {
    "最初に・値を読む順番": """この画面で分かること
保存された受信ビットが、誤り訂正、試聴キーの適用、音声パラメータの復元を経て、どの音声になったかを追跡します。AMBE+2は波形そのものを送る方式ではなく、声の高さ・有声／無声・振幅・音色を短いビット列で表し、受信側で波形を合成する方式です。

おすすめの読む順番
1. 上の4行で、音声が記録されたブロックか確認します。80msの無線フレームには20msのスロットが4個あります。
2. 「復号状態・解説」のwire_typeとactionを見ます。VOICE以外の出力を通常音声のパラメータとして評価しないでください。
3. FEC e0/e1とfailureを確認します。訂正候補との距離であって、実際に発生した全誤りの個数ではありません。
4. 秘話の記録なら試聴キーを確認します。FECが良くてもキーが正しいとは限りません。
5. b0〜b8を選び、コードブック番号と復元された値を区別します。
6. 波形・倍音グラフを見て、前後約1秒を試聴します。20msだけでは言葉や音質を判断しにくいことがあります。

判断の例
e0=0 / e1=0、action=VOICE：保護された語は訂正候補と一致し、通常音声を合成しました。ただし無保護ビットの誤りやキー違いは残り得ます。
wire_type=UNTRUSTED_FEC、action=REPEAT：今回の値を使わず、前の合成モデルを反復しています。聞こえた声は今回のビットが正しい証拠にはなりません。
action=MUTED：この参照実装では小さなcomfort noiseを出します。スピーカーのミュート設定とは別です。

対象と限界
値は同梱のHR-PUBLIC-ALLFRAMES-v1参照実装のものです。M500-CENTER-v1（帯域の有声判定）、E4ZERO-v1（平滑化）などの参照上の選択を含みます。正式DVSI機器の内部値やPCMと一致することを認証した画面ではありません。""",
    "操作・20msと80ms・受信の用語": """フレーム #
録音一覧の0始まりの番号です。1行の無線フレームは80ms。復号器内部のframe_index（20ms処理の数）とは単位が違います。

TCH（Traffic Channel）
通話の音声やデータを運ぶ領域です。TCH1/1、TCH1/2、TCH2/1、TCH2/2の順に0〜20、20〜40、40〜60、60〜80msを表示します。4スロット全部が常に音声とは限りません。

RICH / F / M / parityOK
RICHは無線フレームの構成を示す制御情報です。この解析ではparityOKが真、F=1で、M=2または3ならTCH1が音声、M=1または3ならTCH2が音声と扱います。確認できない割当てを音声として推測しません。確認済みF=0では復号状態を初期化します。

SACCH / callStat / CRC
SACCHは通話に付随する制御情報です。ここでは確認済みフレームかつCRCが通ったcallStat=0/1から、記録上の平文／秘話を表示します。CRCは制御情報の整合確認であり、音声49bitや試聴キーの正しさを検証するものではありません。表示が未判定でも平文とは限りません。

試聴キー
0は解除なし。1〜32767は指定キーのPNを適用した解除候補です。この画面は自動探索せず、平文／秘話表示にかかわらず入力されたキーを適用します。試聴ツールから開くとキーを共有するため、変更は元画面にも反映されます。

記録済み軟判定FECを使用
オンでは録音に保存されたsoft_fecの候補コード語を検証して使います。この画面で電波の強さや受信シンボルから新しく計算する機能ではありません。記録がなければ硬判定、記録が不適合なら硬判定に戻し理由を表示します。オンにするだけで必ず音質が改善するわけではありません。

再解析・試聴・停止
キー、フレーム、FEC方式の変更で古い解析と再生を破棄し、録音先頭から履歴を再構成します。「選択20ms」は1行、「この80ms」は4スロット、「前後約1秒」は周辺の文脈を含みます。録音の端では試聴範囲が短くなります。「停止」は再生を止めます。""",
    "ビット列・配置・秘話PN": """bit / byte / BIN / HEX
bitは0か1の1桁、byteは8bitです。BINは2進表示、HEXは16進表示で、16進1桁は4bitに相当します。例：BIN 1010 = HEX A = 10進10。MSBは上位桁、LSBは下位桁。表示・保存は先頭bitをbyteの上位bitから詰めます。

DIBIT36_received
デホワイトニング後の受信72bit（9byte）を、2bitずつ36組の受信配置で表示します。生の電波やIQサンプルではありません。

CODE72_received / CODE72_corrected_candidate
受信配置を並べ替えて、C0(24bit)、C1(23bit)、C2(11bit)、C3(14bit)の順にした72bitです。corrected_candidateは訂正で選んだ情報語を再符号化した候補です。赤は受信値と候補で違う位置であり、真の送信ビットを確定した印ではありません。

INFO49 / U / p
FECから得た情報49bit。u0(12bit)、u1(12bit)、u2(11bit)、u3(14bit)をMSBから連結した配置がINFO49です。p[0..48]はこの49bitの0始まりの位置。u0:b11のような表記は語内のbit番号で、b0〜b8の項目名とは別です。語内ではb0がLSBです。

T49
同じ49bitを既存の秘話解除アダプター用に並べ替えた配置です。INFO49と同じbit数でも順序が違うため、BINやHEXはそのまま比較できません。

PN / XOR / PN49_in_T49_order
PNは擬似乱数の0/1列です。XOR（排他的論理和）はPNが0なら元bitを保持、1なら反転する操作。T49_before_key XOR PN49 = T49_after_keyを比較できます。キー0では適用PNを全0として表示します。

PN196と位置
80msごとに196bitを作り、4ブロックで0〜48、49〜97、98〜146、147〜195を使います。ブロック内の表示順も並べ替えるため、T49のbit tに使う位置はoffset + THUMBDV_MAP[t]です。TCH2だけ記録されていても0からやり直しません。

FECのPNと秘話のPN
C1のFECにはu0から決まる別のPNがあります。秘話解除のキーやPN196とは独立した処理です。秘話キーを変えても受信ビットとFECの結果は変わりません。

青い強調と分散配置
b項目を選ぶとINFO49_after_keyの対応bitを青くします。例えばb0の取得位置はp[0,1,2,3,37,38,39]。b0〜b8の幅で先頭から切る方法は誤りです。

49bit保存時のパディング
7byte=56bitのうち先頭49bitが情報、末尾7bitは0を埋めた未使用領域です。末尾の0を音声情報に含めないでください。""",
    "FEC・e0/e1・品質の限界": """FEC（Forward Error Correction、前方誤り訂正）
追加した冗長bitを使って受信候補を選びます。72bitの内訳は情報49bitと冗長23bit。全49bitが均等に保護されているわけではありません。

C0 / C1 / C2 / C3とGolay
C0は12bitを24bitのGolay符号G24へ、C1は12bitを23bitのGolay符号G23へ符号化します。C1にはu0由来PNも適用されています。C2の11bitとC3の14bitはこのコーデックFECでは無保護です。

e0 / e1 / T
e0はC0の訂正候補までの距離（0〜4）、e1はC1の候補までの距離（0〜3）。異なるbitの数を距離と呼びます。T=e0+e1。値が小さいほど保護語と候補は近いですが、誤訂正や無保護語の誤りまでは分かりません。e0=0/e1=0も「音声全体が正しい」「キーが正しい」の証明ではありません。

failure / UNTRUSTED_FEC
この実装のfailureはe0=4です。復号器はfailureだけでなく、e0>=2かつT>=6も品質不適としてUNTRUSTED_FECにします。例えばe0=3/e1=3はfailure=falseでも通常音声に採用しません。実際のactionも一緒に確認してください。

procedure / hard_e0 / hard_e1
procedureは採用したFECの手順名。FEC-HARD-P23-v1は硬判定、FEC-SOFT-ML-CODEWORD-v1は記録済み軟判定コード語です。hard_e0/hard_e1は比較用の硬判定距離で、採用距離と異なる場合があります。

d23 / parity_delta
硬判定ではC0の23bit部分の距離がd23（0〜3）、追加パリティとの不一致がparity_delta（0か1）で、e0=d23+parity_deltaです。パリティは偶奇を検査するbit。軟判定手順のこの2値は0のプレースホルダーで、硬判定と同じ内訳として読みません。

軟判定の距離の注意
保存候補とのC0/C1距離をそれぞれ最大4/3に制限してe0/e1に渡します。多数bitが違う場合、表示e0+e1と赤い位置の総数が一致しないことがあります。

changed_code72 / changed_wire
候補と異なるbit位置の0始まり配列です。CODE72と受信配置の番号を混ぜないでください。これは訂正候補との差分で、測定した真の誤り位置ではありません。""",
    "b0〜b8・量子化・コードブック": """量子化とコードブックindex
多数の連続した音声値を、代表値・代表ベクトルの表に置き換えるのが量子化です。index（番号）はその表の行を選びます。番号が大きくても音が大きい・高い・良いという意味にはなりません。b項目を選ぶと、このブロックの説明と復元値が「量子化・音声パラメータ」に出ます。

b0：7bit、0〜127、ピッチと種別
通常VOICEでは0〜119からピッチ表を選びます。120〜123はERASURE、124〜125はSILENCE、126〜127はトーン領域ですが、先に専用マーカーを検査するためb0だけでTONEと決めません。SILENCEは符号化された無声音で、PCMが全0という意味ではありません。

b1：5bit、0〜31、V/UVの8帯域パターン
V（Voiced、有声）は周期的な励振、UV（Unvoiced、無声）は雑音状の励振です。「あ」のような音と「さ」の摩擦成分を思い浮かべると分かりやすく、同じ20msに両方が混在できます。この参照表では17〜31は全UVです。5bitをそのまま5帯域のフラグとして読まず、表の8帯域パターンを使います。

b2：5bit、0〜31、ゲイン差分Δγ
GAIN表を引いた差分と、直近の正常VOICEの履歴からgammaを復元します。gamma = GAIN[b2] + 0.5 × last_gamma。同じb2でも直前の音声で結果が変わります。b2やgammaは音量%やdB値ではありません。

b3：9bit、0〜511、PRBAのG2〜G4
b4：7bit、0〜127、PRBAのG5〜G8
PRBAはPrediction Residual Block Average（予測残差のブロック平均）。前の音声から予測できなかったスペクトルの大まかな形を、係数ベクトルで補います。PRBA24/PRBA58はそれぞれ選ばれた3要素/4要素です。周波数binの振幅を直接送っているわけではありません。

b5：5bit、0〜31、HOCブロック1
b6：4bit、0〜15、HOCブロック2
b7：4bit、0〜15、HOCブロック3
b8：3bit、0〜7、HOCブロック4
HOCはHigher Order Coefficients（高次係数）。PRBAで表す大まかな形に細かなスペクトル形状を補います。各番号は4要素の係数ベクトルを選びます。高次は変換の次数であり、そのまま高周波を意味しません。ブロックの長さで使う係数数が変わり、表の全4要素が常に使われるとは限りません。

幅・値・ビット列・位置
幅はその番号を表す桁数。例：b3の9bitなら0〜511を表せます。値は10進、ビット列はMSB→LSB。INFO49 pの位置リストもこの取得順です。番号が範囲内であるだけでは正しい受信や正しいキーとは判断できません。""",
    "音声モデル・周波数・振幅・位相": """pitch / f0_hz / f / omega（ω）
声の繰り返し周期に相当する基本周波数です。fは1サンプル当たりの周期数、f0_hz=f×8000、ω=2πfはrad/sample。例えばf0=200Hzなら周期は5msで、20msに4周期あります。この値はコーデックのモデル値で、PCMから測定した値ではありません。SILENCEのモデルは参照上の250Hzですが、無声音に声の高さがあるという意味ではないため上の周波数欄は「—」です。

L / frequency_hz
Lは合成モデルで扱う倍音数（通常VOICEの表は9〜56）。基本周波数が低いほど帯域内に多くの倍音が入ります。frequency_hzはf0×l、l=1..L。JSON配列の最初の要素が第1倍音で、配列index 0を0Hzと読まないでください。

v / vbar / Luv
vは帯域表から展開した倍音ごとのV/UV（1=有声、0=無声）。vbarは品質と振幅を使って平滑化した合成用の判定です。Luvはvbarで無声となった倍音数。vとvbarが違っても即ビット誤りとは限りません。

gain_delta / gamma（γ）
gain_delta=GAIN[b2]、gammaは履歴を反映した対数領域のゲインです。音量を比べるにはPCMや同じ条件の振幅も確認します。gammaだけから録音機の音量、RSSI、話者の距離は分かりません。

PRBA24 / PRBA58 / HOC / PRBA_R / residual_T
コードブックから選んだ係数、ブロック平均に戻したPRBA_R、各倍音へ展開した予測残差residual_Tです。残差は前の声からの予測との差で、受信雑音やFEC誤り数ではありません。

Lambda（Λ）/ M / E
Lambdaは残差・予測・ゲインを合わせた倍音ごとの対数振幅です。Mは線形振幅へ戻した補強前のモデル振幅で、無声成分の調整も含みます。Eはスペクトル補強と品質に応じた平滑化を経た合成用振幅です。グラフはEを表示します。いずれもマイクの音圧やdB SPLではなく、PCMのFFT測定値でもありません。

phi（φ）/ psi（ψ）
倍音ごとの位相、単位はradです。psiは連続した位相の基準、phiは無声成分などの補正を含む合成位相。履歴を積算するため±πや0〜2πの外にもなり得ます。絶対値の大きさを音質の良さと結び付けないでください。

noise_seed_after
無声音を合成する擬似乱数の内部状態です。同じ履歴を再現するための値で、秘話キーではありません。""",
    "復号状態・wire_typeとaction": """candidate_type / wire_type / action
candidate_typeはキー適用後の情報ビットだけを分類した診断候補。FEC不適でもVOICEやTONE_MARKERに見えることがあります。
wire_typeはFEC品質・トーン構文まで考慮した種別。
actionは履歴を含めて今回本当に出力した処理です。聞こえた音の解釈にはactionを優先します。

VOICE：通常音声モデルから合成。
SILENCE：符号化された無声音。必ずしもPCMゼロではありません。
ERASURE：情報内の使用不可指示。通常モデルに使わず、REPEATかMUTEDへ。
UNTRUSTED_FEC：FEC品質不適。候補パラメータを通常音声に使いません。
MISSING：20ms分の入力欠落。情報ビットがなく、e0/e1はnullです。
REPEAT：直前の合成モデルを反復して欠落を補います。位相などは進むため、直前のPCMをそのままコピーする処理とは異なります。
MUTED：品質悪化や無効入力連続により参照規則の小さなcomfort noiseを出力。
TONE：専用トーンを合成。ZERO_TONE：トーン構文のゼロ出力。
INVALID_TONE_MARKER / INVALID_TONE_ID / INVALID_TONE_SYNTAX：専用トーンのマーカー・番号・パディングが不適。
NOT_VOICE：確認済み非音声スロット。この画面の80msタイムラインでは無音で、通常音声として復号しません。

R / T / invalid_run / mute_reason
T=e0+e1、Rは品質履歴です。受信入力ごとにR_new=0.95×R_old+0.001064×T。Rは0〜1の正解確率や、無線のBERを直接測った値ではありません。MISSINGではRを保持します。invalid_runは無効20ms入力の連続数で最大4、正常種別では0に戻ります。この参照実装ではR>0.096またはinvalid_run=4でMUTED。両条件が成立した場合、mute_reasonはRを優先して表示します。非音声のタイムライン無音はこの連続数を進めません。

tau（τ）/ SE / VM / AM / aM
tauは振幅総和を抑える平滑化の内部閾値で、時間のmsではありません。SEは平滑化したエネルギーの状態。VMは有声化判定の振幅閾値で、"inf"はこの経路では追加の有声化をしない設定。AMは制限前の振幅総和、aMは適用倍率（1なら縮小なし）。tauが大きいから高品質とは言えません。

state_before / state_after
今回の20ms処理の直前／直後の状態。last_gamma/last_Lは直近の正常VOICEの予測履歴、prev_f/prev_Lは直前の通常合成モデル。SILENCE、REPEAT、TONEを挟むと同じ履歴を指すとは限りません。prev_fはcycles/sampleです。

frame_index / sample_position / missed
frame_indexは状態初期化後に処理した20msイベント数、sample_positionはそのサンプル位置（1イベントで160進む）。元録音のフレーム #や時刻ではありません。確認済み制御フレームで0に戻ります。録音のmissedは欠落した80msの数で、4×missed個の20ms欠落として進めます。

quality / profile / soft_note / input_error / uw_imag_max
qualityは品質情報の由来。この画面はFECの結果をINFO49に添えて復号器へ渡すため、metaのHARD_REPORTだけで硬判定の使用を断定しないでください。実際の採用方式はfec.procedureを確認します。profileは参照処理の識別子、soft_noteは軟判定不適合による硬判定への復帰理由、input_errorは入力／数値の例外と欠落処理への移行理由。uw_imag_maxは無声合成の逆FFTで残った虚数成分の最大値で、受信品質の直接指標ではありません。""",
    "TONE・トーン専用の値": """トーンは通常音声の別配置
u0の上位6bitが全1ならTONE_MARKERを先に検査します。b0〜b8の通常音声表を当てはめず、AD・ids・paddingを読みます。FEC不適のトーン候補を有効なトーンへ昇格しません。

AD / amplitude_reference
ADは7bit（0〜127）のトーン振幅番号。参照実装の振幅は32768×10^(0.03555×(AD−127))です。一般の音量%ではありません。二周波トーンでは各成分に半分の振幅を使います。

ids / tone_copy_mismatch
8bitのIDが4回格納されています。tone_copy_mismatchはコピー間の不一致。この参照実装は保護された第1IDを採用し、多数決では決めません。4個とも同じでもキーの正しさは証明できません。

IDとfrequency_hz
ID=5〜122は単一周波数で、周波数はID×31.25Hz。
ID=128〜163は専用の二周波表を使い、frequency_hzに2値を表示します。
ID=255はZERO_TONE（ゼロ出力）。それ以外はINVALID_TONE_ID。

padding
トーン末尾の4bitは0が必要です。非0ならINVALID_TONE_SYNTAXとなります。これは49bitを7byteに保存するときの末尾7bitのパディングとは別です。

周波数の表示は候補の診断情報
toneのfrequency_hzやamplitude_referenceが表示されても、実際に出た音はmeta.actionで確認します。品質不適ならREPEAT/MUTEDの場合があります。""",
    "波形・倍音グラフの読み方": """上段：PCM波形
横軸は0〜20ms、160sample。8kHzは1秒に8000サンプル、PCM16は符号付き16bit（−32768〜32767）の出力です。縦の表示倍率はブロックごとの最大絶対値で自動調整します。小さな雑音でも大きな波形に見えるため、別ブロックの見た目の高さだけでは音量を比較できません。表示される「最大絶対値」や保存PCMのRMSを同じ条件で比べます。

RMSとdBFS（保存PCMを比較するとき）
RMSはsample²の平均の平方根で、信号の大きさを見る指標です。20log10(RMS/32768)がこのPCM契約でのdBFSの目安。0PCMでは−∞です。dBFSはデジタルの最大振幅が基準で、室内の音圧dB SPLとは異なります。ピークが上限に張り付く場合は飽和の可能性があります。

下段：合成用の倍音E[l]
横軸はHz、各棒の位置はf0×l、縦は合成モデルの振幅Eです。緑はvbar=1（有声）、灰はvbar=0（無声）。灰の成分も無声の合成に使われ、音がない意味ではありません。高さはそのブロックの最大Eで自動調整します。PCMにFFTをかけた実測スペクトルではないので、測定のピークと1対1に対応するとは限りません。

モデルがない場合
TONE、REPEAT、MUTED、非音声、未記録には今回採用した通常音声モデルがないため、通常VOICEの倍音グラフを表示しません。波形があることと、今回の通常音声情報を採用したことは別です。

波形表示と保存は別
グラフの正規化は表示だけで、WAVや試聴PCMの値を変えません。この解析にはライブ再生のAGC、AI音声強調などを適用しません。""",
    "保存ファイル・比較の手順": """80ms WAV保存
選択フレーム4スロットの参照復号出力、640sample、8kHz、mono、PCM16を保存します。非音声や欠落の扱いを含むタイムラインです。これは新しくこの条件で合成した音声で、元録音のWAVそのものとは限りません。

解析JSON・BIN保存
JSONにはキー、フレーム番号、参照プロファイル、4スロットのビット・FEC・パラメータ・状態・PCM、元録音のメタデータを保存します。context_pcm（前後試聴の全音声）は保存対象外。BINは各記録済み音声ブロックの受信DIBIT36、受信／訂正候補CODE72、キー前後のINFO49/T49を別ファイルにします。72bitは9byte、49bitは7byteで末尾7bitが0です。

再現性のある比較
1. 同じ元録音・フレーム・ブロックを選びます。
2. キーとfec.procedureを記録します。
3. actionを確認し、候補だけの値と実際に合成したモデルを区別します。
4. 画面の自動倍率を音量比較に使わず、JSONのEやPCM、WAVを同じ尺度で比べます。
5. 比較する実装のprofileと履歴の初期化条件をそろえます。同じ49bitでも前の状態が違えばPCMは変わります。

資料
このガイドの値と閾値は同梱vendor/ambe2の処理に合わせています。詳しいローカル文書はapp/docs/ambe_voice_analysis.md、参照調査はD:/ai/ambe/AMBE2_DECODER_SPEC.md v0.13です。公開資料の入口はTIA-102.BABA Vocoder Description / Half-Rate Vocoder Annex：
https://connect.tiaonline.org/viewdocument/tia-102baba-vocoder-description
公開規格由来の定義と、この参照実装が選択した処理規則は区別して読んでください。""",
}


FIELD_HELP = {
    "b0": "7bitのピッチ表／種別番号です。0〜119は通常VOICE、120〜123はERASURE、124〜125はSILENCE。126〜127だけでトーンとは決めず、専用マーカーを先に検査します。Hzそのものではありません。",
    "b1": "5bitで8帯域の有声／無声パターン表を選びます。1=有声（周期的な励振）、0=無声（雑音状の励振）。5個のフラグではありません。参照表の17〜31は全UVです。合成では品質に応じてvからvbarへ平滑化します。",
    "b2": "5bitのGAIN表の番号です。表の差分Δγと直近の正常VOICEの履歴からgammaを復元します。同じ番号でも履歴が違えば復元ゲインは変わります。番号は音量%やdBではありません。",
    "b3": "9bit（0〜511）でPRBAのG2〜G4、3要素の係数ベクトルを選びます。PRBA（予測残差のブロック平均）は、前の音声からの予測に対する大まかなスペクトル形状の補正です。番号の大小は音量の大小ではありません。",
    "b4": "7bit（0〜127）でPRBAのG5〜G8、4要素の係数ベクトルを選びます。b3と合わせて予測残差の大まかな形状を表します。周波数や振幅の直接値ではありません。",
    **{f"b{i}": f"{width}bit（0〜{2 ** width - 1}）でHOCブロック{i - 4}の4要素の高次係数ベクトルを選びます。HOCはPRBAの大まかな形状に細部を補う係数です。高次は変換の次数で、高周波そのものではありません。ブロック長により採用する係数数は変わります。"
       for i, width in ((5, 5), (6, 4), (7, 4), (8, 3))},
}


def field_explanation(field, trace):
    """Explain a selected index using only the model actually accepted by the decoder."""
    name = field["name"]
    text = f"読み方：{FIELD_HELP[name]}\n表せる範囲：0〜{2 ** field['width'] - 1}\n"
    model = trace.get("model")
    if not model:
        return text + (f"今回のwire_type={trace['meta'].get('wire_type', '—')}、action={trace['meta'].get('action', '—')}。"
                       "以下のb値は診断候補で、今回の通常音声モデルには採用されていません。\n")
    if name == "b0":
        if trace["meta"]["action"] == "SILENCE":
            text += "今回はSILENCE。モデルの250Hzは無声合成用の参照値で、話者の声の高さではありません。\n"
        else:
            text += f"今回の復元：f0={model['f0_hz']:.3f} Hz、周期={1000 / model['f0_hz']:.3f} ms、倍音数L={model['L']}。\n"
    elif name == "b1":
        text += f"今回の倍音判定（第1倍音から）：v={model['v']}\n平滑化後：vbar={model['vbar']}\n"
    elif name == "b2":
        text += (f"今回の復元：gamma = Δγ({model['gain_delta']:.6g}) + 0.5 × last_gamma({trace['state_before']['last_gamma']:.6g})"
                 f" = {model['gamma']:.6g}。\n")
    elif name in ("b3", "b4"):
        key = "PRBA24" if name == "b3" else "PRBA58"
        text += f"今回選んだ{key}の係数：{model[key]}\n"
    else:
        text += f"今回選んだHOCブロック{int(name[1:]) - 4}の係数：{model['HOC'][int(name[1:]) - 5]}\n"
    return text + "復元値はこの参照実装のモデル値です。詳しい単位と判断の注意は「項目・用語ガイド」を参照してください。\n"


def state_explanation(trace):
    meta = trace["meta"]
    text = (f"今回の読み方：wire_type={meta.get('wire_type', '—')} / action={meta.get('action', '—')}\n"
            "candidate_typeはビットだけの診断候補、wire_typeは品質を考慮した種別、actionは実際の出力処理です。\n")
    fec = trace.get("fec")
    if fec:
        text += (f"採用FEC={fec['procedure']}、T=e0+e1={fec['e0'] + fec['e1']}、failure={fec['failure']}。\n"
                 "e0=4、またはe0>=2かつT>=6は通常音声に採用しません。FECは秘話キーの正否を検証しません。\n")
    if "R" in meta:
        text += f"品質履歴R={meta['R']:.6g}、無効入力の連続数invalid_run={meta['invalid_run']}（最大4）。\n"
    action = meta.get("action")
    if action == "REPEAT":
        text += "今回のビットによる通常音声ではなく、前の合成モデルの反復です。位相は進むためPCMの単純コピーではありません。\n"
    elif action == "MUTED":
        text += f"ミュート理由={meta.get('mute_reason', '—')}。この参照実装は小さなcomfort noiseを出力します。\n"
    elif action == "SILENCE":
        text += "SILENCEは符号化された無声音です。PCMが全0になるとは限りません。\n"
    return text + ("Rは正解確率や実測BERではなく、tauは時間ではなく振幅平滑化の閾値です。\n"
                   "state_before/afterは20ms処理の前後。frame_indexは制御フレームで初期化した後の20ms処理数です。\n"
                   "同じb値でもゲイン・予測・位相の履歴で音が変わります。詳しくは「項目・用語ガイド」の復号状態を参照してください。\n\n")


TONE_HELP = ("ADは0〜127の振幅番号、idsは4個のトーンID、paddingは末尾4bit（0が必要）です。\n"
             "この参照実装は第1IDを採用します。5〜122はID×31.25Hz、128〜163は二周波表、255はゼロ出力です。\n"
             "frequency_hz/amplitude_referenceは候補の診断値です。実際の出力は復号状態のactionで確認してください。\n"
             "詳しくは「項目・用語ガイド」のTONEを参照してください。\n\n")
