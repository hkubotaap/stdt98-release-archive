"""Packet splitting for the non-T98 4800 sym/s 4FSK signal seen on 3R ch11.

On 2026-10-05 a continuous signal sat on 351.2625 MHz (3R ch11 = 97ch ch38):
4FSK at 4800 sym/s with about +-650 / +-1900 Hz deviation, i.e. twice the
T98 symbol rate and deviation. None of the DMR, P25, NXDN, YSF, M17 or T98
sync words occur in it. Its structure, recovered from a 30 s capture:

  idle      steady +1 symbols (a tone at about +630 Hz), 170-650 symbols
  preamble  32 symbol pairs "x -1", x = +3 or -3 changing per packet
  header    a fixed block, sent twice 192 symbols apart
  data      the rest; total packet 3925-4326 symbols, one packet a second

Consecutive packets' data agree on about 55 % of their symbols in long
identical stretches, so the payload is coded but not encrypted. Its coding is
not known yet; this module only cuts the symbol stream into packets so they
can be logged and compared.

Symbols are soft values scaled so the outer levels sit near +-3; a symbol is
written as its level index 0..3 (-3, -1, +1, +3).
"""
from dataclasses import dataclass

import numpy as np

SYMBOL_RATE = 4800.0
DEVIATION_HZ = 1890.0  # outer level; quadrature demod gain maps it to +-1 before the x3
IDLE_LEVEL = 2  # +1
IDLE_MIN = 32
IDLE_TOLERANCE = 2
MIN_PACKET = 64
MAX_PACKET = 8000
HEADER_SEARCH = 400
HEADER_REPEAT = 192
HEADER_MIN_MATCH = 45

# First 53 symbols of the fixed header, as level indices.
HEADER = np.array([{"A": 0, "B": 1, "C": 2, "D": 3}[c]
                   for c in "DDCCCBCDCDBCACDADCCCDADCDBBDCCBAABDDCADCCDBBACDDACCDB"], dtype=np.int8)


def quantize(soft):
    return np.clip(np.round((np.asarray(soft, dtype=np.float32) + 3.0) / 2.0), 0, 3).astype(np.int8)


def symbols_text(levels):
    return "".join("0123"[v] for v in levels)


@dataclass
class Packet:
    start: int            # absolute symbol index of the first symbol after idle
    idle: int             # idle symbols before it
    levels: np.ndarray    # level indices 0..3
    soft: np.ndarray
    truncated: bool = False

    @property
    def length(self):
        return len(self.levels)

    def header(self):
        """(offset, matched symbols) of the best header match, and of its repeat."""
        def best(lo, hi):
            hi = min(hi, self.length - len(HEADER))
            if hi <= lo:
                return None, 0
            scores = np.array([int(np.sum(self.levels[k:k + len(HEADER)] == HEADER)) for k in range(lo, hi)])
            # Both copies match about equally well; the first one is the header.
            good = np.flatnonzero(scores >= HEADER_MIN_MATCH)
            k = int(good[0]) if len(good) else int(np.argmax(scores))
            return lo + k, int(scores[k])

        first, score = best(0, HEADER_SEARCH)
        if first is None:
            return None, 0, None, 0
        second, score2 = best(first + HEADER_REPEAT - 4, first + HEADER_REPEAT + 5)
        return first, score, second, score2

    def quality(self):
        """RMS distance of the soft symbols from their decided levels (0 = clean eye)."""
        if not len(self.soft):
            return float("nan")
        return float(np.sqrt(np.mean((self.soft - (2.0 * self.levels - 3.0)) ** 2)))

    def summary(self, previous=None):
        first, score, second, score2 = self.header()
        out = {"start": self.start, "idle": self.idle, "length": self.length,
               "truncated": self.truncated, "quality": round(self.quality(), 3),
               "header": first, "header_match": f"{score}/{len(HEADER)}",
               "header2": second, "header2_match": f"{score2}/{len(HEADER)}"}
        if first is not None:
            out["preamble"] = symbols_text(self.levels[:first])
        if previous is not None:
            # Compare from the header on, so a shifted preamble does not misalign the data.
            ours, theirs = self.levels[first or 0:], previous.levels[previous.header()[0] or 0:]
            n = min(len(ours), len(theirs))
            out["same_as_previous"] = round(float(np.mean(ours[:n] == theirs[:n])), 3) if n else None
        out["symbols"] = symbols_text(self.levels)
        return out


class PacketSplitter:
    """Cuts a stream of soft symbols into packets at the idle-tone gaps."""

    def __init__(self, idle_min=IDLE_MIN, tolerance=IDLE_TOLERANCE, max_packet=MAX_PACKET):
        self.idle_min = idle_min
        self.tolerance = tolerance
        self.max_packet = max_packet
        self.soft = np.zeros(0, dtype=np.float32)
        self.base = 0          # absolute index of soft[0]
        self.state = "search"
        self.idle_start = 0
        self.packet_start = 0
        self.packet_idle = 0

    def _idle_windows(self, levels):
        """mask[i]: the idle_min symbols starting at i are (almost) all idle."""
        if len(levels) < self.idle_min:
            return np.zeros(0, dtype=bool)
        hits = np.convolve((levels == IDLE_LEVEL).astype(np.int16), np.ones(self.idle_min, np.int16), "valid")
        return hits >= self.idle_min - self.tolerance

    def _drop(self, count):
        self.soft = self.soft[count:]
        self.base += count

    def feed(self, soft):
        """Add soft symbols; return the packets completed by them."""
        self.soft = np.concatenate([self.soft, np.asarray(soft, dtype=np.float32)])
        done = []
        while True:
            levels = quantize(self.soft)
            mask = self._idle_windows(levels)
            idle = levels == IDLE_LEVEL
            if self.state == "search":
                hits = np.flatnonzero(mask)
                if not len(hits):
                    self._drop(max(0, len(self.soft) - self.idle_min))
                    return done
                k = int(hits[0])
                while k < len(idle) and not idle[k]:
                    k += 1
                self._drop(k)
                self.state, self.idle_start = "idle", self.base
            elif self.state == "idle":
                gaps = np.flatnonzero(~mask)
                if not len(gaps):
                    self._drop(max(0, len(self.soft) - self.idle_min))
                    return done
                end = int(gaps[0]) + self.idle_min - 1
                while end > 0 and not idle[end - 1]:
                    end -= 1
                self._drop(end)
                self.state, self.packet_start = "packet", self.base
                self.packet_idle = self.base - self.idle_start
            else:
                offset = self.packet_start - self.base
                hits = np.flatnonzero(mask[offset:]) if len(mask) > offset else np.zeros(0, int)
                if len(hits):
                    end = offset + int(hits[0])
                    while end < len(idle) and not idle[end]:
                        end += 1
                    truncated = False
                elif len(self.soft) - offset > self.max_packet:
                    end, truncated = offset + self.max_packet, True
                else:
                    return done
                if end - offset < MIN_PACKET:
                    # A short burst of noise inside the idle tone, not a packet.
                    self._drop(end)
                    self.state = "idle"
                    continue
                done.append(Packet(self.packet_start, self.packet_idle, levels[offset:end].copy(),
                                   self.soft[offset:end].copy(), truncated))
                self._drop(end)
                self.state = "search" if truncated else "idle"
                self.idle_start = self.base
