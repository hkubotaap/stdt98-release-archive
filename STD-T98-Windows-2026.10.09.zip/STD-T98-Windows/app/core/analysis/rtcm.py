"""RTCM 3 messages: CRC-24Q, field decoding and study notes (data analysis window).

Field layouts follow RTCM 10403.x (DFxxx numbers in the comments). Decoded
values are what the message says; for a message whose CRC failed they are only
a hint (any bit may be wrong).

Notes (MESSAGE_NOTES / FIELD_NOTES) are short Japanese explanations shown next
to the values, for learning how an RTK base station describes itself.
"""
import datetime
import math

GPS_EPOCH_UNIX = 315964800          # 1980-01-06 00:00:00 UTC
DEFAULT_LEAP_SECONDS = 18           # GPS - UTC since 2017-01-01 (1013 carries the current value)
LIGHT_MS_M = 299792.458             # one light-millisecond: ambiguity unit of 1002/1004
GLONASS_AMBIGUITY_M = 599584.916    # two light-milliseconds: ambiguity unit of 1010/1012
WEEKDAYS = "日月火水木金土"


def crc24q(data):
    crc = 0
    for byte in data:
        crc ^= byte << 16
        for _ in range(8):
            crc <<= 1
            if crc & 0x1000000:
                crc ^= 0x1864CFB
    return crc & 0xFFFFFF


class BitReader:
    def __init__(self, data):
        self.data, self.pos = data, 0

    def u(self, count):
        value = 0
        for _ in range(count):
            value = (value << 1) | ((self.data[self.pos >> 3] >> (7 - (self.pos & 7))) & 1)
            self.pos += 1
        return value

    def s(self, count):
        """Two's complement."""
        value = self.u(count)
        return value - (1 << count) if value & (1 << (count - 1)) else value

    def sm(self, count):
        """Sign-magnitude (GLONASS ephemeris fields)."""
        negative = self.u(1)
        value = self.u(count - 1)
        return -value if negative else value

    def text(self, count):
        return bytes(self.u(8) for _ in range(count)).decode("latin-1", "replace")


RTCM_NAMES = {
    1001: "GPS L1 観測量", 1002: "GPS L1 観測量(拡張)", 1003: "GPS L1/L2 観測量", 1004: "GPS L1/L2 観測量(拡張)",
    1005: "基準局位置 (ARP)", 1006: "基準局位置 (ARP+アンテナ高)", 1007: "アンテナ記述子",
    1008: "アンテナ記述子+シリアル", 1009: "GLONASS L1 観測量", 1010: "GLONASS L1 観測量(拡張)",
    1011: "GLONASS L1/L2 観測量", 1012: "GLONASS L1/L2 観測量(拡張)", 1013: "システムパラメータ",
    1019: "GPS 衛星軌道 (エフェメリス)", 1020: "GLONASS 衛星軌道", 1029: "テキスト (Unicode)",
    1033: "受信機・アンテナ記述子",
    1042: "BeiDou 衛星軌道", 1044: "QZSS 衛星軌道", 1045: "Galileo F/NAV 軌道", 1046: "Galileo I/NAV 軌道",
    1014: "ネットワークRTK 補助局データ", 1015: "ネットワークRTK 電離層補正差",
    1016: "ネットワークRTK 幾何補正差", 1017: "ネットワークRTK 幾何+電離層補正差",
    1021: "座標変換パラメータ (Helmert)", 1022: "座標変換パラメータ (Molodenski-Badekas)",
    1023: "残差 (楕円体格子)", 1024: "残差 (平面格子)", 1025: "投影パラメータ (LCC2SP以外)",
    1026: "投影パラメータ (LCC2SP)", 1027: "投影パラメータ (OM)",
    1230: "GLONASS コード/位相バイアス",
}
MSM_SYSTEMS = {107: "GPS", 108: "GLONASS", 109: "Galileo", 110: "SBAS", 111: "QZSS", 112: "BeiDou", 113: "NavIC"}
EPHEMERIS_SAT_BITS = {1042: 6, 1044: 4, 1045: 6, 1046: 6}

# Legacy observation messages: per-satellite bits after the header.
GPS_OBS_SAT_BITS = {1001: 58, 1002: 74, 1003: 101, 1004: 125}       # header 64 bits
GLONASS_OBS_SAT_BITS = {1009: 64, 1010: 79, 1011: 107, 1012: 130}   # header 61 bits

MESSAGE_NOTES = {
    "obs": ("基準局が同じ瞬間(エポック)に受けた各衛星の擬似距離と搬送波位相。移動局は自分の観測量との差を取り、"
            "共通の誤差(衛星時計・軌道・電離層・対流圏)を打ち消してcm級の位置を出します。RTKの本体で、通常1秒ごとに送られます。"
            "L1のみ(1001/1002, 1009/1010)とL1/L2(1003/1004, 1011/1012)、「拡張」はC/N0と整数アンビギュイティ付き。"),
    "msm": ("MSM(Multiple Signal Message)は新しい形式の観測量。1つの形式で全衛星系・全信号を扱え、"
            "MSM4以上は信号ごとのC/N0、MSM5/7はドップラーも含みます。"),
    1005: ("基準局アンテナの基準点(ARP)の位置(地球中心座標 ECEF)。移動局は「基準局からのベクトル」を求めるので、"
           "最終的な位置の精度はこの座標の正しさで決まります。数十秒〜数分ごとに送られます。"),
    1007: "基準局のアンテナ型式(IGS名)。移動局はアンテナ位相中心の補正(PCV)に使います。",
    1013: ("基準局が「何番のメッセージを何秒ごとに送るか」の予定表と、日付・UTC時刻・うるう秒(GPS時刻とUTCの差)。"),
    1014: ("ネットワークRTK(VRS/FKP/MAC方式)で、主局と補助局の位置関係。複数の基準局を組み合わせて"
           "広い範囲を補正するしくみの一部です。"),
    "net": ("ネットワークRTKの補正差(主局と補助局の誤差の違い)。1015=電離層、1016=幾何(軌道・対流圏)、1017=両方。"
            "移動局はこれで基準局から離れた場所の誤差を補間します。"),
    1019: ("GPS衛星の軌道要素(エフェメリス)。航法メッセージと同じ内容で、移動局がまだ衛星から直接受けていなくても"
           "すぐに衛星位置を計算できるよう基準局が中継します。軌道長半径・離心率・傾斜角などのケプラー要素です。"),
    1020: ("GLONASS衛星の軌道情報。GPSと違い、基準時刻tbでの衛星の位置・速度・加速度(PZ-90座標)をそのまま送り、"
           "受信機が運動方程式を積分して衛星位置を出します。"),
    1021: ("座標変換パラメータ。GNSSで求めた位置(ITRF/WGS84系)を、その国の測地系(日本ならJGD2011など)に"
           "変換する7パラメータ(平行移動3・回転3・縮尺1)。"),
    1230: "GLONASSの受信機間バイアス(コードと位相のずれ)。異なるメーカーの受信機の組み合わせでFIX率を上げるため。",
    "vendor": "メーカー独自メッセージ(4001-4095)。中身は各社の非公開仕様です。",
}
for _t in (1006,):
    MESSAGE_NOTES[_t] = MESSAGE_NOTES[1005]
for _t in (1008, 1033):
    MESSAGE_NOTES[_t] = MESSAGE_NOTES[1007] + ("1008はシリアル番号、1033は受信機の型式・ファームウェアも含みます。")
for _t in (1022,):
    MESSAGE_NOTES[_t] = MESSAGE_NOTES[1021]

# key -> (label, note)
FIELD_NOTES = {
    "station": ("基準局ID", "基準局を区別する番号(0-4095)。同じ局のメッセージは同じ番号です。"),
    "system": ("衛星系", ""),
    "time_system": ("時刻系", "GPST=GPS時刻(UTC+うるう秒)、GLONASST=モスクワ時刻(UTC+3時間)、BDT=BeiDou時刻(GPST-14秒)。"),
    "epoch_s": ("エポック", "観測した瞬間。GPS系は週の始め(日曜0時)からの秒、GLONASSはその日の0時からの秒。"),
    "epoch_text": ("エポック(読み)", ""),
    "delay_s": ("受信までの遅れ", "観測した瞬間からこのフレームを受けるまでの秒数(PCの時計基準なので、PCの時刻がずれていると値もずれます)。"
                                   "補正データは古くなるほど精度が落ち、数秒以内が目安です。"),
    "sync": ("同期フラグ", "Trueなら同じエポックの観測量の続きがまだある(例: GPSの後にGLONASS)。"),
    "satellites": ("衛星数", "このメッセージに含まれる衛星の数。"),
    "smoothing": ("平滑化", "コード擬似距離を搬送波で平滑化しているか(ハッチフィルタ)。"),
    "sats": ("衛星ごとの値", ""),
    "itrf_year": ("ITRF実現年", "座標の基準(ITRFの版)。0は未指定。"),
    "systems": ("対応衛星系", "この基準局が観測している衛星系。"),
    "reference_station": ("物理局でない", "Trueなら仮想基準点(VRS)などの計算上の局。"),
    "ecef_x": ("ECEF X [m]", "地球中心を原点とする直交座標。X軸は経度0°、Z軸は北極方向。"),
    "ecef_y": ("ECEF Y [m]", ""),
    "ecef_z": ("ECEF Z [m]", ""),
    "lat": ("緯度 [°]", "ECEFからWGS84楕円体で計算した値。"),
    "lon": ("経度 [°]", ""),
    "height_m": ("楕円体高 [m]", "楕円体からの高さ。標高(ジオイド高を引いた値)とは日本で約30-40m違います。"),
    "antenna_height_m": ("アンテナ高 [m]", "標石などの地上の点からARPまでの高さ。"),
    "antenna": ("アンテナ型式", "IGSの型式名。空欄なら未設定。"),
    "setup_id": ("セットアップID", "アンテナ設置を変えたときに増える番号。"),
    "antenna_serial": ("アンテナシリアル", ""),
    "receiver": ("受信機型式", ""),
    "firmware": ("ファームウェア", ""),
    "receiver_serial": ("受信機シリアル", ""),
    "mjd": ("修正ユリウス日", "1858年11月17日からの日数。"),
    "date": ("日付(UTC)", ""),
    "utc_time": ("UTC時刻", ""),
    "leap_seconds": ("うるう秒", "GPS時刻とUTCの差(秒)。2017年から18秒。"),
    "schedule": ("送信予定", "メッセージ番号ごとの送信間隔。"),
    "network_id": ("ネットワークID", "ネットワークRTKの網の番号。"),
    "subnetwork_id": ("サブネットワークID", ""),
    "aux_count": ("補助局数", ""),
    "master_station": ("主局ID", "ネットワークRTKで基準とする局。"),
    "aux_station": ("補助局ID", ""),
    "dlat_deg": ("補助局-主局 緯度差 [°]", ""),
    "dlon_deg": ("補助局-主局 経度差 [°]", ""),
    "dh_m": ("補助局-主局 高さの差 [m]", ""),
    "distance_km": ("主局-補助局 距離(概算) [km]", "緯度差・経度差からの概算(主局の緯度は1005が無ければ35°で計算)。"),
    "multiple_message": ("続きあり", ""),
    "satellite": ("衛星番号", "GPSはPRN、GLONASSはスロット番号。"),
    "week": ("GPS週番号", "1980年1月6日からの週番号を1024で割った余り。"),
    "ura": ("URA指標", "衛星が示す距離精度の目安(小さいほど良い)。"),
    "iode": ("IODE", "軌道情報の発行番号。基準局と移動局で同じIODEの軌道を使う必要があります。"),
    "iodc": ("IODC", "時計情報の発行番号。"),
    "toc_s": ("toc [秒]", "衛星時計補正の基準時刻(週内秒)。"),
    "toe_s": ("toe [秒]", "軌道要素の基準時刻(週内秒)。通常2時間ごとに更新されます。"),
    "eccentricity": ("離心率", "軌道の楕円の度合い。GPSは0.02以下のほぼ円軌道。"),
    "semi_major_km": ("軌道長半径 [km]", "GPSは約26,560 km(高度約20,200 km)。"),
    "inclination_deg": ("軌道傾斜角 [°]", "赤道面に対する傾き。GPSは約55°。"),
    "health": ("健康状態", "0なら正常。0以外の衛星は測位に使いません。"),
    "freq_ch": ("周波数チャンネル", "GLONASSは衛星ごとに周波数が違う(FDMA)。L1 = 1602 MHz + k×0.5625 MHz。"),
    "tk": ("tk", "この軌道情報のフレーム開始時刻(モスクワ時刻)。"),
    "tb": ("tb", "軌道情報の基準時刻(モスクワ時刻、15分刻み)。"),
    "x_km": ("X [km]", "tbでの衛星位置(PZ-90座標)。"),
    "y_km": ("Y [km]", ""),
    "z_km": ("Z [km]", ""),
    "radius_km": ("地心距離 [km]", "地球中心からの距離。GLONASSは約25,500 km(高度約19,100 km)。"),
    "source_name": ("変換元の測地系", ""),
    "target_name": ("変換先の測地系", ""),
    "system_id": ("系ID", "変換の識別番号。"),
    "plate_number": ("プレート番号", "地殻プレート(0=未使用)。プレート運動の補正に使います。"),
    "computation": ("計算方法", "0=標準7パラメータ(近似式)、1=厳密式 など。"),
    "height_type": ("高さの種類", "0=楕円体高、1=標高(変換先)、2=標高(変換元)。"),
    "origin_lat_deg": ("適用範囲の原点 緯度 [°]", ""),
    "origin_lon_deg": ("適用範囲の原点 経度 [°]", ""),
    "ext_lat_deg": ("適用範囲の幅 緯度 [°]", ""),
    "ext_lon_deg": ("適用範囲の幅 経度 [°]", ""),
    "dx_m": ("平行移動 dX [m]", ""),
    "dy_m": ("平行移動 dY [m]", ""),
    "dz_m": ("平行移動 dZ [m]", ""),
    "r1_arcsec": ("回転 R1 [秒角]", ""),
    "r2_arcsec": ("回転 R2 [秒角]", ""),
    "r3_arcsec": ("回転 R3 [秒角]", ""),
    "ds_ppm": ("縮尺 dS [ppm]", ""),
    "msm": ("MSM番号", "1-7。数字が大きいほど含む情報が多い。"),
    "signals": ("信号の種類数", "L1C/A・L2C・L5など、観測している信号の種類。"),
    "epoch": ("エポック(生値)", ""),
    "truncated": ("途中で終わり", "メッセージが短く、全部の項目を読めませんでした。"),
}
# Notes on per-satellite columns (衛星タブ / 詳細表示)
SAT_NOTES = {
    "cnr": "C/N0(搬送波対雑音密度比, dB-Hz)。衛星の電波の強さ。40以上で良好、30未満は弱く、ビルや木の陰で下がります。",
    "lock": "ロック時間。搬送波を途切れず追尾している時間。短いと位相が飛んだ(サイクルスリップ)直後で、整数アンビギュイティを解き直します。",
    "pseudorange": "擬似距離。電波の伝搬時間×光速。受信機時計の誤差を含むので「擬似」。",
}


def message_note(msg_type):
    if msg_type in MESSAGE_NOTES:
        return MESSAGE_NOTES[msg_type]
    if msg_type in GPS_OBS_SAT_BITS or msg_type in GLONASS_OBS_SAT_BITS:
        return MESSAGE_NOTES["obs"]
    if 1015 <= msg_type <= 1017:
        return MESSAGE_NOTES["net"]
    if msg_type // 10 in MSM_SYSTEMS and 1 <= msg_type % 10 <= 7:
        return MESSAGE_NOTES["msm"]
    if 4001 <= msg_type <= 4095:
        return MESSAGE_NOTES["vendor"]
    return ""


def rtcm_name(msg_type):
    if msg_type in RTCM_NAMES:
        return RTCM_NAMES[msg_type]
    if 4001 <= msg_type <= 4095:
        return "メーカー独自メッセージ"
    system = MSM_SYSTEMS.get(msg_type // 10)
    if system and 1 <= msg_type % 10 <= 7:
        return f"{system} MSM{msg_type % 10} 観測量"
    return "その他"


def ecef_to_llh(x, y, z):
    """WGS84 ECEF (m) -> latitude, longitude (deg), ellipsoidal height (m)."""
    a, f = 6378137.0, 1 / 298.257223563
    e2 = f * (2 - f)
    lon = math.atan2(y, x)
    p = math.hypot(x, y)
    lat = math.atan2(z, p * (1 - e2))
    for _ in range(8):
        n = a / math.sqrt(1 - e2 * math.sin(lat) ** 2)
        height = p / math.cos(lat) - n
        lat = math.atan2(z, p * (1 - e2 * n / (n + height)))
    n = a / math.sqrt(1 - e2 * math.sin(lat) ** 2)
    return math.degrees(lat), math.degrees(lon), p / math.cos(lat) - n


def lock_time_s(indicator):
    """Minimum lock time (s) of the 7-bit lock-time indicator (DF013/DF019/DF043/DF049)."""
    i = indicator
    if i < 24:
        return i
    if i < 48:
        return 2 * i - 24
    if i < 72:
        return 4 * i - 120
    if i < 96:
        return 8 * i - 408
    if i < 120:
        return 16 * i - 1176
    if i < 127:
        return 32 * i - 3096
    return 937


def _clock_text(seconds):
    seconds %= 86400
    h, rest = divmod(seconds, 3600)
    m, s = divmod(rest, 60)
    return f"{int(h):02d}:{int(m):02d}:{s:06.3f}"


def week_time_text(seconds_of_week, system="GPST"):
    day, rest = divmod(seconds_of_week, 86400)
    return f"{WEEKDAYS[int(day) % 7]} {_clock_text(rest)} {system}"


def _cnr(value):
    return value * 0.25 if value else None   # 0 = not computed


def _decode_gps_obs(r, msg_type, fields):
    fields["system"], fields["time_system"] = "GPS", "GPST"
    fields["station"] = r.u(12)
    fields["epoch_s"] = r.u(30) / 1000
    fields["epoch_text"] = week_time_text(fields["epoch_s"])
    fields["sync"] = bool(r.u(1))
    count = r.u(5)
    fields["satellites"] = count
    fields["smoothing"] = bool(r.u(1))
    r.u(3)
    extended, dual = msg_type in (1002, 1004), msg_type in (1003, 1004)
    sats = []
    for _ in range(count):
        sat = {"sat": r.u(6), "l1_code": "P" if r.u(1) else "C/A"}
        pseudorange = r.u(24) * 0.02
        r.s(20)
        sat["lock_l1_s"] = lock_time_s(r.u(7))
        if extended:
            sat["pseudorange_m"] = round(r.u(8) * LIGHT_MS_M + pseudorange, 2)
            sat["cnr_l1"] = _cnr(r.u(8))
        if dual:
            r.u(2)
            r.s(14)
            r.s(20)
            sat["lock_l2_s"] = lock_time_s(r.u(7))
            if extended:
                sat["cnr_l2"] = _cnr(r.u(8))
        sats.append(sat)
    fields["sats"] = sats
    fields["sat_ids"] = [s["sat"] for s in sats]


def _decode_glonass_obs(r, msg_type, fields):
    fields["system"], fields["time_system"] = "GLONASS", "GLONASST"
    fields["station"] = r.u(12)
    fields["epoch_s"] = r.u(27) / 1000
    fields["epoch_text"] = f"{_clock_text(fields['epoch_s'])} モスクワ (UTC {_clock_text(fields['epoch_s'] - 10800)})"
    fields["sync"] = bool(r.u(1))
    count = r.u(5)
    fields["satellites"] = count
    fields["smoothing"] = bool(r.u(1))
    r.u(3)
    extended, dual = msg_type in (1010, 1012), msg_type in (1011, 1012)
    sats = []
    for _ in range(count):
        sat = {"sat": r.u(6), "l1_code": "P" if r.u(1) else "C/A", "freq_ch": r.u(5) - 7}
        pseudorange = r.u(25) * 0.02
        r.s(20)
        sat["lock_l1_s"] = lock_time_s(r.u(7))
        if extended:
            sat["pseudorange_m"] = round(r.u(7) * GLONASS_AMBIGUITY_M + pseudorange, 2)
            sat["cnr_l1"] = _cnr(r.u(8))
        if dual:
            r.u(2)
            r.s(14)
            r.s(20)
            sat["lock_l2_s"] = lock_time_s(r.u(7))
            if extended:
                sat["cnr_l2"] = _cnr(r.u(8))
        sats.append(sat)
    fields["sats"] = sats
    fields["sat_ids"] = [s["sat"] for s in sats]


def _decode_msm(r, msg_type, fields):
    system = MSM_SYSTEMS[msg_type // 10]
    fields["station"] = r.u(12)
    epoch = r.u(30)
    fields["epoch"] = epoch
    if system == "GLONASS":
        day, ms = epoch >> 27, epoch & ((1 << 27) - 1)
        fields["time_system"], fields["epoch_s"] = "GLONASST", ms / 1000
        fields["epoch_text"] = f"{_clock_text(ms / 1000)} モスクワ (曜日 {day})"
    else:
        fields["time_system"] = "BDT" if system == "BeiDou" else "GPST"
        fields["epoch_s"] = epoch / 1000
        fields["epoch_text"] = week_time_text(epoch / 1000, fields["time_system"])
    fields["multiple_message"] = bool(r.u(1))
    r.u(3 + 7 + 2 + 2 + 1 + 3)
    sat_mask = r.u(64)
    sig_mask = r.u(32)
    satellites = [i + 1 for i in range(64) if sat_mask >> (63 - i) & 1]
    fields.update(system=system, msm=msg_type % 10, satellites=len(satellites), sat_ids=satellites,
                  signals=bin(sig_mask).count("1"), sats=[{"sat": s} for s in satellites])


def _decode_1013(r, fields):
    fields["station"] = r.u(12)
    mjd = r.u(16)
    seconds = r.u(17)
    count = r.u(5)
    fields["mjd"] = mjd
    fields["date"] = (datetime.date(1858, 11, 17) + datetime.timedelta(days=mjd)).isoformat()
    fields["utc_time"] = _clock_text(seconds)
    fields["leap_seconds"] = r.u(8)
    schedule = []
    for _ in range(count):
        msg_type = r.u(12)
        sync = bool(r.u(1))
        schedule.append({"type": msg_type, "name": rtcm_name(msg_type), "sync": sync, "interval_s": r.u(16) / 10})
    fields["schedule"] = schedule


def _decode_1014(r, fields):
    fields["network_id"] = r.u(8)
    fields["subnetwork_id"] = r.u(4)
    fields["aux_count"] = r.u(5)
    fields["master_station"] = r.u(12)
    fields["aux_station"] = r.u(12)
    fields["station"] = fields["master_station"]
    fields["dlat_deg"] = round(r.s(20) * 25e-6, 6)
    fields["dlon_deg"] = round(r.s(21) * 25e-6, 6)
    fields["dh_m"] = r.s(23) * 0.001


def _decode_network(r, fields):
    fields["network_id"] = r.u(8)
    fields["subnetwork_id"] = r.u(4)
    fields["time_system"] = "GPST"
    fields["epoch_s"] = r.u(23) / 10
    fields["epoch_text"] = week_time_text(fields["epoch_s"])
    fields["multiple_message"] = bool(r.u(1))
    fields["master_station"] = r.u(12)
    fields["aux_station"] = r.u(12)
    fields["station"] = fields["master_station"]
    fields["satellites"] = r.u(4)


def _decode_1019(r, fields):
    fields["system"] = "GPS"
    fields["satellite"] = r.u(6)
    fields["week"] = r.u(10)
    fields["ura"] = r.u(4)
    r.u(2)                      # code on L2
    r.s(14)                     # IDOT
    fields["iode"] = r.u(8)
    fields["toc_s"] = r.u(16) * 16
    r.s(8); r.s(16); r.s(22)    # af2, af1, af0
    fields["iodc"] = r.u(10)
    r.s(16); r.s(16); r.s(32); r.s(16)   # Crs, delta n, M0, Cuc
    fields["eccentricity"] = round(r.u(32) * 2 ** -33, 7)
    r.s(16)                     # Cus
    sqrt_a = r.u(32) * 2 ** -19
    fields["semi_major_km"] = round(sqrt_a ** 2 / 1000, 1)
    fields["toe_s"] = r.u(16) * 16
    r.s(16); r.s(32); r.s(16)   # Cic, Omega0, Cis
    fields["inclination_deg"] = round(r.s(32) * 2 ** -31 * 180, 3)
    r.s(16); r.s(32); r.s(24); r.s(8)    # Crc, omega, OmegaDot, tGD
    fields["health"] = r.u(6)


def _decode_1020(r, fields):
    fields["system"] = "GLONASS"
    fields["satellite"] = r.u(6)
    fields["freq_ch"] = r.u(5) - 7
    r.u(1); r.u(1); r.u(2)      # almanac health, availability, P1
    tk = r.u(12)
    fields["tk"] = f"{tk >> 7:02d}:{(tk >> 1) & 0x3F:02d}:{30 * (tk & 1):02d}"
    fields["health"] = r.u(1)  # Bn MSB
    r.u(1)                      # P2
    tb = r.u(7) * 15
    fields["tb"] = f"{tb // 60:02d}:{tb % 60:02d}"
    position = []
    for _ in range(3):
        r.sm(24)                # velocity
        position.append(r.sm(27) * 2 ** -11)
        r.sm(5)                 # acceleration
    fields["x_km"], fields["y_km"], fields["z_km"] = (round(v, 3) for v in position)
    fields["radius_km"] = round(math.sqrt(sum(v * v for v in position)), 1)


def _decode_helmert(r, fields):
    fields["source_name"] = r.text(r.u(5))
    fields["target_name"] = r.text(r.u(5))
    fields["system_id"] = r.u(8)
    r.u(10)                     # utilized transformation messages
    fields["plate_number"] = r.u(5)
    fields["computation"] = r.u(4)
    fields["height_type"] = r.u(2)
    arcsec = 1 / 3600
    fields["origin_lat_deg"] = round(r.s(19) * 2 * arcsec, 5)
    fields["origin_lon_deg"] = round(r.s(20) * 2 * arcsec, 5)
    fields["ext_lat_deg"] = round(r.u(14) * 2 * arcsec, 5)
    fields["ext_lon_deg"] = round(r.u(14) * 2 * arcsec, 5)
    fields["dx_m"] = r.s(23) * 0.001
    fields["dy_m"] = r.s(23) * 0.001
    fields["dz_m"] = r.s(23) * 0.001
    fields["r1_arcsec"] = round(r.s(32) * 0.00002, 5)
    fields["r2_arcsec"] = round(r.s(32) * 0.00002, 5)
    fields["r3_arcsec"] = round(r.s(32) * 0.00002, 5)
    fields["ds_ppm"] = round(r.s(25) * 0.00001, 5)


def decode_rtcm(body):
    """Decoded fields of one RTCM3 message body (without preamble/length/CRC)."""
    r = BitReader(body)
    msg_type = r.u(12)
    fields = {"type": msg_type, "name": rtcm_name(msg_type)}
    try:
        if msg_type in (1005, 1006):
            fields["station"] = r.u(12)
            fields["itrf_year"] = r.u(6)
            systems = [name for name in ("GPS", "GLONASS", "Galileo") if r.u(1)]
            fields["systems"] = "/".join(systems) or "-"
            fields["reference_station"] = bool(r.u(1))
            x = r.s(38) * 1e-4
            r.u(2)
            y = r.s(38) * 1e-4
            r.u(2)
            z = r.s(38) * 1e-4
            fields.update(ecef_x=round(x, 4), ecef_y=round(y, 4), ecef_z=round(z, 4))
            if msg_type == 1006:
                fields["antenna_height_m"] = r.u(16) * 1e-4
            lat, lon, height = ecef_to_llh(x, y, z)
            fields.update(lat=round(lat, 8), lon=round(lon, 8), height_m=round(height, 3))
        elif msg_type in (1007, 1008, 1033):
            fields["station"] = r.u(12)
            fields["antenna"] = r.text(r.u(8)).strip()
            fields["setup_id"] = r.u(8)
            if msg_type in (1008, 1033):
                fields["antenna_serial"] = r.text(r.u(8)).strip()
            if msg_type == 1033:
                fields["receiver"] = r.text(r.u(8)).strip()
                fields["firmware"] = r.text(r.u(8)).strip()
                fields["receiver_serial"] = r.text(r.u(8)).strip()
        elif msg_type in GPS_OBS_SAT_BITS:
            _decode_gps_obs(r, msg_type, fields)
        elif msg_type in GLONASS_OBS_SAT_BITS:
            _decode_glonass_obs(r, msg_type, fields)
        elif msg_type // 10 in MSM_SYSTEMS and 1 <= msg_type % 10 <= 7:
            _decode_msm(r, msg_type, fields)
        elif msg_type == 1013:
            _decode_1013(r, fields)
        elif msg_type == 1014:
            _decode_1014(r, fields)
        elif 1015 <= msg_type <= 1017:
            _decode_network(r, fields)
        elif msg_type == 1019:
            _decode_1019(r, fields)
        elif msg_type == 1020:
            _decode_1020(r, fields)
        elif msg_type in (1021, 1022):
            _decode_helmert(r, fields)
        elif msg_type in EPHEMERIS_SAT_BITS:
            fields["satellite"] = r.u(EPHEMERIS_SAT_BITS[msg_type])
        elif len(body) >= 3:
            fields["station"] = r.u(12)   # most RTCM messages carry the station ID next
    except IndexError:
        fields["truncated"] = True
    return fields


def expected_body_length(body):
    """Body length (bytes) implied by the message's own type and counters, or None.

    Used to tell a damaged message (its CRC fails but the declared length fits
    its contents) from random bytes that happen to start with 0xD3. Only types
    whose length can be derived are covered.
    """
    r = BitReader(body)
    try:
        msg_type = r.u(12)
        fixed = {1005: 19, 1006: 21, 1014: 15, 1019: 61, 1020: 45}
        if msg_type in fixed:
            return fixed[msg_type]
        if msg_type in GPS_OBS_SAT_BITS:
            r.u(12 + 30 + 1)
            return math.ceil((64 + GPS_OBS_SAT_BITS[msg_type] * r.u(5)) / 8)
        if msg_type in GLONASS_OBS_SAT_BITS:
            r.u(12 + 27 + 1)
            return math.ceil((61 + GLONASS_OBS_SAT_BITS[msg_type] * r.u(5)) / 8)
        if msg_type == 1013:
            r.u(12 + 16 + 17)
            return math.ceil((70 + 29 * r.u(5)) / 8)
        if msg_type in (1007, 1008, 1033):
            r.u(12)
            bits = 24
            strings = {1007: 1, 1008: 2, 1033: 5}[msg_type]
            for index in range(strings):
                count = r.u(8)
                r.text(count)
                bits += 8 + 8 * count
                if index == 0:
                    r.u(8)              # setup ID
                    bits += 8
            return math.ceil(bits / 8)
    except IndexError:
        return None
    return None


def rtcm_summary(fields):
    t = fields["type"]
    if "lat" in fields:
        return f"局{fields['station']}  {fields['lat']:.7f}, {fields['lon']:.7f}  h={fields['height_m']:.2f} m  ({fields['systems']})"
    if "sats" in fields and "msm" not in fields:
        cnrs = [s["cnr_l1"] for s in fields["sats"] if s.get("cnr_l1")]
        cnr = f"  C/N0平均 {sum(cnrs) / len(cnrs):.1f} dB-Hz" if cnrs else ""
        return f"局{fields['station']}  {fields['system']} 衛星{fields['satellites']}  {fields['epoch_text']}{cnr}"
    if "msm" in fields:
        return (f"局{fields['station']}  {fields['system']} 衛星{fields['satellites']} 信号{fields['signals']}  "
                f"{fields.get('epoch_text', fields['epoch'])}")
    if "schedule" in fields:
        listed = ", ".join(f"{s['type']}/{s['interval_s']:g}s" for s in fields["schedule"][:8])
        return f"局{fields['station']}  {fields['date']} {fields['utc_time']} UTC  うるう秒{fields['leap_seconds']}  予定: {listed}"
    if "dlat_deg" in fields:
        return (f"網{fields['network_id']}  主局{fields['master_station']} → 補助局{fields['aux_station']}  "
                f"Δ緯度{fields['dlat_deg']:+.4f}° Δ経度{fields['dlon_deg']:+.4f}° Δh{fields['dh_m']:+.2f} m")
    if "network_id" in fields:
        return (f"網{fields['network_id']}  主局{fields['master_station']} 補助局{fields['aux_station']}  "
                f"衛星{fields['satellites']}  {fields['epoch_text']}")
    if "source_name" in fields:
        return (f"{fields['source_name'] or '?'} → {fields['target_name'] or '?'}  "
                f"dX{fields['dx_m']:+.3f} dY{fields['dy_m']:+.3f} dZ{fields['dz_m']:+.3f} m")
    if "semi_major_km" in fields:
        return (f"G{fields['satellite']:02d}  IODE {fields['iode']}  toe {fields['toe_s']} s  "
                f"a={fields['semi_major_km']:.0f} km  e={fields['eccentricity']:.4f}  i={fields['inclination_deg']:.1f}°")
    if "radius_km" in fields:
        return (f"R{fields['satellite']:02d}  ch{fields['freq_ch']:+d}  tb {fields['tb']}  "
                f"地心距離 {fields['radius_km']:.0f} km")
    if "antenna" in fields:
        return f"局{fields['station']}  アンテナ '{fields['antenna'] or '-'}'" + (
            f"  受信機 '{fields['receiver']}'" if fields.get("receiver") else "")
    if "satellite" in fields:
        return f"衛星 {fields['satellite']}"
    if "station" in fields:
        return f"局{fields['station']}"
    return str(t)


def receive_delay(fields, unix_s, leap_seconds=DEFAULT_LEAP_SECONDS):
    """Seconds from the message's epoch to ``unix_s`` (PC clock), or None without an epoch."""
    system, epoch = fields.get("time_system"), fields.get("epoch_s")
    if epoch is None:
        return None
    if system == "GLONASST":
        now, period = (unix_s + 10800) % 86400, 86400
    else:
        offset = leap_seconds - (14 if system == "BDT" else 0)
        now, period = (unix_s - GPS_EPOCH_UNIX + offset) % 604800, 604800
    delay = (now - epoch) % period
    return round(delay - period if delay > period / 2 else delay, 2)
