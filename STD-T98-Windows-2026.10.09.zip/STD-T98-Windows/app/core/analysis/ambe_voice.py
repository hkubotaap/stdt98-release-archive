"""Trace AMBE+2 bits and state using the bundled D:/ai/ambe reference codec.

No recording is modified. PN is applied in the existing STD-T98 T49 adapter,
at the original block's offset within the 196-bit burst, never at a new offset
just because a user selects TCH2 or a single 20 ms block.
"""
from dataclasses import dataclass
import math

import numpy as np

from core.crypto.pn_sequence import generate_pn_sequence_196
from core.crypto.secret_voice import THUMBDV_MAP, descramble_burst
from vendor.ambe2 import bitio
from vendor.ambe2.decoder import (Decoder, InputInvalid, NumericInvalid, classify,
                                  reconstruct, spectral_T, unpack_tone, tone_amplitude)


FIELD_MEANINGS = (
    "ピッチ・フレーム種別", "有声／無声の8帯域パターン", "ゲイン差分 Δγ",
    "PRBA G2〜G4 のコードブックindex", "PRBA G5〜G8 のコードブックindex",
    "HOC ブロック1", "HOC ブロック2", "HOC ブロック3", "HOC ブロック4",
)


class AnalysisCancelled(Exception):
    pass


@dataclass(frozen=True)
class VoiceBurst:
    blocks: tuple  # four bytes(9) or None, in physical TCH1/1,1/2,2/1,2/2 order
    F: int | None
    mode: int | None
    parity_ok: bool
    missed: int = 0
    secret: bool | None = None
    soft_blocks: tuple = ()


def parse_trial_key(value):
    if isinstance(value, bool):
        raise ValueError("試聴キーは0〜32767の整数です。")
    text = str(value).strip()
    if not text or not text.isascii() or not text.isdecimal() or not 0 <= int(text) <= 32767:
        raise ValueError("試聴キーは0〜32767の整数です（0は解除なし）。")
    return int(text)


def _bits(data, length):
    return "".join(map(str, bitio.bytes_to_bits(data, length)))


def parameter_fields(u, block):
    """Annex A mapping: indices are not contiguous fields of INFO49."""
    values = bitio.u_to_b(u)
    inverse_t49 = {p: t for t, p in enumerate(bitio.T49_Q)}
    result = []
    for index, (value, width) in enumerate(zip(values, bitio.B_WIDTHS)):
        cells = sorted((cell for cell in bitio.T.BITMAP if cell[2] == index), key=lambda c: -c[3])
        positions = [sum(bitio.U_WIDTHS[:word]) + bitio.U_WIDTHS[word] - 1 - bit for word, bit, _bi, _bb in cells]
        t49 = [inverse_t49[p] for p in positions]
        result.append({"name": f"b{index}", "width": width, "value": value,
                       "bits": f"{value:0{width}b}", "meaning": FIELD_MEANINGS[index],
                       "info49_positions": positions, "t49_positions": t49,
                       "pn196_positions": [block * 49 + THUMBDV_MAP[t] for t in t49],
                       "word_bits": [f"u{word}:b{bit}" for word, bit, _bi, _bb in cells]})
    return result


def _state_summary(state):
    return {name: getattr(state, name) for name in ("frame_index", "sample_position", "R", "invalid_run",
                                                  "tau", "SE", "last_gamma", "last_L", "prev_f", "prev_L")}


def _trace_block(raw, block, key, pn, decoder, soft=None, detailed=True):
    words = bitio.dibit36_to_c(raw)
    hard = bitio.fec_decode(words)
    report, soft_note = hard, None
    if soft is not None:
        try:
            report = bitio.soft_fec_decode(words, bitio.dibit36_to_c(soft))
        except (InputInvalid, ValueError, TypeError):
            soft_note = "軟判定コード語がこの受信ブロックに対応しないため、硬判定へ戻しました。"
    corrected = bitio.encode_u(report.u)
    information = bitio.u_to_info49(report.u)
    packed_t49 = bitio.info49_to_t49(information)
    # This adapter includes the T49 permutation. It is also its own inverse.
    decoded_t49 = descramble_burst([packed_t49] * 4, pn)[block] if key else packed_t49
    decoded_info = bitio.t49_to_info49(decoded_t49)
    after_u = bitio.info49_to_u(decoded_info)
    before = decoder.state.clone() if detailed else None
    try:
        decoded = decoder.decode(decoded_info, "INFO49", quality=(report.e0, report.e1, report.failure))
        meta, pcm = dict(decoded.meta), decoded.pcm.copy()
    except (InputInvalid, NumericInvalid) as exc:
        decoded = decoder.decode(missing=True)
        meta, pcm = dict(decoded.meta), decoded.pcm.copy()
        meta["input_error"] = str(exc)
    if not detailed:
        return {"pcm": pcm, "meta": meta}
    candidate_type = classify(after_u)
    code_before, code_after = _bits(bitio.c_to_code72(words), 72), _bits(bitio.c_to_code72(corrected), 72)
    wire_after = _bits(bitio.c_to_dibit36(corrected), 72)
    wire_before = _bits(raw, 72)
    result = {
        "block": block, "TCH": "TCH1" if block < 2 else "TCH2", "time_ms": [block * 20, (block + 1) * 20],
        "frame_bits": [96 + block * 72, 167 + block * 72],
        "formats": {"DIBIT36_received": wire_before, "CODE72_received": code_before,
                    "CODE72_corrected_candidate": code_after, "DIBIT36_corrected_candidate": wire_after,
                    "INFO49_before_key": _bits(information, 49), "T49_before_key": _bits(packed_t49, 49),
                    "PN49_in_T49_order": "".join(str(pn[block * 49 + THUMBDV_MAP[t]]) for t in range(49)) if key else "0" * 49,
                    "T49_after_key": _bits(decoded_t49, 49), "INFO49_after_key": _bits(decoded_info, 49)},
        "hex": {"DIBIT36_received": raw.hex(), "CODE72_received": bitio.c_to_code72(words).hex(),
                "CODE72_corrected_candidate": bitio.c_to_code72(corrected).hex(),
                "INFO49_before_key": information.hex(), "T49_before_key": packed_t49.hex(),
                "T49_after_key": decoded_t49.hex(), "INFO49_after_key": decoded_info.hex()},
        "C": list(words), "U_before_key": list(report.u), "U_after_key": after_u,
        "fec": {"procedure": report.procedure, "e0": report.e0, "e1": report.e1,
                "failure": report.failure, "d23": report.d23, "parity_delta": report.delta,
                "hard_e0": hard.e0, "hard_e1": hard.e1,
                "changed_code72": [i for i, (a, b) in enumerate(zip(code_before, code_after)) if a != b],
                "changed_wire": [i for i, (a, b) in enumerate(zip(wire_before, wire_after)) if a != b]},
        "key": key, "pn196_range": [block * 49, block * 49 + 48],
        "candidate_type": candidate_type, "meta": meta, "soft_note": soft_note,
        "state_before": _state_summary(before), "state_after": _state_summary(decoder.state),
        "fields": [] if candidate_type == "TONE_MARKER" else parameter_fields(after_u, block),
        "pcm": pcm,
    }
    if meta.get("action") in ("VOICE", "SILENCE"):
        b = bitio.u_to_b(after_u)
        f, L, v, gamma, lam, magnitude = reconstruct(b, meta["wire_type"], before)
        residual, prba = spectral_T(b, L)
        result["model"] = {"f0_hz": f * 8000, "omega": 2 * math.pi * f, "L": L, "gamma": gamma,
                           "gain_delta": float(bitio.T.GAIN[b[2]]), "PRBA24": list(bitio.T.PRBA24[b[3]]),
                           "PRBA58": list(bitio.T.PRBA58[b[4]]),
                           "HOC": [list(bitio.T.HOC[i][b[5 + i]]) for i in range(4)],
                           "PRBA_R": prba.tolist(), "residual_T": residual.tolist(),
                           "Lambda": lam.tolist(), "M": magnitude.tolist(),
                           "frequency_hz": [f * 8000 * i for i in range(1, L + 1)],
                           "v": v.astype(int).tolist(), "vbar": list(meta["vbar"]),
                           "E": decoder.state.prev_E[1:L + 1].tolist(),
                           "phi": decoder.state.phi[1:L + 1].tolist(),
                           "psi": decoder.state.psi[1:L + 1].tolist(),
                           "noise_seed_after": decoder.state.noise_seed}
    elif candidate_type == "TONE_MARKER":
        tone = unpack_tone(after_u)
        tone_id = tone["ids"][0]
        result["tone"] = {**tone, "amplitude_reference": tone_amplitude(tone["AD"]),
                          "frequency_hz": list(bitio.T.DUAL_TONES[tone_id]) if tone_id in bitio.T.DUAL_TONES else
                          [tone_id * 31.25] if 5 <= tone_id <= 122 else []}
    return result


def analyse_recording(bursts, index, key=0, use_soft=False, context_frames=12, cancelled=None):
    """Restore prediction/PLC from the start; retain only the requested neighborhood."""
    key = parse_trial_key(key)
    if not 0 <= index < len(bursts):
        raise ValueError("フレーム番号が記録範囲外です。")
    decoder, pn = Decoder(), generate_pn_sequence_196(key)
    first, last = max(0, index - context_frames), min(len(bursts), index + context_frames + 1)
    chunks, selected, selected_start = [], [], 0
    sample_count = 0
    for frame_index in range(last):
        if cancelled and cancelled():
            raise AnalysisCancelled()
        burst = bursts[frame_index]
        if len(burst.blocks) != 4:
            raise ValueError("音声フレームは4スロットで指定してください。")
        if burst.F == 0 and burst.parity_ok:
            decoder = Decoder()  # A control/sync burst starts a new voice context.
        missed = burst.missed
        if isinstance(missed, bool) or not isinstance(missed, int) or not 0 <= missed <= 10000:
            raise ValueError("missedの値が不正です。")
        for _ in range(missed * 4):
            if cancelled and cancelled():
                raise AnalysisCancelled()
            gap = decoder.decode(missing=True).pcm
            if frame_index >= first:
                chunks.append(gap)
                sample_count += 160
        if frame_index == index:
            selected_start = sample_count
        for block in range(4):
            voice = burst.parity_ok and burst.F == 1 and burst.mode in ((2, 3) if block < 2 else (1, 3))
            raw = burst.blocks[block]
            reason = None if voice and raw is not None else "受信ビット未記録" if voice else "音声割当てではない／RICH未確定"
            if reason:
                decoded = decoder.decode(missing=True) if voice or not burst.parity_ok else None
                pcm = decoded.pcm.copy() if decoded is not None else np.zeros(160, dtype=np.int16)
                trace = {"block": block, "TCH": "TCH1" if block < 2 else "TCH2", "unavailable": reason,
                         "time_ms": [block * 20, (block + 1) * 20], "pcm": pcm,
                         "meta": dict(decoded.meta) if decoded is not None else {"action": "NOT_VOICE", "wire_type": "NOT_VOICE"}}
            else:
                if not isinstance(raw, bytes) or len(raw) != 9:
                    raise ValueError("受信音声ブロックは9byteです。")
                soft = burst.soft_blocks[block] if use_soft and len(burst.soft_blocks) == 4 else None
                trace = _trace_block(raw, block, key, pn, decoder, soft, detailed=frame_index == index)
                pcm = trace["pcm"]
            if frame_index == index:
                trace["recording_frame"] = frame_index
                trace["secret_recorded"] = burst.secret
                selected.append(trace)
            if frame_index >= first:
                chunks.append(pcm)
                sample_count += 160
    context = np.concatenate(chunks) if chunks else np.zeros(0, np.int16)
    lo, hi = max(0, selected_start - 8000), min(len(context), selected_start + 640 + 8000)
    return {"key": key, "frame": index, "blocks": selected, "rate": 8000,
            "context_pcm": context[lo:hi], "selected_offset": selected_start - lo,
            "selected_pcm": context[selected_start:selected_start + 640],
            "history": "録音先頭から復号。確認済み制御フレームで状態初期化。missedは20ms欠落×4として処理。",
            "profile": "HR-PUBLIC-ALLFRAMES-v1", "soft_requested": bool(use_soft)}


def serialisable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {k: serialisable(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [serialisable(v) for v in value]
    if isinstance(value, np.generic):
        return value.item()
    return value
