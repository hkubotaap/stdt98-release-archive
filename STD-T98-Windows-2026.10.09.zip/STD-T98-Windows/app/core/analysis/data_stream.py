"""User data carried in STD-T98 data-mode frames: extraction and protocol decoding.

A recording (.t98raw) stores each frame's 36-byte traffic payload (4 slots of
9 bytes); its edu .jsonl line has the RICH mode (M), RICH parity, SACCH CRC and
a frame sequence number. Slots the RICH mode does not mark as voice carry user
data (same rule as the audio service). The data bytes are usable as stored:
RTCM3 messages pass their CRC-24Q across slot and frame boundaries.

Lost frames: the edu "seq" is a counter shared by ALL channels, so its jumps
mostly count other channels' traffic and must not be read as losses. Newer
recordings store "missed" (this channel's frames lost before each frame); the
stream is split only there, and a message that runs into such a gap is
reported as incomplete. Older recordings have no "missed": the stream is not
split and the CRC alone rejects messages that crossed a loss.

On channel 40 (2026-10-02) almost all broken long messages had every byte
present but failed their CRC: the data is sent without error correction, so
the raw bit error rate (about 2 %, estimated from the 0xFF idle fill) is what
limits them. Voice and SACCH tolerate it thanks to their FEC.

Decoders: RTCM 3 (CRC-24Q; fields of 1005/1006, 1007/1008/1033, MSM headers,
ephemeris satellite IDs), NMEA 0183 (checksum; GGA position) and u-blox UBX
(Fletcher checksum).
"""
import json
import re
import struct
from collections import Counter
from dataclasses import dataclass, field

# RTCM decoding lives in core.analysis.rtcm; re-exported here for older imports.
from core.analysis.rtcm import (BitReader, DEFAULT_LEAP_SECONDS, MSM_SYSTEMS, RTCM_NAMES,  # noqa: F401
                                crc24q, decode_rtcm, ecef_to_llh, expected_body_length, receive_delay,
                                rtcm_name, rtcm_summary)

FRAME_BYTES = 36
SLOT_BYTES = 9
FRAME_SECONDS = 0.08
HEADER_BYTES = {b"T98RAW03": 52, b"T98RAW02": 48, b"T98RAW01": 32}


# --- recordings -------------------------------------------------------------------

@dataclass
class DataFrame:
    index: int          # frame number within the recording
    seq: int            # shared by all channels: not a loss indicator
    missed: object      # this channel's frames lost just before this one; None if not recorded
    mode: int           # RICH M
    parity_ok: bool
    sacch_ok: bool
    slots: tuple        # indices of the slots carrying data
    data: bytes         # those slots' bytes, in order
    time_s: float       # seconds from the recording start (frame position + known losses)
    user_code: object = None    # SACCH user code (sending station); None when its CRC failed
    maker_code: object = None


def data_slots(mode):
    """Slots carrying user data for RICH mode ``mode`` (the audio service's voice mask, inverted)."""
    voice = [mode in (2, 3)] * 2 + [mode in (1, 3)] * 2
    return tuple(i for i in range(4) if not voice[i])


def read_recording(raw_path, edu_path):
    """(header, frames) of one recording. ``header``: freq_hz, start_ms, csm, path."""
    blob = open(raw_path, "rb").read()
    header_size = HEADER_BYTES.get(blob[:8])
    if header_size is None:
        raise ValueError(f"not a T98RAW recording: {raw_path}")
    freq, start_ms = struct.unpack_from("<qq", blob, 8)
    csm = blob[32:48].split(b"\0")[0].decode("utf-8", "ignore").strip() if header_size >= 48 else ""
    payload = blob[header_size:]
    lines = [json.loads(line) for line in open(edu_path, encoding="utf-8") if line.strip()]
    frames = []
    lost_so_far = 0
    for index, line in enumerate(lines):
        chunk = payload[index * FRAME_BYTES:(index + 1) * FRAME_BYTES]
        if len(chunk) < FRAME_BYTES:
            break
        rich = line.get("rich", {})
        mode = int(rich.get("M", 3))
        slots = data_slots(mode)
        data = b"".join(chunk[s * SLOT_BYTES:(s + 1) * SLOT_BYTES] for s in slots)
        seq = int(line.get("seq", index))
        missed = line.get("missed")
        missed = int(missed) if missed is not None else None
        lost_so_far += missed or 0
        sacch = line.get("sacch", {})
        sacch_ok = bool(sacch.get("crcOK", True))
        frames.append(DataFrame(index, seq, missed, mode, bool(rich.get("parityOK", True)), sacch_ok, slots, data,
                                (index + lost_so_far) * FRAME_SECONDS,
                                sacch.get("userCode") if sacch_ok else None,
                                sacch.get("makerCode") if sacch_ok else None))
    header = {"freq_hz": freq, "start_ms": start_ms, "csm": csm, "path": raw_path}
    return header, frames


@dataclass
class Segment:
    """Contiguous data bytes (no missing frame inside)."""
    start_frame: int
    end_frame: int
    data: bytes
    frame_of_byte: list = field(repr=False)   # recording frame index per byte
    time_s: float = 0.0
    gap_before: int = 0                       # frames missing just before this segment


def segments(frames):
    """Split the data bytes at recorded losses ("missed") and at frames without data slots."""
    result, current, owners, previous = [], bytearray(), [], None
    start, gap = None, 0

    def close():
        if current:
            result.append(Segment(start, owners[-1], bytes(current), list(owners), frames_by_index[start].time_s, gap))

    frames_by_index = {f.index: f for f in frames}
    for frame in frames:
        missing = 0 if previous is None else (frame.missed or 0)
        if not frame.data or missing:
            close()
            current, owners, start = bytearray(), [], None
            gap = missing if missing else 0
        if frame.data:
            if start is None:
                start = frame.index
            current += frame.data
            owners.extend([frame.index] * len(frame.data))
        previous = frame
    close()
    return result


# --- NMEA / UBX ---------------------------------------------------------------------

NMEA_RE = re.compile(rb"\$([A-Z]{2}[A-Z]{3}),([ -~]*?)\*([0-9A-Fa-f]{2})")
UBX_NAMES = {(0x01, 0x07): "NAV-PVT", (0x01, 0x02): "NAV-POSLLH", (0x01, 0x03): "NAV-STATUS",
             (0x01, 0x35): "NAV-SAT", (0x02, 0x15): "RXM-RAWX", (0x02, 0x13): "RXM-SFRBX",
             (0x05, 0x01): "ACK-ACK", (0x05, 0x00): "ACK-NAK", (0x0A, 0x04): "MON-VER"}


def _nmea_coord(value, hemisphere):
    if not value:
        return None
    degrees = int(float(value) / 100)
    result = degrees + (float(value) - degrees * 100) / 60
    return -result if hemisphere in ("S", "W") else result


def decode_nmea(talker_type, body):
    fields = {"type": talker_type.decode(), "name": f"NMEA {talker_type[2:].decode()}"}
    parts = body.decode("ascii", "replace").split(",")
    if talker_type.endswith(b"GGA") and len(parts) >= 9:
        try:
            fields.update(time=parts[0], lat=_nmea_coord(parts[1], parts[2]), lon=_nmea_coord(parts[3], parts[4]),
                          fix=parts[5], satellites=parts[6], height_m=parts[8])
        except ValueError:
            pass
    return fields


def _ubx_checksum(data):
    a = b = 0
    for byte in data:
        a = (a + byte) & 0xFF
        b = (b + a) & 0xFF
    return a, b


# --- scanning ----------------------------------------------------------------------

@dataclass
class Message:
    protocol: str          # "RTCM3" / "NMEA" / "UBX"
    msg_type: str
    name: str
    status: str            # "ok", "incomplete" (runs into a frame gap) or "crc_ng" (damaged, values unreliable)
    offset: int            # byte offset in the segment
    length: int            # total bytes, framing included
    raw: bytes
    fields: dict
    summary: str
    frame: int = 0         # recording frame where it starts
    time_s: float = 0.0
    recording: str = ""


def scan_segment(segment, recording=""):
    """Messages found in one segment, in order."""
    data, found, i = segment.data, [], 0
    while i < len(data):
        byte = data[i]
        if byte == 0xD3 and i + 3 <= len(data) and data[i + 1] & 0xFC == 0:
            n = ((data[i + 1] & 3) << 8) | data[i + 2]
            end = i + 3 + n + 3
            if n and end <= len(data) and crc24q(data[i:i + 3 + n]) == int.from_bytes(data[i + 3 + n:end], "big"):
                fields = decode_rtcm(data[i + 3:i + 3 + n])
                found.append(Message("RTCM3", str(fields["type"]), fields["name"], "ok", i, end - i,
                                     data[i:end], fields, rtcm_summary(fields)))
                i = end
                continue
            if n and end <= len(data) and expected_body_length(data[i + 3:i + 3 + n]) == n:
                # The CRC failed but the length fits the message's own counters: a
                # damaged message, not random bytes. Its values are only a hint.
                fields = decode_rtcm(data[i + 3:i + 3 + n])
                found.append(Message("RTCM3", str(fields["type"]), fields["name"], "crc_ng", i, end - i,
                                     data[i:end], fields, "[CRC NG・参考値] " + rtcm_summary(fields)))
                i = end
                continue
            if n >= 8 and end > len(data) and len(data) - i >= 5:
                # Header near the end of a segment: the rest was lost in a gap.
                msg_type = (data[i + 3] << 4) | (data[i + 4] >> 4)
                if 1001 <= msg_type <= 1300 or 4001 <= msg_type <= 4095:
                    found.append(Message("RTCM3", str(msg_type), rtcm_name(msg_type), "incomplete", i, len(data) - i,
                                         data[i:], {"type": msg_type, "declared_length": n},
                                         f"途中で途切れ ({len(data) - i}/{n + 6} バイト・録音の終わりか欠落)"))
                    break
        elif byte == 0x24:   # '$'
            match = NMEA_RE.match(data, i)
            if match:
                checksum = 0
                for b in data[i + 1:match.start(3) - 1]:
                    checksum ^= b
                if checksum == int(match.group(3), 16):
                    fields = decode_nmea(match.group(1), match.group(2))
                    summary = (f"{fields['lat']:.6f}, {fields['lon']:.6f}  fix={fields['fix']} 衛星{fields['satellites']}"
                               if fields.get("lat") is not None else match.group(2)[:60].decode("ascii", "replace"))
                    found.append(Message("NMEA", fields["type"], fields["name"], "ok", i, match.end() - i,
                                         data[i:match.end()], fields, summary))
                    i = match.end()
                    continue
        elif byte == 0xB5 and i + 8 <= len(data) and data[i + 1] == 0x62:
            cls, mid = data[i + 2], data[i + 3]
            n = data[i + 4] | (data[i + 5] << 8)
            end = i + 6 + n + 2
            if end <= len(data) and _ubx_checksum(data[i + 2:i + 6 + n]) == (data[end - 2], data[end - 1]):
                name = UBX_NAMES.get((cls, mid), f"0x{cls:02X}-0x{mid:02X}")
                found.append(Message("UBX", f"{cls:02X}{mid:02X}", f"UBX {name}", "ok", i, end - i, data[i:end],
                                     {"class": cls, "id": mid, "length": n}, f"{name} ({n} バイト)"))
                i = end
                continue
        i += 1
    for message in found:
        message.frame = segment.frame_of_byte[message.offset]
        message.time_s = segment.time_s + (message.frame - segment.start_frame) * FRAME_SECONDS
        message.recording = recording
    return found


# --- whole analysis -----------------------------------------------------------------

def idle_fill_errors(frames):
    """(flipped bits, bits) in idle-fill frames (data bytes all 0xFF when sent).

    A frame counts as idle when nearly every data byte is 0xFF or one bit off;
    every 0 bit in it is then a bit error. Gives the raw bit error rate of the
    uncoded data without knowing any message content.
    """
    flipped = total = 0
    for frame in frames:
        data = frame.data
        if len(data) < 18:
            continue
        ones = [bin(b).count("1") for b in data]
        if min(ones) >= 5 and sum(o >= 7 for o in ones) >= 0.85 * len(data):
            flipped += sum(8 - o for o in ones)
            total += 8 * len(data)
    return flipped, total


# Printable ASCII (plus tab/CR/LF) of at least this length. Random data makes
# many 3-byte runs; 4 keeps the noise down while catching short headers.
MIN_ASCII_RUN = 4
ASCII_RUN_RE = re.compile(rb"[\x20-\x7e\t\r\n]{%d,}" % MIN_ASCII_RUN)


@dataclass
class AsciiRun:
    recording: str
    offset: int         # byte offset in the segment
    frame: int          # recording frame index of the first byte
    time_s: float
    text: str


def ascii_runs(segment, recording=""):
    """Printable ASCII runs of at least MIN_ASCII_RUN bytes in one segment.

    The data has no error correction, so a bit error splits a run or changes a
    character: the same header shows up in a few spellings.
    """
    runs = []
    for match in ASCII_RUN_RE.finditer(segment.data):
        frame = segment.frame_of_byte[match.start()]
        runs.append(AsciiRun(recording, match.start(), frame,
                             segment.time_s + (frame - segment.start_frame) * FRAME_SECONDS,
                             match.group().decode("ascii")))
    return runs


def survival(ber, length_bytes):
    """Probability that a message of ``length_bytes`` arrives without a bit error."""
    return (1 - ber) ** (8 * length_bytes)


@dataclass
class Analysis:
    recordings: list
    frames: int
    data_frames: int
    missing_frames: object  # int, or None when the recordings do not store "missed"
    data_bytes: int
    messages: list
    frame_rows: list        # (recording, frame or None for a gap row, missing count)
    idle_bits: int = 0
    idle_errors: int = 0
    ascii: list = field(default_factory=list)      # AsciiRun, in time order
    segments: list = field(default_factory=list)   # (recording header, Segment)
    senders: Counter = field(default_factory=Counter)   # (user code, maker code) -> data frames
    leap_seconds: int = DEFAULT_LEAP_SECONDS       # from a 1013 when one decoded

    @property
    def bit_error_rate(self):
        return self.idle_errors / self.idle_bits if self.idle_bits >= 2000 else None


def analyse(paths):
    """Analyse recordings (list of (raw_path, edu_path)) in time order."""
    recordings, messages, rows, texts, parts, senders = [], [], [], [], [], Counter()
    frames_total = data_frames = missing = data_bytes = idle_bits = idle_errors = 0
    loss_known = True
    for raw_path, edu_path in paths:
        header, frames = read_recording(raw_path, edu_path)
        recordings.append(header)
        frames_total += len(frames)
        data_frames += sum(1 for f in frames if f.data)
        loss_known = loss_known and all(f.missed is not None for f in frames)
        senders.update((f.user_code, f.maker_code) for f in frames if f.data and f.user_code is not None)
        for frame in frames:
            if frame.missed:
                missing += frame.missed
                rows.append((header, None, frame.missed))
            rows.append((header, frame, 0))
        flipped, bits = idle_fill_errors(frames)
        idle_errors += flipped
        idle_bits += bits
        for segment in segments(frames):
            data_bytes += len(segment.data)
            messages.extend(scan_segment(segment, raw_path))
            texts.extend(ascii_runs(segment, raw_path))
            parts.append((header, segment))
    leap = next((m.fields["leap_seconds"] for m in messages
                 if m.status == "ok" and "leap_seconds" in m.fields), DEFAULT_LEAP_SECONDS)
    starts = {header["path"]: header["start_ms"] for header in recordings}
    for message in messages:
        if message.protocol == "RTCM3" and "epoch_s" in message.fields:
            delay = receive_delay(message.fields, starts[message.recording] / 1000 + message.time_s, leap)
            if delay is not None:
                message.fields["delay_s"] = delay
    return Analysis(recordings, frames_total, data_frames, missing if loss_known else None, data_bytes,
                    messages, rows, idle_bits, idle_errors, texts, parts, senders, leap)


def type_table(messages):
    """[(protocol, type, name, ok, incomplete, crc_ng, mean interval s)] sorted by count."""
    groups = {}
    for message in messages:
        groups.setdefault((message.protocol, message.msg_type, message.name), []).append(message)
    table = []
    for (protocol, msg_type, name), group in groups.items():
        ok = [m for m in group if m.status == "ok"]
        times = sorted((m.recording, m.time_s) for m in ok)
        intervals = [b[1] - a[1] for a, b in zip(times, times[1:]) if a[0] == b[0] and b[1] > a[1]]
        mean = sum(intervals) / len(intervals) if intervals else None
        damaged = sum(1 for m in group if m.status == "crc_ng")
        table.append((protocol, msg_type, name, len(ok), len(group) - len(ok) - damaged, damaged, mean))
    return sorted(table, key=lambda row: -(row[3] + row[4] + row[5]))


def base_positions(messages):
    """Latest decoded RTCM base position per station."""
    positions = {}
    for message in messages:
        if message.protocol == "RTCM3" and message.status == "ok" and "lat" in message.fields:
            positions[message.fields["station"]] = message.fields
    return positions
