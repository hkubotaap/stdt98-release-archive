"""Offline analysis of recorded STD-T98 traffic."""
