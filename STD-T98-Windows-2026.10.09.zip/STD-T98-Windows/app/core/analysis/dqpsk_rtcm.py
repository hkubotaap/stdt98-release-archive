"""Observed pi/4-DQPSK data profile, independent of RF frequency.

The radio container/PN9 anchor is measured, not a universal STD-T98 mode.
Only CRC-valid packets and zero-cost, CRC6/BCD-valid PICH are accepted.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import json
import numpy as np
from scipy import signal

from core.analysis.rtcm import crc24q
from core.rf.dqpsk_options import parse_frequencies

FS = 38400
BAUD = 4800
PROFILE = "observed_pi4dqpsk_pn9_rtcm"
PN9 = np.ones(511, dtype=np.uint8)
for _n in range(9, 511):
    PN9[_n] = PN9[_n - 9] ^ PN9[_n - 5]


def sync_positions(bits, word, width):
    target = np.array([(word >> i) & 1 for i in range(width - 1, -1, -1)], dtype=np.uint8)
    if len(bits) < width:
        return []
    windows = np.lib.stride_tricks.sliding_window_view(bits, width)
    return np.flatnonzero(np.all(windows == target, axis=1)).tolist()


def decode_pich(rx):
    pairs = np.asarray(rx, dtype=np.uint8).reshape(8, 15).T.reshape(60, 2)
    cost = np.full(32, 1000, dtype=int)
    cost[0] = 0
    paths = np.zeros((60, 32), dtype=np.uint8)
    predecessors = np.zeros((60, 32), dtype=np.uint8)
    for step, pair in enumerate(pairs):
        new = np.full(32, 1000, dtype=int)
        for state in range(32):
            for bit in (0, 1):
                reg = (state << 1) | bit
                nxt = reg & 31
                encoded = ((reg & 0x2B).bit_count() & 1, (reg & 0x3D).bit_count() & 1)
                candidate = cost[state] + sum(int(a != b) for a, b in zip(encoded, pair))
                if candidate < new[nxt]:
                    new[nxt] = candidate
                    paths[step, nxt] = bit
                    predecessors[step, nxt] = state
        cost = new
    decoded = np.zeros(60, dtype=np.uint8)
    state = 0
    for step in range(59, -1, -1):
        decoded[step] = paths[step, state]
        state = int(predecessors[step, state])
    crc = 0x3F
    for bit in decoded[:48]:
        feedback = ((crc >> 5) & 1) ^ int(bit)
        crc = ((crc << 1) & 63) ^ (3 if feedback else 0)
    received = int(''.join(map(str, decoded[48:54])), 2)
    digits = [int(''.join(map(str, decoded[i:i + 4])), 2) for i in range(0, 36, 4)]
    valid = int(cost[0]) == 0 and crc == received and max(digits) <= 9 and not np.any(decoded[54:])
    return {"validated": bool(valid), "csm": ''.join(map(str, digits)) if valid else None,
            "viterbi_errors": int(cost[0]), "crc6_ok": crc == received}


class RtcmStream:
    """Bounded incremental framing. Keep incomplete candidates across blocks."""
    def __init__(self):
        self.buffer = bytearray()
        self.crc_failures = 0

    def feed(self, data):
        self.buffer.extend(data)
        packets = []
        while self.buffer:
            start = self.buffer.find(b'\xd3')
            if start < 0:
                self.buffer.clear()
                break
            del self.buffer[:start]
            if len(self.buffer) < 3:
                break
            if self.buffer[1] & 0xFC:
                del self.buffer[0]
                continue
            size = ((self.buffer[1] & 3) << 8 | self.buffer[2]) + 6
            if len(self.buffer) < size:
                break
            packet = bytes(self.buffer[:size])
            if crc24q(packet[:-3]) != int.from_bytes(packet[-3:], 'big'):
                self.crc_failures += 1
                del self.buffer[0]
                continue
            packets.append(packet)
            del self.buffer[:size]
        return packets


def decode_bits(bits):
    identities = []
    for pos in sync_positions(bits, 0x2F94D06B, 32):
        if pos + 192 <= len(bits):
            identities.append(dict(decode_pich(bits[pos + 72:pos + 192]), sync_bit_offset=pos))
    packets = []
    failures = 0
    syncs = sync_positions(bits, 0x1E56F, 20)
    # Each sync marks a new payload; PN9 continues across packets within it.
    for i, pos in enumerate(syncs):
        start = pos + 40
        end = syncs[i + 1] if i + 1 < len(syncs) else len(bits)
        payload = bits[start:end]
        payload = payload ^ PN9[(231 + np.arange(len(payload))) % 511]
        reader = RtcmStream()
        packets.extend(reader.feed(np.packbits(payload[:len(payload) // 8 * 8], bitorder='big').tobytes()))
        failures += reader.crc_failures
    return identities, packets, failures


def rrc_taps():
    t = np.arange(-64, 65) / 8
    a = .2
    h = np.empty_like(t)
    for i, x in enumerate(t):
        if abs(x) < 1e-9:
            h[i] = 1 + a * (4 / np.pi - 1)
        elif abs(abs(x) - 1 / (4 * a)) < 1e-9:
            h[i] = a / np.sqrt(2) * ((1 + 2 / np.pi) * np.sin(np.pi / (4 * a)) + (1 - 2 / np.pi) * np.cos(np.pi / (4 * a)))
        else:
            h[i] = (np.sin(np.pi * x * (1 - a)) + 4 * a * x * np.cos(np.pi * x * (1 + a))) / (np.pi * x * (1 - (4 * a * x) ** 2))
    return h / np.linalg.norm(h)


RRC = rrc_taps()


def demodulate(z):
    """Acquire each complete burst with continuous samples, never DSP chunks."""
    if len(z) < FS * .15:
        return None
    f, power = signal.welch(z, fs=FS, nperseg=min(4096, len(z)), return_onesided=False)
    selected = abs(f) < 4500
    cfo = float(np.sum(f[selected] * power[selected]) / max(np.sum(power[selected]), 1e-30))
    matched = signal.fftconvolve(z * np.exp(-2j * np.pi * cfo * np.arange(len(z)) / FS), RRC, mode='same')
    best = None
    grid = np.arange(len(matched))
    for phase in np.arange(0, 8, .125):
        pos = np.arange(100 + phase, len(matched) - 100, 8)
        v = np.interp(pos, grid, matched.real) + 1j * np.interp(pos, grid, matched.imag)
        delta = np.angle(v[1:] * np.conj(v[:-1]))
        moment = np.mean(np.exp(4j * delta))
        if best is None or abs(moment) > best[0]:
            best = (abs(moment), delta, moment)
    score, delta, moment = best
    shift = np.angle(-moment) / 4
    corrected = (delta - shift + np.pi) % (2 * np.pi) - np.pi
    ideals = np.deg2rad([-135, -45, 45, 135])
    labels = np.argmin(abs(np.angle(np.exp(1j * (corrected[:, None] - ideals)))), axis=1)
    dibits = np.array([3, 2, 0, 1], dtype=np.uint8)[labels]
    bits = np.stack((dibits >> 1, dibits & 1), axis=1).reshape(-1)
    identities, packets, failures = decode_bits(bits)
    return {"bits": bits, "identities": identities, "packets": packets, "crc_failures": failures,
            "cfo_hz": cfo + float(shift * BAUD / (2 * np.pi)), "concentration": float(score),
            "phase_rms_deg": float(np.sqrt(np.mean((np.angle(-np.exp(4j * (delta - shift))) / 4) ** 2)) * 180 / np.pi)}


class BurstReceiver:
    """Causal gate; retain IQ/filter/window state across arbitrary input chunks.

    Burst acquisition operates on buffered IQ. CW intervals break differential
    and PN9 continuity. Gaps discard a partial burst and reacquire.
    """
    def __init__(self, callback):
        self.callback = callback
        self.sample_offset = 0
        self.sos = signal.butter(5, 1800, fs=FS, output='sos')
        self.reset()

    def reset(self):
        self.pending = np.empty(0, dtype=np.complex64)
        self.zi = np.zeros((len(self.sos), 2))
        self.previous = 0j
        self.burst = []
        self.history = []
        self.quiet = 0

    def feed(self, samples):
        self.pending = np.concatenate((self.pending, samples))
        while len(self.pending) >= 768:
            z, self.pending = self.pending[:768], self.pending[768:]
            self.sample_offset += 768
            derivative = np.angle(z * np.conj(np.r_[self.previous, z[:-1]])) * FS / (2 * np.pi)
            self.previous = z[-1]
            derivative, self.zi = signal.sosfilt(self.sos, derivative, zi=self.zi)
            active = np.std(derivative) > 200
            if active:
                if not self.burst:
                    self.burst = list(self.history)
                self.burst.append(z)
                self.quiet = 0
            elif self.burst:
                self.burst.append(z)
                self.quiet += 1
                if self.quiet >= 2:
                    self._finish()
            self.history = (self.history + [z])[-2:]
            if len(self.burst) >= 500:  # finite 10 s acquisition, including noise
                self._finish()

    def _finish(self):
        if self.burst:
            result = demodulate(np.concatenate(self.burst))
            if result is not None:
                result['sample_offset'] = self.sample_offset
                self.callback(result)
        self.burst = []
        self.quiet = 0

    def close(self):
        self._finish()


class SessionRecorder:
    """A self-describing session: channel IQ, valid RTCM, fields, burst metrics."""
    def __init__(self, directory, frequency_hz, metadata=None, save_iq=True, save_data=True):
        self.frequency_hz = frequency_hz
        self.counts = Counter()
        self.packet_count = self.crc_failures = self.pich_count = self.samples = self.dropped = 0
        self.csm = None
        self.latest = {}
        self.error = None
        self.metadata = dict(metadata or {}, profile=PROFILE, frequency_hz=frequency_hz,
                             sample_rate_hz=FS, format='complex64_le_I+jQ',
                             start_utc=datetime.now(timezone.utc).isoformat(),
                             time_basis='PC clock; not GPS-disciplined',
                             scope='Measured radio container; compatibility with other data modes is unverified')
        self.path = None
        self.iq = self.rtcm = self.events = None
        if save_iq or save_data:
            name = datetime.now().strftime('%Y%m%d_%H%M%S_%f') + f'_{frequency_hz / 1e6:.6f}MHz'
            self.path = Path(directory) / name
            self.path.mkdir(parents=True, exist_ok=False)
            if save_iq:
                self.iq = (self.path / 'channel.cf32').open('wb')
            if save_data:
                self.rtcm = (self.path / 'validated.rtcm3').open('wb')
                self.events = (self.path / 'analysis.jsonl').open('w', encoding='utf-8')
            self._write_metadata()

    def feed_iq(self, z, gap=0):
        if gap:
            self.dropped += gap
            self.event({"event": "gap", "sample_offset": self.samples, "missing_samples": gap})
        if self.iq:
            self.iq.write(np.asarray(z, dtype='<c8').tobytes())
            self.iq.flush()
        self.samples += len(z)

    def event(self, row):
        if self.events:
            self.events.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n')
            self.events.flush()

    def consume(self, result):
        from core.analysis.dqpsk_fields import decode_packet
        self.crc_failures += result['crc_failures']
        metrics = {k: result[k] for k in ('cfo_hz', 'concentration', 'phase_rms_deg')}
        for identity in result['identities']:
            if identity['validated']:
                self.pich_count += 1
                self.csm = identity['csm']
        self.latest.update(metrics)
        self.event(dict(event='burst', sample_offset=result.get('sample_offset', self.samples), valid_bits=len(result['bits']),
                        raw_bits_hex=np.packbits(result['bits']).tobytes().hex(),
                        identities=result['identities'], **metrics))
        for packet in result['packets']:
            typ = (packet[3] << 4 | packet[4] >> 4) if len(packet) >= 8 else None
            self.packet_count += 1
            self.counts[str(typ)] += 1
            try:
                fields = decode_packet(packet)
            except ValueError as exc:
                fields = {"message_type": typ, "crc24q_ok": True, "field_layout_ok": False, "parse_error": str(exc)}
            self.latest['fields'] = fields
            if fields.get('message_type') == 1005:
                self.latest['reference_station'] = fields
            if fields.get('message_type') == 1033:
                self.latest['receiver'] = fields
            if self.rtcm:
                self.rtcm.write(packet)
                self.rtcm.flush()
            self.event(dict(event='packet', sample_offset=result.get('sample_offset', self.samples), packet_hex=packet.hex(), fields=fields))
        self._write_metadata()

    def snapshot(self):
        return dict(frequency_hz=self.frequency_hz, packets=self.packet_count, crc_failures=self.crc_failures,
                    pich_valid=self.pich_count, csm=self.csm, message_counts=dict(self.counts),
                    samples=self.samples, dropped_samples=self.dropped, directory=str(self.path) if self.path else None,
                    error=self.error, **self.latest)

    def _write_metadata(self):
        if self.path:
            tmp = self.path / 'metadata.tmp'
            tmp.write_text(json.dumps(dict(self.metadata, **self.snapshot()), indent=2, ensure_ascii=False), encoding='utf-8')
            tmp.replace(self.path / 'metadata.json')

    def close(self):
        self.metadata['end_utc'] = datetime.now(timezone.utc).isoformat()
        try:
            self._write_metadata()
        finally:
            for handle in (self.iq, self.rtcm, self.events):
                if handle:
                    handle.close()
