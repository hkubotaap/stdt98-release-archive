"""Parse recovered CRC-valid RTCM3 packets, using RTKLIB field definitions.

Reference: https://github.com/tomojitakasu/RTKLIB/blob/master/src/rtcm3.c
The parser is independently implemented, bounds checks every field, and preserves
raw packets in an ordinary RTCM3 stream for other GNSS tools.
"""
import json
import math

def crc24q(data):
    crc=0
    for byte in data:
        crc^=byte<<16
        for _ in range(8):
            crc<<=1
            if crc&0x1000000: crc^=0x1864CFB
    return crc&0xFFFFFF

class Bits:
    def __init__(self,data):
        self.data=int.from_bytes(data,'big'); self.n=len(data)*8; self.i=0
    def take(self,n,signed=False):
        if n<0 or self.i+n>self.n: raise ValueError('Truncated RTCM field')
        v=(self.data>>(self.n-self.i-n))&((1<<n)-1); self.i+=n
        return v-(1<<n) if signed and v&(1<<(n-1)) else v
    def text(self):
        return bytes(self.take(8) for _ in range(self.take(8))).decode('ascii',errors='replace')

GPS_SIG={2:'L1 C/A',3:'L1 P',4:'L1 Z-tracking',8:'L2 C/A',9:'L2 P',10:'L2 Z-tracking',15:'L2C M',16:'L2C L',17:'L2C M+L',22:'L5 I',23:'L5 Q',24:'L5 I+Q'}
GAL_SIG={2:'E1 C',3:'E1 A',4:'E1 B',5:'E1 B+C',6:'E1 A+B+C',8:'E6 C',14:'E5b I',15:'E5b Q',16:'E5b I+Q',18:'E5 I',19:'E5 Q',20:'E5 I+Q',22:'E5a I',23:'E5a Q',24:'E5a I+Q'}

def ecef_to_geodetic(x,y,z):
    a=6378137.0; e2=6.6943799901413165e-3
    p=math.hypot(x,y)
    if p < 1e-9:
        if abs(z) < 1e-9:
            return {'latitude_deg':None, 'longitude_deg':None, 'ellipsoid_height_m':None}
        return {'latitude_deg':math.copysign(90,z), 'longitude_deg':0,
                'ellipsoid_height_m':abs(z)-a*math.sqrt(1-e2)}
    lat=math.atan2(z,p*(1-e2))
    for _ in range(12):
        n=a/math.sqrt(1-e2*math.sin(lat)**2)
        lat=math.atan2(z+e2*n*math.sin(lat),p)
    n=a/math.sqrt(1-e2*math.sin(lat)**2)
    height=p/math.cos(lat)-n
    return {'latitude_deg':math.degrees(lat),'longitude_deg':math.degrees(math.atan2(y,x)),
            'ellipsoid_height_m':height,'conversion_ellipsoid':'WGS84; source ITRF realization not resolved'}

def decode_packet(packet):
    if len(packet)<8 or packet[0]!=0xD3 or packet[1]&0xFC: raise ValueError('Invalid RTCM3 header')
    length=((packet[1]&3)<<8)|packet[2]
    if len(packet)!=length+6: raise ValueError('RTCM3 length mismatch')
    if crc24q(packet[:-3])!=int.from_bytes(packet[-3:],'big'): raise ValueError('CRC24Q mismatch')
    b=Bits(packet[3:-3]); typ=b.take(12); station=b.take(12) if typ in (1005,1033,1074,1094) else None
    row={'message_type':typ,'station_id':station,'payload_bytes':length,'crc24q_ok':True}
    if typ==1005:
        row['kind']='Reference station antenna reference point'
        row['itrf_realization']=b.take(6)
        row['gps_indicator']=bool(b.take(1)); row['glonass_indicator']=bool(b.take(1)); row['galileo_indicator']=bool(b.take(1)); row['reference_station_indicator']=bool(b.take(1))
        x=b.take(38,True)*.0001; row['single_receiver_oscillator']=bool(b.take(1)); b.take(1)
        y=b.take(38,True)*.0001; row['quarter_cycle_indicator']=b.take(2); z=b.take(38,True)*.0001
        row['ecef_m']=[x,y,z]; row['geodetic']=ecef_to_geodetic(x,y,z)
    elif typ==1033:
        row['kind']='Receiver and antenna descriptors'
        row['antenna_descriptor']=b.text(); row['antenna_setup_id']=b.take(8)
        row['antenna_serial']=b.text(); row['receiver_descriptor']=b.text()
        row['receiver_firmware']=b.text(); row['receiver_serial']=b.text()
    elif typ in (1074,1094):
        system='GPS' if typ==1074 else 'Galileo'
        row['kind']=system+' MSM4 observations'; row['constellation']=system
        row['epoch_tow_ms']=b.take(30); row['multiple_message']=bool(b.take(1)); row['issue_of_data_station']=b.take(3)
        b.take(7); row['clock_steering']=b.take(2); row['external_clock']=b.take(2)
        row['smoothing']=bool(b.take(1)); row['smoothing_interval_indicator']=b.take(3)
        sats=[i for i in range(1,65) if b.take(1)]
        signals=[i for i in range(1,33) if b.take(1)]
        cells=[(s,g) for s in sats for g in signals if b.take(1)]
        ranges=[b.take(8) for _ in sats]; fractions=[b.take(10) for _ in sats]
        rough={s:(None if r==255 else (r+f/1024)*299792.458) for s,r,f in zip(sats,ranges,fractions)}
        pr=[b.take(15,True) for _ in cells]; cp=[b.take(22,True) for _ in cells]
        locks=[b.take(4) for _ in cells]; half=[bool(b.take(1)) for _ in cells]; cnr=[b.take(6) for _ in cells]
        prefix='G' if system=='GPS' else 'E'; sigmap=GPS_SIG if system=='GPS' else GAL_SIG
        row['satellite_ids']=[f'{prefix}{s:02d}' for s in sats]
        row['signal_ids']=signals; row['signals']=[sigmap.get(g,f'Signal {g}') for g in signals]
        observations=[]
        for i,(s,g) in enumerate(cells):
            coarse=rough[s]
            observations.append({'satellite':f'{prefix}{s:02d}','signal_id':g,'signal':sigmap.get(g,f'Signal {g}'),
                'pseudorange_m':None if coarse is None or pr[i]==-16384 else coarse+pr[i]*299792.458/2**24,
                'phase_range_m':None if coarse is None or cp[i]==-2097152 else coarse+cp[i]*299792.458/2**29,
                'lock_time_indicator':locks[i],'half_cycle_ambiguity':half[i],'cnr_dbhz':cnr[i]})
        row['observations']=observations
    else:
        row['kind']='Unparsed RTCM3 message'
        return row
    remaining=b.n-b.i
    if remaining>7: raise ValueError(f'Unexpected payload remainder {remaining} bits for type {typ}')
    if remaining and b.take(remaining): raise ValueError('Nonzero RTCM padding')
    row['field_layout_ok']=True
    return row
