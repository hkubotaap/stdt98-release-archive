"""Soft-decision FEC for AMBE 3600x2450 voice blocks (STD-T98 TCH).

C0 (extended Golay 24,12) and C1 (Golay 23,12, whitened with
a PN sequence seeded by C0's data) are decoded by
maximum likelihood over all 4096 codewords using the per-bit soft values of
the frame and written back into a selected 9-byte codeword. The independent
AMBE+2 decoder receives the original block and this selected codeword, then
computes its own channel-quality distances. The returned error counts are
data-bit changes relative to the hard decision, retained as diagnostics.
"""
from dataclasses import dataclass

import numpy as np


# Same bit placement as core.audio.ambe_adapter / the SDR# Ambe.cs wrapper:
# payload bit 2s -> frame[_RW[s]][_RX[s]], bit 2s+1 -> frame[_RY[s]][_RZ[s]].
_RW = (0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,2,0,2,0,2,0,2,0,2,0,2,0,2)
_RX = (23,10,22,9,21,8,20,7,19,6,18,5,17,4,16,3,15,2,14,1,13,0,12,10,11,9,10,8,9,7,8,6,7,5,6,4)
_RY = (0,2,0,2,0,2,0,2,0,3,0,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3)
_RZ = (5,3,4,2,3,1,2,0,1,13,0,12,22,11,21,10,20,9,19,8,18,7,17,6,16,5,15,4,14,3,13,2,12,1,11,0)
# mbelib-neo ecc_const.c
_GOLAY_GENERATOR = (0x63a, 0x31d, 0x7b4, 0x3da, 0x1ed, 0x6cc, 0x366, 0x1b3, 0x6e3, 0x54b, 0x49f, 0x475)


def _frame_positions(row, length):
    position = {}
    for s in range(36):
        position[(_RW[s], _RX[s])] = 2 * s
        position[(_RY[s], _RZ[s])] = 2 * s + 1
    return np.array([position[(row, column)] for column in range(length)])


# Payload bit index of frame[row][0..length-1].
_C0_BITS = _frame_positions(0, 24)
_C1_BITS = _frame_positions(1, 23)


def _golay23_codebook():
    """codebook[d][i]: bit i of the Golay(23,12) codeword for data d, in
    mbelib's order (bits 22..11 data MSB first, bits 10..0 parity)."""
    data = np.arange(4096)
    words = np.zeros((4096, 23), dtype=np.uint8)
    parity = np.zeros(4096, dtype=np.int64)
    for i, generator in enumerate(_GOLAY_GENERATOR):
        bit = (data >> (11 - i)) & 1
        words[:, 22 - i] = bit
        parity ^= bit * generator
    for k in range(11):
        words[:, k] = (parity >> k) & 1
    return words


_GOLAY23 = _golay23_codebook()
# C0: frame[0][1..23] is the Golay(23,12) codeword, frame[0][0] even parity.
_C0_WORDS = np.concatenate(((_GOLAY23.sum(axis=1, keepdims=True) & 1).astype(np.uint8), _GOLAY23), axis=1)
_C0_SIGNS = 1.0 - 2.0 * _C0_WORDS.astype(np.float32)
_C1_SIGNS = 1.0 - 2.0 * _GOLAY23.astype(np.float32)
_DATA_BITS = slice(11, 23)  # codeword data bits (mbelib counts corrections here)


def _c1_pn_bits(c0_data):
    """mbelib demodulateAmbe3600Data: PN bit XORed into frame[1][j]."""
    pr = 16 * int(c0_data)
    bits = np.zeros(23, dtype=np.uint8)
    for k in range(1, 24):
        pr = (173 * pr + 13849) % 65536
        bits[23 - k] = pr // 32768  # j = 22 .. 0 for k = 1 .. 23
    return bits


_C1_PN = np.array([_c1_pn_bits(data) for data in range(4096)], dtype=np.uint8)
_C1_PN_SIGNS = 1.0 - 2.0 * _C1_PN.astype(np.float32)


def _c1_pn(c0_data):
    return _C1_PN[c0_data]


@dataclass(frozen=True)
class SoftBlock:
    payload: bytes        # 9-byte block with C0/C1 replaced by the chosen codewords
    c0_errors: int        # C0 data bits changed vs the hard decision
    total_errors: int     # c0_errors + C1 data bits changed


def soft_decode_block(hard_payload: bytes, soft_bits) -> SoftBlock:
    """``hard_payload``: the block's 9 bytes as received; ``soft_bits``: its
    72 soft values in payload bit order (positive = 0, larger = surer)."""
    soft = np.asarray(soft_bits, dtype=np.float32)
    if len(hard_payload) != 9 or soft.shape != (72,):
        raise ValueError("AMBE block needs 9 bytes and 72 soft values.")
    bits = np.unpackbits(np.frombuffer(hard_payload, dtype=np.uint8))

    c0 = int(np.argmax(_C0_SIGNS @ soft[_C0_BITS]))
    pn = _C1_PN[c0]
    c1_soft = soft[_C1_BITS] * _C1_PN_SIGNS[c0]
    c1 = int(np.argmax(_C1_SIGNS @ c1_soft))

    hard_c0 = bits[_C0_BITS][1:]
    hard_c1 = bits[_C1_BITS] ^ pn
    c0_errors = int(np.count_nonzero(hard_c0[_DATA_BITS] != _GOLAY23[c0][_DATA_BITS]))
    c1_errors = int(np.count_nonzero(hard_c1[_DATA_BITS] != _GOLAY23[c1][_DATA_BITS]))

    corrected = bits.copy()
    corrected[_C0_BITS] = _C0_WORDS[c0]
    corrected[_C1_BITS] = _GOLAY23[c1] ^ pn
    return SoftBlock(np.packbits(corrected).tobytes(), c0_errors, c0_errors + c1_errors)
