"""Soft-decision Viterbi for the K=5 rate-1/2 code shared by SACCH and PICH/TCH.

Soft inputs are per coded bit, positive meaning 0 and larger magnitude meaning
more reliable; 0.0 marks a punctured bit. Decoding the received symbol levels
instead of hard bits recovered far more SACCH CRCs on weak signals (offline,
RTL capture with added noise sigma 0.5: 955 -> 1148 of 1183) without raising
the CRC false-pass rate on noise.
"""
import numpy as np

from core.protocol.sacch import TRELLIS

_STATES = 16
# Each next state n is reached from two states with input bit n >> 3.
_PREV = np.array([[((n & 7) << 1) | low for low in (0, 1)] for n in range(_STATES)])
_INPUT = np.array([n >> 3 for n in range(_STATES)])
_OUT = np.zeros((_STATES, 2, 2), dtype=np.int8)
for (_state, _bit), (_next, _g1, _g2) in TRELLIS.items():
    _OUT[_state, _bit] = (_g1, _g2)
# Coded bits on each (next state, predecessor) branch, as +-1 (+1 for a 1 bit).
_SIGNS = np.stack([2 * _OUT[_PREV[:, k], _INPUT, :] - 1 for k in (0, 1)], axis=1).astype(np.float64)


def decode(soft, steps, info_steps):
    """Decode ``steps`` trellis steps (2 soft values each); returns (bits, errors).

    The trellis starts and ends in state 0; steps past ``info_steps`` are the
    zero tail. ``errors`` counts non-punctured hard decisions that disagree
    with the decoded path, comparable to the hard decoder's BitErrors.
    """
    values = np.asarray(soft, dtype=np.float64).reshape(steps, 2)
    cost = np.full(_STATES, np.inf)
    cost[0] = 0.0
    choices = np.zeros((steps, _STATES), dtype=np.int8)
    for step in range(steps):
        branch = cost[_PREV] + _SIGNS @ values[step]          # (next state, predecessor)
        if step >= info_steps:
            branch[_INPUT == 1] = np.inf
        choice = np.argmin(branch, axis=1)
        choices[step] = choice
        cost = branch[np.arange(_STATES), choice]
    bits = []
    errors = 0
    state = 0
    for step in range(steps - 1, -1, -1):
        previous = _PREV[state, choices[step, state]]
        bit = int(_INPUT[state])
        for value, coded in zip(values[step], _OUT[previous, bit]):
            if value != 0.0 and (value < 0) != bool(coded):
                errors += 1
        bits.append(bit)
        state = previous
    return bits[::-1][:info_steps], errors
