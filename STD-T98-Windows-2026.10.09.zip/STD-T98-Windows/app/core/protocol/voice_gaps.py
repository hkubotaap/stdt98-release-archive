"""Count lost 80 ms frame slots between consecutive voice bursts of one call.

The RF correlator reports slots with no detected sync (FramePacket.missed);
frames that arrived but carried no voice (sync/data bursts, unreadable RICH)
also leave a hole in the speech. The audio service fills the total with
concealment so playback keeps the call's real timing.
"""

FRAME_NS = 80_000_000
# Matches the correlator's MAX_TRACKED_MISSED_FRAMES (0.96 s). The audio
# service further limits the fill to what its jitter buffer lost.
MAX_FILLED_FRAMES = 12
# Beyond this since the previous voice burst it is a new call, not a gap.
_SAME_CALL_NS = int((MAX_FILLED_FRAMES + 1.5) * FRAME_NS)


class VoiceGapTracker:
    def __init__(self):
        self.pending = {}
        self.last_voice_ns = {}
        self.recovered_since_frame = {}

    def frame(self, channel_id, missed):
        """Every received frame: add the slots the correlator skipped before it,
        less those recovered by the flywheel (sent as voice already)."""
        recovered = self.recovered_since_frame.pop(channel_id, 0)
        self.pending[channel_id] = self.pending.get(channel_id, 0) + max(0, int(missed) - recovered)

    def recovered(self, channel_id, monotonic_ns):
        """A flywheel-recovered voice burst: lost slots right before it. The
        correlator still counts its slot as missed in the next frame."""
        self.recovered_since_frame[channel_id] = self.recovered_since_frame.get(channel_id, 0) + 1
        return self.voice(channel_id, monotonic_ns)

    def non_voice(self, channel_id):
        """A received frame that produced no voice burst."""
        self.pending[channel_id] = self.pending.get(channel_id, 0) + 1

    def voice(self, channel_id, monotonic_ns):
        """Lost slots right before this voice burst (0 at the start of a call)."""
        pending = self.pending.pop(channel_id, 0)
        previous = self.last_voice_ns.get(channel_id)
        self.last_voice_ns[channel_id] = monotonic_ns
        if previous is None or not 0 <= monotonic_ns - previous <= _SAME_CALL_NS:
            return 0
        return min(pending, MAX_FILLED_FRAMES)
