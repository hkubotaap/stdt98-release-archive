import numpy as np


FRAME_STRUCTURE = (
    ("SW", 20),
    ("RICH", 16),
    ("SACCH", 60),
    ("TCH1", 144),
    ("TCH2", 144),
)


def quantize_float_symbols(raw_symbols):
    raw_array = np.asarray(raw_symbols, dtype=np.float32)
    symbols = np.zeros(raw_array.shape, dtype=np.int8)
    symbols[raw_array > 2.0] = 3
    symbols[(raw_array > 0.0) & (raw_array <= 2.0)] = 1
    symbols[(raw_array > -2.0) & (raw_array <= 0.0)] = -1
    symbols[raw_array <= -2.0] = -3
    return symbols


# Soft symbols travel as int8 in units of 1/16 symbol level (+-3 -> +-48).
SOFT_SYMBOL_SCALE = 16


def encode_soft_symbols(raw_symbols):
    """int8 soft symbols that quantize exactly like ``raw_symbols``.

    Rounding to 1/16 could move a value across a decision threshold (0, +-2),
    so those few values are nudged back to the side the float was on.
    """
    raw = np.asarray(raw_symbols, dtype=np.float32)
    scale = SOFT_SYMBOL_SCALE
    soft = np.clip(np.round(raw * scale), -127, 127).astype(np.int16)
    edge = 2 * scale
    soft[(raw > 2.0) & (soft <= edge)] = edge + 1
    soft[(raw > 0.0) & (raw <= 2.0) & (soft < 1)] = 1
    soft[(raw > -2.0) & (raw <= 0.0) & (soft <= -edge)] = -edge + 1
    soft[(raw <= 0.0) & (soft > 0)] = 0
    return soft.astype(np.int8)


def decode_soft_symbols(soft_symbols):
    return np.asarray(soft_symbols, dtype=np.int8).astype(np.float32) / SOFT_SYMBOL_SCALE


def soft_bit_values(symbols):
    """Two soft values per (dewhitened) symbol, MSB then LSB; positive = bit 0.

    Matches symbols_to_bit_values: the MSB is the sign (1 for -1/-3) and the
    LSB marks the outer levels (+-3), decided at +-2.
    """
    values = np.asarray(symbols, dtype=np.float64)
    return np.stack((values, 2.0 - np.abs(values)), axis=1).reshape(-1)


def split_soft_bits(soft_bits):
    """Per-field slices of soft_bit_values output, keyed like split_frame_binary_string."""
    fields = {}
    current_bit_index = 0
    for name, bit_length in FRAME_STRUCTURE:
        fields[name] = soft_bits[current_bit_index : current_bit_index + bit_length]
        current_bit_index += bit_length
    return fields


def symbols_to_bit_values(symbols):
    symbol_array = np.asarray(symbols, dtype=np.int8)
    mapped = np.zeros(symbol_array.shape, dtype=np.uint8)
    mapped[symbol_array == -3] = 3
    mapped[symbol_array == -1] = 2
    mapped[symbol_array == 1] = 0
    mapped[symbol_array == 3] = 1
    return mapped


def symbols_to_binary_string(symbols):
    mapped = symbols_to_bit_values(symbols)
    return "".join(f"{value:02b}" for value in mapped)


def split_frame_binary_string(frame_bits):
    fields = {}
    current_bit_index = 0
    for name, bit_length in FRAME_STRUCTURE:
        fields[name] = frame_bits[current_bit_index : current_bit_index + bit_length]
        current_bit_index += bit_length
    return fields


def parse_frame_symbols(symbols):
    return split_frame_binary_string(symbols_to_binary_string(symbols))


def format_binary_string(bin_str, chunk_size=8):
    return " ".join(
        bin_str[index : index + chunk_size]
        for index in range(0, len(bin_str), chunk_size)
    )