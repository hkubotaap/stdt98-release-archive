#!/usr/bin/env python3
"""Replay CU8/CF32/NPY IQ at any RF frequency through the observed data profile."""
import argparse
from fractions import Fraction
from pathlib import Path
import sys
import numpy as np
from scipy import signal

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core.analysis.dqpsk_rtcm import FS, BurstReceiver, SessionRecorder, demodulate


def analyse_file(path, center, frequency, rate, directory, causal=False):
    path = Path(path)
    if not all(np.isfinite(x) and x > 0 for x in (center, frequency, rate)):
        raise ValueError('中心・対象周波数とサンプルレートは正の有限値が必要です。')
    if abs(center - frequency) + 4500 >= rate / 2:
        raise ValueError('対象信号は保存IQの帯域外です。')
    if path.suffix.lower() == '.cu8':
        raw = np.fromfile(path, np.uint8)
        if len(raw) % 2:
            raise ValueError('CU8の末尾に未完のI/Qサンプルがあります。')
        raw = raw.reshape(-1, 2).astype(np.float32)
        z = ((raw[:, 0] - 127.5) + 1j * (raw[:, 1] - 127.5)) / 128
    elif path.suffix.lower() == '.npy':
        z = np.load(path, allow_pickle=False)
        if z.ndim != 1 or not np.iscomplexobj(z):
            raise ValueError('1次元の複素IQ配列が必要です。')
    else:
        if path.stat().st_size % 8:
            raise ValueError('CF32の末尾に未完のI/Qサンプルがあります。')
        z = np.fromfile(path, '<c8')
    if len(z) < rate * .2:
        raise ValueError('解析には0.2秒以上のIQが必要です。')
    z = z * np.exp(-2j * np.pi * (frequency - center) * np.arange(len(z)) / rate)
    ratio = Fraction(FS / rate).limit_denominator(100000)
    z = signal.resample_poly(z, ratio.numerator, ratio.denominator).astype(np.complex64)
    recorder = SessionRecorder(directory, frequency, save_iq=False,
                               metadata={'source_file': str(path.resolve()), 'center_hz': center,
                                         'input_sample_rate_hz': rate, 'acquisition': 'causal' if causal else 'reference_offline'})
    try:
        if causal:
            receiver = BurstReceiver(recorder.consume)
            for start in range(0, len(z), 4093):
                chunk = z[start:start + 4093]
                recorder.feed_iq(chunk)
                receiver.feed(chunk)
            receiver.close()
        else:
            recorder.feed_iq(z)
            derivative = np.angle(z[1:] * np.conj(z[:-1])) * FS / (2 * np.pi)
            derivative = signal.sosfiltfilt(signal.butter(5, 1800, fs=FS, output='sos'), derivative)
            active = np.std(derivative[:len(derivative) // 768 * 768].reshape(-1, 768), axis=1) > 200
            starts = np.flatnonzero(np.diff(active.astype(int)) == 1) + 1
            ends = np.flatnonzero(np.diff(active.astype(int)) == -1) + 1
            for start in starts:
                later = ends[ends > start]
                if not len(later):
                    continue
                begin, end = start * .02 + .025, later[0] * .02 - .025
                result = demodulate(z[int(begin * FS):int(end * FS)])
                if result is not None:
                    result['sample_offset'] = int(end * FS)
                    recorder.consume(result)
        return recorder.snapshot()
    finally:
        recorder.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input')
    parser.add_argument('--center', type=float, required=True, help='IQ centre frequency in Hz')
    parser.add_argument('--frequency', type=float, required=True, help='Target RF frequency in Hz (not fixed to 351.200 MHz)')
    parser.add_argument('--rate', type=float, required=True, help='Input complex samples/s')
    parser.add_argument('--output', default='std98_data/dqpsk_replay')
    parser.add_argument('--causal', action='store_true', help='Use the same block-based gate as the live receiver')
    args = parser.parse_args()
    import json
    print(json.dumps(analyse_file(args.input, args.center, args.frequency, args.rate, args.output, args.causal), indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
