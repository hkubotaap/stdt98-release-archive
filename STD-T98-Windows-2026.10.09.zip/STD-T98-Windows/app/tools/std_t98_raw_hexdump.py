#!/usr/bin/env python3
"""Hex dump of recorded STD-T98 traffic (std98_data/raw + edu), for studying data channels.

Each recorded frame (80 ms) carries 36 bytes: the two traffic-channel halves TCH1 and
TCH2 (144 bits = 18 bytes each), already de-whitened. The edu log next to it holds the
frame's RICH (frame type M) and SACCH (CRC, user code) results.

    python tools/std_t98_raw_hexdump.py list --channel 3R13
    python tools/std_t98_raw_hexdump.py frames latest --channel 3R13 --limit 40
    python tools/std_t98_raw_hexdump.py stream latest --channel 3R13 --packets 5
    python tools/std_t98_raw_hexdump.py stream latest --channel 3R13 --html ch13.html

Markings: all-ones fill (FF) is dimmed, SOH (01) right after fill marks a packet start,
the 16-byte radio header is cyan, and RTCM 3 frames (D3...) are green when their own
CRC-24Q passes, yellow when it does not. RTCM frames are only identified (type, CRC);
their contents are not decoded.
"""
import argparse
import datetime
import html
import json
import os
import struct
import sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

APP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP))
from core.rf.channel_plan import FULL_351_BY_FREQUENCY, FULL_351_CHANNELS  # noqa: E402
from core.audio.data_paths import resolve_data_dir

DATA_DIR = resolve_data_dir(os.environ.get("STD_T98_DATA_DIR"), APP)
RAW_HEADER = struct.Struct("<8sqqII16sB3x")
FRAME_BYTES = 36
HALF_BYTES = 18
FILL = 0xFF
SOH = 0x01
RADIO_HEADER_BYTES = 16          # observed on 3R CH13: 01 "LECUO#" 00 "XD#" FF 01 xx xx xx
RICH_MODES = {0: "非音声1/非音声1", 1: "非音声2/音声", 2: "音声/非音声2", 3: "音声/音声",
              4: "非音声2/非音声2", 5: "アイドル(終話)"}


# ---------------------------------------------------------------- loading
@dataclass
class Frame:
    index: int
    data: bytes                  # 36 bytes: TCH1 + TCH2
    mode: int | None             # RICH M (None if parity failed)
    sacch_ok: bool
    user: int | None

    @property
    def clean_data(self):
        """Parity-good RICH, SACCH CRC OK and both halves non-voice-1 (M=0)."""
        return self.mode == 0 and self.sacch_ok


@dataclass
class Recording:
    path: Path
    frequency: int
    start: datetime.datetime
    frames: list = field(default_factory=list)

    @property
    def label(self):
        info = FULL_351_BY_FREQUENCY.get(self.frequency)
        return info.label if info else f"{self.frequency / 1e6:.5f}MHz"

    @property
    def seconds(self):
        return len(self.frames) * 0.08


def parse_channel(spec):
    """'3R13', '3R CH13', '351.275' (MHz) or '351275000' (Hz) -> frequency in Hz."""
    if spec is None:
        return None
    text = spec.upper().replace(" ", "").replace("CH", "")
    for info in FULL_351_CHANNELS:
        if text == f"{info.group}{info.channel_number}".upper() or text == f"{info.group}{info.channel_number:02d}".upper():
            return info.frequency_hz
    value = float(spec)
    return int(round(value * 1e6)) if value < 1e4 else int(value)


def recording_paths(frequency=None, date=None, data_dir=None):
    data_dir = resolve_data_dir(data_dir or DATA_DIR, APP)
    pattern = f"*_{frequency}_*.t98raw" if frequency else "*.t98raw"
    paths = sorted((data_dir / "raw").rglob(pattern))
    if date:
        paths = [p for p in paths if p.name.startswith(date.replace("-", ""))]
    return paths


def load(path, data_dir=None):
    data_dir = resolve_data_dir(data_dir or DATA_DIR, APP)
    path = Path(path)
    blob = path.read_bytes()
    _, frequency, start_ms, _, _, _, _ = RAW_HEADER.unpack_from(blob)
    edu = next((data_dir / "edu").rglob(path.stem + ".jsonl"), None)
    lines = [json.loads(l) for l in edu.read_text(encoding="utf-8").splitlines() if l.strip()] if edu else []
    recording = Recording(path, int(frequency), datetime.datetime.fromtimestamp(start_ms / 1000))
    for index, offset in enumerate(range(RAW_HEADER.size, len(blob) - FRAME_BYTES + 1, FRAME_BYTES)):
        info = lines[index] if index < len(lines) else {}
        rich, sacch = info.get("rich") or {}, info.get("sacch") or {}
        recording.frames.append(Frame(index, blob[offset:offset + FRAME_BYTES],
                                      rich.get("M") if rich.get("parityOK") else None,
                                      bool(sacch.get("crcOK")), sacch.get("userCode")))
    return recording


def pick(selector, frequency=None, date=None, data_dir=None):
    """'latest', a list index from `list`, or a file path."""
    if selector and Path(selector).exists():
        return Path(selector)
    paths = recording_paths(frequency, date, data_dir)
    if not paths:
        raise SystemExit("該当する録音がありません")
    if selector in (None, "latest"):
        return paths[-1]
    return paths[int(selector)]


# ---------------------------------------------------------------- analysis
def crc24q(data):
    crc = 0
    for byte in data:
        crc ^= byte << 16
        for _ in range(8):
            crc <<= 1
            if crc & 0x1000000:
                crc ^= 0x1864CFB
    return crc & 0xFFFFFF


def rtcm_at(data, offset):
    """(total length, message type, crc_ok) if an RTCM 3 frame header sits at offset, else None."""
    if offset + 6 > len(data) or data[offset] != 0xD3 or data[offset + 1] & 0xFC:
        return None
    length = ((data[offset + 1] & 3) << 8) | data[offset + 2]
    end = offset + 6 + length
    kind = (data[offset + 3] << 4) | (data[offset + 4] >> 4) if length >= 2 else None
    if not length or end > len(data):
        return (min(end, len(data)) - offset, kind, False)
    ok = crc24q(data[offset:offset + 3 + length]) == int.from_bytes(data[end - 3:end], "big")
    return (end - offset, kind, ok)


def fill_ber(frames):
    """Bit error rate measured on fill halves (>= 132 of 144 bits set)."""
    errors = bits = 0
    for frame in frames:
        for half in (frame.data[:HALF_BYTES], frame.data[HALF_BYTES:]):
            ones = sum(bin(b).count("1") for b in half)
            if ones >= 132:
                errors += 144 - ones
                bits += 144
    return errors / bits if bits else None


def clean_segments(recording):
    """Runs of consecutive clean data frames joined into byte strings (a bad frame breaks a run)."""
    segments, current = [], []
    for frame in recording.frames:
        if frame.clean_data:
            current.append(frame.data)
        elif current:
            segments.append(b"".join(current)); current = []
    if current:
        segments.append(b"".join(current))
    return segments


# A fill run starts with 6 fill-like bytes of which at least 4 are exactly FF. Random data
# has a byte with <= 2 zero bits 15% of the time, so shorter or looser tests split packets.
FILL_RUN = 6
FILL_RUN_EXACT = 4


def fill_like(byte):
    """FF, or FF with up to two bit errors (the data channel has no error correction)."""
    return bin(byte).count("1") >= 6


def _fill_run_at(segment, i):
    window = segment[i:i + FILL_RUN]
    return (len(window) == FILL_RUN and all(fill_like(b) for b in window)
            and sum(b == FILL for b in window) >= FILL_RUN_EXACT)


def split_packets(segment):
    """[(kind, bytes)]: 'fill' for fill runs (bit errors tolerated), 'packet' for SOH-led
    packets right after fill, 'data' for anything else (e.g. a packet whose start was lost)."""
    parts, i = [], 0
    while i < len(segment):
        if _fill_run_at(segment, i):
            j = i
            while j < len(segment) and fill_like(segment[j]) and segment[j] != SOH:
                j += 1
            parts.append(("fill", segment[i:j])); i = j
            continue
        j = i + 1
        while j < len(segment) and not _fill_run_at(segment, j):
            j += 1
        starts_packet = segment[i] == SOH and i > 0 and fill_like(segment[i - 1])
        parts.append(("packet" if starts_packet else "data", segment[i:j])); i = j
    return parts


# ---------------------------------------------------------------- rendering
class Painter:
    """ANSI or HTML styling of byte cells."""
    STYLES = {"fill": ("2", "#9a9a9a"), "soh": ("1;35", "#b0279f"), "header": ("36", "#0f7c90"),
              "rtcm_ok": ("32", "#1b7f2a"), "rtcm_bad": ("33", "#9a6b00"), "err": ("31", "#c0392b")}

    def __init__(self, mode):
        self.mode = mode           # "ansi", "plain" or "html"

    def cell(self, text, style=None, title=None):
        if not style or self.mode == "plain":
            return html.escape(text) if self.mode == "html" else text
        ansi, color = self.STYLES[style]
        if self.mode == "html":
            tip = f' title="{html.escape(title)}"' if title else ""
            return f'<span style="color:{color}"{tip}>{html.escape(text)}</span>'
        return f"\x1b[{ansi}m{text}\x1b[0m"

    def text(self, value):
        return html.escape(value) if self.mode == "html" else value


def byte_styles(chunk, kind):
    """Per-byte style for a packet/data chunk: SOH, radio header, RTCM frames."""
    styles = [None] * len(chunk)
    titles = [None] * len(chunk)
    start = 0
    if kind == "packet":
        styles[0], titles[0] = "soh", "SOH: パケット開始"
        for k in range(1, min(RADIO_HEADER_BYTES, len(chunk))):
            styles[k], titles[k] = "header", f"無線機ヘッダ {k}バイト目"
        start = RADIO_HEADER_BYTES
    # A failing frame is only shown where one is expected (right after the radio header, or
    # right after a CRC-valid frame); elsewhere a D3 byte is just as likely random data.
    expected = {start} if kind == "packet" else set()
    offset = start
    while offset < len(chunk):
        found = rtcm_at(chunk, offset)
        if found and (found[2] or offset in expected):
            length, kind_number, ok = found
            style = "rtcm_ok" if ok else "rtcm_bad"
            title = f"RTCM 3 type {kind_number} ({length}バイト, CRC {'OK' if ok else 'NG'})"
            for k in range(offset, min(offset + length, len(chunk))):
                styles[k], titles[k] = style, title
            offset += length
            if ok:
                expected.add(offset)
        else:
            offset += 1
    return styles, titles


def hex_line(painter, offset, chunk, styles, titles):
    cells = [painter.cell(f"{b:02x}", s, t) for b, s, t in zip(chunk, styles, titles)]
    cells += ["  "] * (16 - len(chunk))
    ascii_part = "".join(painter.cell(chr(b) if 32 <= b < 127 else ".", s, t)
                         for b, s, t in zip(chunk, styles, titles))
    return f"{offset:06x}  {' '.join(cells[:8])}  {' '.join(cells[8:])}  |{ascii_part}|"


def render_frames(recording, painter, limit=None, only_data=False):
    out = [painter.text(f"{recording.path.name}  {recording.label}  {recording.start:%Y-%m-%d %H:%M:%S}  "
                        f"{len(recording.frames)}フレーム ({recording.seconds:.1f}s)"),
           painter.text("   #     t[s]  M  内容                SACCH user | TCH1 (18B)"
                        + " " * 38 + "| TCH2 (18B)")]
    shown = 0
    for frame in recording.frames:
        if only_data and not frame.clean_data:
            continue
        halves = []
        for half in (frame.data[:HALF_BYTES], frame.data[HALF_BYTES:]):
            cells = []
            mostly_fill = sum(fill_like(b) for b in half) >= HALF_BYTES - 2
            for k, b in enumerate(half):
                # Inside fill, a byte that is not FF is a bit error.
                style = "fill" if b == FILL else "err" if mostly_fill and fill_like(b) else \
                    "soh" if b == SOH and k and fill_like(half[k - 1]) else None
                cells.append(painter.cell(f"{b:02x}", style))
            halves.append(" ".join(cells))
        mode = "-" if frame.mode is None else str(frame.mode)
        label = RICH_MODES.get(frame.mode, "RICH不良" if frame.mode is None else "予約")
        crc = "OK" if frame.sacch_ok else "NG"
        user = "" if frame.user is None else str(frame.user)
        out.append(painter.text(f"{frame.index:5d} {frame.index * 0.08:7.2f}  {mode}  {label:<14s}  {crc:>4s} {user:>4s} | ")
                   + halves[0] + painter.text(" | ") + halves[1])
        shown += 1
        if limit and shown >= limit:
            break
    return out


def render_stream(recording, painter, packets_limit=None):
    out = [painter.text(f"{recording.path.name}  {recording.label}  {recording.start:%Y-%m-%d %H:%M:%S}  "
                        f"非音声1(M=0)・CRC良好フレームを連結")]
    stats = Counter()
    rtcm_types = Counter()
    for seg_number, segment in enumerate(clean_segments(recording)):
        out.append(painter.text(f"--- 連続区間 {seg_number + 1}: {len(segment)} バイト "
                                f"({len(segment) // FRAME_BYTES} フレーム)"))
        for kind, chunk in split_packets(segment):
            if kind == "fill":
                stats["fill"] += len(chunk)
                damaged = [b for b in chunk if b != FILL]
                note = f"[FF ×{len(chunk)}]"
                if damaged:
                    note += f" ビット誤り {len(damaged)}バイト: " + " ".join(f"{b:02x}" for b in damaged[:8])
                    note += " …" if len(damaged) > 8 else ""
                out.append(painter.cell(f"        {note}", "fill"))
                continue
            stats[kind] += 1
            if kind == "packet" and packets_limit is not None and stats["packet"] > packets_limit:
                continue
            styles, titles = byte_styles(chunk, kind)
            name = "パケット" if kind == "packet" else "データ(区間の途中から)"
            out.append(painter.text(f"  [{name} {len(chunk)} バイト]"))
            for offset in range(0, len(chunk), 16):
                out.append(hex_line(painter, offset, chunk[offset:offset + 16],
                                    styles[offset:offset + 16], titles[offset:offset + 16]))
            offset = RADIO_HEADER_BYTES if kind == "packet" else 0
            while offset < len(chunk):
                found = rtcm_at(chunk, offset)
                if found and found[2]:
                    rtcm_types[found[1]] += 1
                    offset += found[0]
                else:
                    offset += 1
    ber = fill_ber(recording.frames)
    out.append(painter.text(
        f"=== 集計: パケット {stats['packet']} / 途中データ {stats['data']} / 埋め草 {stats['fill']} バイト / "
        f"埋め草のビット誤り率 {'-' if ber is None else f'{ber * 100:.2f}%'} / "
        f"CRC一致RTCM {dict(rtcm_types) or 'なし'}"))
    return out


def render_list(paths, painter, data_dir=None):
    out = [painter.text("  #  開始                 長さ   フレーム  M=0割合  CRC良好  ユーザ  ファイル")]
    for number, path in enumerate(paths):
        recording = load(path, data_dir)
        frames = recording.frames
        m0 = sum(f.mode == 0 for f in frames) / max(1, len(frames))
        ok = sum(f.sacch_ok for f in frames) / max(1, len(frames))
        users = Counter(f.user for f in frames if f.sacch_ok and f.user is not None)
        out.append(painter.text(f"{number:3d}  {recording.start:%Y-%m-%d %H:%M:%S}  {recording.seconds:6.1f}s  "
                                f"{len(frames):6d}  {m0 * 100:6.0f}%  {ok * 100:6.0f}%  "
                                f"{users.most_common(1)[0][0] if users else '-':>5}  {path.name}"))
    return out


HTML_PAGE = """<!doctype html><html lang="ja"><head><meta charset="utf-8"><title>STD-T98 RAW hex dump</title>
<style>body{{font:13px/1.45 Consolas,monospace;background:#fff;color:#222;margin:16px}}
@media (prefers-color-scheme: dark){{body{{background:#161616;color:#ddd}}}}
pre{{white-space:pre;overflow-x:auto}} .legend span{{margin-right:14px}}</style></head><body>
<div class="legend">{legend}</div><pre>{body}</pre></body></html>"""


def write_html(lines, path):
    painter = Painter("html")
    legend = " ".join(painter.cell(text, style) for text, style in
                      (("FF 埋め草", "fill"), ("01 パケット開始(SOH)", "soh"), ("無線機ヘッダ(16B)", "header"),
                       ("RTCM 3 (CRC OK)", "rtcm_ok"), ("RTCM 3 (CRC NG)", "rtcm_bad")))
    Path(path).write_text(HTML_PAGE.format(legend=legend, body="\n".join(lines)), encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("command", choices=("list", "frames", "stream"))
    parser.add_argument("recording", nargs="?", default="latest", help="latest / list の番号 / ファイルパス")
    parser.add_argument("--channel", help="例: 3R13, '3R CH13', 351.275")
    parser.add_argument("--date", help="YYYY-MM-DD")
    parser.add_argument("--limit", type=int, help="frames: 表示するフレーム数")
    parser.add_argument("--only-data", action="store_true", help="frames: 非音声1・CRC良好のフレームだけ")
    parser.add_argument("--packets", type=int, help="stream: 表示するパケット数（集計は全体）")
    parser.add_argument("--html", help="HTMLファイルに出力（ブラウザで閲覧）")
    parser.add_argument("--plain", action="store_true", help="色を付けない")
    args = parser.parse_args(argv)

    frequency = parse_channel(args.channel)
    painter = Painter("html" if args.html else "plain" if args.plain or not sys.stdout.isatty() else "ansi")
    if args.command == "list":
        lines = render_list(recording_paths(frequency, args.date), painter)
    else:
        recording = load(pick(args.recording, frequency, args.date))
        lines = (render_frames(recording, painter, args.limit, args.only_data) if args.command == "frames"
                 else render_stream(recording, painter, args.packets))
    if args.html:
        write_html(lines, args.html)
        print(f"wrote {args.html}")
    else:
        if os.name == "nt":
            os.system("")          # enable ANSI colours in the Windows console
        sys.stdout.reconfigure(encoding="utf-8")
        print("\n".join(lines))


if __name__ == "__main__":
    main()
