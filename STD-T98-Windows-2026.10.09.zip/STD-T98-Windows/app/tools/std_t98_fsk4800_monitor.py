#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Receive the 4800 sym/s 4FSK signal on 3R ch11 and log it packet by packet.

The signal is not T98 (see core.analysis.fsk4800 for what is known about it),
so the receiver ignores it. This tool demodulates one channel, cuts the symbol
stream into packets at the idle tone between them, and writes one JSON line
per packet: timing, length, header match, eye quality, how much of it equals
the previous packet, and the symbols themselves (0..3 = -3, -1, +1, +3).

The SDR can only be opened by one program, so stop the receiver first for a
live run. A capture from std_t98_record_iq.py works without the radio:

    python tools/std_t98_fsk4800_monitor.py --config rtl-sdr.toml --seconds 300
    python tools/std_t98_fsk4800_monitor.py --config rtl-sdr.toml --replay capture.cf32

Output goes to std98_data/fsk4800/<date>/ unless --output names a file.
"""

import datetime
import json
import math
import signal
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from gnuradio import analog, blocks, digital, filter, gr

from core.analysis.fsk4800 import DEVIATION_HZ, HEADER_MIN_MATCH, SYMBOL_RATE, PacketSplitter
from core.audio.recordings import default_data_dir
from core.rf.backend_config import add_config_arguments, derive_rates, load_config

DEMOD_RATE = 48000
DEFAULT_FREQ = 351_262_500  # 3R ch11 = 97ch ch38
REPORT_SECONDS = 60


class PacketSink(gr.sync_block):
    """Feeds soft symbols to the splitter and hands finished packets on."""

    def __init__(self, on_packet):
        gr.sync_block.__init__(self, name="fsk4800_packet_sink", in_sig=[np.float32], out_sig=[])
        self.splitter = PacketSplitter()
        self.on_packet = on_packet

    def work(self, input_items, output_items):
        for packet in self.splitter.feed(input_items[0]):
            self.on_packet(packet)
        return len(input_items[0])


class Monitor(gr.top_block):
    def __init__(self, config, freq, on_packet, capture=None):
        gr.top_block.__init__(self, "4800 sym/s 4FSK monitor", catch_exceptions=True)
        rates = derive_rates(config.sdr, config.channelizer)
        rate = rates.samp_rate_post_resamp1
        # Same geometry as the receiver: the stream after stage 1 is centred on
        # center_freq + freq_offset (the error correction is applied when tuning).
        self.stream_center = config.sdr.center_freq + config.sdr.freq_offset
        offset = freq - self.stream_center
        if abs(offset) > rate / 2 - 10_000:
            raise SystemExit(f"{freq/1e6:.5f} MHz is outside the captured band "
                             f"({self.stream_center/1e6:.5f} MHz +- {rate/2e3:.0f} kHz)")

        if capture:
            head = blocks.file_source(gr.sizeof_gr_complex, str(capture), False)
            chain = [head]
        else:
            from core.rf.soapy_source import open_source
            self._source = open_source(config.sdr)
            resamp1 = filter.rational_resampler_ccc(
                interpolation=rates.resamp1_interp, decimation=rates.resamp1_decim,
                taps=[], fractional_bw=0)
            chain = [self._source.source, resamp1]

        # rate -> 48 kHz: integer decimation first, then a small rational step.
        decim = max(1, int(rate // (DEMOD_RATE * 3)))
        mid_rate = rate / decim
        xlate = filter.freq_xlating_fir_filter_ccc(
            decim, filter.firdes.low_pass(1.0, rate, 8000, 6000), offset, rate)
        interp, down = _ratio(DEMOD_RATE, mid_rate)
        resamp = filter.rational_resampler_ccc(interpolation=interp, decimation=down, taps=[], fractional_bw=0)
        # Neighbouring T98 channels sit 6.25 kHz away; the signal itself spans about +-4.4 kHz.
        chan = filter.fir_filter_ccf(1, filter.firdes.low_pass(1.0, DEMOD_RATE, 4600, 1500))
        fm = analog.quadrature_demod_cf(DEMOD_RATE / (2 * math.pi * DEVIATION_HZ))
        rrc = filter.firdes.root_raised_cosine(1.0, DEMOD_RATE, SYMBOL_RATE, 0.5, 161)
        matched = filter.fir_filter_fff(1, [t / sum(rrc) for t in rrc])
        sync = digital.symbol_sync_ff(
            digital.TED_GARDNER, DEMOD_RATE / SYMBOL_RATE, 0.01, 1.0, 1.0, 1.5, 1,
            digital.constellation_bpsk().base(), digital.IR_MMSE_8TAP, 128, [])
        scale = blocks.multiply_const_ff(3.0)
        self.sink = PacketSink(on_packet)
        self.connect(*chain, xlate, resamp, chan, fm, matched, sync, scale, self.sink)


def _ratio(out_rate, in_rate):
    from fractions import Fraction
    r = Fraction(int(round(out_rate)), int(round(in_rate))).limit_denominator(1000)
    return r.numerator, r.denominator


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Log the 4800 sym/s 4FSK signal (3R ch11) packet by packet.")
    add_config_arguments(parser)
    parser.add_argument("--channel-freq", type=float, default=DEFAULT_FREQ, help="Channel centre in Hz (default 3R ch11).")
    parser.add_argument("--replay", help="Read a std_t98_record_iq.py .cf32 capture instead of the SDR.")
    parser.add_argument("--seconds", type=float, default=0.0, help="Live run length; 0 = until Ctrl+C.")
    parser.add_argument("-o", "--output", help="Output .jsonl (default std98_data/fsk4800/<date>/...).")
    parser.add_argument("--quiet", action="store_true", help="No per-packet console lines.")
    args = parser.parse_args()

    config = load_config(args)
    now = datetime.datetime.now()
    if args.output:
        path = Path(args.output)
    else:
        path = (default_data_dir(Path(__file__).resolve().parent.parent) / "fsk4800" / now.strftime("%Y-%m-%d")
                / f"{now:%Y%m%d_%H%M%S}_{int(args.channel_freq)}.jsonl")
    path.parent.mkdir(parents=True, exist_ok=True)

    out = path.open("w", encoding="utf-8")
    state = {"previous": None, "count": 0, "noise": 0}
    started = time.time()

    def on_packet(packet):
        if packet.header()[1] < HEADER_MIN_MATCH:
            # Noise cut at a chance run of +1 symbols: the signal is absent.
            state["noise"] += 1
            return
        record = {"type": "packet", "n": state["count"], "t": round(packet.start / SYMBOL_RATE, 3)}
        if not args.replay:
            record["time"] = datetime.datetime.fromtimestamp(started + packet.start / SYMBOL_RATE).isoformat(
                timespec="milliseconds")
        record.update(packet.summary(state["previous"]))
        out.write(json.dumps(record, ensure_ascii=False) + "\n")
        out.flush()
        state["previous"], state["count"] = packet, state["count"] + 1
        if not args.quiet:
            same = record.get("same_as_previous")
            print(f"#{record['n']:4d} t={record['t']:8.3f}s idle={record['idle']:4d} len={record['length']:5d} "
                  f"hdr={record['header_match']:>6} hdr2={record['header2_match']:>6} q={record['quality']:.2f}"
                  + (f" same={same:.2f}" if same is not None else "")
                  + (" TRUNCATED" if record["truncated"] else ""), flush=True)

    tb = Monitor(config, args.channel_freq, on_packet, capture=args.replay)
    meta = {"type": "meta", "freq": args.channel_freq, "source": args.replay or config.sdr.device_string(),
            "stream_center": tb.stream_center, "symbol_rate": SYMBOL_RATE, "started": now.isoformat(),
            "levels": "0..3 = -3,-1,+1,+3"}
    out.write(json.dumps(meta, ensure_ascii=False) + "\n")
    print(f"monitoring {args.channel_freq/1e6:.5f} MHz from {meta['source']} -> {path}", flush=True)

    stopping = False

    def stop(sig=None, frame=None):
        nonlocal stopping
        stopping = True

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)

    tb.start()
    if args.replay:
        tb.wait()  # the file source ends the flowgraph by itself
    else:
        deadline = time.monotonic() + args.seconds if args.seconds else None
        next_report = time.monotonic() + REPORT_SECONDS
        while not stopping and (deadline is None or time.monotonic() < deadline):
            time.sleep(0.2)
            if time.monotonic() >= next_report:
                next_report += REPORT_SECONDS
                print(f"[{datetime.datetime.now():%H:%M:%S}] {state['count']} packets so far"
                      + ("" if state["count"] else " (no signal on this channel yet)"), flush=True)
        tb.stop()
        tb.wait()
    out.close()
    print(f"{state['count']} packets written to {path}"
          + (f" ({state['noise']} noise segments without the header skipped)" if state["noise"] else ""))


if __name__ == "__main__":
    main()
