# Download the latest radioconda (GNU Radio + SoapySDR) for Windows x86_64,
# verify its published SHA256 and install it silently for the current user.
# Then make sure the SoapySDR packages the receiver uses are present.
# Called by setup_env.bat / run.bat / run_gui.bat.
param([Parameter(Mandatory = $true)][string]$Target)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# SoapySDR core, its GNU Radio block, and the device modules for the drivers
# run.bat auto-detects (SDRplay needs the vendor API and is not included).
$SoapyPackages = @(
    'soapysdr', 'gnuradio-soapy',
    'soapysdr-module-hackrf', 'soapysdr-module-rtlsdr', 'soapysdr-module-airspy',
    'soapysdr-module-airspyhf', 'soapysdr-module-uhd', 'soapysdr-module-bladerf',
    'soapysdr-module-lms7', 'soapysdr-module-plutosdr'
)

function Install-SoapyPackages {
    $meta = Join-Path $Target 'conda-meta'
    # conda-meta\<name>-<version>-<build>.json; the version digit keeps
    # 'soapysdr' from matching 'soapysdr-module-*'.
    $installed = Get-ChildItem -Path $meta -Filter '*.json' -ErrorAction SilentlyContinue | ForEach-Object Name
    $missing = $SoapyPackages | Where-Object {
        $pattern = '^' + [regex]::Escape($_) + '-\d'
        -not ($installed | Where-Object { $_ -match $pattern })
    }
    if ($missing) {
        $conda = @('Scripts\mamba.exe', 'Scripts\conda.exe', 'condabin\conda.bat') |
            ForEach-Object { Join-Path $Target $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
        if (-not $conda) { throw "conda not found in $Target; cannot install: $($missing -join ' ')" }
        Write-Host "[INFO] Installing SoapySDR packages: $($missing -join ' ') ..."
        & $conda install -y -p $Target -c conda-forge @missing
        if ($LASTEXITCODE) { throw "conda install failed (exit $LASTEXITCODE)" }
    }
    & (Join-Path $Target 'python.exe') -c "import SoapySDR; from gnuradio import gr, soapy"
    if ($LASTEXITCODE) { throw 'SoapySDR / gnuradio.soapy cannot be imported' }
    Write-Host '[INFO] SoapySDR / gnuradio.soapy ready.'
}

if (Test-Path (Join-Path $Target 'python.exe')) {
    try { Install-SoapyPackages; exit 0 }
    catch { Write-Host "[ERROR] $($_.Exception.Message)"; exit 1 }
}
if ((Test-Path $Target) -and (Get-ChildItem -Force $Target | Select-Object -First 1)) {
    Write-Host "[ERROR] $Target exists but has no python.exe. Remove or rename it, then retry."
    exit 1
}
if ($Target -match '[^\x20-\x7E]') {
    # conda packages with hard-coded prefixes fail under non-ASCII paths.
    Write-Host "[ERROR] Install path contains non-ASCII characters: $Target"
    Write-Host "        Install radioconda manually to an ASCII-only folder (e.g. C:\radioconda)."
    exit 1
}

try {
    $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/radioconda/radioconda-installer/releases/latest' `
        -Headers @{ 'User-Agent' = 'std-t98-setup' }
    $installer = $release.assets | Where-Object { $_.name -like '*-Windows-x86_64.exe' } | Select-Object -First 1
    $checksum = $release.assets | Where-Object { $_.name -eq "$($installer.name).sha256" } | Select-Object -First 1
    if (-not $installer -or -not $checksum) { throw "No Windows x86_64 installer in release $($release.tag_name)" }

    $exe = Join-Path $env:TEMP $installer.name
    Write-Host "[INFO] Downloading $($installer.name) ($([math]::Round($installer.size / 1MB)) MB) ..."
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) {
        & $curl.Source -L --fail --retry 3 -o $exe $installer.browser_download_url
        if ($LASTEXITCODE) { throw "Download failed (curl exit $LASTEXITCODE)" }
    } else {
        Invoke-WebRequest -Uri $installer.browser_download_url -OutFile $exe -UseBasicParsing
    }

    $expected = ((Invoke-RestMethod -Uri $checksum.browser_download_url -Headers @{ 'User-Agent' = 'std-t98-setup' }) -split '\s+')[0]
    $actual = (Get-FileHash -Algorithm SHA256 $exe).Hash
    if ($actual -ne $expected.ToUpper()) { throw "SHA256 mismatch (expected $expected, got $actual)" }
    Write-Host '[INFO] SHA256 verified.'

    Write-Host "[INFO] Installing radioconda $($release.tag_name) to $Target (several minutes) ..."
    # /D must be last and unquoted (NSIS); it may contain spaces.
    $process = Start-Process -FilePath $exe -Wait -PassThru `
        -ArgumentList "/S /InstallationType=JustMe /RegisterPython=0 /AddToPath=0 /D=$Target"
    if ($process.ExitCode) { throw "Installer exited with code $($process.ExitCode)" }
    if (-not (Test-Path (Join-Path $Target 'python.exe'))) { throw "python.exe not found in $Target after install" }
    Remove-Item $exe -ErrorAction SilentlyContinue
    Write-Host '[INFO] radioconda installed.'
    Install-SoapyPackages
    exit 0
} catch {
    Write-Host "[ERROR] radioconda install failed: $($_.Exception.Message)"
    Write-Host '        Manual install: https://github.com/radioconda/radioconda-installer'
    exit 1
}
