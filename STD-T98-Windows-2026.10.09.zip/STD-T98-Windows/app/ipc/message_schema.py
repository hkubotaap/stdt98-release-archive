from dataclasses import dataclass
import json
import struct

import numpy as np


MESSAGE_VERSION = 1
MSG_TYPE_FRAME = 1
MSG_TYPE_VOICE_BURST = 2
MSG_TYPE_STATUS = 3
MSG_TYPE_SECRET_CRACK_REQUEST = 4
MSG_TYPE_SECRET_CRACK_RESULT = 5
MSG_TYPE_CONTROL_SQUELCH = 6
MSG_TYPE_CONTROL_GAIN = 7
# Message type 8 is reserved for the removed IQ capture command.
MSG_TYPE_CONTROL_CORRECT_IQ = 11
MSG_TYPE_VOICE_QUALITY = 9
MSG_TYPE_CONTROL_HACKRF_GAIN = 10
MSG_TYPE_CONTROL_FREQ_AUTO = 12

FRAME_FLAG_SYNC_DETECTED = 1 << 0
FRAME_FLAG_CLIPPED = 1 << 1
FRAME_FLAG_CONFIDENCE_LOW = 1 << 2
# Symbols are soft values in 1/16 level units (frame_layout.encode_soft_symbols)
# rather than hard +-1/+-3.
FRAME_FLAG_SOFT_SYMBOLS = 1 << 3
# Flywheel probe (on unless STD_T98_FLYWHEEL_PROBE=0): cut at the slot where
# a call's next frame was due although no sync word was detected there. The
# protocol service must not decode it as a received frame: it validates it
# and forwards only a recovered voice burst (quality["recovered"]).
FRAME_FLAG_FLYWHEEL = 1 << 4

VOICE_FORMAT_RAW_3600 = 1
VOICE_FORMAT_AMBE_2450 = 2

VOICE_BURST_BLOCK_BYTES_RAW_3600 = 9
VOICE_BURST_BLOCK_BYTES_AMBE_2450 = 7

STATUS_SOURCE_PROTOCOL = 1
STATUS_SOURCE_AUDIO = 2
STATUS_SOURCE_LAUNCHER = 3
STATUS_SOURCE_SECRET = 4
STATUS_SOURCE_RF = 5

SECRET_RESULT_NONE = 0
SECRET_RESULT_CURRENT_KEY = 1
SECRET_RESULT_GLOBAL_CACHE = 2
SECRET_RESULT_FULL_SEARCH = 3

FRAME_HEADER = struct.Struct("<HHIQHHHH")
VOICE_HEADER = struct.Struct("<HHIHBHIBB")
STATUS_HEADER = struct.Struct("<HHIQHHI")
SECRET_REQUEST_HEADER = struct.Struct("<HHIHHHBB")
SECRET_RESULT_HEADER = struct.Struct("<HHIHHHBB")
CONTROL_SQUELCH_HEADER = struct.Struct("<HHf")
CONTROL_GAIN_HEADER = struct.Struct("<HHBf")
CONTROL_HACKRF_GAIN_HEADER = struct.Struct("<HHBBBB")

SECRET_BURST_BYTES_AMBE_2450 = VOICE_BURST_BLOCK_BYTES_AMBE_2450 * 4


def _voice_payload_block_size(payload_format: int) -> int:
    if payload_format == VOICE_FORMAT_RAW_3600:
        return VOICE_BURST_BLOCK_BYTES_RAW_3600
    if payload_format == VOICE_FORMAT_AMBE_2450:
        return VOICE_BURST_BLOCK_BYTES_AMBE_2450
    raise ValueError(f"Unsupported voice payload format: {payload_format}")


@dataclass(frozen=True)
class FramePacket:
    sequence: int
    monotonic_ns: int
    channel_id: int
    flags: int
    symbols: np.ndarray
    # Frame slots on this channel with no detected sync since its previous
    # frame (same transmission). Carried in the formerly reserved field.
    missed: int = 0

    def encode(self) -> bytes:
        symbols = np.asarray(self.symbols, dtype=np.int8)
        return FRAME_HEADER.pack(
            MESSAGE_VERSION,
            MSG_TYPE_FRAME,
            self.sequence,
            self.monotonic_ns,
            self.channel_id,
            self.flags,
            symbols.size,
            max(0, min(0xFFFF, int(self.missed))),
        ) + symbols.tobytes()

    @classmethod
    def decode(cls, payload: bytes):
        if len(payload) < FRAME_HEADER.size:
            raise ValueError("Frame packet is shorter than the header size.")

        version, msg_type, sequence, monotonic_ns, channel_id, flags, symbol_count, missed = FRAME_HEADER.unpack(
            payload[: FRAME_HEADER.size]
        )
        if version != MESSAGE_VERSION:
            raise ValueError(f"Unsupported message version: {version}")
        if msg_type != MSG_TYPE_FRAME:
            raise ValueError(f"Unsupported message type: {msg_type}")

        expected_size = FRAME_HEADER.size + symbol_count
        if len(payload) != expected_size:
            raise ValueError(
                f"Frame packet size mismatch: expected {expected_size} bytes, got {len(payload)} bytes."
            )

        symbols = np.frombuffer(payload[FRAME_HEADER.size:], dtype=np.int8, count=symbol_count).copy()
        return cls(
            sequence=sequence,
            monotonic_ns=monotonic_ns,
            channel_id=channel_id,
            flags=flags,
            symbols=symbols,
            missed=missed,
        )


@dataclass(frozen=True)
class VoiceBurstPacket:
    sequence: int
    channel_id: int
    call_stat: int
    key_id: int
    burst_index: int
    payload_format: int
    payload: bytes
    quality: dict | None = None

    def encode(self) -> bytes:
        block_size = _voice_payload_block_size(self.payload_format)
        if len(self.payload) % block_size != 0:
            raise ValueError(
                f"Voice burst payload size {len(self.payload)} is not a multiple of {block_size} bytes."
            )

        block_count = len(self.payload) // block_size
        if block_count > 0xFF:
            raise ValueError("Voice burst block count exceeds the header limit.")

        return VOICE_HEADER.pack(
            MESSAGE_VERSION,
            MSG_TYPE_VOICE_QUALITY if self.quality is not None else MSG_TYPE_VOICE_BURST,
            self.sequence,
            self.channel_id,
            self.call_stat,
            self.key_id,
            self.burst_index,
            block_count,
            self.payload_format,
        ) + (self._quality_bytes() if self.quality is not None else b"") + self.payload

    def _quality_bytes(self):
        data = json.dumps(self.quality, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        if len(data) > 4096:
            raise ValueError("Voice quality metadata is too large.")
        return struct.pack("<H", len(data)) + data

    @classmethod
    def decode(cls, payload: bytes):
        if len(payload) < VOICE_HEADER.size:
            raise ValueError("Voice burst packet is shorter than the header size.")

        version, msg_type, sequence, channel_id, call_stat, key_id, burst_index, block_count, payload_format = VOICE_HEADER.unpack(
            payload[: VOICE_HEADER.size]
        )
        if version != MESSAGE_VERSION:
            raise ValueError(f"Unsupported message version: {version}")
        if msg_type not in (MSG_TYPE_VOICE_BURST, MSG_TYPE_VOICE_QUALITY):
            raise ValueError(f"Unsupported message type: {msg_type}")

        burst_payload = payload[VOICE_HEADER.size:]
        quality = None
        if msg_type == MSG_TYPE_VOICE_QUALITY:
            if len(burst_payload) < 2:
                raise ValueError("Missing voice quality length.")
            size = struct.unpack_from("<H", burst_payload)[0]
            if size > 4096 or len(burst_payload) < 2 + size:
                raise ValueError("Invalid voice quality length.")
            quality = json.loads(burst_payload[2:2 + size])
            if not isinstance(quality, dict):
                raise ValueError("Voice quality must be an object.")
            burst_payload = burst_payload[2 + size:]
        block_size = _voice_payload_block_size(payload_format)
        if block_count * block_size != len(burst_payload):
            raise ValueError("Voice burst payload size mismatch.")

        return cls(
            sequence=sequence,
            channel_id=channel_id,
            call_stat=call_stat,
            key_id=key_id,
            burst_index=burst_index,
            payload_format=payload_format,
            payload=burst_payload,
            quality=quality,
        )


@dataclass(frozen=True)
class StatusPacket:
    sequence: int
    monotonic_ns: int
    source: int
    channel_id: int
    payload: bytes

    def encode(self) -> bytes:
        return STATUS_HEADER.pack(
            MESSAGE_VERSION,
            MSG_TYPE_STATUS,
            self.sequence,
            self.monotonic_ns,
            self.source,
            self.channel_id,
            len(self.payload),
        ) + self.payload

    def to_dict(self):
        return json.loads(self.payload.decode("utf-8"))

    @classmethod
    def from_dict(cls, sequence: int, monotonic_ns: int, source: int, channel_id: int, payload_dict: dict):
        payload = json.dumps(payload_dict, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
        return cls(
            sequence=sequence,
            monotonic_ns=monotonic_ns,
            source=source,
            channel_id=channel_id,
            payload=payload,
        )

    @classmethod
    def decode(cls, payload: bytes):
        if len(payload) < STATUS_HEADER.size:
            raise ValueError("Status packet is shorter than the header size.")

        version, msg_type, sequence, monotonic_ns, source, channel_id, payload_length = STATUS_HEADER.unpack(
            payload[: STATUS_HEADER.size]
        )
        if version != MESSAGE_VERSION:
            raise ValueError(f"Unsupported message version: {version}")
        if msg_type != MSG_TYPE_STATUS:
            raise ValueError(f"Unsupported message type: {msg_type}")

        status_payload = payload[STATUS_HEADER.size:]
        if len(status_payload) != payload_length:
            raise ValueError("Status payload size mismatch.")

        return cls(
            sequence=sequence,
            monotonic_ns=monotonic_ns,
            source=source,
            channel_id=channel_id,
            payload=status_payload,
        )


@dataclass(frozen=True)
class SecretCrackRequestPacket:
    sequence: int
    channel_id: int
    session_id: int
    current_key: int
    burst_count: int
    payload: bytes

    def encode(self) -> bytes:
        if self.burst_count <= 0 or self.burst_count > 0xFF:
            raise ValueError("Secret crack request burst count must be between 1 and 255.")

        expected_size = self.burst_count * SECRET_BURST_BYTES_AMBE_2450
        if len(self.payload) != expected_size:
            raise ValueError(
                f"Secret crack request payload size mismatch: expected {expected_size} bytes, got {len(self.payload)} bytes."
            )

        return SECRET_REQUEST_HEADER.pack(
            MESSAGE_VERSION,
            MSG_TYPE_SECRET_CRACK_REQUEST,
            self.sequence,
            self.channel_id,
            self.session_id,
            self.current_key,
            self.burst_count,
            0,
        ) + self.payload

    @classmethod
    def decode(cls, payload: bytes):
        if len(payload) < SECRET_REQUEST_HEADER.size:
            raise ValueError("Secret crack request packet is shorter than the header size.")

        version, msg_type, sequence, channel_id, session_id, current_key, burst_count, _ = SECRET_REQUEST_HEADER.unpack(
            payload[: SECRET_REQUEST_HEADER.size]
        )
        if version != MESSAGE_VERSION:
            raise ValueError(f"Unsupported message version: {version}")
        if msg_type != MSG_TYPE_SECRET_CRACK_REQUEST:
            raise ValueError(f"Unsupported message type: {msg_type}")

        burst_payload = payload[SECRET_REQUEST_HEADER.size:]
        expected_size = burst_count * SECRET_BURST_BYTES_AMBE_2450
        if len(burst_payload) != expected_size:
            raise ValueError("Secret crack request payload size mismatch.")

        return cls(
            sequence=sequence,
            channel_id=channel_id,
            session_id=session_id,
            current_key=current_key,
            burst_count=burst_count,
            payload=burst_payload,
        )


@dataclass(frozen=True)
class SecretCrackResultPacket:
    sequence: int
    channel_id: int
    session_id: int
    resolved_key: int
    result_source: int

    def encode(self) -> bytes:
        return SECRET_RESULT_HEADER.pack(
            MESSAGE_VERSION,
            MSG_TYPE_SECRET_CRACK_RESULT,
            self.sequence,
            self.channel_id,
            self.session_id,
            self.resolved_key,
            self.result_source,
            0,
        )

    @classmethod
    def decode(cls, payload: bytes):
        if len(payload) != SECRET_RESULT_HEADER.size:
            raise ValueError("Secret crack result packet size mismatch.")

        version, msg_type, sequence, channel_id, session_id, resolved_key, result_source, _ = SECRET_RESULT_HEADER.unpack(
            payload
        )
        if version != MESSAGE_VERSION:
            raise ValueError(f"Unsupported message version: {version}")
        if msg_type != MSG_TYPE_SECRET_CRACK_RESULT:
            raise ValueError(f"Unsupported message type: {msg_type}")

        return cls(
            sequence=sequence,
            channel_id=channel_id,
            session_id=session_id,
            resolved_key=resolved_key,
            result_source=result_source,
        )


@dataclass(frozen=True)
class ControlSquelchPacket:
    """GUI -> backend: set the per-channel squelch threshold live.

    Sent over the control socket (see ipc.transport.uds_seqpacket), the
    reverse direction of the status socket, so the backend can be re-tuned
    without restarting the flowgraph.
    """

    threshold_db: float

    def encode(self) -> bytes:
        return CONTROL_SQUELCH_HEADER.pack(
            MESSAGE_VERSION,
            MSG_TYPE_CONTROL_SQUELCH,
            self.threshold_db,
        )

    @classmethod
    def decode(cls, payload: bytes):
        if len(payload) != CONTROL_SQUELCH_HEADER.size:
            raise ValueError("Control squelch packet size mismatch.")

        version, msg_type, threshold_db = CONTROL_SQUELCH_HEADER.unpack(payload)
        if version != MESSAGE_VERSION:
            raise ValueError(f"Unsupported message version: {version}")
        if msg_type != MSG_TYPE_CONTROL_SQUELCH:
            raise ValueError(f"Unsupported message type: {msg_type}")

        return cls(threshold_db=threshold_db)


@dataclass(frozen=True)
class ControlGainPacket:
    auto: bool
    gain_db: float

    def encode(self) -> bytes:
        return CONTROL_GAIN_HEADER.pack(MESSAGE_VERSION, MSG_TYPE_CONTROL_GAIN, self.auto, self.gain_db)

    @classmethod
    def decode(cls, payload: bytes):
        if len(payload) != CONTROL_GAIN_HEADER.size:
            raise ValueError("Control gain packet size mismatch.")
        version, kind, auto, gain_db = CONTROL_GAIN_HEADER.unpack(payload)
        if version != MESSAGE_VERSION or kind != MSG_TYPE_CONTROL_GAIN or auto not in (0, 1):
            raise ValueError("Invalid control gain packet.")
        return cls(bool(auto), gain_db)


@dataclass(frozen=True)
class ControlHackRFGainPacket:
    auto: bool
    lna_gain: int
    vga_gain: int
    amp: bool

    def encode(self) -> bytes:
        from core.rf.hackrf_gain import HackRFGains
        gains = HackRFGains(self.lna_gain, self.vga_gain, self.amp)
        if not isinstance(self.auto, bool):
            raise ValueError("HackRF auto mode must be a boolean")
        return CONTROL_HACKRF_GAIN_HEADER.pack(MESSAGE_VERSION, MSG_TYPE_CONTROL_HACKRF_GAIN,
                                              self.auto, int(gains.lna), int(gains.vga), gains.amp)

    @classmethod
    def decode(cls, payload):
        from core.rf.hackrf_gain import HackRFGains
        if len(payload) != CONTROL_HACKRF_GAIN_HEADER.size:
            raise ValueError("Control HackRF gain packet size mismatch")
        version, kind, auto, lna, vga, amp = CONTROL_HACKRF_GAIN_HEADER.unpack(payload)
        if version != MESSAGE_VERSION or kind != MSG_TYPE_CONTROL_HACKRF_GAIN or auto not in (0, 1) or amp not in (0, 1):
            raise ValueError("Invalid control HackRF gain packet")
        HackRFGains(lna, vga, bool(amp))
        return cls(bool(auto), lna, vga, bool(amp))


@dataclass(frozen=True)
class ControlCorrectIQPacket:
    enabled: bool

    def encode(self):
        if not isinstance(self.enabled, bool):
            raise ValueError("Correct IQ mode must be a boolean")
        return struct.pack("<HHB", MESSAGE_VERSION, MSG_TYPE_CONTROL_CORRECT_IQ, self.enabled)

    @classmethod
    def decode(cls, payload):
        if len(payload) != 5:
            raise ValueError("Invalid Correct IQ control size")
        version, kind, enabled = struct.unpack("<HHB", payload)
        if version != MESSAGE_VERSION or kind != MSG_TYPE_CONTROL_CORRECT_IQ or enabled not in (0, 1):
            raise ValueError("Invalid Correct IQ control packet")
        return cls(bool(enabled))


@dataclass(frozen=True)
class ControlFreqAutoPacket:
    """Switch automatic frequency correction on/off in a running backend."""
    enabled: bool

    def encode(self):
        if not isinstance(self.enabled, bool):
            raise ValueError("Automatic frequency correction mode must be a boolean")
        return struct.pack("<HHB", MESSAGE_VERSION, MSG_TYPE_CONTROL_FREQ_AUTO, self.enabled)

    @classmethod
    def decode(cls, payload):
        if len(payload) != 5:
            raise ValueError("Invalid frequency auto control size")
        version, kind, enabled = struct.unpack("<HHB", payload)
        if version != MESSAGE_VERSION or kind != MSG_TYPE_CONTROL_FREQ_AUTO or enabled not in (0, 1):
            raise ValueError("Invalid frequency auto control packet")
        return cls(bool(enabled))
