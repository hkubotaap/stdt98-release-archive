import errno
import os
import select
import socket
import time


# On Windows there is no AF_UNIX/SOCK_SEQPACKET and no select.poll, so the whole
# transport is swapped for a TCP-loopback implementation with identical class
# names and method contract (see _tcp). The switch can also be forced with
# STD_T98_IPC=tcp for testing the TCP path on Linux. The actual override happens
# at the bottom of this module, after the UDS classes are defined, so the names
# imported elsewhere resolve to the TCP versions on Windows.
_USE_TCP = (os.name == "nt") or (os.environ.get("STD_T98_IPC", "").lower() == "tcp")


_TEMPORARY_SEND_ERRNOS = {
    errno.EAGAIN,
    getattr(errno, "EWOULDBLOCK", errno.EAGAIN),
    getattr(errno, "ENOBUFS", errno.EAGAIN),
    errno.EINTR,
}


def _is_temporary_send_error(exc: OSError) -> bool:
    return exc.errno in _TEMPORARY_SEND_ERRNOS


def _is_temporary_recv_error(exc: OSError) -> bool:
    return exc.errno in _TEMPORARY_SEND_ERRNOS


def _validate_packet_send(sent: int, payload: bytes) -> int:
    if sent != len(payload):
        raise OSError(errno.EPIPE, "partial packet send")
    return sent


# Socket location. /tmp is world-writable and shared between users, so two
# people running this on the same machine collide on the same paths and a stale
# socket from a dead run is left for anyone to replace. XDG_RUNTIME_DIR is the
# per-user, 0700, auto-cleaned directory meant for exactly this, so prefer it
# and keep /tmp only as the fallback for environments that do not set it.
RUNTIME_DIR_ENV_VAR = "STD_T98_RUNTIME_DIR"
_RUNTIME_SUBDIR = "std-t98"
_FALLBACK_SOCKET_DIR = "/tmp"

# AF_UNIX paths are capped by sun_path (108 bytes on Linux, minus the NUL).
# A long XDG_RUNTIME_DIR would otherwise fail at bind() with a bad error.
_MAX_UNIX_SOCKET_PATH_LEN = 107


def socket_dir() -> str:
    """Directory the default socket paths live in."""
    override = os.environ.get(RUNTIME_DIR_ENV_VAR)
    if override:
        return override

    runtime_dir = os.environ.get("XDG_RUNTIME_DIR")
    if runtime_dir and os.path.isdir(runtime_dir):
        return os.path.join(runtime_dir, _RUNTIME_SUBDIR)

    return _FALLBACK_SOCKET_DIR


def _default_socket_path(env_var: str, basename: str) -> str:
    """Resolve one socket path: explicit env var, else the runtime directory."""
    override = os.environ.get(env_var)
    if override:
        return override

    path = os.path.join(socket_dir(), basename)
    if len(path.encode("utf-8")) > _MAX_UNIX_SOCKET_PATH_LEN:
        return os.path.join(_FALLBACK_SOCKET_DIR, basename)
    return path


DEFAULT_MULTI_FRAME_SOCKET_PATH = _default_socket_path(
    "STD_T98_MULTI_FRAME_SOCKET", "std_t98_multi_frame.sock"
)
DEFAULT_MULTI_VOICE_SOCKET_PATH = _default_socket_path(
    "STD_T98_MULTI_VOICE_SOCKET", "std_t98_multi_voice.sock"
)
DEFAULT_MULTI_STATUS_SOCKET_PATH = _default_socket_path(
    "STD_T98_MULTI_STATUS_SOCKET", "std_t98_multi_status.sock"
)
DEFAULT_MULTI_SECRET_REQUEST_SOCKET_PATH = _default_socket_path(
    "STD_T98_MULTI_SECRET_REQUEST_SOCKET", "std_t98_multi_secret_request.sock"
)
DEFAULT_MULTI_SECRET_RESULT_SOCKET_PATH = _default_socket_path(
    "STD_T98_MULTI_SECRET_RESULT_SOCKET", "std_t98_multi_secret_result.sock"
)
DEFAULT_MULTI_CONTROL_SOCKET_PATH = _default_socket_path(
    "STD_T98_MULTI_CONTROL_SOCKET", "std_t98_multi_control.sock"
)


def resolve_frame_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_FRAME_SOCKET_PATH


def resolve_voice_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_VOICE_SOCKET_PATH


def resolve_status_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_STATUS_SOCKET_PATH


def resolve_secret_request_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_SECRET_REQUEST_SOCKET_PATH


def resolve_secret_result_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_SECRET_RESULT_SOCKET_PATH


def resolve_control_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_CONTROL_SOCKET_PATH


class UdsSeqpacketServer:
    def __init__(self, socket_path, backlog=1):
        self.socket_path = socket_path
        self.listener = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        self.listener.setblocking(False)
        self.client = None

        parent = os.path.dirname(self.socket_path)
        if parent:
            os.makedirs(parent, mode=0o700, exist_ok=True)

        if os.path.exists(self.socket_path):
            os.unlink(self.socket_path)

        self.listener.bind(self.socket_path)
        self.listener.listen(backlog)

    def _accept_client(self):
        if self.client is not None:
            return True

        try:
            client, _ = self.listener.accept()
        except BlockingIOError:
            return False

        client.setblocking(False)
        self.client = client
        return True

    def _drop_client(self):
        if self.client is None:
            return
        try:
            self.client.close()
        finally:
            self.client = None

    def send(self, payload: bytes) -> bool:
        if not self._accept_client():
            return False

        try:
            _validate_packet_send(self.client.send(payload), payload)
            return True
        except OSError as exc:
            if _is_temporary_send_error(exc):
                return False
            self._drop_client()
            return False

    def close(self):
        self._drop_client()
        try:
            self.listener.close()
        finally:
            if os.path.exists(self.socket_path):
                os.unlink(self.socket_path)
# (UdsSeqpacketServer continues below in the UDS implementation)


class UdsSeqpacketClient:
    def __init__(self, socket_path, retry_interval=0.25, connect_timeout=None):
        self.socket_path = socket_path
        self.socket = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        self._connect(retry_interval=retry_interval, connect_timeout=connect_timeout)

    def _connect(self, retry_interval, connect_timeout):
        deadline = None if connect_timeout is None else time.monotonic() + connect_timeout
        while True:
            try:
                self.socket.connect(self.socket_path)
                return
            except OSError as exc:
                if deadline is not None and time.monotonic() >= deadline:
                    raise TimeoutError(f"Timed out connecting to {self.socket_path}") from exc
                if exc.errno not in (errno.ENOENT, errno.ECONNREFUSED, errno.EAGAIN):
                    raise
                time.sleep(retry_interval)

    def fileno(self):
        return self.socket.fileno()

    def _send(self, payload: bytes, flags: int = 0) -> int:
        return _validate_packet_send(self.socket.send(payload, flags), payload)

    def send(self, payload: bytes):
        return self._send(payload)

    def try_send(self, payload: bytes) -> bool:
        try:
            self._send(payload, getattr(socket, "MSG_DONTWAIT", 0))
            return True
        except OSError as exc:
            if _is_temporary_send_error(exc):
                return False
            raise

    def recv(self, max_size=65536):
        return self.socket.recv(max_size)

    def try_recv(self, max_size=65536):
        try:
            return self.socket.recv(max_size, getattr(socket, "MSG_DONTWAIT", 0))
        except BlockingIOError:
            return None
        except OSError as exc:
            if _is_temporary_recv_error(exc):
                return None
            raise

    def close(self):
        self.socket.close()


class UdsSeqpacketReceiver:
    def __init__(self, socket_path, backlog=8, max_size=65536):
        self.socket_path = socket_path
        self.max_size = max_size
        self.listener = socket.socket(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        self.listener.setblocking(False)
        self.clients = {}
        self.poller = select.poll()

        parent = os.path.dirname(self.socket_path)
        if parent:
            os.makedirs(parent, mode=0o700, exist_ok=True)

        if os.path.exists(self.socket_path):
            os.unlink(self.socket_path)

        self.listener.bind(self.socket_path)
        self.listener.listen(backlog)
        self.poller.register(self.listener.fileno(), select.POLLIN)

    def _accept_pending_clients(self):
        while True:
            try:
                client, _ = self.listener.accept()
            except BlockingIOError:
                return

            client.setblocking(False)
            fileno = client.fileno()
            self.clients[fileno] = client
            self.poller.register(fileno, select.POLLIN | select.POLLHUP | select.POLLERR | select.POLLNVAL)

    def _drop_client(self, fileno):
        client = self.clients.pop(fileno, None)
        if client is None:
            return

        try:
            self.poller.unregister(fileno)
        except KeyError:
            pass
        finally:
            client.close()

    def recv(self, timeout_ms=None):
        poll_timeout = -1 if timeout_ms is None else timeout_ms

        while True:
            events = self.poller.poll(poll_timeout)
            if not events:
                return None

            poll_timeout = 0
            for fileno, mask in events:
                if fileno == self.listener.fileno():
                    self._accept_pending_clients()
                    continue

                if mask & (select.POLLHUP | select.POLLERR | select.POLLNVAL):
                    self._drop_client(fileno)
                    continue

                client = self.clients.get(fileno)
                if client is None:
                    continue

                try:
                    payload = client.recv(self.max_size)
                except OSError:
                    self._drop_client(fileno)
                    continue

                if not payload:
                    self._drop_client(fileno)
                    continue
                return payload

    def close(self):
        for fileno in list(self.clients):
            self._drop_client(fileno)

        try:
            self.poller.unregister(self.listener.fileno())
        except KeyError:
            pass

        try:
            self.listener.close()
        finally:
            if os.path.exists(self.socket_path):
                os.unlink(self.socket_path)


# --- Windows / STD_T98_IPC=tcp: swap in the TCP-loopback transport ---------
# Done last so these names shadow the UDS definitions above. Every importer of
# this module (``from ipc.transport.uds_seqpacket import ...``) then transparently
# gets the TCP versions, which share the same class names and method contract.
if _USE_TCP:
    from ._tcp import (  # noqa: F401,F811
        DEFAULT_MULTI_CONTROL_SOCKET_PATH,
        DEFAULT_MULTI_FRAME_SOCKET_PATH,
        DEFAULT_MULTI_SECRET_REQUEST_SOCKET_PATH,
        DEFAULT_MULTI_SECRET_RESULT_SOCKET_PATH,
        DEFAULT_MULTI_STATUS_SOCKET_PATH,
        DEFAULT_MULTI_VOICE_SOCKET_PATH,
        UdsSeqpacketClient,
        UdsSeqpacketReceiver,
        UdsSeqpacketServer,
        resolve_control_socket_path,
        resolve_frame_socket_path,
        resolve_secret_request_socket_path,
        resolve_secret_result_socket_path,
        resolve_status_socket_path,
        resolve_voice_socket_path,
        socket_dir,
    )
