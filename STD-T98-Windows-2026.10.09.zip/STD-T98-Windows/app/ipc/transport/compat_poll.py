"""Cross-platform stand-in for ``select.poll`` over socket file descriptors.

Windows has no ``select.poll``; it does have ``select.select``, which works on
sockets. The services here only ever poll a handful of socket fds for
readability, so this thin wrapper reproduces the small slice of the poll API
they use (``register`` / ``unregister`` / ``poll`` returning ``[(fd, revents)]``)
on top of ``select.select``. It behaves identically on Linux and Windows.
"""

import select


POLLIN = getattr(select, "POLLIN", 0x001)


class Poller:
    def __init__(self):
        self._fds = {}

    def register(self, fd, eventmask=POLLIN):
        self._fds[int(fd)] = eventmask

    def unregister(self, fd):
        self._fds.pop(int(fd), None)

    def poll(self, timeout_ms=None):
        """Return ``[(fd, revents)]`` for readable (or errored) fds."""
        timeout = None if timeout_ms is None else max(0.0, timeout_ms / 1000.0)
        fds = list(self._fds)
        if not fds:
            # Nothing registered: honour the timeout like poll() would.
            if timeout:
                import time
                time.sleep(timeout)
            return []
        try:
            readable, _, errored = select.select(fds, [], fds, timeout)
        except (OSError, ValueError):
            # A closed/invalid fd makes select raise; report all as readable so
            # the caller attempts a recv and discovers the broken socket itself.
            return [(fd, POLLIN) for fd in fds]
        events = {}
        for fd in readable:
            events[fd] = events.get(fd, 0) | POLLIN
        for fd in errored:
            events[fd] = events.get(fd, 0) | POLLIN
        return list(events.items())


def make_poller():
    return Poller()
