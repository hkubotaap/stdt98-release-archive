"""Cross-platform (Windows-friendly) loopback transport.

The project's native IPC uses ``AF_UNIX`` + ``SOCK_SEQPACKET`` (see
``uds_seqpacket``), which is Linux-only and also relies on ``select.poll``.
Windows has neither reliably, so this module provides a drop-in replacement
with the *same class names and method contract* built on ordinary TCP loopback
sockets plus a 4-byte length prefix to restore the message boundaries that
SEQPACKET gave for free.

``uds_seqpacket`` re-exports these classes on Windows (or when
``STD_T98_IPC=tcp``), so every existing ``from ipc.transport.uds_seqpacket
import ...`` site keeps working unchanged on both platforms.

Endpoints are written as ``host:port`` strings in place of a filesystem path.
A plain integer is accepted as a port on 127.0.0.1, and a path-like string
(e.g. a leftover ``*.sock`` default) is hashed to a stable private port so
that two processes handed the same string still agree on where to meet.
"""

import errno
import hashlib
import os
import select
import socket
import time
from collections import deque


# A single framed message is capped so a corrupt length prefix cannot make us
# allocate unbounded memory. 64 MiB is far above any real FramePacket/voice
# burst (the UDS path capped recv at 64 KiB).
_MAX_MESSAGE_BYTES = 64 * 1024 * 1024
# How much unsent data a push server buffers before it gives up on a stalled
# consumer and drops it (mirrors SEQPACKET's ENOBUFS backpressure).
_MAX_SEND_BACKLOG = 8 * 1024 * 1024
_LOOPBACK_HOST = "127.0.0.1"


# ---------------------------------------------------------------------------
# Endpoint resolution (host:port in place of a socket path)
# ---------------------------------------------------------------------------

# Fixed, human-readable default ports. Deterministic so independent processes
# agree without the launcher having to pass anything.
_DEFAULT_PORTS = {
    "frame": 48811,
    "voice": 48812,
    "status": 48813,
    "secret_request": 48814,
    "secret_result": 48815,
    "control": 48816,
}


def _port_from_name(name: str) -> int:
    """Deterministically map an arbitrary string to a private-range port."""
    digest = hashlib.sha1(name.encode("utf-8")).digest()
    return 49152 + (int.from_bytes(digest[:2], "big") % (65535 - 49152 + 1))


def parse_endpoint(endpoint) -> tuple:
    """Return ``(host, port)`` for an endpoint string/int.

    Accepts ``"host:port"``, ``"port"``, a bare int, or a path-like string
    (hashed to a stable port).
    """
    if isinstance(endpoint, tuple):
        return endpoint
    if isinstance(endpoint, int):
        return (_LOOPBACK_HOST, endpoint)
    text = str(endpoint)
    if ":" in text:
        host, _, port = text.rpartition(":")
        if port.isdigit():
            return (host or _LOOPBACK_HOST, int(port))
    if text.isdigit():
        return (_LOOPBACK_HOST, int(text))
    return (_LOOPBACK_HOST, _port_from_name(os.path.basename(text) or text))


def socket_dir() -> str:
    """Kept for API parity with the UDS module; meaningless for TCP."""
    return os.environ.get("STD_T98_RUNTIME_DIR", "")


def _default_endpoint(env_var: str, key: str) -> str:
    override = os.environ.get(env_var)
    if override:
        return override
    return f"{_LOOPBACK_HOST}:{_DEFAULT_PORTS[key]}"


DEFAULT_MULTI_FRAME_SOCKET_PATH = _default_endpoint("STD_T98_MULTI_FRAME_SOCKET", "frame")
DEFAULT_MULTI_VOICE_SOCKET_PATH = _default_endpoint("STD_T98_MULTI_VOICE_SOCKET", "voice")
DEFAULT_MULTI_STATUS_SOCKET_PATH = _default_endpoint("STD_T98_MULTI_STATUS_SOCKET", "status")
DEFAULT_MULTI_SECRET_REQUEST_SOCKET_PATH = _default_endpoint(
    "STD_T98_MULTI_SECRET_REQUEST_SOCKET", "secret_request"
)
DEFAULT_MULTI_SECRET_RESULT_SOCKET_PATH = _default_endpoint(
    "STD_T98_MULTI_SECRET_RESULT_SOCKET", "secret_result"
)
DEFAULT_MULTI_CONTROL_SOCKET_PATH = _default_endpoint("STD_T98_MULTI_CONTROL_SOCKET", "control")


def resolve_frame_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_FRAME_SOCKET_PATH


def resolve_voice_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_VOICE_SOCKET_PATH


def resolve_status_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_STATUS_SOCKET_PATH


def resolve_secret_request_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_SECRET_REQUEST_SOCKET_PATH


def resolve_secret_result_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_SECRET_RESULT_SOCKET_PATH


def resolve_control_socket_path(channel_count=1, socket_path=None):
    del channel_count
    return socket_path or DEFAULT_MULTI_CONTROL_SOCKET_PATH


# ---------------------------------------------------------------------------
# Framing helpers
# ---------------------------------------------------------------------------

def _frame(payload: bytes) -> bytes:
    if len(payload) > _MAX_MESSAGE_BYTES:
        raise OSError(errno.EMSGSIZE, "message too large")
    return len(payload).to_bytes(4, "big") + payload


def _pop_message(buf: bytearray):
    """Pop one complete framed message from ``buf``; return bytes or None."""
    if len(buf) < 4:
        return None
    length = int.from_bytes(buf[:4], "big")
    if length > _MAX_MESSAGE_BYTES:
        raise OSError(errno.EMSGSIZE, "framed message too large")
    if len(buf) < 4 + length:
        return None
    message = bytes(buf[4:4 + length])
    del buf[:4 + length]
    return message


def _listen(endpoint, backlog):
    host, port = parse_endpoint(endpoint)
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    exclusive = getattr(socket, "SO_EXCLUSIVEADDRUSE", None)
    if exclusive is not None:
        # Windows: SO_REUSEADDR lets a second process bind a port that a live
        # one still holds, and connections keep going to the old one. A
        # leftover secret service from an earlier session silently swallowed
        # every key result that way. Claim the port exclusively instead.
        listener.setsockopt(socket.SOL_SOCKET, exclusive, 1)
    else:
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listener.bind((host, port))
    except OSError as exc:
        listener.close()
        raise OSError(exc.errno, f"IPC port {host}:{port} is already in use by another process "
                                 f"(a receiver service from an earlier session may still be running): {exc}") from exc
    listener.listen(backlog)
    listener.setblocking(False)
    return listener


def _is_would_block(exc: OSError) -> bool:
    return isinstance(exc, BlockingIOError) or exc.errno in (
        errno.EAGAIN,
        getattr(errno, "EWOULDBLOCK", errno.EAGAIN),
    )


# ---------------------------------------------------------------------------
# Server: single consumer, best-effort non-blocking push (sender side)
# ---------------------------------------------------------------------------

class UdsSeqpacketServer:
    def __init__(self, socket_path, backlog=1):
        self.socket_path = socket_path
        self.listener = _listen(socket_path, backlog)
        self.client = None
        self._sendbuf = bytearray()

    def _accept_client(self):
        if self.client is not None:
            return True
        try:
            client, _ = self.listener.accept()
        except (BlockingIOError, OSError):
            return False
        client.setblocking(False)
        client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.client = client
        self._sendbuf = bytearray()
        return True

    def _drop_client(self):
        if self.client is None:
            return
        try:
            self.client.close()
        finally:
            self.client = None
            self._sendbuf = bytearray()

    def _flush(self) -> bool:
        while self._sendbuf:
            try:
                sent = self.client.send(self._sendbuf)
            except OSError as exc:
                if _is_would_block(exc):
                    return True       # try again on the next send()
                self._drop_client()
                return False
            if sent <= 0:
                self._drop_client()
                return False
            del self._sendbuf[:sent]
        return True

    def send(self, payload: bytes) -> bool:
        if not self._accept_client():
            return False
        self._sendbuf += _frame(payload)
        if len(self._sendbuf) > _MAX_SEND_BACKLOG:
            # Consumer cannot keep up; drop it like SEQPACKET would drop packets.
            self._drop_client()
            return False
        return self._flush()

    def close(self):
        self._drop_client()
        try:
            self.listener.close()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Client: connect, send/recv framed messages
# ---------------------------------------------------------------------------

class UdsSeqpacketClient:
    def __init__(self, socket_path, retry_interval=0.25, connect_timeout=None):
        self.socket_path = socket_path
        self._endpoint = parse_endpoint(socket_path)
        self.socket = None
        self._recvbuf = bytearray()
        self._connect(retry_interval=retry_interval, connect_timeout=connect_timeout)

    def _connect(self, retry_interval, connect_timeout):
        deadline = None if connect_timeout is None else time.monotonic() + connect_timeout
        while True:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.connect(self._endpoint)
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                sock.setblocking(False)
                self.socket = sock
                return
            except OSError as exc:
                sock.close()
                if deadline is not None and time.monotonic() >= deadline:
                    raise TimeoutError(
                        f"Timed out connecting to {self.socket_path}"
                    ) from exc
                time.sleep(retry_interval)

    def fileno(self):
        return self.socket.fileno()

    # -- send ---------------------------------------------------------------
    def _sendall(self, frame: bytes):
        view = memoryview(frame)
        while view:
            try:
                sent = self.socket.send(view)
                view = view[sent:]
            except OSError as exc:
                if _is_would_block(exc):
                    select.select([], [self.socket], [], None)
                    continue
                raise

    def send(self, payload: bytes):
        self._sendall(_frame(payload))
        return len(payload)

    def try_send(self, payload: bytes) -> bool:
        _, writable, _ = select.select([], [self.socket], [], 0)
        if not writable:
            return False
        self._sendall(_frame(payload))
        return True

    # -- recv ---------------------------------------------------------------
    def _fill_once(self, block: bool) -> bool:
        """Read some bytes into the buffer. Return False on clean close."""
        if block:
            select.select([self.socket], [], [], None)
        try:
            chunk = self.socket.recv(65536)
        except OSError as exc:
            if _is_would_block(exc):
                return True
            raise
        if not chunk:
            raise ConnectionError("peer closed")
        self._recvbuf += chunk
        return True

    def recv(self, max_size=65536):
        del max_size
        while True:
            message = _pop_message(self._recvbuf)
            if message is not None:
                return message
            self._fill_once(block=True)

    def try_recv(self, max_size=65536):
        del max_size
        message = _pop_message(self._recvbuf)
        if message is not None:
            return message
        readable, _, _ = select.select([self.socket], [], [], 0)
        if not readable:
            return None
        try:
            self._fill_once(block=False)
        except ConnectionError:
            return None
        return _pop_message(self._recvbuf)

    def close(self):
        if self.socket is not None:
            self.socket.close()
            self.socket = None


# ---------------------------------------------------------------------------
# Receiver: many producers connect in, we pull one message at a time
# ---------------------------------------------------------------------------

class UdsSeqpacketReceiver:
    def __init__(self, socket_path, backlog=8, max_size=65536):
        self.socket_path = socket_path
        self.max_size = max_size
        self.listener = _listen(socket_path, backlog)
        self.clients = {}          # fileno -> socket
        self._buffers = {}         # fileno -> bytearray
        self._ready = deque()

    def _accept_pending(self):
        while True:
            try:
                client, _ = self.listener.accept()
            except (BlockingIOError, OSError):
                return
            client.setblocking(False)
            fileno = client.fileno()
            self.clients[fileno] = client
            self._buffers[fileno] = bytearray()

    def _drop_client(self, fileno):
        client = self.clients.pop(fileno, None)
        self._buffers.pop(fileno, None)
        if client is not None:
            client.close()

    def _drain_client(self, fileno):
        client = self.clients.get(fileno)
        if client is None:
            return
        try:
            chunk = client.recv(65536)
        except OSError as exc:
            if _is_would_block(exc):
                return
            self._drop_client(fileno)
            return
        if not chunk:
            self._drop_client(fileno)
            return
        buf = self._buffers[fileno]
        buf += chunk
        while True:
            try:
                message = _pop_message(buf)
            except OSError:
                self._drop_client(fileno)
                return
            if message is None:
                break
            self._ready.append(message)

    def recv(self, timeout_ms=None):
        if self._ready:
            return self._ready.popleft()

        deadline = None if timeout_ms is None else time.monotonic() + timeout_ms / 1000.0
        while True:
            if timeout_ms is None:
                timeout = None
            else:
                timeout = max(0.0, deadline - time.monotonic())
            rlist = [self.listener] + list(self.clients.values())
            readable, _, _ = select.select(rlist, [], [], timeout)
            if not readable:
                return None
            for sock in readable:
                if sock is self.listener:
                    self._accept_pending()
                else:
                    self._drain_client(sock.fileno())
            if self._ready:
                return self._ready.popleft()
            if timeout_ms is not None and deadline - time.monotonic() <= 0:
                return None

    def close(self):
        for fileno in list(self.clients):
            self._drop_client(fileno)
        try:
            self.listener.close()
        except OSError:
            pass
