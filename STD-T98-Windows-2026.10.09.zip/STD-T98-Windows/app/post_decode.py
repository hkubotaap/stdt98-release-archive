"""
交信終了後に別プロセスで走る「秘話生録音 → 復号WAV」ポストデコーダ。

SDR# プラグイン(Std98)は、秘話の有無に関係なく各トラフィックフレームの生
AMBE ペイロード(payload9 x4)を <freq>_<time>.t98raw にそのまま保存する。
descramble も vocoder もかけていないので、録音時点で鍵を知っている必要はない。

このスクリプトは交信終了時にプラグインから 1 回起動され:
  1. .t98raw を読む(header + payload9 の並び)
  2. 鍵を決める
       --key K (>0)         : 既知鍵。まず検証し、外れていれば探索へ回す
       plaintext(秘話OFF)  : 鍵不要 → decode_3600
       上記以外             : SecretCracker で 32767 鍵探索
  3. 復号
       鍵あり : descramble_burst → decode_2450
       平文   : decode_3600
  4. 8kHz mono WAV を保存

鍵が見つからなければ WAV は書かず、.t98raw はそのまま残す(後で手動再試行できる)。

reuse: tallcat4/std-t98-tools(gr_port/)の protocol/crypto と 独自AMBE+2(app/vendor/ambe2)。
プラグインの Secret.cs / Ambe.cs はここと同じ処理の C# 移植。
"""
import argparse
import csv
import os
import struct
import sys
import wave as wavemod

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np

from core.crypto.pn_sequence import generate_pn_sequence_196
from core.crypto.secret_voice import descramble_burst
from core.audio.ambe_adapter import fec_demod_to_2450_payload
from core.audio.data_paths import resolve_data_dir

MAGIC_V1 = b"T98RAW01"   # CSM 欄なし(旧)
MAGIC_V2 = b"T98RAW02"   # 32:16B に CSM
MAGIC_V3 = b"T98RAW03"   # +48:1B 秘話フラグ(0=不明/1=平文/2=秘話, SACCH通話識別由来)
BURST_BYTES = 28  # 4 x 7-byte AMBE2450 packed frame (SecretCracker input unit)

FFNN_MODEL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "secret_voice", "ambe2_ffnn.onnx")
HYBRID_MODEL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "secret_voice", "ambe2_hybrid.onnx")

# 人間が確定した「本当に秘話で、鍵はこれ」という周波数だけを列挙する authoritative な
# 鍵ファイル。プラグインは触らない(①のML誤学習で汚染される keys.csv とは別物)。
# ここに載っていない周波数はすべて平文(decode_3600)として復号する。
# 形式: 各行 "freq_hz,key"  (# で始まる行と空行は無視)
MANUAL_KEYS_CSV = os.path.join(resolve_data_dir(os.environ.get("STD_T98_DATA_DIR"), os.path.dirname(os.path.abspath(__file__))), "manual_keys.csv")


def log(msg):
    print(f"[post_decode] {msg}", file=sys.stderr, flush=True)


def load_manual_keys():
    """(by_csm, by_freq) を返す。行形式: csm,freq_hz,key
      - csm 記入 → その局(CSM)に鍵を紐付け(局は周波数を跨いでも同じ鍵なので最優先)
      - csm 空欄 → freq_hz で照合(CSM が取れない録音でも効く=互換)
    ヘッダ/空行/# 行は無視。key<=0 は無視。"""
    by_csm, by_freq = {}, {}
    try:
        with open(MANUAL_KEYS_CSV, encoding="utf-8-sig", newline="") as f:
            for row in csv.reader(f):
                if not row or row[0].strip().startswith(("#", "csm")):
                    continue
                cells = [c.strip() for c in row]
                csm = cells[0] if len(cells) > 0 else ""
                freq = cells[1] if len(cells) > 1 else ""
                key = cells[2] if len(cells) > 2 else ""
                try:
                    k = int(key)
                except ValueError:
                    continue
                if k <= 0:
                    continue
                if csm:
                    by_csm[csm] = k
                if freq:
                    try:
                        by_freq[int(freq)] = k
                    except ValueError:
                        pass
    except FileNotFoundError:
        pass
    except Exception:
        pass
    return by_csm, by_freq


def read_raw(path):
    """Return (freq_hz, frames, csm, secret). frames = list of [payload9 x N] (bytes)。
    csm は v02/v03 のヘッダから(未取得/旧 v01 は "")。
    secret は v03 のヘッダから: True=秘話 / False=平文 / None=不明(旧 v01/v02 または未確定)。
    SACCH の通話識別由来なので、ML に頼らず鍵要否を決められる。"""
    with open(path, "rb") as f:
        data = f.read()
    magic = data[:8]
    if magic == MAGIC_V3:
        header_len = 52
    elif magic == MAGIC_V2:
        header_len = 48
    elif magic == MAGIC_V1:
        header_len = 32
    else:
        raise ValueError("not a T98RAW file (bad magic)")
    if len(data) < header_len:
        raise ValueError("truncated header")

    freq_hz = struct.unpack_from("<q", data, 8)[0]
    blocks_per_frame = struct.unpack_from("<I", data, 24)[0]
    payload_bytes = struct.unpack_from("<I", data, 28)[0]
    if payload_bytes != 9 or blocks_per_frame < 1:
        raise ValueError(f"unexpected layout: {blocks_per_frame}x{payload_bytes}")

    csm = ""
    if magic in (MAGIC_V2, MAGIC_V3):
        csm = data[32:48].split(b"\x00")[0].decode("utf-8", "ignore").strip()

    secret = None
    if magic == MAGIC_V3:
        flag = data[48]
        secret = True if flag == 2 else False if flag == 1 else None

    body = data[header_len:]
    frame_bytes = blocks_per_frame * payload_bytes
    n_frames = len(body) // frame_bytes
    frames = []
    for fi in range(n_frames):
        base = fi * frame_bytes
        blocks = [body[base + bi * 9: base + bi * 9 + 9] for bi in range(blocks_per_frame)]
        frames.append(blocks)
    return freq_hz, frames, csm, secret


def build_burst_payload(frames):
    """Concatenated 28-byte AMBE2450 bursts for SecretCracker (4x packed7 per frame)."""
    out = bytearray()
    for blocks in frames:
        for payload9 in blocks:
            out.extend(fec_demod_to_2450_payload(payload9))  # 7 bytes each
    return bytes(out)


# 鍵決定は「既知鍵 > 平文判定 > (明示時のみ)探索」の順。既知鍵は決して ML 探索で
# 上書きしない -- 複数の誤った鍵がどれも音声っぽい出力を作り、探索/有声率では真の鍵を
# 選べないことが実データで判明したため(①でライブ確認した鍵を尊重する)。

def detect_plaintext(frames):
    """秘話 OFF(平文)なら True。hybrid モデルの平文/秘話 判別は信頼できるので、
    鍵未知でも「平文なら decode_3600 で復号、秘話なら保留」の判断に使う。"""
    burst_payload = build_burst_payload(frames)
    burst_count = len(frames)
    if burst_count < 5:
        return False
    from core.secret.onnx_cracker import SecretCracker, _payload_to_blocks, LABEL_PLAIN
    cracker = SecretCracker(ffnn_model_path=FFNN_MODEL, hybrid_model_path=HYBRID_MODEL)
    blocks = _payload_to_blocks(burst_payload, burst_count)
    if not blocks:
        return False
    logits = cracker._hybrid_logits(blocks[0].reshape(1, -1).astype(np.float32))[0]
    return int(np.argmax(logits)) == LABEL_PLAIN


def search_key(frames):
    raise RuntimeError("Privacy-key analysis is disabled in this distribution")


def is_voice(pcm, min_active=5, active_rel=0.20, voiced_zcr=0.18, voiced_floor=0.15):
    """復号結果が実際に了解可能な音声か(=復号成功か)を判定する品質ゲート。

    正しい鍵/平文なら AMBE 復号は準周期的な有声音声(高エネルギ・低ゼロ交差率)に
    なるが、鍵違い/秘話ON無鍵だとノイズ状(有声フレームがほぼ無い)になる。
    プラグインの Std98Decoder の 秘話推定器(AnalyzeVoiceFrame/EvaluateSecret)と
    同じ指標。これを満たさなければ「復号できなかった」とみなし WAV を書かない。
    """
    a = np.asarray(pcm, dtype=np.float64)
    n = len(a) // 160
    if n == 0:
        return False
    rms = np.empty(n)
    zcr = np.empty(n)
    for i in range(n):
        f = a[i * 160:(i + 1) * 160]
        rms[i] = np.sqrt(np.mean(f * f))
        zcr[i] = np.count_nonzero(np.diff(np.signbit(f))) / len(f)
    mx = rms.max()
    if mx <= 0:
        return False
    active = rms > mx * active_rel
    na = int(active.sum())
    if na < min_active:
        return False
    voiced = int(np.count_nonzero(active & (zcr < voiced_zcr)))
    return (voiced / na) >= voiced_floor


class IndependentCodec:
    """独自AMBE+2 (core/audio/independent_ambe.py) で frames を順に復号する。
    反復/ミュートの状態を持つので、1 つの録音は 1 つのインスタンスで先頭から順に渡す
    (チャンクに分けても状態を引き継ぐ)。誤りの程度は受信した 72bit から判定する。"""

    def __init__(self):
        from core.audio.independent_ambe import IndependentAmbe
        self.engine = IndependentAmbe()

    def decode(self, frames, key, metas=None):
        """metas にリストを渡すと、20ms ごとの復号メタデータ(action, b など)を追記する。"""
        pcm = []
        if key and key > 0:
            pn196 = generate_pn_sequence_196(key)
            for blocks in frames:
                packed7 = [fec_demod_to_2450_payload(p9) for p9 in blocks]
                for d7, p9 in zip(descramble_burst(packed7, pn196), blocks):
                    pcm.extend(self.engine.decode_info(d7, p9)[0].tolist())
                    if metas is not None:
                        metas.append(self.engine.last_meta)
        else:
            for blocks in frames:
                for payload9 in blocks:
                    pcm.extend(self.engine.decode_raw(payload9)[0].tolist())
                    if metas is not None:
                        metas.append(self.engine.last_meta)
        return pcm


def pitch_continuity(metas, max_step=3):
    """声らしさ: 隣り合う有声(VOICE)フレームのピッチ index b0 の差が max_step 以下の割合。
    本物の音声はピッチがなめらかに変わり、誤った鍵で解いたパラメータはランダムに飛ぶ
    (秘話8録音・鍵2種で、正しい鍵 0.55..0.71 / 誤った鍵 平均0.06・最大0.33)。
    返り値 (割合, 比較したフレーム対の数)。対が無ければ (0.0, 0)。"""
    pairs = [(a["b"][0], b["b"][0]) for a, b in zip(metas, metas[1:])
             if a and b and a.get("action") == "VOICE" and b.get("action") == "VOICE"]
    if not pairs:
        return 0.0, 0
    return sum(abs(x - y) <= max_step for x, y in pairs) / len(pairs), len(pairs)


def decode_to_pcm(frames, key, codec=None):
    """frames を PCM(8kHz) に復号する。独自AMBE+2デコーダを使う。
    codec を省略すると 1 回分の復号器を新しく作る(先頭から順に処理する前提)。"""
    return (codec or IndependentCodec()).decode(frames, key)


# --- 出力ファイル名: <raw基名>_ch<公式番号>_<plain|keyN>.wav ---
# デジ簡登録局の公式チャンネル番号は「周波数順の連番ではない」。総務省/実機の割当:
#   3R 地上 ch1-30 : 351.20000〜351.38125
#   3T 地上 ch31-70: 351.38750〜351.63125,  ch71-82: 351.03125〜351.10000(下側へ折返し)
#   3S 上空 ch1-5  : 351.16875〜351.19375
#   3U 上空 ch6-15 : 351.10625〜351.16250
# 出典: airband-japan / 総務省 令和5年改正(2023-06-01)97ch化。
# 地上(3R/3T)は番号一意なので "ch<n>"、上空(3S/3U)は 3R と番号が衝突するので "ch<n>上空"。
_CH_STEP = 6_250


def _build_dcr_channel_map():
    m = {}

    def put(base_hz, start_ch, count, air):
        for i in range(count):
            m[base_hz + i * _CH_STEP] = (start_ch + i, air)

    put(351_200_000, 1, 30, False)   # 3R 地上 ch1-30
    put(351_387_500, 31, 40, False)  # 3T 地上 ch31-70
    put(351_031_250, 71, 12, False)  # 3T 地上 ch71-82 (下側折返し)
    put(351_168_750, 1, 5, True)     # 3S 上空 ch1-5
    put(351_106_250, 6, 10, True)    # 3U 上空 ch6-15
    return m


_DCR_CH_MAP = _build_dcr_channel_map()


def channel_label(freq_hz):
    freq_hz = int(freq_hz)
    ent = _DCR_CH_MAP.get(freq_hz)          # 登録局 351MHz(非連番)
    if ent is not None:
        n, air = ent
        return f"ch{n}a" if air else f"ch{n}"
    # 免許局467 467.00000〜467.40000, 6.25kHz連番 ch1..65
    d = freq_hz - 467_000_000
    if 0 <= d and d % _CH_STEP == 0:
        i = d // _CH_STEP
        if i < 65:
            return f"ch{i + 1}"
    # 免許局154 154.44375起点, ch1..19(音声) / D1..9(データ)
    d2 = freq_hz - 154_443_750
    if 0 <= d2 and d2 % _CH_STEP == 0:
        i = d2 // _CH_STEP
        if i < 28:
            return f"ch{i + 1}" if i < 19 else f"D{i - 18}"
    return "chNA"   # a = 上空(aerial)。地上は番号のみ


def key_label(key):
    return "plain" if not key or key <= 0 else f"key{key}"


def day_sub_from_name(name):
    """"yyyyMMdd_..." というファイル名 → 日付サブフォルダ名 "yyyy-MM-dd"。取れなければ None。"""
    b = os.path.basename(name)
    return f"{b[0:4]}-{b[4:6]}-{b[6:8]}" if len(b) >= 8 and b[:8].isdigit() else None


def rec_dir_for(raw_path, rec_dir):
    """raw の日付サブフォルダに対応する rec 出力先(無ければ作成)。日付が取れない旧名は
    rec 直下。録音が増えても 1 フォルダを小さく保つための整理(日付別)。"""
    sub = day_sub_from_name(raw_path)
    d = os.path.join(rec_dir, sub) if sub else rec_dir
    os.makedirs(d, exist_ok=True)
    return d


def decoded_name(raw_path, freq_hz, key):
    base = os.path.splitext(os.path.basename(raw_path))[0]
    return f"{base}_{channel_label(freq_hz)}_{key_label(key)}.wav"


def write_wav(pcm, out_wav, sample_rate=8000):
    pcm_arr = np.array(pcm, dtype=np.int16)
    with wavemod.open(out_wav, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm_arr.tobytes())


# Exit / return codes (shared with redecode.py and the C# launcher):
#   0 = decoded to intelligible voice, WAV written
#   1 = error / no frames
#   2 = could not decode to voice (wrong/unknown key, or noise) -> NO WAV written,
#       the .t98raw is left in place so a later key can decode it retroactively.
def run_decode(raw_path, out_wav, sample_rate=8000, override_key=0, hint_key=0):
    """録音を復号して WAV を書く。鍵の決め方(この順序で、ML は一切使わない):

      1. override_key(--test-key)>0  -> その鍵で強制 descramble(CLIの明示テスト用)
      2. manual_keys.csv に CSM/freq  -> その鍵で descramble(人間が確定=最優先・高速化用)
      3. hint_key(--key)>0 かつ v03秘話フラグ=秘話 -> その鍵(プラグインがライブ確定した鍵)
      4. それ以外                     -> 平文 decode_3600 + is_voice ゲート

    v03ヘッダの秘話フラグ(SACCH通話識別由来)が「平文」なら、どの鍵も捨てて平文で復号する
    (平文にPNをかけてモガモガ音になる事故を防ぐ)。この安全弁があるので、以前は無視していた
    プラグインの --key を安全に採用できる。
    戻り値: 0=WAV書いた / 1=エラー / 2=保留(平文がノイズ=本当に秘話で鍵未登録)。
    """
    freq_hz, frames, csm, secret = read_raw(raw_path)
    log(f"loaded {len(frames)} frames from {raw_path} "
        f"(freq={freq_hz}, csm={csm or '-'}, secret={secret})")
    if not frames:
        log("no frames, nothing to decode")
        return 1

    # 鍵の決定: --test-key(強制) > manual_keys(人間確定・局優先) > --key(プラグインがライブ確定) > 0。
    if override_key and override_key > 0:
        key = override_key
        log(f"forced key (--test-key) -> {key}")
    else:
        by_csm, by_freq = load_manual_keys()
        if csm and csm in by_csm:
            key = by_csm[csm]
            log(f"manual key by CSM {csm} -> {key}")
        elif freq_hz in by_freq:
            key = by_freq[freq_hz]
            log(f"manual key by freq {freq_hz} -> {key}")
        elif hint_key and hint_key > 0 and secret is True:
            # プラグインがライブで確定した鍵。SACCH通話識別で秘話と確定(v03 secret=True)の
            # ときだけ採用するので、平文に鍵をかけるモガモガ事故は起きない。
            key = hint_key
            log(f"plugin key (--key, 秘話確定) -> {key}")
        else:
            key = 0

    # 平文確定(v03 秘話フラグ=平文)なら鍵を捨てて平文で復号(--test-key の強制テストは尊重)。
    if secret is False and key > 0 and not (override_key and override_key > 0):
        log(f"SACCH通話識別=平文 のため鍵{key}を無視して平文で復号")
        key = 0

    # 実際の出力名は復号方式が決まってから組む: <raw基名>_ch<NN>_<plain|keyN>.wav。
    # 呼び出し側が渡した out_wav は「保存先ディレクトリ」としてだけ使う。
    out_dir = os.path.dirname(out_wav) or "."

    if key > 0:
        # 人間が明記した秘話鍵。信頼して descramble、ゲートはかけない。
        log(f"manual/override key {key} -> descramble (trusted, no gate)")
        pcm = decode_to_pcm(frames, key)
        if not pcm:
            return 1
        final = os.path.join(out_dir, decoded_name(raw_path, freq_hz, key))
        write_wav(pcm, final, sample_rate)
        log(f"saved {final}  ({len(pcm) / sample_rate:.2f}s, key={key})")
        return 0

    # 鍵なし。SACCH通話識別(v03ヘッダの secret)が取れていれば ML/有声率に頼らず確定:
    #   secret is True  -> 秘話で鍵未登録。平文化しても壊れるだけなので即保留(raw温存)。
    #   secret is False -> 平文確定。有声率ゲート抜きで無条件に保存(静かな/短い平文も落とさない)。
    #   secret is None  -> 旧録音/未確定。従来どおり 平文復号 + is_voice ゲートで判断。
    if secret is True:
        log("SACCH通話識別=秘話 かつ鍵未登録 -> 保留(manual_keys.csv に鍵を書けば遡及復号)")
        return 2

    pcm = decode_to_pcm(frames, 0)   # decode_3600
    if not pcm:
        return 1
    if secret is None and not is_voice(pcm):
        log("plaintext decode is noise-like -> 本当に秘話で鍵未登録の可能性。保留")
        return 2
    final = os.path.join(out_dir, decoded_name(raw_path, freq_hz, 0))
    write_wav(pcm, final, sample_rate)
    tag = "plaintext" if secret is False else "plaintext(unknown-secret)"
    log(f"saved {final}  ({len(pcm) / sample_rate:.2f}s, {tag})")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True, help="input .t98raw file")
    ap.add_argument("--out", required=True, help="output WAV path")
    # --key は後方互換で受けるが無視する(C# 側が汚染された keys.csv の値を渡してくる
    # ため。descramble 鍵は manual_keys.csv だけを信頼する)。CLI で明示的に鍵を試す
    # ときは --test-key を使う。
    ap.add_argument("--key", type=int, default=0,
                    help="プラグインがライブ確定した鍵(hint)。v03秘話フラグが秘話の時のみ採用、manual_keys優先")
    ap.add_argument("--test-key", type=int, default=0, help="この鍵で強制descramble(CLIテスト用)")
    ap.add_argument("--sample-rate", type=int, default=8000)
    args = ap.parse_args()
    return run_decode(args.raw, args.out, args.sample_rate,
                      override_key=args.test_key, hint_key=args.key)


if __name__ == "__main__":
    sys.exit(main())
