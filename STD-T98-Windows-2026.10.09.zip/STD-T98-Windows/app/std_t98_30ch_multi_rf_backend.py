#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# GNU Radio version: 3.10.12.0

from gnuradio import analog
import math
from gnuradio import blocks
from gnuradio import digital
from gnuradio import filter
from gnuradio import gr
from gnuradio.fft import window
import sys
import signal
from gnuradio.filter import pfb
import std_t98_multi_sync as sync_word_corr  # embedded python block
import threading
import numpy as np

from firdes import make_rx_taps
from core.rf.auto_gain import AutoGainController
from core.rf.hackrf_gain import HackRFGains, HackRFAutoGainController
from core.rf.correct_iq import CorrectIQ
from core.rf.backend_config import BackendConfig, derive_rates
from core.rf.soapy_source import open_source
from core.rf.runtime_budget import limit_rf_cpu

SYNC_BATCH_SYMBOLS = 240  # sync-word correlator call size (100 ms at 2400 baud)
# Wideband chain call size. GNU Radio's default 4096-item buffers cut the
# 800 kS/s stream into ~5 ms pieces, so the channelizer ran ~200 times/s and
# woke all ~600 per-channel threads each time (live 97ch: ~6.6 cores, half of
# it kernel time). 50 ms pieces cut realtime replay CPU 38.9 s -> 25.8 s per
# 20 s with identical frames/CRC/AMBE errors.
WIDEBAND_BATCH_SECONDS = 0.05


class _InputLevelMeter(gr.sync_block):
    """Low-cost, decimated wideband level meter for software gain control."""

    def __init__(self):
        gr.sync_block.__init__(self, name="input_level_meter", in_sig=[np.complex64], out_sig=[])
        self._lock = threading.Lock()
        self._power = 0.0
        self._clipped = 0
        self._count = 0

    def work(self, input_items, output_items):
        samples = input_items[0]
        measured = samples[::16]
        if len(measured):
            power = float(np.sum(np.abs(measured) ** 2, dtype=np.float64))
            clipped = int(np.count_nonzero((np.abs(measured.real) >= 0.98) | (np.abs(measured.imag) >= 0.98)))
            with self._lock:
                self._power += power
                self._clipped += clipped
                self._count += len(measured)
        return len(samples)

    def snapshot(self):
        with self._lock:
            power, clipped, count = self._power, self._clipped, self._count
            self._power = 0.0
            self._clipped = 0
            self._count = 0
        if not count:
            return None
        return 10 * math.log10(max(power / count, 1e-12)), clipped / count


def _make_freq_error_monitor(config, sample_rate, channel_count, correlator, retune=None):
    """Receiver frequency-error estimate for the GUI's calibration field.

    With a ``retune`` callback it can also correct automatically
    (profile ``freq_auto`` / --freq-auto, switchable live).
    """
    from core.pipeline.runtime_status import StatusPublisher
    from core.rf.freq_error import make_monitor
    from ipc.message_schema import STATUS_SOURCE_RF
    from ipc.transport.uds_seqpacket import resolve_status_socket_path
    publisher = StatusPublisher(resolve_status_socket_path(channel_count=channel_count), STATUS_SOURCE_RF)
    return make_monitor(sample_rate, config.channelizer.channel_spacing, channel_count, correlator,
                        publisher, config.sdr.resolved_freq_err_offset(), retune=retune,
                        auto=bool(config.sdr.freq_auto))


def _make_spectrum_tap(config, sample_rate, channel_count):
    """GUI spectrum of the channelizer input (same centre as the streamed IQ)."""
    from core.pipeline.runtime_status import StatusPublisher
    from core.rf.spectrum import make_tap
    from ipc.message_schema import STATUS_SOURCE_RF
    from ipc.transport.uds_seqpacket import resolve_status_socket_path
    publisher = StatusPublisher(resolve_status_socket_path(channel_count=channel_count), STATUS_SOURCE_RF)
    return make_tap(config.sdr.center_freq + config.sdr.freq_offset, sample_rate, publisher)


class test3(gr.top_block):

    def __init__(self, config: BackendConfig | None = None, replay=None, remote_iq=None, correct_iq=True):
        gr.top_block.__init__(self, "Test 3", catch_exceptions=True)
        self.flowgraph_started = threading.Event()
        self._gain_stop = threading.Event()
        self._gain_lock = threading.RLock()
        self._correct_iq = CorrectIQ(correct_iq)

        self.config = config = config or BackendConfig()
        self.rf_cpu_limit = limit_rf_cpu(config.channelizer.num_channels)
        if self.rf_cpu_limit is not None:
            print(f"RF CPU budget: {self.rf_cpu_limit} logical processors", flush=True)
        sdr_cfg = config.sdr
        rates = derive_rates(sdr_cfg, config.channelizer)

        ##################################################
        # 1. SDR / RF Parameters
        ##################################################
        self.rf_samp_rate = rf_samp_rate = sdr_cfg.sample_rate
        self.rf_freq = rf_freq = sdr_cfg.center_freq
        self.freq_offset = freq_offset = sdr_cfg.freq_offset
        self.freq_err_offset = freq_err_offset = sdr_cfg.resolved_freq_err_offset()

        self.sdr_tuner_gain = sdr_tuner_gain = sdr_cfg.tuner_gain
        self.sdr_agc_enabled = sdr_agc_enabled = sdr_cfg.agc
        self.sdr_biastee_enabled = sdr_biastee_enabled = sdr_cfg.bias_tee
        self.sdr_freq_corr = sdr_freq_corr = sdr_cfg.freq_correction

        ##################################################
        # 2. Resampling & Channelization Rates (derived from sample rate)
        ##################################################
        # Stage 1: Initial resampling to the channelizer input rate
        self.resamp1_interp = resamp1_interp = rates.resamp1_interp
        self.resamp1_decim = resamp1_decim = rates.resamp1_decim
        self.samp_rate_post_resamp1 = samp_rate_post_resamp1 = rates.samp_rate_post_resamp1

        # Stage 2: PFB Channelizer
        self.pfb_num_channels = pfb_num_channels = rates.pfb_num_channels
        self.num_channels = num_channels = config.channelizer.num_channels
        self.samp_rate_post_pfb = samp_rate_post_pfb = rates.samp_rate_post_pfb

        # Stage 3: Second Resampling (per channel)
        self.resamp2_interp = resamp2_interp = rates.resamp2_interp
        self.resamp2_decim = resamp2_decim = rates.resamp2_decim
        self.demod_samp_rate = demod_samp_rate = rates.demod_samp_rate

        ##################################################
        # 3. Demodulation Parameters
        ##################################################
        self.fsk_dev = fsk_dev = 315
        self.fm_demod_gain = fm_demod_gain = demod_samp_rate / (2 * math.pi * fsk_dev)
        
        self.squelch_threshold = squelch_threshold = config.demod.squelch_threshold
        self._base_squelch = squelch_threshold
        self._reference_gain = float(sdr_cfg.tuner_gain)
        self._current_gain = self._reference_gain
        self._auto_gain = bool(sdr_cfg.resolved_auto_gain()) and not replay
        self._gain_controller = AutoGainController(self._current_gain)
        self.squelch_alpha = squelch_alpha = config.demod.squelch_alpha

        ##################################################
        # 4. FSK & Timing Sync Parameters
        ##################################################
        self.baud_rate = baud_rate = 2400
        self.sps = sps = demod_samp_rate / baud_rate 
        
        self.excess_bw = excess_bw = 0.2
        self.filter_ntaps_per_sym = filter_ntaps_per_sym = 20
        self.filter_ntaps = filter_ntaps = int(sps) * filter_ntaps_per_sym 

        self.sym_sync_loop_bw = sym_sync_loop_bw = 0.06
        self.sym_sync_damping = sym_sync_damping = 1.1
        self.sym_sync_ted_gain = sym_sync_ted_gain = 0.1
        self.sym_sync_max_dev = sym_sync_max_dev = 0.02
        self.sym_sync_osps = sym_sync_osps = 1
        self.sym_sync_interp = sym_sync_interp = 128

        ##################################################
        # 5. Gains and Miscellaneous
        ##################################################
        self.post_filt_gain = post_filt_gain = 0.23
        self.post_sync_gain = post_sync_gain = 5

        ##################################################
        # 6. PFB Taps Generation
        ##################################################
        pfb_cutoff = samp_rate_post_pfb / 2.0
        pfb_trans_bw = pfb_cutoff * 0.5 
        
        self.pfb_taps = filter.firdes.low_pass_2(
            1.0,
            samp_rate_post_resamp1,
            pfb_cutoff,
            pfb_trans_bw,
            80.0,
            window.WIN_BLACKMAN_HARRIS
        )

        ##################################################
        # 7. Sync Word Correlator Setup
        ##################################################
        self.sync_error_threshold_ratio = sync_error_threshold_ratio = 0.2
        self.sync_packet_len = sync_packet_len = 192

        ##################################################
        # Blocks
        ##################################################
        self.replay = replay
        self.remote_iq = remote_iq
        if remote_iq:
            from core.rf.remote_iq_blocks import IQNetworkSource
            from core.pipeline.runtime_status import StatusPublisher
            from ipc.message_schema import STATUS_SOURCE_RF
            from ipc.transport.uds_seqpacket import resolve_status_socket_path
            publisher = StatusPublisher(resolve_status_socket_path(channel_count=num_channels), STATUS_SOURCE_RF)
            self._remote_source = IQNetworkSource(remote_iq, publisher, getattr(remote_iq, 'endpoint', ''))
        elif replay:
            # A recording from std_t98_record_iq.py is already past stage 1, so
            # it joins the flowgraph at the channelizer. This lets the whole
            # four-process stack be exercised on a machine with no SDR at all,
            # deterministically and as often as needed.
            self.file_source = blocks.file_source(
                gr.sizeof_gr_complex, str(replay), False)
            self.replay_throttle = blocks.throttle(
                gr.sizeof_gr_complex, samp_rate_post_resamp1, True, 0)
        else:
            self._source = open_source(sdr_cfg)
            if self._source.is_hackrf:
                self._reference_gain = self._current_gain = self._source.hackrf_gains.total_db
                self._gain_controller = HackRFAutoGainController(self._source.hackrf_gains)
            if sdr_cfg.agc and self._source.has_agc:
                self._auto_gain = False  # Hardware owns the gain in this mode.
            self._level_meter = _InputLevelMeter()
            self.soapy_source_0 = self._source.source

            # Names kept for anything that reached into the flowgraph before
            # the device handling moved into core.rf.soapy_source.
            self.set_soapy_source_0_gain_mode = self._source.set_gain_mode
            self.set_soapy_source_0_gain = self._source.set_gain
            self.set_soapy_source_0_bias = self._source.set_bias
            self.soapy_rtlsdr_source_0 = self.soapy_source_0

        self.rational_resampler_1 = filter.rational_resampler_ccc(
                interpolation=resamp1_interp,
                decimation=resamp1_decim,
                taps=[],
                fractional_bw=0)
        
        ##################################################
        # PFB Channelizer & Mapping
        ##################################################
        self.pfb_channelizer_ccf_0 = pfb.channelizer_ccf(
            pfb_num_channels,
            self.pfb_taps,
            1.0
        )
        
        # Ports 0..neg-1 -> top FFT bins (negative freqs, CH below centre),
        # port neg -> bin 0 (centre channel), then low positive bins, then the
        # unused bins (attached to null sinks below). Derived from the channel
        # counts so it tracks pfb_num_channels / num_channels automatically.
        self.channel_map = rates.channel_map
        self.pfb_channelizer_ccf_0.set_channel_map(self.channel_map)
        
        ##################################################
        # Per-Channel Blocks
        ##################################################
        self.simple_squelch = [None] * num_channels
        self.rational_resampler_2 = [None] * num_channels
        self.analog_quadrature_demod = [None] * num_channels
        self.dc_blocker = [None] * num_channels
        self.fft_filter = [None] * num_channels
        self.symbol_sync = [None] * num_channels
        
        for ch in range(num_channels):
            self.simple_squelch[ch] = analog.simple_squelch_cc((squelch_threshold), squelch_alpha)
            
            self.rational_resampler_2[ch] = filter.rational_resampler_ccc(
                interpolation=resamp2_interp,
                decimation=resamp2_decim,
                taps=[],
                fractional_bw=0)

            self.analog_quadrature_demod[ch] = analog.quadrature_demod_cf(fm_demod_gain)
            # SDR# removes residual carrier offset before timing/quantization.
            # A small FM DC bias otherwise moves all four symbol levels and
            # corrupts control and voice bits together. Keep enough averaging
            # history to preserve data symbols rather than following each one.
            self.dc_blocker[ch] = filter.dc_blocker_ff(8192, True)

            rx_taps = make_rx_taps(demod_samp_rate, baud_rate, excess_bw, filter_ntaps)
            # Fold the fixed gain into the filter instead of scheduling another
            # block/thread for every channel.
            self.fft_filter[ch] = filter.fft_filter_fff(1, [tap * post_filt_gain for tap in rx_taps], 1)
            self.fft_filter[ch].declare_sample_delay(0)
            
            self.symbol_sync[ch] = digital.symbol_sync_ff(
                digital.TED_GARDNER,
                sps,
                sym_sync_loop_bw,
                sym_sync_damping,
                sym_sync_ted_gain,
                sym_sync_max_dev,
                sym_sync_osps,
                digital.constellation_bpsk().base(),
                digital.IR_MMSE_8TAP,
                sym_sync_interp,[])
                
        # 240 symbols = 100 ms per call: the Python block's per-call cost with
        # 97 inputs dominated its CPU at ~140 calls/s. Frames arrive up to 0.1 s
        # later, well inside the audio service's jitter buffer. The block takes
        # each channel's symbols independently, so channels whose timing loops
        # run at slightly different rates can never stall the flowgraph.
        self.sync_word_corr = sync_word_corr.sync_word_correlator(
            num_channels=num_channels,
            sync_word=None,
            error_threshold_ratio=sync_error_threshold_ratio,
            packet_len=sync_packet_len, input_gain=post_sync_gain,
            batch_symbols=SYNC_BATCH_SYMBOLS)

        ##################################################
        # Connections
        ##################################################
        if self.remote_iq:
            self.connect(self._remote_source, self._correct_iq)
        elif self.replay:
            self.connect((self.file_source, 0), (self.replay_throttle, 0))
            self.connect(self.replay_throttle, self._correct_iq)
        else:
            # No throttle here: the SDR's sample clock already paces the
            # flowgraph, and GNU Radio's throttle is explicitly not meant to
            # share a graph with a hardware source.
            # The former rotator_cc(0.0) here was a 2 MS/s no-op block.
            self.connect((self.soapy_source_0, 0), (self.rational_resampler_1, 0))
            self.connect((self.soapy_source_0, 0), (self._level_meter, 0))
            self.connect(self.rational_resampler_1, self._correct_iq)

        self.connect(self._correct_iq, self.pfb_channelizer_ccf_0)
        self.spectrum_tap = _make_spectrum_tap(config, samp_rate_post_resamp1, num_channels)
        self.connect(self._correct_iq, self.spectrum_tap)
        # A remote IQ client's error belongs to the server's radio and profile.
        self.freq_error_monitor = None
        if not self.remote_iq:
            retune = None if self.replay else self.retune_freq_error
            self.freq_error_monitor = _make_freq_error_monitor(config, samp_rate_post_resamp1, num_channels,
                                                               self.sync_word_corr, retune)
            self.connect(self._correct_iq, self.freq_error_monitor)

        for ch in range(num_channels):
            self.connect((self.pfb_channelizer_ccf_0, ch), (self.simple_squelch[ch], 0))
            self.connect((self.simple_squelch[ch], 0), (self.rational_resampler_2[ch], 0))
            self.connect((self.rational_resampler_2[ch], 0), (self.analog_quadrature_demod[ch], 0))
            self.connect((self.analog_quadrature_demod[ch], 0), (self.dc_blocker[ch], 0))
            self.connect((self.dc_blocker[ch], 0), (self.fft_filter[ch], 0))
            self.connect((self.fft_filter[ch], 0), (self.symbol_sync[ch], 0))
            self.connect((self.symbol_sync[ch], 0), (self.sync_word_corr, ch))

        self.null_sinks = []
        for ch in range(num_channels, pfb_num_channels):
            ns = blocks.null_sink(gr.sizeof_gr_complex)
            self.null_sinks.append(ns)
            self.connect((self.pfb_channelizer_ccf_0, ch), (ns, 0))

        self._batch_wideband(rf_samp_rate, samp_rate_post_resamp1)

    def _batch_wideband(self, input_rate, channelizer_rate):
        """Run the wideband chain and channelizer on WIDEBAND_BATCH_SECONDS pieces.

        Uses output multiples: when input runs short the scheduler halves the
        call size down to 1, ignoring set_min_noutput_items (live, calls of
        8-256 samples were observed with it set).
        """
        per_channel = max(1, int(round(channelizer_rate / self.pfb_num_channels * WIDEBAND_BATCH_SECONDS)))
        wideband = per_channel * self.pfb_num_channels
        if self.remote_iq:
            feeders = [self._remote_source]
        elif self.replay:
            feeders = [self.file_source, self.replay_throttle]
        else:
            # Room for one resampler call's input plus what arrives meanwhile.
            self.soapy_source_0.set_min_output_buffer(2 * int(math.ceil(wideband * input_rate / channelizer_rate)) + 4096)
            # A multiple of the interpolation keeps whole resampler phases.
            wideband = math.lcm(wideband, self.resamp1_interp)
            self.rational_resampler_1.set_output_multiple(wideband)
            feeders = [self.rational_resampler_1]
        iq = self._correct_iq
        for block in feeders + [iq.correction, iq.dc_estimate, iq.scale, iq.output]:
            block.set_min_output_buffer(2 * wideband)
        for block in (self.pfb_channelizer_ccf_0.s2ss, self.pfb_channelizer_ccf_0.pfb):
            block.set_output_multiple(per_channel)
            block.set_min_output_buffer(2 * per_channel)

    def set_squelch_threshold(self, threshold_db):
        """Re-tune every channel's squelch on a running flowgraph.

        analog.simple_squelch_cc supports changing its threshold live (the
        same mechanism GRC range widgets use), so this needs no restart.
        """
        self._base_squelch = float(threshold_db)
        self._apply_squelch()

    def _apply_squelch(self):
        # The user's threshold is clamped to -100..0 dB, but the gain offset is
        # not: after a strong signal cuts the gain by 24 dB the channel noise
        # drops 24 dB too, and holding the threshold at -100 then squelched weak
        # stations for the whole recovery. -100 is not a special "always open"
        # value to simple_squelch, just a level, so lower is fine.
        base = max(-100.0, min(0.0, self._base_squelch))
        threshold_db = min(0.0, base + self._current_gain - self._reference_gain)
        self.squelch_threshold = threshold_db
        for squelch in self.simple_squelch:
            squelch.set_threshold(threshold_db)

    def set_gain_control(self, auto, gain_db):
        if self.replay or self.remote_iq:
            return
        if not math.isfinite(gain_db):
            return
        with self._gain_lock:
            if self._source.is_hackrf:
                gains = HackRFGains.from_total(gain_db)
                self.set_hackrf_gain_control(auto, gains.lna, gains.vga, gains.amp)
                return
            self._source.set_gain_mode(0, bool(auto))
            self._auto_gain = bool(auto) and not self._source.has_agc
            if not auto:
                self._set_gain(max(0.0, min(100.0, float(gain_db))))
            self._gain_controller.reset(self._current_gain)

    def set_hackrf_gain_control(self, auto, lna_gain, vga_gain, amp):
        if self.replay or self.remote_iq:
            return
        gains = HackRFGains(lna_gain, vga_gain, amp)
        if not self._source.is_hackrf:
            raise ValueError("HackRF controls received for a different SDR")
        with self._gain_lock:
            self._auto_gain = bool(auto)
            if not auto:
                self._set_hackrf_gains(gains)
            self._gain_controller.reset(self._source.hackrf_gains, reset_cooldown=True)

    def _set_hackrf_gains(self, gains):
        try:
            self._source.set_hackrf_gains(0, gains)
        except (RuntimeError, ValueError) as exc:
            print(f"Could not set HackRF gains: {exc}", file=sys.stderr, flush=True)
        finally:
            # A failed multi-stage write can still have changed one stage.
            actual = self._source.read_hackrf_gains()
            self._source.hackrf_gains = actual
            self._current_gain = actual.total_db
            self._gain_controller.reset(actual)
            self._apply_squelch()

    def _set_gain(self, gain_db):
        try:
            self._source.set_gain(0, gain_db)
        except Exception as exc:
            print(f"Could not set SDR gain to {gain_db:g} dB: {exc}", file=sys.stderr)
            self._gain_controller.reset(self._current_gain)
            return
        self._current_gain = gain_db
        self._apply_squelch()

    def run_auto_gain(self):
        from core.pipeline.runtime_status import StatusPublisher
        from ipc.message_schema import STATUS_SOURCE_RF
        from ipc.transport.uds_seqpacket import resolve_status_socket_path
        publisher = StatusPublisher(resolve_status_socket_path(channel_count=self.num_channels), STATUS_SOURCE_RF)
        try:
            while not self._gain_stop.wait(1.0):
                measurement = self._level_meter.snapshot()
                with self._gain_lock:
                    if self._auto_gain and measurement is not None:
                        gain = self._gain_controller.update(*measurement)
                        if gain is not None:
                            if self._source.is_hackrf:
                                self._set_hackrf_gains(gain)
                            else:
                                self._set_gain(gain)
                    if self._source.is_hackrf:
                        state = self._source.hackrf_gains.to_dict()
                        state["auto"] = self._auto_gain
                        publisher.publish(payload_dict={"hackrf_gain": state})
        finally:
            publisher.close()

    def set_correct_iq(self, enabled):
        self._correct_iq.set_enabled(enabled)

    def retune_freq_error(self, offset_hz):
        """Apply a new freq_err_offset by retuning the running SDR.

        Called from the frequency-error monitor; interrupts reception briefly.
        """
        tuned = self.rf_freq + self.freq_offset + float(offset_hz)
        with self._gain_lock:
            self._source.source.set_frequency(0, tuned)
        self.freq_err_offset = float(offset_hz)

    def set_freq_auto(self, enabled):
        if self.freq_error_monitor is not None and not self.replay:
            self.freq_error_monitor.auto = bool(enabled)


def _run_control_loop(tb, socket_path):
    """Background thread: apply live squelch changes from the GUI.

    Connects as a client because the supervisor (server) binds the control
    socket before spawning this process. Exits quietly on disconnect -- the
    supervisor closes the socket right before SIGINT-ing this process anyway.
    """
    from ipc.message_schema import (ControlSquelchPacket, ControlGainPacket, ControlCorrectIQPacket, ControlHackRFGainPacket,
                                    ControlFreqAutoPacket, MSG_TYPE_CONTROL_SQUELCH, MSG_TYPE_CONTROL_GAIN,
                                    MSG_TYPE_CONTROL_CORRECT_IQ, MSG_TYPE_CONTROL_HACKRF_GAIN, MSG_TYPE_CONTROL_FREQ_AUTO)
    from ipc.transport.uds_seqpacket import UdsSeqpacketClient

    try:
        client = UdsSeqpacketClient(socket_path, connect_timeout=10.0)
    except (OSError, TimeoutError):
        return

    while True:
        try:
            payload = client.recv()
        except OSError:
            return
        if not payload:
            return
        if not tb.flowgraph_started.wait(timeout=30.0):
            return
        if len(payload) < 4:
            continue
        kind = int.from_bytes(payload[2:4], "little")
        try:
            if kind == MSG_TYPE_CONTROL_SQUELCH:
                tb.set_squelch_threshold(ControlSquelchPacket.decode(payload).threshold_db)
            elif kind == MSG_TYPE_CONTROL_GAIN:
                packet = ControlGainPacket.decode(payload)
                tb.set_gain_control(packet.auto, packet.gain_db)
            elif kind == MSG_TYPE_CONTROL_CORRECT_IQ:
                tb.set_correct_iq(ControlCorrectIQPacket.decode(payload).enabled)
            elif kind == MSG_TYPE_CONTROL_FREQ_AUTO:
                tb.set_freq_auto(ControlFreqAutoPacket.decode(payload).enabled)
            elif kind == MSG_TYPE_CONTROL_HACKRF_GAIN:
                packet = ControlHackRFGainPacket.decode(payload)
                tb.set_hackrf_gain_control(packet.auto, packet.lna_gain, packet.vga_gain, packet.amp)
        except (ValueError, OSError, RuntimeError) as exc:
            print(f"Control command failed: {exc}", file=sys.stderr)


def _parse_args(argv=None):
    import argparse

    from core.rf.backend_config import add_config_arguments

    parser = argparse.ArgumentParser(
        description="STD-T98 30ch multi-channel RF backend (SoapySDR)."
    )
    add_config_arguments(parser)
    from core.rf.dqpsk_receiver import add_arguments
    add_arguments(parser)
    parser.add_argument(
        "--replay",
        help="Replay a recording from tools/std_t98_record_iq.py instead of "
        "opening the SDR, so the stack can be exercised without hardware.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the resolved config and derived rates, then exit without "
        "opening the SDR or starting the flowgraph.",
    )
    parser.add_argument(
        "--control-socket",
        help="UDS SOCK_SEQPACKET path to receive live control messages on "
        "(currently: squelch threshold changes). Set by the GUI/launcher's "
        "StackSupervisor; not needed when running this script by hand.",
    )
    parser.add_argument('--no-correct-iq', action='store_true', help='Disable automatic IQ DC offset correction')
    parser.add_argument('--rf-remote', help='IP or hostname of an RF IQ server')
    parser.add_argument('--rf-port', type=int, default=9850)
    return parser.parse_args(argv)


def _print_dry_run(config):
    rates = derive_rates(config.sdr, config.channelizer)
    print("[sdr]")
    for field_name in config.sdr.__dataclass_fields__:
        print(f"  {field_name} = {getattr(config.sdr, field_name)!r}")
    # Resolved view of the two settings that decide whether the device opens
    # at all, so a failing driver can be diagnosed without starting the SDR.
    print("[sdr.resolved]")
    print(f"  device_string = {config.sdr.device_string()!r}")
    print(f"  freq_err_offset = {config.sdr.resolved_freq_err_offset():+.1f} Hz")
    print(f"  tuned_freq = {config.sdr.tuned_freq():.0f} Hz")
    print(f"  stream_args = {config.sdr.resolved_stream_args()!r}")
    print(f"  auto_gain = {config.sdr.resolved_auto_gain()!r}")
    print(f"  antenna = {config.sdr.antenna or '(driver default)'}")
    bandwidth = config.sdr.resolved_bandwidth()
    print(f"  bandwidth = {bandwidth if bandwidth else '(device default)'}")
    print("[demod]")
    for field_name in config.demod.__dataclass_fields__:
        print(f"  {field_name} = {getattr(config.demod, field_name)!r}")
    print("[channelizer]")
    for field_name in config.channelizer.__dataclass_fields__:
        print(f"  {field_name} = {getattr(config.channelizer, field_name)!r}")
    print("[derived]")
    print(f"  resamp1 = {rates.resamp1_interp}/{rates.resamp1_decim}")
    print(f"  samp_rate_post_resamp1 = {rates.samp_rate_post_resamp1}")
    print(f"  samp_rate_post_pfb (bin width) = {rates.samp_rate_post_pfb}")
    print(f"  demod_samp_rate = {rates.demod_samp_rate}")
    print(f"  bin_width_error = {rates.bin_width_error_hz:+.4f} Hz")
    print(f"  channel_map = {rates.channel_map}")


def _relay_remote_frames(remote_iq):
    """Frame-mode client: the server already demodulated; feed frames to the protocol service."""
    import time
    from core.pipeline.runtime_status import StatusPublisher
    from ipc.message_schema import STATUS_SOURCE_RF, FramePacket
    from ipc.transport.uds_seqpacket import UdsSeqpacketServer, resolve_frame_socket_path, resolve_status_socket_path

    channel_count = remote_iq.metadata["channelizer"]["num_channels"]
    transport = UdsSeqpacketServer(resolve_frame_socket_path(channel_count=channel_count))
    publisher = StatusPublisher(resolve_status_socket_path(channel_count=channel_count), STATUS_SOURCE_RF)
    print(f"Receiving demodulated frames from {remote_iq.endpoint}", flush=True)

    def stop(sig=None, frame=None):
        remote_iq.close()
        transport.close()
        publisher.close()
        sys.exit(0)

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    report_at = 0
    try:
        while True:
            now = time.monotonic()
            if now >= report_at:
                publisher.publish(payload_dict={"rf_network": {
                    "mode": "client", "endpoint": remote_iq.endpoint, "bytes": remote_iq.bytes_received,
                    "metadata": remote_iq.metadata, "clients": 1}})
                report_at = now + 1
            try:
                payload = remote_iq.receive_frame()
            except (OSError, ValueError, ConnectionError) as exc:
                if remote_iq.closed.is_set():
                    return
                raise RuntimeError(f'Remote frame connection ended: {exc}') from exc
            FramePacket.decode(payload)  # Reject malformed frames before the decoder sees them.
            transport.send(payload)
    finally:
        remote_iq.close()
        transport.close()
        publisher.close()


def main(top_block_cls=test3, options=None):
    from core.rf.backend_config import load_config

    args = _parse_args()
    config = load_config(args)
    if args.dry_run:
        _print_dry_run(config)
        return
    if args.dqpsk_rtcm:
        from core.rf.dqpsk_options import parse_frequencies, validate_bandwidth
        validate_bandwidth(parse_frequencies(args.dqpsk_frequencies),
                           config.sdr.center_freq + config.sdr.freq_offset,
                           derive_rates(config.sdr, config.channelizer).samp_rate_post_resamp1)

    remote_iq = None
    if args.rf_remote:
        if args.replay:
            raise ValueError('--replay and --rf-remote are mutually exclusive')
        import os
        from core.rf.remote_iq import IQClient, client_config, stream_metadata, TOKEN_ENV, FRAME_FORMAT
        remote_iq = IQClient(args.rf_remote, args.rf_port, os.environ.get(TOKEN_ENV, ''), defer_stream=True)
        remote_iq.endpoint = f'{args.rf_remote}:{args.rf_port}'
        if remote_iq.metadata['format'] == FRAME_FORMAT:
            if args.dqpsk_rtcm:
                remote_iq.close()
                raise ValueError('DQPSK decoding requires IQ; the remote server supplies demodulated FSK frames')
            _relay_remote_frames(remote_iq)
            return
        expected = stream_metadata(config)
        actual = remote_iq.metadata
        if any(expected[key] != actual[key] for key in ('sample_rate', 'center_freq', 'channelizer')):
            remote_iq.close()
            raise ValueError('Remote RF configuration differs; reconnect to refresh server settings')
        config = client_config(actual, demod=config.demod)
    try:
        tb = top_block_cls(config=config, replay=args.replay, remote_iq=remote_iq, correct_iq=not args.no_correct_iq) if remote_iq else top_block_cls(config=config, replay=args.replay, correct_iq=not args.no_correct_iq)
    except Exception:
        if remote_iq is not None:
            remote_iq.close()
        raise
    from core.rf.dqpsk_receiver import attach as attach_dqpsk, close as close_dqpsk
    try:
        dqpsk_branches = attach_dqpsk(tb, args)
    except Exception:
        if remote_iq is not None:
            remote_iq.close()
        raise

    if args.replay:
        print(f"replaying {args.replay} instead of opening the SDR")

    if args.control_socket:
        control_thread = threading.Thread(
            target=_run_control_loop, args=(tb, args.control_socket), daemon=True
        )
        control_thread.start()

    def sig_handler(sig=None, frame=None):
        tb._gain_stop.set()
        if remote_iq is not None:
            tb._remote_source.close()
        tb.stop()
        tb.wait()
        close_dqpsk(dqpsk_branches)
        sys.exit(0)

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    tb.start()
    tb.flowgraph_started.set()
    if args.rf_stop_file:
        def watch_stop_file():
            from pathlib import Path
            while not tb._gain_stop.wait(.1):
                if Path(args.rf_stop_file).exists():
                    tb._gain_stop.set()
                    if remote_iq is not None:
                        tb._remote_source.close()
                    tb.stop()
                    return
        threading.Thread(target=watch_stop_file, name='RF stop watcher', daemon=True).start()
    if not args.replay and remote_iq is None:
        threading.Thread(target=tb.run_auto_gain, daemon=True).start()
    tb.wait()
    close_dqpsk(dqpsk_branches)
    tb._gain_stop.set()
    if remote_iq is not None:
        tb._remote_source.close()
        if tb._remote_source.failure:
            raise RuntimeError(f'Remote IQ connection ended: {tb._remote_source.failure}')

if __name__ == '__main__':
    main()
