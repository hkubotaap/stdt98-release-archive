# 同梱コードのライセンス・対応ソース

## Chart.js 4.4.3

- 配布ファイル：`chart.umd.min.js`
- 著作権表示：Copyright (c) 2014-2024 Chart.js Contributors
- バンドルヘッダの表示：(c) 2024 Chart.js Contributors
- ライセンス：MIT
- 全文：[licenses/Chart.js-4.4.3-MIT.txt](licenses/Chart.js-4.4.3-MIT.txt)
- 原文：[Chart.js v4.4.3 LICENSE.md](https://raw.githubusercontent.com/chartjs/Chart.js/v4.4.3/LICENSE.md)

## @kurkle/color 0.3.2（Chart.jsバンドルに内包）

- 配布ファイル：`chart.umd.min.js` 内
- 原文の著作権表示：Copyright (c) 2018-2021 Jukka Kurkela
- バンドルヘッダの表示：(c) 2023 Jukka Kurkela
- ライセンス：MIT
- 全文：[licenses/kurkle-color-0.3.2-MIT.txt](licenses/kurkle-color-0.3.2-MIT.txt)
- 原文：[@kurkle/color v0.3.2 LICENSE.md](https://raw.githubusercontent.com/kurkle/color/v0.3.2/LICENSE.md)

原文とバンドルヘッダの年表記をそれぞれ保持しています。ライセンス全文はこの
配布物内で読めるため、上記URLに接続できなくても確認できます。

## 独自AMBE+2デコーダー

Copyright (C) 2026 ToTon。独自著作部分の対象・配布条件は
[COPYRIGHT.md](../COPYRIGHT.md)（GPL-3.0-only）を参照してください。

- 配布ファイル：`vendor/ambe2/` 内のPython実装と `_ambe2c.dll`
- 配布条件：GNU General Public License v3.0（[LICENSE](LICENSE)）
- 対応ソース：[vendor/ambe2_source/README.md](vendor/ambe2_source/README.md)
- 対応ソース内のライセンス：[vendor/ambe2_source/LICENSE](vendor/ambe2_source/LICENSE)
- ファイル対応：[vendor/ambe2_source/SOURCE_MANIFEST.json](vendor/ambe2_source/SOURCE_MANIFEST.json)

この一覧は同梱Chart.jsバンドルと独自AMBEデコーダーの案内です。別途導入する
GNU Radio、SoapySDR、Pythonパッケージ等の条件は各配布物のライセンスを参照してください。
