r"""
過去の秘話生録音(.t98raw)を、現在の方針で復号し直す。

方針(post_decode.run_decode に従う): manual_keys.csv に登録された周波数だけ
descramble、それ以外は平文(decode_3600)。ML の秘話判定・鍵探索は使わない。
出力名は <raw基名>_ch<NN>_<plain|keyN>.wav。

  python redecode.py                    # 未復号の raw を復号(既存はスキップ)
  python redecode.py --freq 351212500   # その周波数だけ
  python redecode.py --force            # 既存出力を作り直す(古い名前も掃除)

平文がノイズ状(=本当に秘話で manual_keys 未登録)の raw は WAV を書かず保留。
後で manual_keys.csv に鍵を追記して --force すれば遡及復号できる。
"""
import argparse
import glob
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from post_decode import run_decode, read_raw, log, rec_dir_for
from core.audio.data_paths import resolve_data_dir

DATA_DIR = str(resolve_data_dir(os.environ.get("STD_T98_DATA_DIR"), os.path.dirname(os.path.abspath(__file__))))
RAW_DIR = os.path.join(DATA_DIR, "raw")
REC_DIR = os.path.join(DATA_DIR, "rec")


def existing_outputs(raw_path):
    """この raw から作られた復号 WAV(新名 _ch*_*.wav と旧名 _decoded.wav)。
    日付サブフォルダ(新)と rec 直下(旧フラット)の両方を探す。"""
    base = os.path.splitext(os.path.basename(raw_path))[0]
    out = []
    for d in {rec_dir_for(raw_path, REC_DIR), REC_DIR}:
        out += glob.glob(os.path.join(d, base + "_ch*.wav"))
        out += glob.glob(os.path.join(d, base + "_decoded.wav"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--freq", type=int, default=0, help="この周波数(Hz)だけ処理 (0=全部)")
    ap.add_argument("--force", action="store_true", help="既存出力を作り直す(古い名前も掃除)")
    args = ap.parse_args()

    # 日付サブフォルダ(新)と rec 直下(旧)の両方を再帰的に拾う。
    raws = sorted(glob.glob(os.path.join(RAW_DIR, "**", "*.t98raw"), recursive=True))
    done = recovered = still = 0
    for raw in raws:
        outs = [p for p in existing_outputs(raw) if os.path.getsize(p) > 44]
        if outs and not args.force:
            done += 1
            continue

        try:
            freq_hz, frames, _csm, _secret = read_raw(raw)
        except Exception as exc:
            log(f"skip {os.path.basename(raw)}: {exc}")
            continue
        if args.freq and freq_hz != args.freq:
            continue
        if not frames:
            continue

        # --force: 古い出力(誤鍵ゴミ・旧名含む)を消してから作り直す。
        if args.force:
            for p in existing_outputs(raw):
                try:
                    os.remove(p)
                except OSError:
                    pass

        # run_decode が manual_keys.csv を見て descramble/平文を決め、
        # <raw基名>_ch<NN>_<plain|keyN>.wav を raw と同じ日付サブフォルダの rec に書く。
        code = run_decode(raw, os.path.join(rec_dir_for(raw, REC_DIR), "x.wav"))
        if code == 0:
            recovered += 1
        else:
            still += 1   # 平文がノイズ = 秘話で鍵未登録。raw は保持。

    log(f"完了: 既存{done} / 復号{recovered} / 未復号のまま(保留){still}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
