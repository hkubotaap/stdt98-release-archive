"""Collapsible wideband spectrum + waterfall over the channel bank.

With the channel-history table attached, each table column shows its own
channel's +-3.125 kHz slice directly above it, so the spectrum follows the
table's zoom, horizontal scroll and selection. Without a visible table (RF
server mode) the band is drawn on a linear frequency axis.
"""
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets

from core.rf.spectrum import decode

WATERFALL_ROWS = 150
CHANNEL_HALF_WIDTH_HZ = 3125.0
_COLOR_STOPS = ((0.0, (8, 10, 40)), (0.35, (20, 70, 160)), (0.6, (30, 180, 190)),
                (0.8, (240, 220, 60)), (1.0, (240, 60, 40)))


def _color_table():
    table = []
    for index in range(256):
        value = index / 255
        for (start, a), (end, b) in zip(_COLOR_STOPS, _COLOR_STOPS[1:]):
            if value <= end:
                t = (value - start) / (end - start)
                table.append(QtGui.qRgb(*(round(x + (y - x) * t) for x, y in zip(a, b))))
                break
    return table


def _tint(color, alpha):
    color = QtGui.QColor(color)
    color.setAlpha(alpha)
    return color


class SpectrumCanvas(QtWidgets.QWidget):
    channel_clicked = QtCore.pyqtSignal(int)
    zoom_step = QtCore.pyqtSignal(int)
    linear_left = 46
    linear_bottom = 18

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(230)
        self.setMouseTracking(True)
        self.columns = ()
        self.table = None          # WaterfallCanvas
        self.table_scroll = None   # its QScrollArea
        self.selected_channel = None
        self.message = "受信を開始すると表示します。"
        self.color_table = _color_table()
        self.clear()

    def clear(self):
        self.db = None
        self.center = self.rate = None
        self.rows = None
        self.image = None
        self.floor = self.top = None

    def set_columns(self, columns):
        self.columns = tuple(col for col in columns if col.frequency_hz is not None)
        self.update()

    def set_spectrum(self, db, center, rate):
        if self.db is None or len(db) != len(self.db) or center != self.center or rate != self.rate:
            self.rows = np.zeros((WATERFALL_ROWS, len(db)), dtype=np.uint8)
            self.floor = self.top = None
        self.db, self.center, self.rate = db, center, rate
        # Smoothed auto range: noise floor near the bottom, strongest signal near the top.
        floor, peak = float(np.percentile(db, 20)) - 8, float(np.max(db)) + 6
        top = max(peak, floor + 45)
        self.floor = floor if self.floor is None else self.floor + 0.1 * (floor - self.floor)
        self.top = top if self.top is None else self.top + 0.1 * (top - self.top)
        scaled = np.clip((db - self.floor) / (self.top - self.floor) * 255, 0, 255).astype(np.uint8)
        self.rows = np.roll(self.rows, 1, axis=0)
        self.rows[0] = scaled
        # QImage borrows the buffer; keep the bytes alive alongside it.
        self.image_bytes = self.rows.tobytes()
        self.image = QtGui.QImage(self.image_bytes, self.rows.shape[1], self.rows.shape[0],
                                  self.rows.shape[1], QtGui.QImage.Format_Indexed8)
        self.image.setColorTable(self.color_table)
        self.message = None
        self.update()

    # --- geometry ----------------------------------------------------------
    def _aligned(self):
        return (self.table is not None and self.table.isVisible() and self.columns
                and tuple(self.table.columns) and len(self.table.columns) == len(self.columns))

    def _bin_at(self, frequency):
        return (frequency - (self.center - self.rate / 2)) / self.rate * len(self.db)

    def _layout(self):
        """(plot rect, clip x-range, [(column, x0, x1, bin0, bin1)]) in this widget's coordinates."""
        top, bottom = 4, self.height() - 4
        if self._aligned():
            table = self.table
            origin = self.mapFromGlobal(table.mapToGlobal(QtCore.QPoint(0, 0))).x()
            viewport = self.table_scroll.viewport()
            view0 = self.mapFromGlobal(viewport.mapToGlobal(QtCore.QPoint(0, 0))).x()
            view1 = view0 + viewport.width()
            cw = table.cell_width()
            spans = []
            for index, col in enumerate(table.columns):
                x0 = origin + table.left + index * cw
                if x0 + cw < view0 or x0 > view1:
                    continue
                spans.append((col, x0, x0 + cw, self._bin_at(col.frequency_hz - CHANNEL_HALF_WIDTH_HZ),
                              self._bin_at(col.frequency_hz + CHANNEL_HALF_WIDTH_HZ)))
            # The dB labels sit in the table's left label column; once that has
            # scrolled away they are pinned in a narrow strip at the left edge.
            left = origin + table.left if origin + table.left >= view0 + self.linear_left else view0 + self.linear_left
            rect = QtCore.QRectF(left, top, max(10, view1 - left), bottom - top)
            return rect, (left, view1), spans
        rect = QtCore.QRectF(self.linear_left, top, max(10, self.width() - self.linear_left - 6),
                             max(10, bottom - top - self.linear_bottom))
        return rect, (rect.left(), rect.right()), [(None, rect.left(), rect.right(), 0, len(self.db))]

    def _span_at(self, x):
        _, (clip0, clip1), spans = self._layout()
        if not clip0 <= x <= clip1:
            return None
        return next((span for span in spans if span[1] <= x < span[2]), None)

    def _frequency_at(self, x, span):
        _, x0, x1, b0, b1 = span
        bin_position = b0 + (x - x0) / max(1e-9, x1 - x0) * (b1 - b0)
        return self.center - self.rate / 2 + bin_position / len(self.db) * self.rate

    def _channel_at(self, frequency):
        nearest = min(self.columns, key=lambda col: abs(col.frequency_hz - frequency), default=None)
        if nearest is not None and abs(nearest.frequency_hz - frequency) <= CHANNEL_HALF_WIDTH_HZ:
            return nearest
        return None

    # --- painting ----------------------------------------------------------
    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        palette = self.palette()
        painter.fillRect(self.rect(), palette.color(QtGui.QPalette.Base))
        if self.db is None:
            painter.setPen(palette.color(QtGui.QPalette.PlaceholderText))
            painter.drawText(self.rect(), QtCore.Qt.AlignCenter, self.message or "")
            return
        rect, (clip0, clip1), spans = self._layout()
        split = rect.top() + rect.height() * 0.45
        line_rect = QtCore.QRectF(rect.left(), rect.top(), rect.width(), split - rect.top() - 3)
        fall_top, fall_height = split, rect.bottom() - split
        painter.save()
        painter.setClipRect(QtCore.QRectF(clip0, 0, clip1 - clip0, self.height()))
        for col, x0, x1, b0, b1 in spans:
            # Each column shows exactly its channel's bins, stretched to the column width.
            source = QtCore.QRectF(b0, 0, b1 - b0, self.image.height())
            painter.drawImage(QtCore.QRectF(x0, fall_top, x1 - x0, fall_height), self.image, source)
        self._paint_columns(painter, spans, rect, line_rect)
        self._paint_line(painter, spans, line_rect, palette)
        painter.restore()
        self._paint_axes(painter, rect, line_rect, spans, palette)

    def _paint_columns(self, painter, spans, rect, line_rect):
        text = self.palette().color(QtGui.QPalette.Text)
        selected = self._selected_ids()
        for col, x0, x1, _, _ in spans:
            if col is not None and col.channel_id in selected:
                painter.fillRect(QtCore.QRectF(x0, rect.top(), x1 - x0, rect.height()),
                                 _tint(self.palette().color(QtGui.QPalette.Highlight), 70))
        if self._aligned():
            # Same hairline weights as the table: group edges, then every 10 / 5 channels.
            for index, (col, x0, _, _, _) in enumerate(spans):
                previous = spans[index - 1][0] if index else None
                group = previous is None or previous.group != col.group
                alpha = 70 if group else 34 if col.number % 10 == 1 else 22 if col.number % 5 == 1 else 11
                painter.setPen(QtGui.QPen(_tint(text, alpha), 1))
                x = round(x0) + .5
                painter.drawLine(QtCore.QPointF(x, rect.top()), QtCore.QPointF(x, rect.bottom()))
        else:
            painter.setPen(QtGui.QPen(_tint(text, 28), 1))
            for col in self.columns:
                x = spans[0][1] + (self._bin_at(col.frequency_hz) / len(self.db)) * (spans[0][2] - spans[0][1])
                painter.drawLine(QtCore.QPointF(x, line_rect.bottom() - 6), QtCore.QPointF(x, line_rect.bottom()))

    def _paint_line(self, painter, spans, line_rect, palette):
        points = []
        for _, x0, x1, b0, b1 in spans:
            first, last = max(0, int(np.floor(b0))), min(len(self.db), int(np.ceil(b1)))
            values = self.db[first:last]
            if not len(values):
                continue
            pixels = max(1, int(x1 - x0))
            if len(values) > pixels:
                # One point per pixel; the maximum keeps narrow carriers visible.
                edges = np.linspace(0, len(values), pixels + 1).astype(int)[:-1]
                values = np.maximum.reduceat(values, edges)
            levels = np.clip((values - self.floor) / (self.top - self.floor), 0, 1)
            step = (x1 - x0) / len(levels)
            points += [QtCore.QPointF(x0 + (i + .5) * step, line_rect.bottom() - level * line_rect.height())
                       for i, level in enumerate(levels)]
        if len(points) < 2:
            return
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setPen(QtGui.QPen(palette.color(QtGui.QPalette.Highlight), 1.2))
        painter.drawPolyline(QtGui.QPolygonF(points))
        painter.setRenderHint(QtGui.QPainter.Antialiasing, False)

    def _paint_axes(self, painter, rect, line_rect, spans, palette):
        text = palette.color(QtGui.QPalette.Text)
        grid = _tint(text, 40)
        font = painter.font()
        font.setPointSizeF(max(7.0, font.pointSizeF() * 0.85))
        painter.setFont(font)
        if self._aligned():
            view0 = self.mapFromGlobal(self.table_scroll.viewport().mapToGlobal(QtCore.QPoint(0, 0))).x()
            label_left = max(view0, rect.left() - self.table.left)
        else:
            label_left = rect.left() - self.linear_left
        label_rect = QtCore.QRectF(label_left, 0, rect.left() - label_left, self.height())
        painter.fillRect(label_rect, palette.color(QtGui.QPalette.Base))
        span = self.top - self.floor
        step = 10 if span <= 60 else 20
        level = np.ceil(self.floor / step) * step
        while level < self.top:
            y = line_rect.bottom() - (level - self.floor) / span * line_rect.height()
            if y < line_rect.top() + 16:
                break  # Leave the top-left corner for the unit label.
            painter.setPen(grid)
            painter.drawLine(QtCore.QPointF(line_rect.left(), y), QtCore.QPointF(line_rect.right(), y))
            painter.setPen(text)
            painter.drawText(QtCore.QRectF(label_left, y - 7, label_rect.width() - 4, 14),
                             QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter, f"{level:.0f}")
            level += step
        painter.setPen(text)
        painter.drawText(QtCore.QRectF(label_left + 2, rect.top(), label_rect.width(), 14), QtCore.Qt.AlignLeft, "dBFS")
        if not self._aligned():
            # Linear mode: frequency ticks every 100 kHz.
            x0, x1 = spans[0][1], spans[0][2]
            start = np.ceil((self.center - self.rate / 2) / 100e3) * 100e3
            for frequency in np.arange(start, self.center + self.rate / 2, 100e3):
                x = x0 + self._bin_at(frequency) / len(self.db) * (x1 - x0)
                painter.setPen(grid)
                painter.drawLine(QtCore.QPointF(x, rect.top()), QtCore.QPointF(x, line_rect.bottom()))
                painter.setPen(text)
                painter.drawText(QtCore.QRectF(x - 40, rect.bottom() + 2, 80, self.linear_bottom),
                                 QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop, f"{frequency / 1e6:.2f}")

    def _selected_ids(self):
        if self._aligned():
            return {self.table.columns[i].channel_id for i in self.table.selected_indices
                    if i < len(self.table.columns)}
        return {self.selected_channel} if self.selected_channel is not None else set()

    # --- interaction -------------------------------------------------------
    def mouseMoveEvent(self, event):
        span = self._span_at(event.pos().x()) if self.db is not None else None
        if span is None:
            QtWidgets.QToolTip.hideText()
            return
        frequency = self._frequency_at(event.pos().x(), span)
        index = int(np.clip(self._bin_at(frequency), 0, len(self.db) - 1))
        col = self._channel_at(frequency)
        label = f"\n{col.label}  {col.frequency_hz / 1e6:.5f} MHz\nクリックで選択" if col else ""
        QtWidgets.QToolTip.showText(event.globalPos(), f"{frequency / 1e6:.5f} MHz  {self.db[index]:.1f} dBFS{label}", self)

    def mousePressEvent(self, event):
        span = self._span_at(event.pos().x()) if self.db is not None else None
        if span is None or event.button() != QtCore.Qt.LeftButton:
            return
        col = self._channel_at(self._frequency_at(event.pos().x(), span))
        if col is not None:
            self.selected_channel = col.channel_id
            self.update()
            self.channel_clicked.emit(col.channel_id)

    def wheelEvent(self, event):
        steps = event.angleDelta().y() // 120
        if not steps:
            return
        if event.modifiers() & QtCore.Qt.ControlModifier:
            self.zoom_step.emit(1 if steps > 0 else -1)
        elif self._aligned():
            bar = self.table_scroll.horizontalScrollBar()
            bar.setValue(bar.value() - steps * max(1, int(self.table.cell_width())) * 3)
        event.accept()


class SpectrumView(QtWidgets.QWidget):
    """Header toggle plus canvas; the open/closed state is remembered."""
    channel_clicked = QtCore.pyqtSignal(int)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.last_sequence = None
        self.waterfall = None
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        header = QtWidgets.QHBoxLayout()
        self.toggle = QtWidgets.QToolButton()
        self.toggle.setCheckable(True)
        self.toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle.setAutoRaise(True)
        self.toggle.setText("スペクトラム")
        self.toggle.setToolTip("受信帯域全体の電波の強さを周波数ごとに表示します。どのチャンネルに電波が来ているかが分かります。")
        self.info = QtWidgets.QLabel()
        self.info.setObjectName("cacheLabel")
        header.addWidget(self.toggle)
        header.addWidget(self.info)
        header.addStretch(1)
        layout.addLayout(header)
        self.canvas = SpectrumCanvas()
        self.canvas.channel_clicked.connect(self.channel_clicked)
        self.canvas.zoom_step.connect(self._zoom_step)
        layout.addWidget(self.canvas)
        self.toggle.toggled.connect(self._set_open)
        self.toggle.setChecked(settings.value("spectrum_open", False, type=bool))
        self._set_open(self.toggle.isChecked())

    def attach_table(self, waterfall):
        """Align with a ChannelWaterfall: same columns, zoom, scroll and selection."""
        self.waterfall = waterfall
        self.canvas.table = waterfall.canvas
        self.canvas.table_scroll = waterfall.scroll
        waterfall.scroll.horizontalScrollBar().valueChanged.connect(self.canvas.update)
        waterfall.canvas.selected.connect(lambda _text: self.canvas.update())
        waterfall.zoom.currentIndexChanged.connect(lambda _index: self.canvas.update())
        waterfall.canvas.installEventFilter(self)
        waterfall.scroll.viewport().installEventFilter(self)

    def eventFilter(self, watched, event):
        if event.type() in (QtCore.QEvent.Resize, QtCore.QEvent.Move, QtCore.QEvent.Show, QtCore.QEvent.Hide):
            self.canvas.update()
        return False

    def _zoom_step(self, direction):
        if self.waterfall is not None:
            combo = self.waterfall.zoom
            combo.setCurrentIndex(max(0, min(combo.count() - 1, combo.currentIndex() + direction)))

    def _set_open(self, opened):
        self.toggle.setArrowType(QtCore.Qt.DownArrow if opened else QtCore.Qt.RightArrow)
        self.canvas.setVisible(opened)
        self.settings.setValue("spectrum_open", opened)

    def set_columns(self, columns):
        columns = tuple(col for col in columns if col.frequency_hz is not None)
        if columns != self.canvas.columns:
            self.canvas.set_columns(columns)

    def select_channel(self, channel_id):
        self.canvas.selected_channel = channel_id
        self.canvas.update()

    def update_spectrum(self, state):
        if state is None or state.get("seq") == self.last_sequence:
            return
        self.last_sequence = state.get("seq")
        if not self.toggle.isChecked():
            return  # Closed: skip decoding and painting entirely.
        try:
            db, center, rate = decode(state)
        except ValueError:
            return
        self.canvas.set_spectrum(db, center, rate)
        hint = " · Ctrl+ホイールで拡大・縮小、ホイールで左右移動" if self.canvas._aligned() else ""
        self.info.setText(f"{center / 1e6:.4f} MHz ± {rate / 2e3:.0f} kHz · RBW {rate / len(db):.0f} Hz{hint}")

    def show_message(self, message):
        if self.canvas.db is not None or self.canvas.message != message:
            self.clear(message)

    def clear(self, message="受信を開始すると表示します。"):
        self.last_sequence = None
        self.canvas.clear()
        self.canvas.message = message
        self.info.setText("")
        self.canvas.update()
