# -*- coding: utf-8 -*-
"""Entry point: ``python -m app`` launches the desktop front-end."""

import faulthandler
import sys
import tempfile
import time
from pathlib import Path

from PyQt5 import QtCore, QtWidgets

from app.main_window import MainWindow
from app.stall_watchdog import StallWatchdog
from app.theme import apply_dark_theme

GUI_LOG = Path(tempfile.gettempdir()) / "std-t98-gui.log"
GUI_LOG_MAX_BYTES = 2_000_000

# Harmless lines that Qt's platform / input-method plugins print on some
# desktops (ibus/fcitx create a QSocketNotifier at startup; Wayland cannot honour
# a window-activation request). They come from the plugin, not from this app --
# we use no QSocketNotifier and never call requestActivate/activateWindow. Drop
# exactly these; pass every other Qt message through so real warnings stay.
_BENIGN = (
    "QSocketNotifier: Can only be used with threads started with QThread",
    "Wayland does not support QWindow::requestActivate()",
)


def _is_benign(message):
    return any(line in message for line in _BENIGN)


def _message_filter(mode, context, message):
    if _is_benign(message):
        return
    # Never let a log write raise here: an exception inside Qt's message
    # callback is fatal to the whole process.
    try:
        sys.stderr.write(message + "\n")
        sys.stderr.flush()
    except Exception:
        pass


def _open_gui_log():
    """Log for Qt messages, tracebacks, crashes and stalls.

    Under pythonw sys.stderr is None, so without this a single Qt warning
    raises inside the message handler and aborts the GUI, and nothing explains
    a freeze. With a console, keep printing there as before.
    """
    try:
        if GUI_LOG.exists() and GUI_LOG.stat().st_size > GUI_LOG_MAX_BYTES:
            GUI_LOG.unlink()
        log = open(GUI_LOG, "a", encoding="utf-8", buffering=1)
    except OSError:
        return None
    if sys.stderr is None:
        sys.stderr = log
    if sys.stdout is None:
        sys.stdout = log
    faulthandler.enable(log, all_threads=True)  # hard crashes leave a stack too
    return log


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    log = _open_gui_log()
    QtCore.qInstallMessageHandler(_message_filter)
    app = QtWidgets.QApplication(argv)
    app.setApplicationName("STD-T98 Multi Receiver")
    apply_dark_theme(app)
    window = MainWindow(repo_root=Path(__file__).resolve().parent.parent)
    window.show()
    # A previous receiver window or other SDR software may still hold the radio.
    from app.sdr_holder_dialog import SdrHolderCheck
    holder_check = SdrHolderCheck(window)
    QtCore.QTimer.singleShot(0, holder_check.start)
    if log is not None:
        log.write(f"--- GUI started {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
        watchdog = StallWatchdog(log, parent=app)
        watchdog.start()
    return app.exec_()


if __name__ == "__main__":
    raise SystemExit(main())
