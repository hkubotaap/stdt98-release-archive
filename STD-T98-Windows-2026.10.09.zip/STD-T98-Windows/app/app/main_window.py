# -*- coding: utf-8 -*-
"""Main window for the STD-T98 desktop front-end.

This is the GUI counterpart of the terminal launcher: it drives a
``StackSupervisor`` and renders the same ChannelView / ProcessView state the
launcher prints, but as a live activity view instead of a scrolling dashboard.
The supervisor owns the process lifecycle; the window only starts/stops it and
polls it from a QTimer so the Qt event loop never blocks.
"""

import html
import os
import shlex
import time
from pathlib import Path

from PyQt5 import QtCore, QtWidgets

from app.hackrf_controls import HackRFGainControls
from core.rf.hackrf_gain import HackRFGains
from core.rf.remote_iq import FRAME_FORMAT
from app.remote_rf_window import RemoteRFWindow
from app.channel_card import (ChannelCard, HoneycombSlots, TILE_HEIGHT, comb_height,
                               honeycomb_grid, slot_position)
from app.channel_waterfall import ChannelWaterfall, Column
from app.control_console import (ConsolePanel, StatusLamp, caption, rule, set_session_state_live,
                                 style_session_state)
from app.spectrum_view import SpectrumView
from app.dqpsk_controls import DqpskControls
from app.audio_controls import AudioControls
from app.call_notifier import CallNotifier
from app.config_preview import detect_sdrs, list_device_presets, preview_config
from app.profile_store import (
    assign_device,
    create_profile,
    delete_profile,
    device_serial,
    duplicate_profile,
    is_managed_profile,
    list_profiles,
    read_sdr_settings,
    rename_profile,
    write_sdr_value,
    profiles_dir,
    read_freq_err_offset,
    read_squelch_threshold,
    read_gain_settings,
    read_hackrf_gain_settings,
    write_freq_err_offset,
    write_squelch_threshold,
    write_gain_settings,
)
from core.pipeline.multi_stack_dashboard import (
    ChannelView,
    _format_secret_cache,
)
from core.pipeline.stack_supervisor import StackSupervisor
from core.rf.backend_config import (CONFIG_ENV_VAR, BackendConfig, DemodConfig, apply_band, band_freq_scale,
                                    load_config_file)
from core.rf.channel_plan import BANDS, BANDS_BY_KEY, band_for_raster, call_stat_verified

POLL_INTERVAL_MS = 100
RECENT_CHANNEL_SECONDS = 10.0
SQUELCH_RANGE_DB = (-100, 0)
DEFAULT_SQUELCH_THRESHOLD = DemodConfig().squelch_threshold

_PROCESS_LABELS = {"backend": "RF", "protocol": "プロトコル", "secret": "秘話解析", "audio": "音声"}


def _process_tone(process_view):
    """Chip tone: running / starting / warn / exited.

    Service summaries are ``key=value`` metrics ("OK" from the UHD health
    check). Any free text -- a recording error, UHD drift -- needs attention.
    """
    if process_view.state == "EXITED":
        return "exited"
    if process_view.state == "STALLED":
        return "stalled"
    if process_view.state != "RUNNING":
        return "starting"
    detail = (process_view.detail or "").strip()
    if detail and detail != "OK" and any("=" not in token for token in detail.split()):
        return "warn"
    return "running"


DEFAULT_ANTENNA_TEXT = "（機器の既定）"
# Common RX port names per SoapySDR driver; the field also accepts any name,
# and the backend rejects one the device does not have (listing the valid ones).
KNOWN_ANTENNAS = {
    "rtlsdr": ["RX"],
    "hackrf": ["TX/RX"],
    "uhd": ["RX2", "TX/RX"],
    "airspy": ["RX"],
    "lime": ["LNAH", "LNAL", "LNAW"],
    "sdrplay": ["Antenna A", "Antenna B", "Antenna C"],
}

FREQ_ERR_TIP = ("受信機の周波数のずれを補正します（Hz）。受信機ごとに違う値です。\n"
                "入力すると選択中のプロファイルに保存し、次回の受信開始から使います。\n"
                "下の「推定値を反映」で、交信から測った値を入れられます。")
FREQ_AUTO_TIP = ("受信中に測ったずれに合わせて、SDRの受信周波数を自動で合わせ直します。\n"
                 "注意:\n"
                 "・合わせ直すたびに、全チャンネルの受信が数十ミリ秒途切れます。\n"
                 "・3ch以上で交信を測れていて、ch間のばらつきが80Hz以内のときだけ動きます。\n"
                 "・ずれが30Hz未満なら動きません（数十Hzのずれは復調側でほぼ吸収されるため）。\n"
                 "・合わせ直しは3分以上あけ、交信の少ないときに行います（最長10分待ちます）。\n"
                 "・1回で動かすのは最大1500Hzまでです。\n"
                 "・受信を停止すると、最後の補正値をプロファイルに保存します。\n"
                 "受信中でも切り替えられます。")
FREQ_AUTO_NOTE = ("注意: 自動補正は合わせ直すたびに全chの受信が数十ms途切れます"
                  "（3分以上の間隔・交信の少ないときに実施）。停止時に補正値をプロファイルへ保存します。")

class ProcessBadge(QtWidgets.QFrame):
    """A compact status chip: coloured dot, short name, and a state word only
    when something is not normal. pid and the service's own status-socket
    metrics (e.g. the RF backend's "sync=.../ipc=.../active=..." summary) live
    in the tooltip. A STARTING backend without metrics is still opening the
    SDR (firmware/FPGA load, USB re-enumeration, ...), not stuck.
    """

    _STATE_TEXT = {"starting": "起動中…", "warn": "要確認", "stalled": "応答なし", "exited": "停止"}

    def __init__(self, name, parent=None):
        super().__init__(parent)
        self.name = name
        self.setObjectName("processChip")
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(10, 3, 12, 3)
        layout.setSpacing(6)
        self._dot = QtWidgets.QLabel()
        self._dot.setObjectName("processDot")
        self._dot.setFixedSize(8, 8)
        self._name = QtWidgets.QLabel(_PROCESS_LABELS.get(name, name))
        self._name.setObjectName("processName")
        self._state = QtWidgets.QLabel()
        self._state.setObjectName("processState")
        for widget in (self._dot, self._name, self._state):
            layout.addWidget(widget, 0, QtCore.Qt.AlignVCenter)
        self._set_tone("starting")
        self._state.setText(self._STATE_TEXT["starting"])

    def _set_tone(self, tone):
        if self.property("tone") == tone:
            return
        for widget in (self, self._dot, self._state):
            widget.setProperty("tone", tone)
            widget.style().unpolish(widget)
            widget.style().polish(widget)

    @property
    def tone(self):
        return self.property("tone")

    def update_from(self, process_view):
        tone = _process_tone(process_view)
        self._set_tone(tone)
        self._state.setText(self._STATE_TEXT.get(tone, ""))
        self._state.setVisible(tone != "running")
        detail = process_view.detail
        if tone == "starting" and not detail:
            detail = "最初の報告待ち（SDRを開いている途中など）"
        lines = [f"<b>{_PROCESS_LABELS.get(self.name, self.name)}</b>　{process_view.state}"]
        if tone == "stalled":
            lines.append(f"{process_view.silent_seconds:.0f}秒間 報告がありません。プロセスは動いていますが、"
                         "受信処理が止まっている可能性があります。<br>受信を停止して開始し直してください。")
        if process_view.pid is not None:
            lines.append(f"pid {process_view.pid} · {process_view.script_name}")
        if detail:
            lines.append(f"<span style='font-family:Consolas,monospace'>{html.escape(detail)}</span>")
        self.setToolTip("<br>".join(lines))


class MainWindow(RemoteRFWindow, QtWidgets.QMainWindow):
    def __init__(self, repo_root=None, parent=None):
        super().__init__(parent)
        self.repo_root = Path(repo_root) if repo_root else Path(__file__).resolve().parent.parent
        self.supervisor = None
        self._running = False
        self._syncing_profile = False
        self._external_profiles = []  # profiles opened from outside profiles_dir()
        self._profile_serial = None    # [sdr] device_args serial of the selected profile

        self._audio_controls = AudioControls(self.repo_root, self)
        self._call_notifier = CallNotifier()
        self._tray = None
        self._last_notice_channel = None
        self._audio_controls.test_notification_requested.connect(self._show_test_notification)
        self._settings = QtCore.QSettings("std-t98-tools", "receiver")
        # Restore the last profile; seed from the env var the backend/launcher
        # read, so an existing STD_T98_BACKEND_CONFIG still works on first run.
        initial_profile = (
            self._settings.value("profile_path", "", type=str)
            or os.environ.get(CONFIG_ENV_VAR, "")
        )

        self.setWindowTitle("STD-T98 | Multi Receiver（秘話キー解析無効版）")
        self.resize(1500, 940)

        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(POLL_INTERVAL_MS)
        self._timer.timeout.connect(self._on_tick)

        self._build_ui()
        self._rf_controls.mode.currentIndexChanged.connect(self._refresh_band_enabled)
        self._apply_stylesheet()
        self._reload_profiles(select_path=initial_profile or None)
        self._set_running(False)

    # --- UI construction ---------------------------------------------------
    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root = QtWidgets.QVBoxLayout(central)
        root.setContentsMargins(20, 18, 20, 14)
        root.setSpacing(14)

        # Run-control console (EVA-style neon panel, like the channel tiles).
        control_frame = ConsolePanel()
        control_layout = QtWidgets.QVBoxLayout(control_frame)
        control_layout.setContentsMargins(18, 20, 18, 12)
        control_layout.setSpacing(10)

        # Row 1: session state, run buttons, tools.
        self._status_lamp = StatusLamp()
        self._session_state = QtWidgets.QLabel("停止中")
        self._session_state.setObjectName("sessionState")
        self._session_state.setProperty("running", False)
        self._session_state.setMinimumWidth(96)
        self._session_glow = style_session_state(self._session_state)
        set_session_state_live(self._session_state, self._session_glow, False)

        self._start_button = QtWidgets.QPushButton("▶  受信開始")
        self._start_button.setObjectName("startButton")
        self._stop_button = QtWidgets.QPushButton("■  停止")
        self._stop_button.setObjectName("stopButton")
        for button in (self._start_button, self._stop_button):
            button.setCursor(QtCore.Qt.PointingHandCursor)
        self._start_button.setToolTip("選択中のプロファイルでSDRを開き、全チャンネルの受信・復号・音声再生・録音を始めます。")
        self._stop_button.setToolTip("受信を止めてSDRを解放します。録音中のデータは書き込んでから終了します。")
        self._start_button.clicked.connect(self.start_stack)
        self._stop_button.clicked.connect(self.stop_stack)
        # Receive band. Every entry is STD-T98 on the same raster, so switching
        # only retunes; while receiving it restarts the stack on the new band.
        self._band_combo = QtWidgets.QComboBox()
        self._band_combo.addItem("帯域：プロファイルの設定", None)
        for band in BANDS:
            self._band_combo.addItem(band.name, band.key)
        saved_band = self._settings.value("band", "", type=str)
        self._band_combo.setCurrentIndex(max(0, self._band_combo.findData(saved_band)) if saved_band in BANDS_BY_KEY else 0)
        self._band_combo.currentIndexChanged.connect(self._on_band_changed)
        self._band_combo.setToolTip(
            "受信する帯域を選びます（どれもデジタル簡易無線 STD-T98）。\n"
            "「プロファイルの設定」はプロファイルの周波数・チャンネル数をそのまま使います。\n"
            "465/468MHz の中継用はペア波で、どちらが中継機の送信側かは局によって異なります。\n"
            "受信中に切り替えると、受信を止めて新しい帯域で開き直します（数秒途切れます）。\n"
            "周波数補正はプロファイルの周波数で測った値をppmとして帯域に換算します。")
        self._band_session = None  # band the running session was started on
        self._services_only =QtWidgets.QCheckBox("サービスのみ")
        self._services_only.setToolTip("RF受信部を別に起動している場合に使います。\n復号・音声のサービスだけを起動します。")
        self._services_only.toggled.connect(self._update_preview)
        self._services_only.toggled.connect(self._refresh_squelch_controls_enabled)
        self._services_only.toggled.connect(self._refresh_gain_controls_enabled)
        self._show_debug = QtWidgets.QCheckBox("詳細メトリクス")
        self._show_debug.setToolTip("各サービスの内部の統計を表示します（不具合を調べるとき用）。")

        self._playback_button = QtWidgets.QPushButton("録音・再生…")
        self._playback_button.setToolTip("保存した録音を試聴するツールを開きます。\n"
                                         "シーク、鍵を指定しての秘話の聞き直し、再デコード、WAV保存ができます。")
        self._playback_button.clicked.connect(self._open_audio_playback)
        self._audio_settings_button = QtWidgets.QPushButton("音声設定…")
        self._audio_settings_button.clicked.connect(self._audio_controls.show)
        self._audio_settings_button.setToolTip("音量の自動調整、音切れの補間、自動録音、チャンネルごとの除外・優先・通知などを設定します。\n"
                                               "受信中の変更も約0.5秒で反映します。")
        self._settings_toggle = QtWidgets.QToolButton()
        self._settings_toggle.setText("設定")
        self._settings_toggle.setCheckable(True)
        self._settings_toggle.setChecked(True)
        self._settings_toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self._settings_toggle.setArrowType(QtCore.Qt.DownArrow)
        self._settings_toggle.toggled.connect(self._on_settings_toggled)
        self._settings_toggle.setToolTip("設定パネルの表示・非表示を切り替えます。受信を始めると自動で畳みます。")

        controls = QtWidgets.QHBoxLayout()
        controls.setSpacing(10)
        controls.addWidget(self._status_lamp)
        controls.addWidget(self._session_state)
        controls.addSpacing(6)
        controls.addWidget(rule())
        controls.addSpacing(6)
        controls.addWidget(self._start_button)
        controls.addWidget(self._stop_button)
        controls.addWidget(self._band_combo)
        controls.addWidget(self._services_only)
        self._services_only.hide()
        controls.addWidget(self._show_debug)
        self._show_debug.hide()
        controls.addStretch(1)
        controls.addWidget(self._playback_button)
        controls.addWidget(self._audio_settings_button)
        controls.addWidget(rule())
        controls.addWidget(self._settings_toggle)
        control_layout.addLayout(controls)

        # Row 2: squelch and volume. Live controls, so they stay outside the
        # collapsible Settings panel below and remain usable while receiving.
        squelch_row = QtWidgets.QHBoxLayout()
        squelch_row.setSpacing(10)
        squelch_row.addWidget(caption("SQUELCH"))
        self._squelch_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self._squelch_slider.setRange(*SQUELCH_RANGE_DB)
        self._squelch_slider.setValue(int(round(DEFAULT_SQUELCH_THRESHOLD)))
        self._squelch_slider.valueChanged.connect(self._on_squelch_changed)
        self._squelch_slider.setToolTip(
            "この強さ（dB）を超える電波が来たチャンネルだけを復調します。\n"
            "下げるほど弱い局も拾えますが、雑音を交信と取り違えやすくなり、CPU負荷も増えます。\n"
            "-100 にすると全チャンネルが常に開きます。受信中も変更できます。")
        squelch_row.addWidget(self._squelch_slider, 1)
        self._squelch_value_label = QtWidgets.QLabel(f"{int(round(DEFAULT_SQUELCH_THRESHOLD))} dB")
        self._squelch_value_label.setObjectName("squelchReadout")
        self._squelch_value_label.setMinimumWidth(86)
        self._squelch_value_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        squelch_row.addWidget(self._squelch_value_label)
        self._squelch_save_button = QtWidgets.QPushButton("保存")
        self._squelch_save_button.setToolTip("今のスケルチ値を選択中のプロファイルに保存し、次回からの初期値にします。")
        self._squelch_save_button.clicked.connect(self._save_squelch_to_profile)
        squelch_row.addWidget(self._squelch_save_button)
        squelch_row.addSpacing(8)
        squelch_row.addWidget(rule())
        squelch_row.addSpacing(8)
        self._live_volume = self._audio_controls.create_live_volume_control(control_frame)
        squelch_row.addWidget(self._live_volume, 1)
        control_layout.addLayout(squelch_row)
        root.addWidget(control_frame)

        # Collapsible settings panel: config picker, resolved preview, extra
        # backend args. Not needed while receiving, so it folds away on Start.
        self._settings_panel = QtWidgets.QWidget()
        panel = QtWidgets.QVBoxLayout(self._settings_panel)
        panel.setContentsMargins(0, 0, 0, 0)

        # Profile picker (layer B). A profile is a per-unit config file; the
        # (none) entry runs the backend's built-in defaults. New profiles are
        # copied from a device template; per-unit values live in the file.
        profile_row = QtWidgets.QHBoxLayout()
        self._profile_combo = QtWidgets.QComboBox()
        self._profile_combo.currentIndexChanged.connect(self._on_profile_selected)
        self._profile_combo.setToolTip("受信に使う設定ファイルを選びます（SDRの種類、周波数、チャンネル数、ゲイン、周波数補正）。\n"
                                       "受信中は変更できません。")
        self._new_profile_button = QtWidgets.QPushButton("機器から作成…")
        self._new_profile_button.clicked.connect(self._new_profile_from_device)
        self._new_profile_button.setToolTip("SDRの種類別のひな形から、この受信機用のプロファイルを作ります。")
        self._open_profile_button = QtWidgets.QPushButton("ファイルを開く…")
        self._open_profile_button.clicked.connect(self._open_other_profile)
        self._open_profile_button.setToolTip("別の場所にあるプロファイル（.toml）を開いて使います。")
        self._detect_button = QtWidgets.QPushButton("SDR を検出")
        self._detect_button.clicked.connect(self._detect_sdrs)
        self._detect_button.setToolTip("接続されているSDRを一覧表示します。\n他のプログラムがSDRを使っていて開けないときも、ここで分かります。")
        profile_row.addWidget(QtWidgets.QLabel("プロファイル"))
        profile_row.addWidget(self._profile_combo, 1)
        profile_row.addWidget(self._new_profile_button)
        profile_row.addWidget(self._open_profile_button)
        profile_row.addWidget(self._detect_button)
        self._manage_profile_button = QtWidgets.QToolButton()
        self._manage_profile_button.setText("管理")
        self._manage_profile_button.setPopupMode(QtWidgets.QToolButton.InstantPopup)
        self._manage_profile_button.setToolTip("選択中のプロファイルの名前変更・複製・削除をします。")
        manage_menu = QtWidgets.QMenu(self._manage_profile_button)
        manage_menu.setToolTipsVisible(True)
        self._rename_profile_action = manage_menu.addAction("名前を変更…", self._rename_profile)
        self._duplicate_profile_action = manage_menu.addAction("複製…", self._duplicate_profile)
        self._delete_profile_action = manage_menu.addAction("削除…", self._delete_profile)
        self._rename_profile_action.setToolTip("プロファイルフォルダ内のプロファイルだけ変更できます。")
        self._duplicate_profile_action.setToolTip("設定を引き継いだ新しいプロファイルを作ります（別の場所のファイルはプロファイルフォルダにコピー）。")
        self._delete_profile_action.setToolTip("プロファイルフォルダ内の .deleted へ移します。必要ならそこから戻せます。")
        self._manage_profile_button.setMenu(manage_menu)
        profile_row.addWidget(self._manage_profile_button)
        panel.addLayout(profile_row)

        # Which physical unit the profile uses (its calibration belongs to it).
        device_row = QtWidgets.QHBoxLayout()
        device_row.addWidget(QtWidgets.QLabel("使用する機器"))
        self._device_label = QtWidgets.QLabel()
        self._device_label.setToolTip("このプロファイルで開くSDRです。周波数補正はこの機器ごとの値です。")
        self._assign_device_button = QtWidgets.QPushButton("機器を割り当て…")
        self._assign_device_button.setToolTip("接続中のSDRから1台を選び、シリアル番号でこのプロファイルに結び付けます。\n"
                                              "同じ種類のSDRを複数つないでいても、その1台だけを使います。")
        self._assign_device_button.clicked.connect(self._assign_device)
        self._unassign_device_button = QtWidgets.QPushButton("割り当て解除")
        self._unassign_device_button.setToolTip("機器の指定をやめ、つながっている同じ種類の最初の1台を使います。")
        self._unassign_device_button.clicked.connect(self._unassign_device)
        device_row.addWidget(self._device_label, 1)
        device_row.addWidget(self._assign_device_button)
        device_row.addWidget(self._unassign_device_button)
        panel.addLayout(device_row)

        # The per-profile settings are grouped into tabs so the panel stays short.
        self._settings_tabs = QtWidgets.QTabWidget()
        self._settings_tabs.setDocumentMode(True)
        panel.addWidget(self._settings_tabs)

        def add_tab(title, tip):
            page = QtWidgets.QWidget()
            layout = QtWidgets.QVBoxLayout(page)
            layout.setContentsMargins(4, 10, 4, 4)
            index = self._settings_tabs.addTab(page, title)
            self._settings_tabs.setTabToolTip(index, tip)
            return layout

        tuner_tab = add_tab("アンテナ・ゲイン", "アンテナ端子、アンテナ給電、受信ゲインの設定です。")
        calib_tab = add_tab("周波数補正", "受信機の周波数のずれの補正と、受信中の交信からの推定値です。")
        rf_tab = add_tab("RF接続", "ローカル受信・IPクライアント・RFデータ配信サーバの切り替えと接続設定です。")
        detail_tab = add_tab("詳細", "実際に使われる設定の一覧と、上級者向けの追加引数です。")
        data_tab = add_tab('データ受信', 'π/4-DQPSK・RTCM3の受信・保存・解析オプションです。')
        self._dqpsk_controls = DqpskControls(self._settings, self)
        data_tab.addWidget(self._dqpsk_controls)
        self._setup_remote_rf(rf_tab, control_layout)
        # The tab already names the section, so drop the group box frame/title.
        self._rf_controls.setTitle("")
        self._rf_controls.setFlat(True)
        rf_tab.addStretch(1)

        # Per-unit calibration, stored in the selected profile file itself.
        calib_row = QtWidgets.QHBoxLayout()
        self._freq_err = QtWidgets.QLineEdit()
        self._freq_err.setPlaceholderText("(none)")
        self._freq_err.setMaximumWidth(120)
        self._freq_err.textChanged.connect(self._update_preview)
        self._freq_err.editingFinished.connect(self._save_calibration_to_profile)
        self._freq_err.setToolTip(FREQ_ERR_TIP)
        calib_row.addWidget(QtWidgets.QLabel("周波数補正"))
        calib_row.addWidget(self._freq_err)
        calib_row.addWidget(QtWidgets.QLabel("Hz ・選択中のプロファイルに保存"))
        calib_row.addStretch(1)
        calib_tab.addLayout(calib_row)

        # Receiver error measured from live transmissions (core.rf.freq_error).
        estimate_row = QtWidgets.QHBoxLayout()
        self._freq_estimate = QtWidgets.QLabel("推定ずれ: 受信中の交信から測定します")
        self._freq_estimate.setWordWrap(True)
        self._freq_estimate.setToolTip("交信中のチャンネルから測った、受信機の周波数のずれです（約5秒ごとに更新）。\n"
                                       "各局の送信機にも数十Hzのずれがあるので、3ch以上で測れているときの値が目安です。")
        self._freq_estimate_apply = QtWidgets.QPushButton("推定値を反映")
        self._freq_estimate_apply.setEnabled(False)
        self._freq_estimate_apply.clicked.connect(self._apply_freq_estimate)
        self._freq_estimate_apply.setToolTip("推定した補正値をプロファイルに保存します。次回の受信開始から反映します。")
        self._freq_estimate_state = None
        estimate_row.addWidget(self._freq_estimate, 1)
        estimate_row.addWidget(self._freq_estimate_apply)
        calib_tab.addLayout(estimate_row)

        # Automatic correction: the backend retunes to follow the estimate.
        auto_row = QtWidgets.QHBoxLayout()
        self._freq_auto = QtWidgets.QCheckBox("自動で補正する")
        self._freq_auto.setToolTip(FREQ_AUTO_TIP)
        self._freq_auto.toggled.connect(self._on_freq_auto_toggled)
        auto_row.addWidget(self._freq_auto)
        auto_row.addStretch(1)
        calib_tab.addLayout(auto_row)
        self._freq_auto_note = QtWidgets.QLabel(FREQ_AUTO_NOTE)
        self._freq_auto_note.setObjectName("cacheLabel")   # muted secondary text
        self._freq_auto_note.setWordWrap(True)
        self._freq_auto_note.setToolTip(FREQ_AUTO_TIP)
        calib_tab.addWidget(self._freq_auto_note)
        calib_tab.addStretch(1)

        antenna_row = QtWidgets.QHBoxLayout()
        antenna_row.addWidget(QtWidgets.QLabel("アンテナ端子"))
        self._antenna_combo = QtWidgets.QComboBox()
        self._antenna_combo.setEditable(True)
        self._antenna_combo.setMinimumWidth(140)
        self._antenna_combo.setToolTip("アンテナをつなぐ端子です。端子が1つの機器は「（機器の既定）」のままにします。\n"
                                       "一覧に無い名前も入力できます。機器に無い名前だと、受信開始時に使える名前を表示します。")
        self._antenna_combo.activated.connect(self._save_antenna)
        self._antenna_combo.lineEdit().editingFinished.connect(self._save_antenna)
        antenna_row.addWidget(self._antenna_combo)
        self._bias_tee = QtWidgets.QCheckBox("アンテナに給電（Bias Tee）")
        self._bias_tee.setToolTip("アンテナ端子に直流の電圧をかけ、外付けのLNAなどに電源を送ります。\n"
                                  "給電で動く機器をつないでいるときだけONにしてください。\n"
                                  "受信開始時に反映します。")
        self._bias_tee.toggled.connect(self._on_bias_tee_toggled)
        antenna_row.addWidget(self._bias_tee)
        antenna_row.addStretch(1)
        tuner_tab.addLayout(antenna_row)

        gain_row = QtWidgets.QHBoxLayout()
        gain_row.addWidget(QtWidgets.QLabel("ゲイン"))
        self._gain_auto = QtWidgets.QCheckBox("自動調整")
        self._gain_auto.toggled.connect(self._on_gain_changed)
        self._gain_auto.setToolTip("入力レベルを見てゲインを自動で調整します。\n強すぎて歪むときは下げ、弱いときは上げます。")
        gain_row.addWidget(self._gain_auto)
        self._gain_spin = QtWidgets.QSpinBox()
        self._gain_spin.setRange(0, 100)
        self._gain_spin.setSuffix(" dB")
        self._gain_spin.valueChanged.connect(self._on_gain_changed)
        self._gain_spin.setToolTip("受信感度（dB）。上げると弱い電波を拾えますが、強い電波で歪みやすくなります。\n"
                                   "「自動調整」がオフのときに使います。")
        gain_row.addWidget(self._gain_spin)
        self._hackrf_controls = HackRFGainControls()
        self._hackrf_controls.changed.connect(self._on_gain_changed)
        gain_row.addWidget(self._hackrf_controls)
        self._profile_driver = "rtlsdr"
        self._gain_save_button = QtWidgets.QPushButton("設定に保存")
        self._gain_save_button.clicked.connect(self._save_gain_to_profile)
        self._gain_save_button.setToolTip("今のゲイン設定をプロファイルに保存し、次回の開始値にします。")
        gain_row.addWidget(self._gain_save_button)
        gain_row.addStretch(1)
        tuner_tab.addLayout(gain_row)
        tuner_tab.addStretch(1)

        self._preview = QtWidgets.QPlainTextEdit()
        self._preview.setReadOnly(True)
        self._preview.setObjectName("preview")
        self._preview.setFixedHeight(150)
        self._preview.setLineWrapMode(QtWidgets.QPlainTextEdit.NoWrap)
        self._preview.setToolTip("選択中のプロファイルから、実際に使われる設定の一覧です。")
        detail_tab.addWidget(self._preview)
        self._preview_note = QtWidgets.QLabel("")
        self._preview_note.setObjectName("previewNote")
        self._preview_note.setWordWrap(True)
        detail_tab.addWidget(self._preview_note)

        backend_row = QtWidgets.QHBoxLayout()
        self._backend_args = QtWidgets.QLineEdit()
        self._backend_args.textChanged.connect(self._refresh_gain_controls_enabled)
        self._backend_args.setPlaceholderText("通常は空欄（例: --replay capture.cf32）")
        self._backend_args.setToolTip("上級者向け。RF受信部に渡す追加オプションです。\n"
                                      "例: --replay 録音.cf32 で、SDRの代わりにIQ録音を再生します。")
        backend_row.addWidget(QtWidgets.QLabel("追加引数"))
        backend_row.addWidget(self._backend_args, 1)
        detail_tab.addLayout(backend_row)

        self._settings_panel.setObjectName("settingsPanel")
        panel.setContentsMargins(14, 12, 14, 12)
        root.addWidget(self._settings_panel)

        # Process health strip
        self._process_badges = {}
        self._process_container = QtWidgets.QFrame()
        self._process_container.setObjectName("processStrip")
        self._process_row = QtWidgets.QHBoxLayout(self._process_container)
        self._process_row.setContentsMargins(2, 0, 2, 0)
        self._process_row.setSpacing(6)
        process_title = QtWidgets.QLabel("プロセス")
        process_title.setObjectName("processTitle")
        self._process_row.addWidget(process_title)
        self._process_row.addSpacing(4)
        self._process_row.addStretch(1)
        root.addWidget(self._process_container)
        self._process_container.hide()

        # Secret cache line
        self._cache_label = QtWidgets.QLabel("秘話キー解析: 無効")
        self._cache_label.setObjectName("cacheLabel")
        self._cache_label.setToolTip("この版では秘話キーの自動解析・探索は使用できません。")
        self._history_panel = QtWidgets.QFrame()
        self._history_panel.setObjectName("historyPanel")
        history_layout = QtWidgets.QVBoxLayout(self._history_panel)
        history_layout.setContentsMargins(14, 10, 14, 10)
        history_layout.setSpacing(8)
        section = QtWidgets.QHBoxLayout()
        section.setSpacing(10)
        section_title = QtWidgets.QLabel("チャンネル履歴")
        section_title.setObjectName("sectionTitle")
        section.addWidget(section_title)
        self._active_count = QtWidgets.QLabel("受信中  0 / 30")
        self._active_count.setObjectName("activeCount")
        section.addWidget(self._active_count)
        section.addStretch(1)
        section.addWidget(self._cache_label)
        history_layout.addLayout(section)
        self._detail_cards = QtWidgets.QToolButton()
        self._detail_cards.setCheckable(True)
        self._detail_cards.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self._detail_cards.setAutoRaise(True)
        self._detail_cards.setText("詳細カード")
        self._detail_cards.setToolTip("チャンネルごとの詳しい状態（受信・復号・音声・秘話鍵・CSM・SACCH）をカードで表示します。")

        # Cards follow the selected 30/97-channel profile; only RX OPEN is laid out.
        self._scroll = QtWidgets.QScrollArea()
        self._scroll.setObjectName("channelScroll")
        self._scroll.setWidgetResizable(True)
        # Hexagonal tiles in a honeycomb, placed by _layout_active_cards.
        self._grid_host = QtWidgets.QWidget()
        self._grid_host.setObjectName("gridHost")
        self._cards = []
        self._active_ids = ()
        self._visible_ids = ()
        self._recent_until = {}
        self._grid_width = None
        self._card_slots = HoneycombSlots()
        self._empty_state = QtWidgets.QFrame(self._grid_host)
        self._empty_state.setObjectName("emptyState")
        empty_layout = QtWidgets.QVBoxLayout(self._empty_state)
        empty_layout.setContentsMargins(30, 44, 30, 44)
        empty_layout.setSpacing(8)
        self._empty_title = QtWidgets.QLabel("受信待機中")
        self._empty_title.setObjectName("emptyTitle")
        self._empty_title.setAlignment(QtCore.Qt.AlignCenter)
        self._empty_hint = QtWidgets.QLabel("受信を開始すると、信号のあるチャンネルだけをここに表示します。")
        self._empty_hint.setObjectName("emptyHint")
        self._empty_hint.setAlignment(QtCore.Qt.AlignCenter)
        self._empty_hint.setWordWrap(True)
        empty_layout.addWidget(self._empty_title)
        empty_layout.addWidget(self._empty_hint)
        self._scroll.setWidget(self._grid_host)
        self._scroll.viewport().installEventFilter(self)
        self._waterfall = ChannelWaterfall()
        self._waterfall.set_columns([Column(card.channel_id, card.channel_id) for card in self._cards])
        self._waterfall.canvas.exclusion_toggled.connect(self._audio_controls.set_channel_excluded)
        self._waterfall.canvas.role_toggled.connect(self._audio_controls.set_channel_role)
        self._waterfall.canvas.bulk_role_toggled.connect(self._audio_controls.set_channels_role)
        self._waterfall.canvas.solo_cleared.connect(lambda: self._audio_controls.clear_role("solo"))
        self._audio_controls.channel_roles_changed.connect(self._refresh_channel_exclusions)
        self._refresh_channel_exclusions()
        self._spectrum = SpectrumView(self._settings)
        self._spectrum.attach_table(self._waterfall)
        self._spectrum.channel_clicked.connect(self._waterfall.canvas.select_channel)
        history_layout.addWidget(self._spectrum)
        history_layout.addWidget(self._waterfall)
        cards_bar = QtWidgets.QHBoxLayout()
        cards_bar.addWidget(self._detail_cards)
        cards_bar.addStretch(1)
        history_layout.addLayout(cards_bar)
        # The waterfall is fixed height; spare height goes to the tiles, or to
        # this filler while they are folded so the sections stay at the top.
        history_layout.addWidget(self._scroll)
        history_layout.addStretch(0)
        self._scroll.setMinimumHeight(TILE_HEIGHT // 2 + 8)
        root.addWidget(self._history_panel, 1)
        self._detail_cards.toggled.connect(self._on_detail_cards_toggled)
        self._on_detail_cards_toggled(self._settings.value("detail_cards_open", False, type=bool))
        self._waterfall.toggle.toggled.connect(self._on_waterfall_toggled)
        self._on_waterfall_toggled(self._settings.value("waterfall_open", True, type=bool))

        self._status_bar = self.statusBar()
        self._status_bar.showMessage("Stopped.")

    def _apply_stylesheet(self):
        self.setStyleSheet(
            """
            QWidget#gridHost { background: palette(window); }
            /* The run-control console paints and styles itself (ConsolePanel). */
            QWidget#settingsPanel, QFrame#historyPanel {
                border: 1px solid palette(mid); border-radius: 6px; background: #0f0d12;
            }
            QLabel#sectionTitle { font-size: 15px; font-weight: 700; color: #ffb45c; }
            QLabel#sectionEyebrow { font-size: 10px; font-weight: 700; }
            QLabel#activeCount {
                padding: 2px 10px; font-size: 12px; font-weight: 600; border-radius: 10px;
                border: 1px solid palette(midlight); background: palette(base);
            }
            QLabel#activeCount[live="true"] {
                color: #39ff88; border-color: #2a8a55; background: rgba(57,255,136,0.10);
            }
            QScrollArea#channelScroll { border: none; }
            /* Channel cards paint and style themselves (ChannelCard). */
            QFrame#emptyState {
                border: 1px dashed palette(mid); border-radius: 6px;
            }
            QLabel#emptyTitle { font-size: 19px; font-weight: 700; }
            QFrame#processChip {
                border: 1px solid palette(midlight); border-radius: 12px;
                background: palette(base);
            }
            QFrame#processChip[tone="starting"], QFrame#processChip[tone="warn"],
            QFrame#processChip[tone="stalled"] {
                border-color: #c99a2e; background: rgba(255,210,58,0.10);
            }
            QFrame#processChip[tone="exited"] {
                border-color: #ff3355; background: rgba(255,51,85,0.12);
            }
            QLabel#processDot { border-radius: 4px; background: #39ff88; }
            QLabel#processDot[tone="starting"], QLabel#processDot[tone="warn"],
            QLabel#processDot[tone="stalled"] { background: #ffd23a; }
            QLabel#processDot[tone="exited"] { background: #ff3355; }
            QLabel#processTitle { font-size: 11px; font-weight: 700; color: #9c8668; }
            QLabel#processName { font-weight: 600; }
            QLabel#processState { font-size: 11px; color: #ffd23a; }
            QLabel#processState[tone="exited"] { color: #ff5c77; font-weight: 700; }
            QLabel#processState[tone="stalled"] { font-weight: 700; }
            QLabel#cacheLabel { color: #9c8668; }
            QPlainTextEdit#preview { font-family: monospace; font-size: 11px; }
            QLabel#previewNote[level="error"] { color: #ff5c77; font-weight: 600; }
            QLabel#previewNote[level="warn"] { color: #ffd23a; font-weight: 600; }
            """
        )

    # --- lifecycle ---------------------------------------------------------
    def _set_running(self, running):
        self._dqpsk_controls.set_running(running)
        self._running = running
        self._session_state.setText("受信中" if running else "停止中")
        self._session_state.setProperty("running", running)
        set_session_state_live(self._session_state, self._session_glow, running)
        self._status_lamp.set_live(running)
        self.centralWidget().findChild(ConsolePanel).set_live(running)
        self._update_empty_state()
        self._start_button.setEnabled(not running)
        self._stop_button.setEnabled(running)
        self._rf_controls.set_running(running)
        self._on_rf_mode_changed()
        if not running:
            self._rf_status.reset('IP配信・受信：停止中')
        elif self._rf_controls.mode.currentData() == 'server':
            self._rf_status.reset('RFサーバを起動中…')
            self._session_state.setText('RF配信中')
        elif self._rf_controls.mode.currentData() == 'client':
            self._rf_status.reset('IQ配信へ接続中…')
        self._services_only.setEnabled(not running)
        self._backend_args.setEnabled(not running)
        self._profile_combo.setEnabled(not running)
        self._new_profile_button.setEnabled(not running)
        self._open_profile_button.setEnabled(not running)
        self._detect_button.setEnabled(not running)
        self._refresh_profile_tools()
        self._refresh_freq_field_enabled()
        self._refresh_squelch_controls_enabled()
        self._refresh_gain_controls_enabled()
        self._refresh_band_enabled()

    def _refresh_band_enabled(self, *_):
        # An IP client receives whatever band the server tunes.
        self._band_combo.setEnabled(self._rf_controls.mode.currentData() != "client")

    def _on_waterfall_toggled(self, opened):
        """Collapsing the waterfall hands its height to the honeycomb tiles."""
        self._waterfall.set_open(opened)
        self._settings.setValue("waterfall_open", opened)

    def _on_detail_cards_toggled(self, opened):
        self._detail_cards.setChecked(opened)
        self._detail_cards.setArrowType(QtCore.Qt.DownArrow if opened else QtCore.Qt.RightArrow)
        self._scroll.setVisible(opened)
        self._settings.setValue("detail_cards_open", opened)
        layout = self._history_panel.layout()
        layout.setStretchFactor(self._scroll, 1 if opened else 0)
        layout.setStretch(layout.count() - 1, 0 if opened else 1)  # the trailing filler

    # --- settings panel ----------------------------------------------------
    def _on_settings_toggled(self, checked):
        self._settings_panel.setVisible(checked)
        self._settings_toggle.setArrowType(
            QtCore.Qt.DownArrow if checked else QtCore.Qt.RightArrow
        )

    # --- profiles (layer B: per-unit config files) ------------------------
    def _current_profile_path(self):
        """Selected profile path (str), or None for built-in defaults."""
        return self._profile_combo.currentData()

    def _append_profile_item(self, path):
        self._profile_combo.addItem(f"{Path(path).stem} (external)", str(path))

    def _reload_profiles(self, select_path=None):
        self._syncing_profile = True
        self._profile_combo.clear()
        self._profile_combo.addItem("(none — built-in defaults)", None)
        for profile in list_profiles():
            self._profile_combo.addItem(profile.name, str(profile.path))
        for path in self._external_profiles:
            self._append_profile_item(path)
        self._syncing_profile = False
        self._select_profile_path(select_path)

    def _select_profile_path(self, path):
        target = os.path.abspath(os.path.expanduser(path)) if path else ""
        index = 0  # "(none)"
        for candidate in range(1, self._profile_combo.count()):
            data = self._profile_combo.itemData(candidate)
            if data and target and os.path.abspath(data) == target:
                index = candidate
                break
        else:
            # A path outside the profiles dir: list it as an external entry.
            if target and os.path.exists(target):
                known = {os.path.abspath(p) for p in self._external_profiles}
                if target not in known:
                    self._external_profiles.append(target)
                    self._append_profile_item(target)
                    index = self._profile_combo.count() - 1
        self._syncing_profile = True
        self._profile_combo.setCurrentIndex(index)
        self._syncing_profile = False
        self._on_profile_changed()

    def _on_profile_selected(self, _index):
        if self._syncing_profile:
            return
        self._on_profile_changed()

    def _on_band_changed(self, _index):
        band_key = self._band_combo.currentData()
        self._settings.setValue("band", band_key or "")
        if self._running and self.supervisor is not None:
            # The flowgraph's raster is fixed at start: reopen on the new band.
            self.stop_stack()
            self._rebuild_channel_cards(self._current_profile_path())
            self.start_stack()
            return
        self._rebuild_channel_cards(self._current_profile_path())
        self._update_preview()

    def _band_backend_args(self):
        band_key = self._band_combo.currentData()
        return ["--band", band_key] if band_key else []

    def _profile_freq_scale(self, band_key):
        """Band Hz per profile Hz of calibration (see backend_config.apply_band)."""
        path = self._current_profile_path()
        try:
            config = load_config_file(path) if path else BackendConfig()
        except (OSError, ValueError):
            return 1.0
        return band_freq_scale(config, band_key)

    def _on_profile_changed(self):
        path = self._current_profile_path()
        self._rebuild_channel_cards(path)
        offset = read_freq_err_offset(path) if path else None
        # Programmatic setText fires textChanged (-> preview), not editingFinished,
        # so mirroring the file into the field does not write it straight back.
        self._freq_err.setText("" if offset is None else f"{offset:g}")
        self._freq_auto.blockSignals(True)
        self._freq_auto.setChecked(bool(read_sdr_settings(path).get("freq_auto")) if path else False)
        self._freq_auto.blockSignals(False)

        squelch = read_squelch_threshold(path) if path else None
        # blockSignals so seeding the slider from the file does not push a
        # live control message (there is nothing running to push to anyway,
        # since the profile combo is disabled while the stack is running).
        self._squelch_slider.blockSignals(True)
        self._squelch_slider.setValue(
            int(round(squelch if squelch is not None else DEFAULT_SQUELCH_THRESHOLD))
        )
        self._squelch_slider.blockSignals(False)
        self._squelch_value_label.setText(f"{self._squelch_slider.value()} dB")

        auto_gain, tuner_gain, driver, hardware_agc = (
            read_gain_settings(path) if path else (None, None, None, True)
        )
        self._profile_driver = driver or "rtlsdr"
        self._gain_auto.blockSignals(True)
        self._gain_spin.blockSignals(True)
        self._gain_auto.setChecked(
            bool(auto_gain) if auto_gain is not None
            else (self._effective_gain_driver() == "hackrf" or bool(hardware_agc))
        )
        self._gain_spin.setValue(int(round(tuner_gain if tuner_gain is not None else 30)))
        self._gain_auto.blockSignals(False)
        self._gain_spin.blockSignals(False)
        try:
            gains = read_hackrf_gain_settings(path) if path else HackRFGains()
        except (OSError, ValueError):
            gains = HackRFGains()
        self._hackrf_controls.set_gains(gains)
        self._hackrf_controls.current.setText("開始時の設定値。受信開始後に現在値を表示します。")
        self._show_profile_device(path)

        self._refresh_profile_tools()
        self._refresh_freq_field_enabled()
        self._refresh_squelch_controls_enabled()
        self._refresh_gain_controls_enabled()
        self._update_preview()

    def _refresh_channel_exclusions(self):
        controls = self._audio_controls
        self._waterfall.canvas.set_excluded(controls.channel_ids("exclude"))
        self._waterfall.canvas.set_roles(controls.channel_ids("solo"), controls.channel_ids("priority"),
                                         controls.channel_ids("notify"), controls.channel_ids("mute"))

    def _rebuild_channel_cards(self, profile_path):
        try:
            config = load_config_file(profile_path) if profile_path else BackendConfig()
        except (OSError, ValueError):
            config = BackendConfig()
        band_key = self._band_combo.currentData()
        if band_key:
            config = apply_band(config, band_key)

        channelizer = config.channelizer
        # Same raster as channel_frequencies(): exclusions are matched by frequency.
        tuned = config.sdr.center_freq + config.sdr.freq_offset
        self._audio_controls.set_channel_frequencies({
            index + 1: round(tuned + (index - channelizer.num_channels // 2) * channelizer.channel_spacing)
            for index in range(channelizer.num_channels)})
        band = band_for_raster(config.sdr.center_freq, channelizer.channel_spacing, channelizer.num_channels)
        columns = [Column(info.slot_id, info.channel_number, info.group, info.frequency_hz)
                   for info in band.channels] if band else [
                       Column(index + 1, index + 1,
                              frequency_hz=config.sdr.center_freq +
                              (index - channelizer.num_channels // 2) * channelizer.channel_spacing)
                       for index in range(channelizer.num_channels)]
        plan_key = band.key if band else None
        if len(self._cards) == channelizer.num_channels and getattr(self, "_plan_key", None) == plan_key:
            self._waterfall.set_columns(columns)
            return

        for card in self._cards:
            card.hide()
            card.deleteLater()
        self._cards = []
        self._active_ids = ()
        self._visible_ids = ()
        self._recent_until.clear()
        self._grid_width = None
        self._card_slots.clear()
        self._plan_key = plan_key
        for index in range(channelizer.num_channels):
            channel_id = index + 1
            title = None
            if band:
                info = band.channels[index]
                title = f"{info.display}  {info.frequency_hz / 1e6:.5f} MHz"
            card = ChannelCard(channel_id, title=title, parent=self._grid_host)
            card.call_stat_verified = call_stat_verified(columns[index].frequency_hz)
            self._cards.append(card)
            card.hide()
        self._waterfall.set_columns(columns)
        self._active_count.setText(f"受信中  0 / {len(self._cards)}")
        self._layout_active_cards(())

    def _refresh_freq_field_enabled(self):
        # Calibration lives in the profile file, so it needs a selected profile.
        has_profile = self._current_profile_path() is not None
        local_radio = self._rf_controls.mode.currentData() != "client"
        self._freq_err.setEnabled((not self._running) and has_profile and local_radio)
        # Switchable while receiving; an IP client's error belongs to the server.
        self._freq_auto.setEnabled(has_profile and local_radio)
        self._freq_err.setToolTip(FREQ_ERR_TIP if has_profile else "プロファイルを作成するか開くと、補正値を保存できます。")

    def _refresh_squelch_controls_enabled(self):
        # The slider stays live (and enabled) while running -- that is the
        # whole point -- but it needs a managed backend to have any effect.
        # Frame delivery demodulates on the server: squelch lives there only.
        mode = self._rf_controls.mode.currentData()
        frames = self._rf_controls.iq_format.currentData() == "frames"
        if mode == "server":
            manages_backend = frames
        elif mode == "client":
            manages_backend = (not self._services_only.isChecked()
                               and getattr(self, "_remote_format", None) != FRAME_FORMAT)
        else:
            manages_backend = not self._services_only.isChecked()
        self._squelch_slider.setEnabled(manages_backend)
        has_profile = self._current_profile_path() is not None
        self._squelch_save_button.setEnabled(manages_backend and has_profile)
        self._squelch_save_button.setToolTip(
            "今のスケルチ値を選択中のプロファイルに保存し、次回からの初期値にします。"
            if has_profile else "プロファイルを作成するか開くと、スケルチ値を保存できます。"
        )

    def _on_squelch_changed(self, value):
        self._squelch_value_label.setText(f"{value} dB")
        if self._running and self.supervisor is not None:
            self.supervisor.set_squelch(float(value))

    # --- profile management, device assignment, antenna -------------------
    def _refresh_profile_tools(self):
        if not hasattr(self, "_manage_profile_button"):
            return
        path = self._current_profile_path()
        has_profile = path is not None
        managed = has_profile and is_managed_profile(path)
        local = self._rf_controls.mode.currentData() != "client"
        idle = not self._running
        self._manage_profile_button.setEnabled(idle and has_profile)
        self._rename_profile_action.setEnabled(managed)
        self._delete_profile_action.setEnabled(managed)
        self._duplicate_profile_action.setEnabled(has_profile)
        self._assign_device_button.setEnabled(idle and has_profile and local)
        self._unassign_device_button.setEnabled(idle and has_profile and local and self._profile_serial is not None)
        for widget in (self._antenna_combo, self._bias_tee):
            widget.setEnabled(idle and has_profile and local)

    def _show_profile_device(self, path):
        settings = read_sdr_settings(path) if path else {}
        driver = settings.get("driver") or "rtlsdr"
        self._profile_serial = device_serial(settings.get("device_args"))
        self._device_label.setText(f"{driver}・シリアル {self._profile_serial}" if self._profile_serial
                                   else f"{driver}（つながっている最初の1台）" if path else "既定の設定（機器は指定なし）")
        antenna = settings.get("antenna")
        self._antenna_combo.blockSignals(True)
        self._antenna_combo.clear()
        self._antenna_combo.addItem(DEFAULT_ANTENNA_TEXT)
        self._antenna_combo.addItems(KNOWN_ANTENNAS.get(driver, []))
        if antenna and self._antenna_combo.findText(antenna) < 0:
            self._antenna_combo.addItem(antenna)
        self._antenna_combo.setCurrentText(antenna or DEFAULT_ANTENNA_TEXT)
        self._antenna_combo.blockSignals(False)
        self._bias_tee.blockSignals(True)
        self._bias_tee.setChecked(bool(settings.get("bias_tee")))
        self._bias_tee.blockSignals(False)

    def _save_antenna(self, *_):
        path = self._current_profile_path()
        if path is None:
            return
        text = self._antenna_combo.currentText().strip()
        value = None if text in ("", DEFAULT_ANTENNA_TEXT) else text
        if read_sdr_settings(path).get("antenna") == value:
            return
        write_sdr_value(path, "antenna", value)
        self._update_preview()

    def _on_bias_tee_toggled(self, checked):
        path = self._current_profile_path()
        if path is None:
            return
        if checked:
            answer = QtWidgets.QMessageBox.warning(
                self, "アンテナへの給電",
                "アンテナ端子に直流の電圧をかけます。\n"
                "給電で動く外付けLNAなどをつないでいるときだけONにしてください。\n"
                "直流的にショートしているアンテナや機器では、故障の原因になることがあります。\n\n"
                "ONにしますか？",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if answer != QtWidgets.QMessageBox.Yes:
                self._bias_tee.blockSignals(True)
                self._bias_tee.setChecked(False)
                self._bias_tee.blockSignals(False)
                return
        write_sdr_value(path, "bias_tee", True if checked else None)
        self._update_preview()

    def _assign_device(self):
        path = self._current_profile_path()
        if path is None:
            return
        settings = read_sdr_settings(path)
        driver = settings.get("driver") or "rtlsdr"
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            devices, error = detect_sdrs()
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()
        if devices is None:
            QtWidgets.QMessageBox.warning(self, "機器を割り当て", error)
            return
        candidates = [device for device in devices if device.driver == driver and device.serial]
        if not candidates:
            QtWidgets.QMessageBox.information(
                self, "機器を割り当て",
                f"このプロファイルの種類（{driver}）で、シリアル番号を持つ機器が見つかりません。\n"
                "接続と、他のプログラムが使っていないかを確認してください。" + (f"\n\n{error}" if error else ""))
            return
        labels = [f"{device.label or device.driver}  シリアル {device.serial}" for device in candidates]
        choice, ok = QtWidgets.QInputDialog.getItem(self, "機器を割り当て", "このプロファイルで使う機器:", labels, 0, False)
        if not ok:
            return
        serial = candidates[labels.index(choice)].serial
        previous = self._profile_serial
        assign_device(path, serial)
        self._show_profile_device(path)
        self._refresh_profile_tools()
        self._update_preview()
        offset = read_freq_err_offset(path)
        if previous and previous != serial and offset:
            QtWidgets.QMessageBox.information(
                self, "周波数補正",
                f"今の周波数補正（{offset:+g} Hz）は、前の機器（シリアル {previous}）の値です。\n"
                "この機器で受信して「推定値を反映」で測り直してください。")
        self._status_bar.showMessage(f"シリアル {serial} の機器をプロファイルに割り当てました。")

    def _unassign_device(self):
        path = self._current_profile_path()
        if path is None:
            return
        assign_device(path, None)
        self._show_profile_device(path)
        self._refresh_profile_tools()
        self._update_preview()

    def _ask_profile_name(self, title, default):
        name, ok = QtWidgets.QInputDialog.getText(self, title, "プロファイル名:", text=default)
        return name.strip() if ok else None

    def _rename_profile(self):
        path = self._current_profile_path()
        if path is None or not is_managed_profile(path):
            return
        name = self._ask_profile_name("名前を変更", Path(path).stem)
        if not name or name == Path(path).stem:
            return
        try:
            dest = rename_profile(path, name)
        except (ValueError, OSError) as exc:
            QtWidgets.QMessageBox.warning(self, "名前を変更", str(exc))
            return
        self._reload_profiles(select_path=str(dest))

    def _duplicate_profile(self):
        path = self._current_profile_path()
        if path is None:
            return
        name = self._ask_profile_name("複製", f"{Path(path).stem}-コピー")
        if not name:
            return
        try:
            dest = duplicate_profile(path, name)
        except (ValueError, OSError) as exc:
            QtWidgets.QMessageBox.warning(self, "複製", str(exc))
            return
        self._reload_profiles(select_path=str(dest))

    def _delete_profile(self):
        path = self._current_profile_path()
        if path is None or not is_managed_profile(path):
            return
        answer = QtWidgets.QMessageBox.question(
            self, "削除", f"プロファイル「{Path(path).stem}」を削除しますか？\n"
            "プロファイルフォルダ内の .deleted へ移すので、後から戻せます。")
        if answer != QtWidgets.QMessageBox.Yes:
            return
        try:
            moved = delete_profile(path)
        except OSError as exc:
            QtWidgets.QMessageBox.warning(self, "削除", str(exc))
            return
        self._reload_profiles(select_path=None)
        self._status_bar.showMessage(f"削除しました（{moved} へ移動）。")

    def _effective_gain_driver(self):
        driver = self._profile_driver
        try:
            extra = shlex.split(self._backend_args.text().strip())
        except ValueError:
            extra = []
        for index, value in enumerate(extra):
            if value == "--driver" and index + 1 < len(extra):
                driver = extra[index + 1]
            elif value.startswith("--driver="):
                driver = value.split("=", 1)[1]
        if self._profile_serial:
            return driver
        return os.environ.get("STD_T98_SDR_DRIVER", "").strip() or driver

    def _gain_backend_args(self):
        auto = self._gain_auto.isChecked()
        if self._effective_gain_driver() == "hackrf":
            gains = self._hackrf_controls.gains()
            return ["--auto-gain" if auto else "--manual-gain", "--no-agc",
                    "--lna-gain", str(gains.lna), "--vga-gain", str(gains.vga),
                    "--amp" if gains.amp else "--no-amp"]
        return ["--auto-gain" if auto else "--manual-gain",
                "--agc" if auto else "--no-agc", "--gain", str(self._gain_spin.value())]

    def _refresh_gain_controls_enabled(self):
        managed = not self._services_only.isChecked() and self._rf_controls.mode.currentData() != "client"
        hackrf = self._effective_gain_driver() == "hackrf"
        self._hackrf_controls.setVisible(hackrf)
        self._gain_spin.setVisible(not hackrf)
        self._hackrf_controls.set_manual_enabled(managed and not self._gain_auto.isChecked())
        self._gain_auto.setEnabled(managed)
        self._gain_spin.setEnabled(managed and not self._gain_auto.isChecked())
        self._gain_save_button.setEnabled(managed and self._current_profile_path() is not None)

    def _on_gain_changed(self, _value=None):
        self._refresh_gain_controls_enabled()
        if self._running and self.supervisor is not None:
            if self._effective_gain_driver() == "hackrf":
                gains = self._hackrf_controls.gains()
                self.supervisor.set_hackrf_gain(self._gain_auto.isChecked(), int(gains.lna), int(gains.vga), gains.amp)
            else:
                self.supervisor.set_gain(self._gain_auto.isChecked(), float(self._gain_spin.value()))

    def _save_gain_to_profile(self):
        path = self._current_profile_path()
        if path is None:
            return
        try:
            gains = self._hackrf_controls.gains() if self._effective_gain_driver() == "hackrf" else None
            write_gain_settings(path, self._gain_auto.isChecked(),
                                gains.total_db if gains else self._gain_spin.value(), gains)
        except OSError as exc:
            QtWidgets.QMessageBox.warning(self, "Save gain", f"Could not write to profile:\n{exc}")
            return
        self._update_preview()

    def _save_squelch_to_profile(self):
        path = self._current_profile_path()
        if path is None:
            return
        try:
            write_squelch_threshold(path, float(self._squelch_slider.value()))
        except OSError as exc:
            QtWidgets.QMessageBox.warning(self, "Save squelch", f"Could not write to profile:\n{exc}")
            return
        self._update_preview()

    def _new_profile_from_device(self):
        presets = list_device_presets(self.repo_root / "devices")
        if not presets:
            QtWidgets.QMessageBox.warning(self, "New profile", "No device templates in devices/.")
            return
        names = [preset.name for preset in presets]
        choice, ok = QtWidgets.QInputDialog.getItem(
            self, "New profile", "Device template:", names, 0, False
        )
        if not ok:
            return
        preset = presets[names.index(choice)]
        name, ok = QtWidgets.QInputDialog.getText(
            self, "New profile", "Profile name:", text=Path(preset.path).stem
        )
        name = name.strip()
        if not ok or not name:
            return
        try:
            dest = create_profile(preset.path, name)
        except FileExistsError:
            resp = QtWidgets.QMessageBox.question(
                self, "Overwrite?", f"A profile named '{name}' exists. Overwrite it?"
            )
            if resp != QtWidgets.QMessageBox.Yes:
                return
            (profiles_dir() / f"{name}.toml").unlink()
            dest = create_profile(preset.path, name)
        self._reload_profiles(select_path=str(dest))

    def _open_other_profile(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Open profile", str(profiles_dir()), "TOML config (*.toml);;All files (*)"
        )
        if path:
            self._reload_profiles(select_path=path)

    def _show_freq_estimate(self, state):
        self._freq_estimate_state = state
        channels = int(state["channels"])
        note = "" if channels >= 3 else "（局が少ないため送信機自体のずれを含みます）"
        auto = ""
        if state.get("auto"):
            auto = (f"\n自動補正中: 適用 {state['applied_hz']:+.0f} Hz・"
                    f"補正 {int(state.get('corrections', 0))} 回")
        self._freq_estimate.setText(
            f"推定ずれ {state['estimate_hz']:+.0f} Hz（{channels}ch・{int(state['samples'])}回・"
            f"ch間の幅 {state['spread_hz']:.0f} Hz）→ 補正値 "
            f"{int(round(state['suggested_hz'] / self._profile_freq_scale(self._band_session))):+d} Hz{note}{auto}")
        self._freq_estimate_apply.setEnabled(self._current_profile_path() is not None)

    def _on_freq_auto_toggled(self, enabled):
        path = self._current_profile_path()
        if path is not None:
            try:
                write_sdr_value(path, "freq_auto", True if enabled else None)
            except OSError as exc:
                QtWidgets.QMessageBox.warning(self, "周波数補正", f"プロファイルに保存できませんでした:\n{exc}")
        if self._running and self.supervisor is not None:
            self.supervisor.set_freq_auto(bool(enabled))
        self._update_preview()

    def _save_auto_correction(self):
        """On stop: keep the last automatically applied correction for next time."""
        state = self._freq_estimate_state
        path = self._current_profile_path()
        if not state or not state.get("auto") or path is None:
            return
        # The session measured on its band; the profile keeps its own frequency's Hz.
        applied = int(round(state["applied_hz"] / self._profile_freq_scale(self._band_session)))
        if read_freq_err_offset(path) == applied:
            return
        try:
            write_freq_err_offset(path, applied)
        except OSError:
            return
        self._freq_err.setText(f"{applied}")
        self._status_bar.showMessage(f"自動補正の値 {applied:+d} Hz をプロファイルに保存しました。")

    def _apply_freq_estimate(self):
        state = self._freq_estimate_state
        if state is None or self._current_profile_path() is None:
            return
        suggested = int(round(state["suggested_hz"] / self._profile_freq_scale(self._band_session)))
        self._freq_err.setText(f"{suggested}")
        self._save_calibration_to_profile()
        self._status_bar.showMessage(
            f"周波数補正を {suggested} Hz に保存しました。次回の受信開始から反映されます。")

    def _parse_freq_err(self):
        """Field value as a float, or None if empty. Raises ValueError if invalid."""
        text = self._freq_err.text().strip()
        if not text:
            return None
        return float(text)

    def _save_calibration_to_profile(self):
        path = self._current_profile_path()
        if path is None:
            return
        try:
            value = self._parse_freq_err()
        except ValueError:
            return  # invalid text: leave the file untouched
        try:
            write_freq_err_offset(path, value)
        except OSError as exc:
            QtWidgets.QMessageBox.warning(self, "Save calibration", f"Could not write to profile:\n{exc}")
            return
        self._update_preview()

    def _update_preview(self):
        # In services-only mode the RF backend is started elsewhere, so the
        # config here is irrelevant -- say so instead of resolving it.
        if self._services_only.isChecked():
            self._preview.setPlainText("Services only — the RF backend (and its config) is started separately.")
            self._preview_note.setText("")
            return

        try:
            override = self._parse_freq_err()
            freq_err_note = ""
        except ValueError:
            override = None
            freq_err_note = "Freq err offset must be a number."

        preview = preview_config(self._current_profile_path() or "", freq_err_offset_override=override,
                                 band=self._band_combo.currentData())
        if freq_err_note:
            self._preview.setPlainText(preview.summary)
            self._preview_note.setText(freq_err_note)
            self._preview_note.setProperty("level", "warn")
            self._preview_note.style().unpolish(self._preview_note)
            self._preview_note.style().polish(self._preview_note)
            return
        if not preview.ok:
            self._preview.setPlainText("")
            self._preview_note.setText(preview.error)
            self._preview_note.setProperty("level", "error")
        else:
            self._preview.setPlainText(preview.summary)
            if preview.warnings:
                self._preview_note.setText("⚠ " + "\n⚠ ".join(preview.warnings))
                self._preview_note.setProperty("level", "warn")
            else:
                self._preview_note.setText("")
                self._preview_note.setProperty("level", "ok")
        self._preview_note.style().unpolish(self._preview_note)
        self._preview_note.style().polish(self._preview_note)

    def _detect_sdrs(self):
        devices, error = detect_sdrs()
        if devices is None:
            QtWidgets.QMessageBox.warning(self, "Detect SDRs", error)
            return
        if not devices:
            QtWidgets.QMessageBox.information(
                self, "Detect SDRs", error or "No SoapySDR devices found."
            )
            return

        lines = []
        for device in devices:
            bits = [f"driver={device.driver}"]
            if device.label:
                bits.append(f"label={device.label}")
            if device.serial:
                bits.append(f"serial={device.serial}")
            lines.append("  • " + "  ".join(bits))

        # Tell the user whether the selected profile's driver is present.
        note = ""
        path = self._current_profile_path()
        if path:
            config = preview_config(path)
            if config.ok:
                driver = config.summary.splitlines()[0].split("driver=")[-1].split(",")[0]
                present = {device.driver for device in devices}
                if driver in present:
                    note = f"\nProfile driver '{driver}' is connected."
                else:
                    note = (
                        f"\n⚠ Profile driver '{driver}' is NOT among the connected devices "
                        f"({', '.join(sorted(present))})."
                    )

        QtWidgets.QMessageBox.information(
            self, "Detected SDRs", "\n".join(lines) + note
        )

    def _open_audio_playback(self):
        interpreter = self.supervisor.service_python if self.supervisor else None
        self._audio_controls.launch_playback(interpreter)

    def start_stack(self):
        if self.supervisor is not None:
            return
        try:
            mode, host, port, token, limit = self._rf_controls.settings()
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(self, 'RF接続', str(exc))
            return
        if mode == 'client' and self._remote_profile is None:
            self._start_rf_probe(host, port, token)
            return

        try:
            extra_args = shlex.split(self._backend_args.text().strip())
        except ValueError as exc:
            QtWidgets.QMessageBox.warning(self, "Backend args", f"Could not parse backend args: {exc}")
            return

        services_only = self._services_only.isChecked() and mode == "local"
        backend_args = list(extra_args)
        if not services_only and mode != "client":
            try:
                self._parse_freq_err()  # validate before writing / starting
            except ValueError:
                QtWidgets.QMessageBox.warning(
                    self, "Cannot start", "Freq err offset must be a number (Hz), or empty."
                )
                return

            # The slider is a plain CLI override (not written to the profile
            # unless Save is clicked), so Start always uses exactly what it
            # shows, whether or not that has been persisted yet.
            squelch_args = ["--squelch", str(self._squelch_slider.value())]
            gain_args = [*self._gain_backend_args(), *self._band_backend_args()]

            path = self._current_profile_path()
            if path is not None:
                if not os.path.exists(os.path.expanduser(path)):
                    QtWidgets.QMessageBox.critical(
                        self, "Cannot start", f"Profile not found:\n{path}"
                    )
                    return
                # The profile file is the source of truth: fold the field into it,
                # then the backend reads the calibration from --config.
                self._save_calibration_to_profile()
                backend_args = ["--config", str(path), *squelch_args, *gain_args, *extra_args]
                self._settings.setValue("profile_path", str(path))
            else:
                backend_args = [*squelch_args, *gain_args, *extra_args]
                self._settings.setValue("profile_path", "")

        # Use the SDR run_gui.bat detected, overriding the profile's driver so a
        # connected HackRF still works even if a USRP/RTL profile is selected.
        # A CLI --driver wins over the --config file's driver.
        # A profile tied to one unit (serial) keeps its own driver.
        sdr_driver = os.environ.get("STD_T98_SDR_DRIVER", "").strip()
        if sdr_driver and mode != "client" and not self._profile_serial:
            backend_args = [*backend_args, "--driver", sdr_driver]

        # This distribution always excludes privacy-key analysis.
        remote_args = self._rf_start_arguments(mode, host, port, token, limit)
        backend_args = remote_args + extra_args if mode == 'client' else backend_args + remote_args
        if mode != 'client' and not services_only:
            import argparse
            from core.rf.backend_config import add_config_arguments, load_config
            from core.rf.remote_iq import stream_metadata
            parser = argparse.ArgumentParser(add_help=False)
            add_config_arguments(parser)
            config_args, _ = parser.parse_known_args(backend_args)
            self._set_remote_columns(stream_metadata(load_config(config_args)))
        if not self._rf_controls.correct.isChecked():
            backend_args.append('--no-correct-iq')
        try:
            data_args = self._dqpsk_controls.backend_args()
            if data_args and (services_only or mode == 'server'):
                raise ValueError('データ解析はローカル受信またはIQ配信クライアントで有効にしてください。')
            if data_args and mode == 'client' and getattr(self, '_remote_format', None) == FRAME_FORMAT:
                raise ValueError('復調済みフレーム配信にはDQPSK用IQがありません。IQ配信を使用してください。')
            if data_args:
                import argparse
                from core.rf.backend_config import add_config_arguments, load_config, derive_rates
                from core.rf.dqpsk_options import parse_frequencies, validate_bandwidth
                parser = argparse.ArgumentParser(add_help=False)
                add_config_arguments(parser)
                config_args, _ = parser.parse_known_args(backend_args)
                data_config = load_config(config_args)
                validate_bandwidth(parse_frequencies(self._dqpsk_controls.frequencies.text()),
                                   data_config.sdr.center_freq + data_config.sdr.freq_offset,
                                   derive_rates(data_config.sdr, data_config.channelizer).samp_rate_post_resamp1)
            backend_args.extend(data_args)
        except (ValueError, OSError) as exc:
            QtWidgets.QMessageBox.warning(self, 'データ受信', str(exc))
            return
        no_secret = True  # Privacy-key analysis is disabled in this distribution.
        try:
            if mode != "server" and not self._audio_controls.configure_backend(backend_args):
                return
        except (ValueError, OSError) as exc:
            QtWidgets.QMessageBox.warning(self, "音声設定", str(exc))
            return
        supervisor = StackSupervisor(
            repo_root=self.repo_root,
            services_only=services_only,
            backend_args=backend_args,
            channel_count=len(self._cards),
            no_secret=no_secret,
            rf_mode=mode,
            rf_token=token,
            audio_args=("--audio-settings", str(self._audio_controls.settings_path),
                        "--record-dir", str(self._audio_controls.data_dir)),
        )

        try:
            supervisor.resolve()
        except RuntimeError as exc:
            # The most common first-run failure: a missing interpreter/import.
            # The supervisor's message names exactly what was searched.
            self._clear_remote_profile()
            QtWidgets.QMessageBox.critical(self, "Cannot start", str(exc))
            return

        self._rebuild_process_badges(supervisor)
        supervisor.start()
        self.supervisor = supervisor
        self._set_running(True)
        self._settings_toggle.setChecked(False)  # fold settings away while receiving
        self._status_bar.showMessage(f"Running ({supervisor.mode_label}).")
        self._freq_estimate_state = None   # a new session measures (and auto-corrects) afresh
        self._band_session = self._band_combo.currentData() if mode != "client" else None
        self._timer.start()

    def stop_stack(self):
        self._pending_rf_start = False
        self._pending_correct_iq = None
        self._timer.stop()
        stopped_session = self.supervisor is not None
        if stopped_session:
            self.supervisor.stop()
            self.supervisor = None
        self._set_running(False)
        self._clear_remote_profile()
        self._spectrum.clear()
        self._active_ids = ()
        self._recent_until.clear()
        self._refresh_from_state([], {}, self._show_debug.isChecked())
        self._process_container.hide()
        self._status_bar.showMessage("Stopped.")
        if stopped_session:
            self._save_auto_correction()   # after "Stopped." so its message stays visible

    def _rebuild_process_badges(self, supervisor):
        for badge in self._process_badges.values():
            badge.setParent(None)
        self._process_badges = {}
        for index, process_view in enumerate(supervisor.process_views):
            badge = ProcessBadge(process_view.name)
            self._process_badges[process_view.name] = badge
            self._process_row.insertWidget(index + 2, badge)  # after title + spacing
        self._process_container.setVisible(bool(supervisor.process_views))

    # --- polling / rendering ----------------------------------------------
    def _on_tick(self):
        supervisor = self.supervisor
        if supervisor is None:
            return
        supervisor.poll(timeout_ms=0)
        backend = next((view for view in supervisor.process_views if view.name == "backend"), None)
        stalled = backend is not None and backend.state == "STALLED"
        if stalled and not getattr(self, "_backend_stalled", False):
            self._status_bar.showMessage("RF受信処理から応答がありません（プロセスは動作中）。受信を停止して開始し直してください。")
        elif not stalled and getattr(self, "_backend_stalled", False):
            self._status_bar.showMessage(f"Running ({supervisor.mode_label}).")
        self._backend_stalled = stalled
        if self._pending_correct_iq is not None and supervisor.set_correct_iq(self._pending_correct_iq):
            self._pending_correct_iq = None
        self._dqpsk_controls.update_states(supervisor.aggregator.dqpsk)
        if supervisor.aggregator.rf_network is not None:
            self._rf_status.update_state(supervisor.aggregator.rf_network)
        if supervisor.aggregator.hackrf_gain is not None:
            self._hackrf_controls.show_current(supervisor.aggregator.hackrf_gain)
        if supervisor.aggregator.freq_error is not None and supervisor.aggregator.freq_error != self._freq_estimate_state:
            self._show_freq_estimate(supervisor.aggregator.freq_error)
        self._spectrum.set_columns(self._waterfall.canvas.columns)
        if self._rf_controls.mode.currentData() == "client" and self._remote_format == FRAME_FORMAT:
            self._spectrum.show_message("フレーム配信のクライアントでは表示できません（IQを受信しないため）。")
        else:
            self._spectrum.update_spectrum(supervisor.aggregator.spectrum)
        self._refresh_from_state(
            supervisor.process_views, supervisor.channels, self._show_debug.isChecked()
        )
        self._update_network_caption()
        if supervisor.exit_message is not None:
            self._timer.stop()
            message = supervisor.exit_message
            self.supervisor = None
            supervisor.stop()
            self._set_running(False)
            self._clear_remote_profile()
            self._spectrum.clear()
            self._active_ids = ()
            self._recent_until.clear()
            self._refresh_from_state([], {}, self._show_debug.isChecked())
            self._process_container.hide()
            self._status_bar.showMessage("A process exited.")
            QtWidgets.QMessageBox.warning(self, "Process exited", message)

    def _refresh_from_state(self, process_views, channels, show_debug):
        for process_view in process_views:
            badge = self._process_badges.get(process_view.name)
            if badge is not None:
                badge.update_from(process_view)

        now = time.monotonic()
        active_ids = tuple(
            channel_id for channel_id in range(1, len(self._cards) + 1)
            if channel_id in channels and channels[channel_id].rx_status == "OPEN"
        )
        for channel_id in self._active_ids:
            if channel_id not in active_ids:
                self._recent_until[channel_id] = now + RECENT_CHANNEL_SECONDS
        for channel_id in active_ids:
            self._recent_until.pop(channel_id, None)
        for channel_id, expires_at in tuple(self._recent_until.items()):
            if expires_at <= now:
                del self._recent_until[channel_id]

        for card in self._cards:
            if card.channel_id in self._recent_until:
                card.mark_recent(self._recent_until[card.channel_id] - now)
            elif card.channel_id in active_ids or card.property("rx") != "close":
                card.update_from(channels.get(card.channel_id), show_debug)

        self._waterfall.update_channels(channels, now, output_muted=(
            self._audio_controls.volume.value() == 0 or
            not self._audio_controls.checks["voice_output"].isChecked()))
        self._active_ids = active_ids
        visible_ids = tuple(sorted(set(active_ids) | self._recent_until.keys()))
        self._layout_active_cards(visible_ids)
        count_text = f"受信中  {len(active_ids)} / {len(self._cards)}"
        if self._recent_until:
            count_text += f"  ·  履歴 {len(self._recent_until)}"
        self._active_count.setText(count_text)
        live = bool(active_ids)
        if self._active_count.property("live") != live:
            self._active_count.setProperty("live", live)
            self._active_count.style().unpolish(self._active_count)
            self._active_count.style().polish(self._active_count)
        self._cache_label.setText("秘話キー解析: 無効")
        self._check_notifications(channels)

    # --- notifications -----------------------------------------------------
    def _check_notifications(self, channels):
        controls = self._audio_controls
        rules = controls.notify_rules()
        if not rules or not channels:
            return
        for notice in self._call_notifier.update(channels, rules, controls.channel_frequency,
                                                 time.monotonic(), controls.notify_cooldown.value()):
            self._deliver_notice(notice)

    def _channel_title(self, channel_id):
        column = next((col for col in self._waterfall.canvas.columns if col.channel_id == channel_id), None)
        frequency = self._audio_controls.channel_frequency(channel_id) or (column.frequency_hz if column else None)
        label = column.label if column else f"CH {channel_id:02d}"
        return f"{label}  {frequency / 1e6:.5f} MHz" if frequency else label

    def _deliver_notice(self, notice):
        title = f"通話開始  {self._channel_title(notice.channel_id)}"
        parts = []
        if notice.csm:
            parts.append(f"CSM {notice.csm}")
        if notice.user_code is not None:
            parts.append(f"UC {notice.user_code}")
        parts.append("秘話" if notice.encrypted else "平文 / 未判定")
        parts.append("一致: " + " / ".join(notice.reasons))
        self._last_notice_channel = notice.channel_id
        self._notify(title, "  ·  ".join(parts))

    def _show_test_notification(self):
        self._last_notice_channel = None
        self._notify("テスト通知", "通知の表示と通知音を確認しています。")

    def _notify(self, title, body):
        controls = self._audio_controls
        self._status_bar.showMessage(f"通知: {title}  ·  {body}", 15000)
        if controls.notify_desktop.isChecked():
            tray = self._notification_tray()
            if tray is not None:
                tray.showMessage(title, body, QtWidgets.QSystemTrayIcon.Information, 8000)
        if controls.notify_sound.isChecked():
            try:
                import winsound
                winsound.MessageBeep(winsound.MB_ICONASTERISK)  # asynchronous, never blocks the GUI
            except (ImportError, RuntimeError):
                QtWidgets.QApplication.beep()

    def _notification_tray(self):
        """Windows shows tray balloon messages as native toast notifications."""
        if self._tray is None and QtWidgets.QSystemTrayIcon.isSystemTrayAvailable():
            icon = self.windowIcon()
            if icon.isNull():
                icon = self.style().standardIcon(QtWidgets.QStyle.SP_MessageBoxInformation)
            self._tray = QtWidgets.QSystemTrayIcon(icon, self)
            self._tray.setToolTip("STD-T98 受信")
            self._tray.messageClicked.connect(self._on_notice_clicked)
            self._tray.show()
        return self._tray

    def _on_notice_clicked(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()
        if self._last_notice_channel is not None:
            self._waterfall.canvas.select_channel(self._last_notice_channel)

    def _update_empty_state(self):
        if self._running:
            self._empty_title.setText("信号を待っています")
            self._empty_hint.setText("受信を検知したチャンネルがここに表示されます。")
        else:
            self._empty_title.setText("受信待機中")
            self._empty_hint.setText("受信を開始すると、信号のあるチャンネルだけをここに表示します。")

    def _layout_active_cards(self, visible_ids=None):
        if visible_ids is None:
            visible_ids = self._visible_ids
        width = max(1, self._scroll.viewport().width())
        if visible_ids == self._visible_ids and width == self._grid_width:
            return
        for channel_id in set(self._visible_ids) - set(visible_ids):
            self._cards[channel_id - 1].hide()
        # Tiles keep their slot while visible; new ones fill the lowest gap.
        slots = self._card_slots.update(visible_ids)
        per_row, left = honeycomb_grid(width)
        for channel_id, slot in slots.items():
            card = self._cards[channel_id - 1]
            card.move(slot_position(slot, per_row, left))
            card.show()
        height = comb_height(max(slots.values(), default=-1) + 1, per_row)
        if visible_ids:
            self._empty_state.hide()
        else:
            height = self._empty_state.sizeHint().height()
            self._empty_state.setGeometry(0, 0, width, height)
            self._empty_state.show()
        # No layout manages the tiles, so the scroll area needs an explicit height.
        self._grid_host.setMinimumHeight(height)
        self._visible_ids = visible_ids
        self._grid_width = width

    def eventFilter(self, watched, event):
        if (hasattr(self, "_scroll") and watched is self._scroll.viewport()
                and event.type() == QtCore.QEvent.Resize):
            self._layout_active_cards()
        return super().eventFilter(watched, event)

    # --- Qt events ---------------------------------------------------------
    def closeEvent(self, event):
        self.stop_stack()
        if self._rf_worker is not None and self._rf_worker.isRunning():
            self._close_after_probe = True
            event.ignore()
            return
        if self._tray is not None:
            self._tray.hide()
        super().closeEvent(event)
