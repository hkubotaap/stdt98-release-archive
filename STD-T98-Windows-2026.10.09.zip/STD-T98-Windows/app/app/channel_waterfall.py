"""Bounded channel history, painted as one light, spreadsheet-like surface."""
from collections import deque
from dataclasses import dataclass
import html
import math
import time

from PyQt5 import QtCore, QtGui, QtWidgets

from app.channel_roles import build_role_menu
from core.rf.channel_plan import PLAN_BY_FREQUENCY


@dataclass(frozen=True)
class Column:
    channel_id: int
    number: int
    group: str = "CH"
    frequency_hz: float | None = None

    @property
    def label(self):
        return f"{self.group} CH{self.number:02d}" if self.group != "CH" else f"CH {self.number:02d}"


@dataclass(frozen=True)
class Cell:
    receiving: bool = False
    playing: bool = False
    encrypted: bool = False
    state: str = "待機"
    quality: float | None = None
    user_code: int | None = None

    @property
    def present(self):
        return self.receiving or self.playing or self.state in ("鍵待ち", "消音")


def channel_cell(channel, now=None, output_muted=False):
    if channel is None:
        return Cell()
    now = time.monotonic() if now is None else now
    sacch = channel.sacch or {}
    encrypted = sacch.get("CallStat") == 1 or channel.audio_status in ("Key required", "Replaying from start")
    # This flag is reported after a successful device write, not after decoding.
    playing = bool(getattr(channel, "playback_active", False)) and (
        now - getattr(channel, "playback_updated_at", 0) < 1.5
    )
    receiving = channel.rx_status == "OPEN"
    control = receiving and channel.protocol_status == "Sync Burst"
    state = "再生中" if playing else "コントロール" if control else {
        "Key required": "鍵待ち", "Call state pending": "識別待ち",
        "CRC muted": "品質ミュート", "Key mismatch": "鍵不一致",
        "Data": "データ", "Playing": "音声データ", "Replaying from start": "再生準備",
        "Excluded": "除外",
    }.get(channel.audio_status, "受信中" if receiving else "待機")
    if not receiving and not playing:
        state = "待機"
    if control and not playing:
        encrypted = False
    if output_muted and (receiving or playing) and state not in ("データ", "コントロール"):
        playing = False
        state = "消音"
    return Cell(receiving, playing, encrypted, state,
                getattr(channel, "crc_percent", None), sacch.get("UserCode"))


class History:
    interval = 0.5
    duration = 10.0

    def __init__(self):
        self.rows = deque(maxlen=20)
        self.current = ()
        self.tick = None
        self.recent = {}

    def update(self, cells, now):
        cells = tuple(cells)
        if self.tick is None:
            self.tick = now
        if len(cells) != len(self.current):
            self.rows.clear()
            self.recent.clear()
            self.tick = now
        elapsed = int((now - self.tick) / self.interval)
        if elapsed:
            # Missing UI polls are empty time, not fabricated receptions.
            for step in range(max(1, elapsed - 19), elapsed + 1):
                sample = self.current if step == 1 else tuple(Cell() for _ in cells)
                self.rows.appendleft((self.tick + step * self.interval, sample))
            self.tick += elapsed * self.interval
        for index, cell in enumerate(cells):
            if cell.present:
                self.recent.pop(index, None)
            elif index < len(self.current) and self.current[index].present:
                self.recent[index] = (now + self.duration, self.current[index])
        self.recent = {i: v for i, v in self.recent.items() if v[0] > now}
        while self.rows and now - self.rows[-1][0] >= self.duration:
            self.rows.pop()
        self.current = cells


QUALITY_GOOD = QtGui.QColor("#21854a")
QUALITY_FAIR = QtGui.QColor("#ba7309")
QUALITY_POOR = QtGui.QColor("#c43b3b")
BLUE = QtGui.QColor("#1268d4")
EXCLUDED_GREY = QtGui.QColor(110, 110, 110)
PRIORITY_AMBER = QtGui.QColor("#e0a800")
NOTIFY_TEAL = QtGui.QColor("#0f9d8a")
MUTE_SLATE = QtGui.QColor("#7a8794")
ROLE_COLORS = {"mute": MUTE_SLATE, "solo": BLUE, "priority": PRIORITY_AMBER, "notify": NOTIFY_TEAL}


def tint(color, alpha):
    """Translucent copy of a palette/text colour, for hairlines and bands."""
    color = QtGui.QColor(color)
    color.setAlpha(alpha)
    return color


def quality_level(value):
    """CRC percent → "good" / "fair" / "poor", or "" when not measured."""
    return "" if value is None else "good" if value >= 80 else "fair" if value >= 50 else "poor"


def quality_color(value):
    return {"good": QUALITY_GOOD, "fair": QUALITY_FAIR, "poor": QUALITY_POOR}.get(
        quality_level(value), QtGui.QColor("#78838c"))


def draw_speaker(painter, center, size, color):
    painter.save()
    painter.translate(center)
    painter.scale(size / 12, size / 12)
    painter.setPen(QtGui.QPen(color, 1.5, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap))
    painter.setBrush(color)
    painter.drawPolygon(QtGui.QPolygonF([
        QtCore.QPointF(-5, -2), QtCore.QPointF(-2, -2), QtCore.QPointF(1, -5),
        QtCore.QPointF(1, 5), QtCore.QPointF(-2, 2), QtCore.QPointF(-5, 2),
    ]))
    painter.setBrush(QtCore.Qt.NoBrush)
    painter.drawArc(QtCore.QRectF(-1, -4, 7, 8), -60 * 16, 120 * 16)
    painter.restore()


def draw_play(painter, center, size, color):
    painter.save()
    painter.translate(center)
    painter.scale(size / 12, size / 12)
    painter.setPen(QtCore.Qt.NoPen)
    painter.setBrush(color)
    painter.drawPolygon(QtGui.QPolygonF([
        QtCore.QPointF(-4, -5), QtCore.QPointF(5, 0), QtCore.QPointF(-4, 5),
    ]))
    painter.restore()


def draw_hourglass(painter, center, size, color):
    painter.save()
    painter.translate(center)
    painter.scale(size / 12, size / 12)
    painter.setPen(QtGui.QPen(color, 1.3, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin))
    painter.setBrush(QtCore.Qt.NoBrush)
    painter.drawPolygon(QtGui.QPolygonF([
        QtCore.QPointF(-4, -5), QtCore.QPointF(4, -5), QtCore.QPointF(4, -3),
        QtCore.QPointF(1, 0), QtCore.QPointF(4, 3), QtCore.QPointF(4, 5),
        QtCore.QPointF(-4, 5), QtCore.QPointF(-4, 3), QtCore.QPointF(-1, 0),
        QtCore.QPointF(-4, -3),
    ]))
    painter.setPen(QtCore.Qt.NoPen)
    painter.setBrush(color)
    for points in (((-3, -4), (3, -4), (0, -1)), ((-3, 4), (3, 4), (0, 2))):
        painter.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(x, y) for x, y in points]))
    painter.restore()


def draw_muted_speaker(painter, center, size, color, background):
    draw_speaker(painter, center, size, color)
    painter.save()
    painter.translate(center)
    painter.scale(size / 12, size / 12)
    start, end = QtCore.QPointF(-5, 5), QtCore.QPointF(5, -5)
    painter.setPen(QtGui.QPen(background, 3.6, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap))
    painter.drawLine(start, end)
    painter.setPen(QtGui.QPen(QUALITY_POOR, 1.6, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap))
    painter.drawLine(start, end)
    painter.restore()


def draw_channel_letter(painter, center, size, color, letter):
    """Stroke D/R/V/C as vectors so small cells do not depend on font fallback."""
    painter.save()
    painter.translate(center)
    painter.scale(size / 12, size / 12)
    painter.setPen(QtGui.QPen(color, 1.7, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin))
    painter.setBrush(QtCore.Qt.NoBrush)
    path = QtGui.QPainterPath()
    if letter == "V":
        path.moveTo(-5, -5)
        path.lineTo(0, 5)
        path.lineTo(5, -5)
    elif letter == "C":
        path.moveTo(4, -4)
        path.cubicTo(-6, -8, -6, 8, 4, 4)
    elif letter == "D":
        path.moveTo(-4, 5)
        path.lineTo(-4, -5)
        path.lineTo(0, -5)
        path.quadTo(5, -5, 5, 0)
        path.quadTo(5, 5, 0, 5)
        path.closeSubpath()
    else:
        path.moveTo(-4, 5)
        path.lineTo(-4, -5)
        path.lineTo(0, -5)
        path.quadTo(4, -5, 4, -2)
        path.quadTo(4, 1, 0, 1)
        path.lineTo(-4, 1)
        path.moveTo(0, 1)
        path.lineTo(5, 5)
    painter.drawPath(path)
    painter.restore()


def status_icon(cell):
    if cell.playing:
        return "play"
    if cell.state in ("鍵待ち", "識別待ち", "再生準備"):
        return "wait"
    if cell.state in ("品質ミュート", "鍵不一致", "消音"):
        return "mute"
    if cell.state == "データ":
        return "data"
    if cell.state == "音声データ":
        return "voice"
    if cell.state == "コントロール":
        return "control"
    if cell.receiving:
        return "receive"
    return None


def draw_key(painter, center, size, color):
    painter.save()
    painter.translate(center)
    painter.scale(size / 12, size / 12)
    painter.setPen(QtGui.QPen(color, 1.5, QtCore.Qt.SolidLine, QtCore.Qt.RoundCap))
    painter.setBrush(QtCore.Qt.NoBrush)
    painter.drawEllipse(QtCore.QRectF(-5, -4, 5, 5))
    painter.drawLine(QtCore.QPointF(-1, 0), QtCore.QPointF(5, 5))
    painter.drawLine(QtCore.QPointF(3, 3), QtCore.QPointF(5, 1))
    painter.restore()


class WaterfallCanvas(QtWidgets.QWidget):
    selected = QtCore.pyqtSignal(str)
    exclusion_toggled = QtCore.pyqtSignal(int, bool)  # channel_id, exclude
    role_toggled = QtCore.pyqtSignal(int, str, bool)  # channel_id, "mute" | "solo" | "priority" | "notify", enabled
    solo_cleared = QtCore.pyqtSignal()
    bulk_role_toggled = QtCore.pyqtSignal(list, str, bool)  # channel_ids, role (incl. "exclude"), enabled
    left = 54
    header = 45
    group_height = 22
    row_height = 26

    def __init__(self, parent=None):
        super().__init__(parent)
        self.columns = ()
        self.history = History()
        self.frozen = None
        self.zoom = 0
        self.selected_index = None
        self.selected_indices = set()
        self.anchor_index = None
        self.excluded_ids = frozenset()
        self.solo_ids = frozenset()
        self.priority_ids = frozenset()
        self.notify_ids = frozenset()
        self.mute_ids = frozenset()
        self.sprites = {}
        self.setMouseTracking(True)
        self.setFocusPolicy(QtCore.Qt.ClickFocus)  # Esc clears the selection
        self.setAccessibleName("チャンネル受信履歴。上が最新、下が過去の10秒間")
        self.setFixedHeight(self.content_height())
        self.animation = QtCore.QTimer(self)
        self.animation.setInterval(100)
        self.animation.timeout.connect(self.advance)
        self.animation.start()

    def set_columns(self, columns):
        columns = tuple(columns)
        if columns == self.columns:
            return
        self.columns = columns
        self.history = History()
        self.frozen = None
        self.selected_index = None
        self.selected_indices = set()
        self.anchor_index = None
        self.history.update(tuple(Cell() for _ in columns), time.monotonic())
        self.update_size()

    def set_excluded(self, channel_ids):
        channel_ids = frozenset(channel_ids)
        if channel_ids != self.excluded_ids:
            self.excluded_ids = channel_ids
            self.update()

    def set_roles(self, solo_ids, priority_ids, notify_ids=(), mute_ids=()):
        roles = frozenset(solo_ids), frozenset(priority_ids), frozenset(notify_ids), frozenset(mute_ids)
        if roles != (self.solo_ids, self.priority_ids, self.notify_ids, self.mute_ids):
            self.solo_ids, self.priority_ids, self.notify_ids, self.mute_ids = roles
            self.update()

    def role_ids(self, role):
        return {"mute": self.mute_ids, "solo": self.solo_ids, "priority": self.priority_ids,
                "notify": self.notify_ids}[role]

    def silenced(self, channel_id):
        """Playback is off (mute, or solo elsewhere) while reception continues."""
        if channel_id in self.excluded_ids:
            return False
        return channel_id in self.mute_ids or bool(self.solo_ids) and channel_id not in self.solo_ids

    def update_size(self):
        self.row_height = max(26, self.zoom)
        self.group_height = self.row_height if self.zoom >= 48 else 22
        self.header = self.row_height * 2 if self.zoom >= 48 else 45
        self.left = math.ceil(self.row_height * 2.1) if self.zoom >= 48 else 54
        self.sprites.clear()
        self.setMinimumWidth(int(self.left + len(self.columns) * (self.zoom or 12)))
        self.setFixedHeight(self.content_height())
        self.update()

    def content_height(self):
        """Header, the latest row, then History.duration of past rows: no blank tail."""
        return self.header + self.row_height * (1 + round(History.duration / History.interval))

    def update_channels(self, channels, now=None, output_muted=False):
        now = time.monotonic() if now is None else now
        self.history.update((channel_cell(channels.get(c.channel_id), now, output_muted) for c in self.columns), now)
        self.update()

    def advance(self):
        now = time.monotonic()
        # Keep the time axis moving after RX stops, and expire playback flags.
        cells = tuple(Cell(c.receiving, False, c.encrypted, "音声データ" if c.receiving else "待機",
                           c.quality, c.user_code) if c.playing and self._last_feed_age(now) > 1.5 else c
                      for c in self.history.current)
        self.history.update(cells, now)
        if self.isVisible() and self.frozen is None:
            self.update()

    def _last_feed_age(self, now):
        return now - getattr(self, "last_feed", now)

    def freeze(self, enabled):
        if enabled:
            self.frozen = (time.monotonic(), self.history.current, tuple(self.history.rows), dict(self.history.recent))
        else:
            self.frozen = None
        self.update()

    def view(self):
        if self.frozen is not None:
            return self.frozen
        return time.monotonic(), self.history.current, tuple(self.history.rows), self.history.recent

    def cell_width(self):
        return (self.width() - self.left - 1) / max(1, len(self.columns))

    def table_font(self):
        font = QtGui.QFont("Consolas")
        font.setBold(self.zoom >= 48)
        # Fit the largest two-digit channel label to both dimensions, using
        # actual font metrics so native Windows fonts do not clip at 48/96px.
        size = max(10, self.header - self.group_height - 4)
        while size > 10:
            font.setPixelSize(size)
            metrics = QtGui.QFontMetrics(font)
            if (metrics.horizontalAdvance("88") <= self.cell_width() - 6 and
                    metrics.height() <= self.header - self.group_height - 2):
                break
            size -= 1
        font.setPixelSize(size)
        return font

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        self.paint_clip = QtCore.QRectF(event.rect())
        pal = self.palette()
        p.fillRect(self.rect(), pal.base())
        if not self.columns:
            return
        now, current, rows, recent = self.view()
        cw = self.cell_width()
        text = pal.color(QtGui.QPalette.Text)
        muted = tint(text, 140)
        p.fillRect(QtCore.QRectF(0, 0, self.width(), self.header), pal.window())
        # Alternate a faint band per channel group so 3T/3U/3S/3R read as blocks.
        group_font = self.table_font()
        group_font.setBold(True)
        group_font.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 1)
        start, band = 0, 0
        for index, col in enumerate(self.columns):
            if index == len(self.columns) - 1 or self.columns[index + 1].group != col.group:
                x0, x1 = self.left + start * cw, self.left + (index + 1) * cw
                if band % 2:
                    p.fillRect(QtCore.QRectF(x0, 0, x1 - x0, self.header), tint(text, 10))
                if col.group != "CH":
                    p.setFont(group_font)
                    p.setPen(tint(text, 190))
                    # Name airborne blocks in the header when the group is wide enough.
                    info = PLAN_BY_FREQUENCY.get(round(col.frequency_hz)) if col.frequency_hz else None
                    name = col.group
                    if info is not None and info.usage == "上空用":
                        wide = f"{col.group}（上空）"
                        if p.fontMetrics().horizontalAdvance(wide) <= x1 - x0 - 4:
                            name = wide
                    p.drawText(QtCore.QRectF(x0, 1, x1 - x0, self.group_height - 2), QtCore.Qt.AlignCenter, name)
                start, band = index + 1, band + 1
        p.fillRect(QtCore.QRectF(self.left, self.header, self.width() - self.left, self.row_height), tint(BLUE, 16))
        p.fillRect(QtCore.QRectF(self.left, self.header, 3, self.row_height), tint(BLUE, 160))
        p.setFont(self.table_font())
        p.setPen(QUALITY_FAIR if self.frozen else BLUE)
        p.drawText(QtCore.QRectF(0, self.header, self.left - 6, self.row_height),
                   QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter, "固定" if self.frozen else "最新")
        p.setPen(muted)
        for second in range(1, 11):
            y = self.header + self.row_height * (1 + second / History.interval)
            if y >= self.height():
                break
            p.drawText(QtCore.QRectF(0, y - self.row_height / 2, self.left - 6, self.row_height), QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter, f"−{second}s")
        for index, col in enumerate(self.columns):
            x = self.left + index * cw
            p.setPen(text if index in self.selected_indices else muted)
            p.drawText(QtCore.QRectF(x, self.group_height, cw, self.header - self.group_height), QtCore.Qt.AlignCenter, f"{col.number:02d}")
        # Hairlines: group boundaries strongest, then 10s, 5s, then single channels.
        for index in range(len(self.columns) + 1):
            group = index in (0, len(self.columns)) or self.columns[index - 1].group != self.columns[index].group
            number = self.columns[index].number if index < len(self.columns) else 0
            alpha = 70 if group else 34 if number % 10 == 1 else 22 if number % 5 == 1 else 11
            p.setPen(QtGui.QPen(tint(text, alpha), 1))
            x = round(self.left + index * cw) + .5
            p.drawLine(QtCore.QPointF(x, 0 if group else self.group_height), QtCore.QPointF(x, self.height()))
        p.setPen(QtGui.QPen(tint(text, 60), 1))
        p.drawLine(QtCore.QPointF(0, self.header + .5), QtCore.QPointF(self.width(), self.header + .5))
        for row in range(2, int((self.height() - self.header) / self.row_height) + 1):
            y = round(self.header + row * self.row_height) + .5
            p.setPen(QtGui.QPen(tint(text, 26 if row % 10 == 1 else 10), 1))
            p.drawLine(QtCore.QPointF(self.left, y), QtCore.QPointF(self.width(), y))
        p.setPen(QtGui.QPen(tint(text, 40), 1))
        y = round(self.header + self.row_height) + .5
        p.drawLine(QtCore.QPointF(self.left, y), QtCore.QPointF(self.width(), y))
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        hatch = QtGui.QBrush(tint(EXCLUDED_GREY, 80), QtCore.Qt.BDiagPattern)
        for index, col in enumerate(self.columns):
            if col.channel_id in self.excluded_ids:
                x = self.left + index * cw
                p.fillRect(QtCore.QRectF(x, self.group_height, cw, self.height() - self.group_height),
                           tint(EXCLUDED_GREY, 24))
                p.fillRect(QtCore.QRectF(x, self.header, cw, self.height() - self.header), hatch)
        for index, col in enumerate(self.columns):
            marks = [color for role, color in ROLE_COLORS.items() if col.channel_id in self.role_ids(role)]
            for slot, color in enumerate(marks):
                width = (cw - 2) / len(marks)
                p.fillRect(QtCore.QRectF(self.left + index * cw + 1 + slot * width, self.group_height, width, 3), color)
        for index in self.selected_indices:
            x = self.left + index * cw
            p.fillRect(QtCore.QRectF(x, 0, cw, self.height()), tint(BLUE, 20))
            p.fillRect(QtCore.QRectF(x, self.header - 3, cw, 3), BLUE)
        for index, value in recent.items():
            x = self.left + index * cw
            p.setPen(QtGui.QPen(QtGui.QColor("#718e79"), 1.5))
            p.drawLine(QtCore.QPointF(x + 2, self.header + 3), QtCore.QPointF(x + cw - 2, self.header + 3))
            self.paint_cell(p, value[1], index, self.header, cw, False, 0.35)
        for index, cell in enumerate(current):
            self.paint_cell(p, cell, index, self.header, cw, True)
        for timestamp, cells in rows:
            age = now - timestamp
            if age >= History.duration:
                continue
            y = self.header + self.row_height * (1 + age / History.interval)
            if y < self.height():
                for index, cell in enumerate(cells):
                    self.paint_cell(p, cell, index, y, cw, False, max(0.38, 0.9 - age * 0.045))
        if self.solo_ids or self.mute_ids:
            # Silenced channels stay visible but recede behind a veil.
            veil = tint(pal.color(QtGui.QPalette.Base), 150)
            for index, col in enumerate(self.columns):
                if self.silenced(col.channel_id):
                    p.fillRect(QtCore.QRectF(self.left + index * cw, self.header, cw, self.height() - self.header), veil)
        p.end()

    def paint_cell(self, p, cell, index, y, cw, latest, opacity=1):
        if not cell.present:
            return
        if not self.paint_clip.intersects(QtCore.QRectF(self.left + index * cw, y, cw, self.row_height)):
            return
        blinking = latest and self.frozen is None and int(time.monotonic() * 2) % 2 != 0
        key = (round(cw, 3), self.row_height, cell.receiving, cell.playing, cell.encrypted,
               cell.state, quality_color(cell.quality).rgb(), blinking,
               self.palette().cacheKey())
        sprite = self.sprites.get(key)
        if sprite is None:
            if len(self.sprites) >= 512:
                self.sprites.clear()
            sprite = QtGui.QPixmap(math.ceil(cw), self.row_height)
            sprite.fill(QtCore.Qt.transparent)
            painter = QtGui.QPainter(sprite)
            painter.setRenderHint(QtGui.QPainter.Antialiasing)
            painter.translate(-self.left, 0)
            self.paint_cell_vector(painter, cell, 0, 0, cw, latest)
            painter.end()
            self.sprites[key] = sprite
        p.save()
        p.setOpacity(opacity)
        p.drawPixmap(QtCore.QPointF(self.left + index * cw, y), sprite)
        p.restore()

    def paint_cell_vector(self, p, cell, index, y, cw, latest):
        p.save()
        x = self.left + index * cw
        color = quality_color(cell.quality)
        inset = 1.5 if cw >= 8 else .5
        p.setPen(QtCore.Qt.NoPen)
        p.setBrush(tint(color, 34))
        p.drawRoundedRect(QtCore.QRectF(x + inset, y + inset, cw - 2 * inset, self.row_height - 2 * inset), 3, 3)
        scale = self.row_height / 26
        size = min(10 * scale, cw - 3)
        dot = QtCore.QRectF(x + cw / 2 - size / 2, y + 14 * scale, size, size)
        icon = status_icon(cell)
        p.setPen(QtGui.QPen(color, max(1, scale * 0.7)))
        p.setBrush(color if icon != "mute" else QtCore.Qt.NoBrush)
        if cell.state == "データ":
            p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(dot.center().x(), dot.top()), QtCore.QPointF(dot.right(), dot.center().y()), QtCore.QPointF(dot.center().x(), dot.bottom()), QtCore.QPointF(dot.left(), dot.center().y())]))
        elif cell.playing:
            p.drawEllipse(dot)
        else:
            p.drawRoundedRect(dot, 1, 1)
        paired = icon is not None and cell.encrypted
        icon_size = min(11 * scale, cw / 2) if paired else min(12 * scale, cw - 2)
        center = QtCore.QPointF(x + (cw * 0.27 if paired else cw / 2), y + 7 * scale)
        if icon == "play":
            # Historical play icons stay blue. Only the latest output blinks.
            bright = not latest or self.frozen is not None or int(time.monotonic() * 2) % 2 == 0
            draw_play(p, center, icon_size, BLUE if bright else QtGui.QColor("#91b4e3"))
        elif icon == "wait":
            draw_hourglass(p, center, icon_size, QUALITY_FAIR)
        elif icon == "mute":
            draw_muted_speaker(p, center, icon_size, self.palette().color(QtGui.QPalette.Text), self.palette().color(QtGui.QPalette.Base))
        elif icon in ("data", "receive", "voice", "control"):
            draw_channel_letter(p, center, icon_size, self.palette().color(QtGui.QPalette.Text),
                                {"data": "D", "receive": "R", "voice": "V", "control": "C"}[icon])
        if cell.encrypted:
            draw_key(p, QtCore.QPointF(x + (cw * 0.74 if paired else cw / 2), y + 7 * scale), icon_size, self.palette().color(QtGui.QPalette.Text))
        p.restore()

    def hit(self, point):
        index = int((point.x() - self.left) / self.cell_width())
        if point.x() < self.left or not 0 <= index < len(self.columns):
            return None
        now, current, rows, recent = self.view()
        cell, age = (current[index] if index < len(current) else Cell()), 0.0
        if point.y() >= self.header + self.row_height:
            age = (point.y() - self.header - self.row_height) / self.row_height * History.interval
            if rows:
                stamp, cells = min(rows, key=lambda item: abs(now - item[0] - age))
                if abs(now - stamp - age) < History.interval and index < len(cells):
                    cell, age = cells[index], now - stamp
                else:
                    cell = Cell()
        elif not cell.present and index in recent:
            cell = recent[index][1]
            age = History.duration - (recent[index][0] - now)
        return index, cell, age

    def description(self, hit):
        index, cell, age = hit
        col = self.columns[index]
        freq = f" · {col.frequency_hz / 1e6:.5f} MHz" if col.frequency_hz else ""
        info = PLAN_BY_FREQUENCY.get(round(col.frequency_hz)) if col.frequency_hz and col.group != "CH" else None
        if info is not None and info.note:
            freq += f"（{info.note}）"
        if info is not None and info.block:
            freq += f" · {info.block}"
        quality = "未測定" if cell.quality is None else f"{cell.quality:.0f}%（直近25フレームのCRC）"
        uc = f" · UC {cell.user_code}" if cell.user_code is not None else ""
        age_text = "最新" if age == 0 else f"{age:.1f}秒前"
        excluded = "".join(text for ids, text in ((self.excluded_ids, " · 受信・録音から除外中"),
                                                    (self.mute_ids, " · 聞かない（再生のみ停止）"),
                                                    (self.solo_ids, " · ソロ"), (self.priority_ids, " · 優先"),
                                                    (self.notify_ids, " · 通知"))
                           if col.channel_id in ids)
        if self.silenced(col.channel_id) and col.channel_id not in self.mute_ids:
            excluded += " · ソロ中のため消音"
        return f"{col.label}{freq}{excluded} · {age_text} · {cell.state} · {'秘話' if cell.encrypted else '平文 / 未判定'}{uc} · 受信品質 {quality}"

    def mouseMoveEvent(self, event):
        hit = self.hit(event.pos())
        if hit is not None:
            QtWidgets.QToolTip.showText(event.globalPos(), "<p>" + html.escape(self.description(hit)) + "</p>", self)
        else:
            QtWidgets.QToolTip.hideText()

    def mousePressEvent(self, event):
        """Click selects one column; Ctrl+click toggles; Shift+click extends from the anchor."""
        hit = self.hit(event.pos())
        if hit is None:
            return
        index = hit[0]
        modifiers = event.modifiers()
        if modifiers & QtCore.Qt.ShiftModifier and self.anchor_index is not None:
            low, high = sorted((self.anchor_index, index))
            span = set(range(low, high + 1))
            self.selected_indices = self.selected_indices | span if modifiers & QtCore.Qt.ControlModifier else span
        elif modifiers & QtCore.Qt.ControlModifier:
            self.selected_indices ^= {index}
            self.anchor_index = index
        else:
            self.selected_indices = {index}
            self.anchor_index = index
        self._selection_changed(hit if index in self.selected_indices else None)

    def _selection_changed(self, hit=None):
        indices = sorted(self.selected_indices)
        self.selected_index = hit[0] if hit is not None else (indices[0] if indices else None)
        if len(indices) == 1:
            index = indices[0]
            hit = hit or (index, self.view()[1][index] if index < len(self.view()[1]) else Cell(), 0.0)
            self.selected.emit("選択時点：" + self.description(hit))
        elif indices:
            labels = [self.columns[i].label for i in indices]
            shown = "、".join(labels[:8]) + (f" ほか{len(labels) - 8}件" if len(labels) > 8 else "")
            self.selected.emit(f"{len(indices)} チャンネルを選択：{shown}　（右クリックでまとめて設定）")
        else:
            self.selected.emit(ChannelWaterfall.HINT)
        self.update()

    def clear_selection(self):
        self.selected_indices = set()
        self._selection_changed()

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape and self.selected_indices:
            self.clear_selection()
        else:
            super().keyPressEvent(event)

    def select_channel(self, channel_id):
        index = next((i for i, col in enumerate(self.columns) if col.channel_id == channel_id), None)
        if index is None:
            return False
        self.selected_indices = {index}
        self.anchor_index = index
        self._selection_changed()
        return True

    def role_targets(self, index):
        """Right-click on a selected column acts on the whole selection."""
        indices = sorted(self.selected_indices) if index in self.selected_indices else [index]
        return [self.columns[i].channel_id for i in indices]

    def exclusion_menu(self, index):
        targets = self.role_targets(index)
        if len(targets) == 1:
            col = self.columns[index]
            freq = f"  {col.frequency_hz / 1e6:.5f} MHz" if col.frequency_hz else ""
            title = f"{col.label}{freq}"
        else:
            title = f"{len(targets)} チャンネルを選択中"

        def ids(role):
            return self.excluded_ids if role == "exclude" else self.role_ids(role)

        def apply(role, enabled):
            if len(targets) > 1:
                self.bulk_role_toggled.emit(list(targets), role, enabled)
            elif role == "exclude":
                self.exclusion_toggled.emit(targets[0], enabled)
            else:
                self.role_toggled.emit(targets[0], role, enabled)

        menu = build_role_menu(self, title, lambda role: (sum(t in ids(role) for t in targets), len(targets)), apply)
        if self.solo_ids:
            menu.addSeparator()
            menu.addAction(f"ソロをすべて解除（{len(self.solo_ids)}件）").triggered.connect(self.solo_cleared.emit)
        if len(targets) > 1:
            menu.addAction("選択を解除").triggered.connect(self.clear_selection)
        return menu

    def contextMenuEvent(self, event):
        hit = self.hit(event.pos())
        if hit is None:
            return
        if hit[0] not in self.selected_indices:
            self.selected_indices = {hit[0]}
            self.anchor_index = hit[0]
            self._selection_changed(hit)
        self.exclusion_menu(hit[0]).exec_(event.globalPos())


class HistoryLegend(QtWidgets.QWidget):
    """One-line legend painted with the same vectors as the grid cells."""

    QUALITY = (("≥80%", QUALITY_GOOD), ("≥50%", QUALITY_FAIR), ("<50%", QUALITY_POOR),
               ("未測定", QtGui.QColor("#78838c")))
    ICONS = (("R", "受信"), ("V", "音声"), ("D", "データ"), ("C", "制御"),
             ("play", "再生"), ("wait", "待ち"), ("mute", "消音"), ("key", "秘話"), ("excluded", "除外"),
             ("role:mute", "聞かない"), ("role:solo", "ソロ"), ("role:priority", "優先"), ("role:notify", "通知"))

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setToolTip("品質は直近25フレームのCRC成功率です。青点滅の▶は実際の音声出力、砂時計は鍵・識別・再生準備の待ち、"
                        "斜線付きスピーカーはミュート、鍵は秘話、灰色の斜線は受信・録音から除外中、"
                        "見出しの灰線は聞かない（薄く表示・録音は継続）、青線はソロ（他のチャンネルは薄く表示して消音）、"
                        "黄線は優先、緑線は通知。列を右クリックで設定 / 解除。"
                        "受信終了後は10秒間、暗い緑のラインを残します。")
        self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)

    def _font(self):
        font = self.font()
        font.setPixelSize(12)
        return font

    def _items(self):
        yield "label", "品質", None
        for text, color in self.QUALITY:
            yield "swatch", text, color
        yield "gap", "", None
        for icon, text in self.ICONS:
            yield "icon", text, icon

    def _layout(self, metrics):
        x, out = 0.0, []
        for kind, text, extra in self._items():
            out.append((kind, x, text, extra))
            if kind == "gap":
                x += 18
            else:
                x += (0 if kind == "label" else 16) + metrics.horizontalAdvance(text) + 12
        return out, x

    def sizeHint(self):
        metrics = QtGui.QFontMetrics(self._font())
        return QtCore.QSize(int(self._layout(metrics)[1]), max(22, metrics.height() + 6))

    def minimumSizeHint(self):
        return QtCore.QSize(120, self.sizeHint().height())

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.setFont(self._font())
        text = self.palette().color(QtGui.QPalette.Text)
        cy = self.height() / 2
        for kind, x, label, extra in self._layout(p.fontMetrics())[0]:
            if kind == "gap":
                p.setPen(QtGui.QPen(tint(text, 50), 1))
                p.drawLine(QtCore.QPointF(x + 8.5, cy - 7), QtCore.QPointF(x + 8.5, cy + 7))
                continue
            if kind == "label":
                p.setPen(tint(text, 150))
                p.drawText(QtCore.QRectF(x, 0, self.width(), self.height()), QtCore.Qt.AlignVCenter, label)
                continue
            center = QtCore.QPointF(x + 6, cy)
            if kind == "swatch":
                p.setPen(QtCore.Qt.NoPen)
                p.setBrush(tint(extra, 60))
                p.drawRoundedRect(QtCore.QRectF(x, cy - 6, 12, 12), 3, 3)
                p.setBrush(extra)
                p.drawRoundedRect(QtCore.QRectF(x + 3, cy - 3, 6, 6), 1, 1)
            elif extra in ("R", "V", "D", "C"):
                draw_channel_letter(p, center, 11, text, extra)
            elif extra == "play":
                draw_play(p, center, 11, BLUE)
            elif extra == "wait":
                draw_hourglass(p, center, 11, QUALITY_FAIR)
            elif extra == "mute":
                draw_muted_speaker(p, center, 11, text, self.palette().color(QtGui.QPalette.Window))
            elif extra == "key":
                draw_key(p, center, 11, text)
            elif extra == "excluded":
                rect = QtCore.QRectF(x, cy - 6, 12, 12)
                p.setPen(QtCore.Qt.NoPen)
                p.setBrush(tint(EXCLUDED_GREY, 40))
                p.drawRoundedRect(rect, 2, 2)
                p.setBrush(QtGui.QBrush(tint(EXCLUDED_GREY, 170), QtCore.Qt.BDiagPattern))
                p.drawRoundedRect(rect, 2, 2)
            elif extra.startswith("role:"):
                p.setPen(QtCore.Qt.NoPen)
                p.setBrush(tint(text, 18))
                p.drawRoundedRect(QtCore.QRectF(x, cy - 6, 12, 12), 2, 2)
                p.fillRect(QtCore.QRectF(x + 1, cy - 6, 10, 3), ROLE_COLORS[extra[5:]])
            p.setPen(tint(text, 200))
            p.drawText(QtCore.QRectF(x + 16, 0, self.width(), self.height()), QtCore.Qt.AlignVCenter, label)
        p.end()


class ChannelWaterfall(QtWidgets.QWidget):
    HINT = "列をクリックで詳細　·　Ctrl / Shift+クリックで複数選択　·　右クリックで 除外 / 聞かない / ソロ / 優先 / 通知 を設定"
    STYLE = """
        QPushButton#historyTool {
            border: 1px solid palette(mid); border-radius: 12px; padding: 3px 12px;
            background: palette(base);
        }
        QPushButton#historyTool:hover { border-color: #ff9a1f; }
        QPushButton#historyTool:checked {
            background: rgba(255,154,31,0.18); border-color: #ff9a1f; color: #ffb45c; font-weight: 600;
        }
        QScrollArea#historyScroll { border: 1px solid palette(midlight); border-radius: 6px; }
        QLabel#historyDetail { color: #9c8668; padding: 2px 4px; }
        QLabel#historyDetail[selected="true"] {
            color: palette(text); background: rgba(255,154,31,0.08);
            border-left: 3px solid #ff9a1f; border-radius: 3px; padding: 4px 8px;
        }
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("channelHistory")
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        bar = QtWidgets.QHBoxLayout()
        bar.setSpacing(6)
        # Collapsing only hides the view; history keeps recording underneath.
        self.toggle = QtWidgets.QToolButton()
        self.toggle.setCheckable(True)
        self.toggle.setChecked(True)
        self.toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.toggle.setAutoRaise(True)
        self.toggle.setText("ウォーターフォール")
        self.toggle.setArrowType(QtCore.Qt.DownArrow)
        self.toggle.setToolTip("チャンネル履歴（ウォーターフォール）の表示・非表示を切り替えます。\n"
                               "隠している間も履歴は記録を続けます。")
        bar.addWidget(self.toggle)
        self.legend = HistoryLegend()
        bar.addWidget(self.legend, 1)
        self.pause = QtWidgets.QPushButton("履歴を固定")
        self.pause.setObjectName("historyTool")
        self.pause.setCheckable(True)
        self.pause.setToolTip("表示だけを固定します。受信と録音は継続します。")
        self.zoom = QtWidgets.QComboBox()
        self.zoom.setObjectName("historyZoom")
        self.zoom.addItems(["全ch表示", "拡大 18px", "拡大 24px", "拡大 48px", "拡大 96px"])
        self.zoom.setToolTip("チャンネル履歴の表示幅です。全chを1画面に収めるか、1chあたりの幅を広げて見やすくします。")
        bar.addWidget(self.pause)
        bar.addWidget(self.zoom)
        bar.addStretch()  # keeps the toggle at the left while the legend is hidden
        layout.addLayout(bar)
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setObjectName("historyScroll")
        self.scroll.setWidgetResizable(True)
        self.canvas = WaterfallCanvas()
        self.scroll.setWidget(self.canvas)
        self.scroll.horizontalScrollBar().rangeChanged.connect(self.fit_height)
        layout.addWidget(self.scroll)
        self.detail = QtWidgets.QLabel(self.HINT)
        self.detail.setObjectName("historyDetail")
        self.detail.setTextFormat(QtCore.Qt.PlainText)
        self.detail.setWordWrap(True)
        layout.addWidget(self.detail)
        self.canvas.selected.connect(self.show_selection)
        self.pause.toggled.connect(self.canvas.freeze)
        self.pause.toggled.connect(lambda enabled: self.pause.setText("履歴を再開" if enabled else "履歴を固定"))
        self.zoom.currentIndexChanged.connect(self.set_zoom)
        self.toggle.toggled.connect(self.set_open)
        self.setStyleSheet(self.STYLE)
        self.fit_height()

    def set_open(self, opened):
        self.toggle.setChecked(opened)
        self.toggle.setArrowType(QtCore.Qt.DownArrow if opened else QtCore.Qt.RightArrow)
        for widget in (self.legend, self.pause, self.zoom, self.scroll, self.detail):
            widget.setVisible(opened)

    def show_selection(self, text):
        self.detail.setText(text)
        if not self.detail.property("selected"):
            self.detail.setProperty("selected", True)
            self.detail.style().unpolish(self.detail)
            self.detail.style().polish(self.detail)

    def set_zoom(self, index):
        self.canvas.zoom = (0, 18, 24, 48, 96)[index]
        self.canvas.update_size()
        self.fit_height()

    def fit_height(self, *_):
        """As tall as the 10 s of history, plus the horizontal scrollbar when it shows.

        The 48/96 px zooms make rows that tall too; they keep the normal
        height and scroll vertically instead of growing past the window.
        """
        bar = self.scroll.horizontalScrollBar()
        extra = bar.sizeHint().height() if bar.maximum() > 0 else 0
        height = min(self.canvas.content_height(), WaterfallCanvas.header + WaterfallCanvas.row_height * 21)
        self.scroll.setFixedHeight(height + 2 * self.scroll.frameWidth() + extra)

    def set_columns(self, columns):
        self.pause.setChecked(False)
        self.canvas.set_columns(columns)

    def update_channels(self, channels, now=None, output_muted=False):
        self.canvas.last_feed = time.monotonic() if now is None else now
        self.canvas.update_channels(channels, now, output_muted)
