"""Dark application theme, matching the EVA-style neon console and channel tiles.

Applied once to the QApplication: Fusion style plus a dark palette, so every
standard widget, dialog and stylesheet rule written as palette(...) follows.
"""
from PyQt5 import QtGui, QtWidgets

WINDOW = "#0b0a0d"
PANEL = "#110f14"
BASE = "#07060a"
ALT_BASE = "#16131a"
TEXT = "#ead9bf"
MUTED = "#9c8668"        # secondary text (captions, hints)
FAINT = "#5e4f3e"        # disabled text
LINE = "#3a2c1c"         # borders, grid
ACCENT = "#ff9a1f"       # orange, as in the console


def dark_palette():
    c = QtGui.QColor
    palette = QtGui.QPalette()
    roles = {
        QtGui.QPalette.Window: WINDOW,
        QtGui.QPalette.WindowText: TEXT,
        QtGui.QPalette.Base: BASE,
        QtGui.QPalette.AlternateBase: ALT_BASE,
        QtGui.QPalette.Text: TEXT,
        QtGui.QPalette.Button: PANEL,
        QtGui.QPalette.ButtonText: TEXT,
        QtGui.QPalette.BrightText: "#ffffff",
        QtGui.QPalette.Highlight: ACCENT,
        QtGui.QPalette.HighlightedText: BASE,
        QtGui.QPalette.ToolTipBase: PANEL,
        QtGui.QPalette.ToolTipText: TEXT,
        QtGui.QPalette.PlaceholderText: MUTED,
        QtGui.QPalette.Link: ACCENT,
        QtGui.QPalette.LinkVisited: "#d9822a",
        # Fusion draws frames and bevels from these.
        QtGui.QPalette.Light: "#2c2430",
        QtGui.QPalette.Midlight: "#221c26",
        QtGui.QPalette.Mid: LINE,
        QtGui.QPalette.Dark: "#050407",
        QtGui.QPalette.Shadow: "#000000",
    }
    for role, color in roles.items():
        palette.setColor(role, c(color))
    for role in (QtGui.QPalette.WindowText, QtGui.QPalette.Text, QtGui.QPalette.ButtonText):
        palette.setColor(QtGui.QPalette.Disabled, role, c(FAINT))
    palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Highlight, c(LINE))
    return palette


def apply_dark_theme(app):
    app.setStyle(QtWidgets.QStyleFactory.create("Fusion"))
    app.setPalette(dark_palette())
    # Tooltips are top-level windows; give them a matching frame.
    app.setStyleSheet(f"QToolTip {{ color: {TEXT}; background: {PANEL}; border: 1px solid {LINE}; padding: 4px; }}")
