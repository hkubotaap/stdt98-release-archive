"""Hexagonal channel tiles (EVA-style neon monitor panels) and their honeycomb placement."""
import math
import time

from PyQt5 import QtCore, QtGui, QtWidgets

from app.channel_waterfall import channel_cell, quality_level
from core.pipeline.multi_stack_dashboard import _format_csm

# Pointy-top hexagon: flat left/right sides, so a row of tiles shares edges.
TILE_RADIUS = 115
TILE_WIDTH = round(math.sqrt(3) * TILE_RADIUS)     # 199
TILE_HEIGHT = 2 * TILE_RADIUS                      # 230
TILE_GAP = 4

# Neon tube colours on a near-black panel.
CARD_ACCENTS = {
    "close": "#6b5236",     # dim amber, unlit: idle channel
    "open": "#ff9a1f",      # orange: receiving, CRC not measured yet
    "good": "#39ff88",      # green: CRC >= 80 %
    "fair": "#ffe14d",      # yellow: CRC >= 50 %
    "poor": "#ff3355",      # red: CRC < 50 %
}
CARD_BACKGROUND = "#07060a"
CARD_TEXT = "#f0b46e"
# EVA titles are set in Matisse EB, squeezed horizontally; HGP Mincho E is the
# usual stand-in on Windows. Fall back to other heavy Mincho faces.
EVA_TITLE_FONTS = ("HGP明朝E", "HGPMinchoE", "Noto Serif JP Black", "Yu Mincho")


def _eva_title_font(pixel_size):
    families = set(QtGui.QFontDatabase().families())
    font = QtGui.QFont(next((name for name in EVA_TITLE_FONTS if name in families), "serif"))
    font.setStyleHint(QtGui.QFont.Serif)
    font.setPixelSize(pixel_size)
    font.setWeight(QtGui.QFont.Black)
    font.setStretch(80)  # 長体, like the EVA title cards
    return font


def content_mode(channel):
    """EVA-style plate text for what an open channel carries.

    Uses the history grid's rules (channel_cell) so both views agree: decoded
    voice or audio playing now -> SOUND ONLY, data -> DATA ONLY, control
    (sync burst) -> CONTROL ONLY, otherwise plain OPEN.
    """
    cell = channel_cell(channel)
    if cell.playing or cell.state == "音声データ":
        return "SOUND ONLY"
    return {"データ": "DATA ONLY", "コントロール": "CONTROL ONLY"}.get(cell.state, "OPEN")


def _glow(widget, color, radius=14):
    """Neon halo around a label (a zero-offset blurred shadow)."""
    effect = QtWidgets.QGraphicsDropShadowEffect(widget)
    effect.setOffset(0, 0)
    effect.setBlurRadius(radius)
    effect.setColor(QtGui.QColor(color))
    widget.setGraphicsEffect(effect)
    return effect


def _hexagon(cx, cy, radius, start_degrees):
    return QtGui.QPolygonF([
        QtCore.QPointF(cx + radius * math.cos(math.radians(start_degrees + 60 * i)),
                       cy + radius * math.sin(math.radians(start_degrees + 60 * i)))
        for i in range(6)
    ])


def tile_hexagon(inset=0.0):
    """The tile outline (pointy-top) in tile coordinates, shrunk by inset px."""
    return _hexagon(TILE_WIDTH / 2, TILE_HEIGHT / 2, TILE_RADIUS - inset, 30)


STEP_X = TILE_WIDTH + TILE_GAP
STEP_Y = round(TILE_HEIGHT * 0.75 + TILE_GAP * math.sqrt(3) / 2)


class HoneycombSlots:
    """Stable slot numbers for the visible tiles.

    A tile keeps its slot while it stays visible, so nothing moves when other
    channels come and go; a newly visible channel takes the lowest free slot,
    filling the gap a closed channel left behind.
    """

    def __init__(self):
        self.slots = {}

    def update(self, visible_ids):
        visible = set(visible_ids)
        for channel_id in tuple(self.slots):
            if channel_id not in visible:
                del self.slots[channel_id]
        taken = set(self.slots.values())
        free = (slot for slot in range(len(visible) + len(taken) + 1) if slot not in taken)
        for channel_id in sorted(visible - self.slots.keys()):
            self.slots[channel_id] = next(free)
        return dict(self.slots)

    def clear(self):
        self.slots.clear()


def honeycomb_grid(available_width):
    """(tiles per row, left offset) for this width.

    Depends only on the width, never on how many tiles are visible, so a
    tile's position is fixed by its slot. Rows share flat edges; every other
    row shifts by half a tile and tucks into the row above.
    """
    per_row = max(1, int((available_width - STEP_X // 2 + TILE_GAP) // STEP_X))
    used = per_row * STEP_X - TILE_GAP + STEP_X // 2
    return per_row, max(0, (available_width - used) // 2)


def slot_position(slot, per_row, left):
    row, col = divmod(slot, per_row)
    return QtCore.QPoint(left + col * STEP_X + (STEP_X // 2 if row % 2 else 0), row * STEP_Y)


def comb_height(slot_count, per_row):
    if slot_count <= 0:
        return 0
    return (math.ceil(slot_count / per_row) - 1) * STEP_Y + TILE_HEIGHT


CALL_STAT_UNVERIFIED_TIP = ("この帯域（免許局）では SACCH の通話識別（平文/秘話）の意味が未確認です。\n"
                            "「平文」と出ても音声として復号できない通話があります。")


def _format_sacch_short(channel, call_stat_verified=True):
    if not channel.sacch:
        return "SACCH --"
    stat = channel.sacch.get("CallStat", 0)
    plain = "平文" if call_stat_verified else "平文?"
    stat_text = plain if stat == 0 else "秘話" if stat == 1 else str(stat)
    return f"UC {channel.sacch.get('UserCode', 0):03d}  MK {channel.sacch.get('MakerCode', 0):03d}  {stat_text}"


class ChannelCard(QtWidgets.QFrame):
    """One channel as a hexagonal monitor tile.

    The accent colour follows RX state and, while receiving, the voice CRC
    (same thresholds as the history grid). The widget is masked to its
    hexagon so neighbouring tiles in the honeycomb never paint over it.
    """

    def __init__(self, channel_id, title=None, parent=None):
        super().__init__(parent)
        self.channel_id = channel_id
        # False on bands where SACCH CallStat's meaning is unconfirmed (licensed stations).
        self.call_stat_verified = True
        self.setObjectName("channelCard")
        self.setProperty("rx", "close")
        self.setProperty("quality", "")
        self.setFixedSize(TILE_WIDTH, TILE_HEIGHT)
        self.setMask(QtGui.QRegion(tile_hexagon().toPolygon()))
        self._accent = None

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(16, 24, 16, 24)
        layout.setSpacing(1)

        # The backend publishes a one-based frequency slot. The 97-channel
        # plan has overlapping 3R/3S/3U channel numbers, so show its label:
        # "3R CH01  351.20000 MHz" splits into a name line and a frequency line
        # so the name fits the narrow top of the hexagon.
        # Parented now: set_title() shows the frequency line before the layout
        # adopts it, and a parentless label would flash up as its own window.
        self._title = QtWidgets.QLabel(self)
        self._title.setObjectName("channelTitle")
        self._title.setAlignment(QtCore.Qt.AlignCenter)
        self._frequency = QtWidgets.QLabel(self)
        self._frequency.setObjectName("channelFrequency")
        self._frequency.setAlignment(QtCore.Qt.AlignCenter)
        self.set_title(title or f"CH {channel_id:02d}")
        self._title.setFont(_eva_title_font(23))
        self._rx = QtWidgets.QLabel("CLOSE")
        self._rx.setAlignment(QtCore.Qt.AlignCenter)
        self._rx.setObjectName("rxBadge")
        self._rx.setProperty("rx", "close")
        self._rx.setProperty("quality", "")
        self._rx.setToolTip("SOUND ONLY: 音声 / DATA ONLY: データ / CONTROL ONLY: 制御信号 / OPEN: 内容未判定\n"
                            "色は音声フレームのCRC（直近25フレーム）です。\n"
                            "緑: 80%以上 / 黄: 50%以上 / 赤: 50%未満 / 橙: 受信中・未測定。")
        # Serif plate lettering, like EVA's SEELE "SOUND ONLY" monoliths.
        badge_font = QtGui.QFont("Times New Roman")
        badge_font.setStyleHint(QtGui.QFont.Serif)
        badge_font.setPixelSize(17)
        badge_font.setBold(True)
        badge_font.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 1.2)
        self._rx.setFont(badge_font)
        self._crc = QtWidgets.QLabel("")
        self._crc.setObjectName("channelCrc")
        self._crc.setAlignment(QtCore.Qt.AlignCenter)
        self._crc.hide()

        self._protocol = QtWidgets.QLabel("Waiting")
        self._audio = QtWidgets.QLabel("Idle")
        self._secret = QtWidgets.QLabel("key=00000 | Idle")
        self._csm = QtWidgets.QLabel("CSM: -")
        self._sacch = QtWidgets.QLabel("SACCH: -")
        self._age = QtWidgets.QLabel("")
        self._age.setObjectName("channelAge")
        for label in (self._protocol, self._audio, self._secret, self._csm, self._sacch, self._age):
            label.setAlignment(QtCore.Qt.AlignCenter)
        for label in (self._protocol, self._audio, self._secret, self._csm, self._sacch):
            label.setObjectName("channelDetail")

        layout.addWidget(self._title)
        layout.addWidget(self._frequency)
        layout.addSpacing(2)
        layout.addWidget(self._rx, 0, QtCore.Qt.AlignHCenter)
        layout.addWidget(self._crc)
        layout.addSpacing(2)
        for label in (self._protocol, self._audio, self._sacch, self._csm, self._secret):
            layout.addWidget(label)
        layout.addStretch(1)
        layout.addWidget(self._age)
        self._rx.setFixedWidth(TILE_WIDTH - 44)
        self._glows = [_glow(widget, CARD_ACCENTS["close"]) for widget in
                       (self._title, self._frequency, self._rx, self._crc, self._age)]
        self._refresh_accent()

    # --- state -------------------------------------------------------------
    def set_title(self, title):
        self.title = title
        name, _, frequency = title.partition("  ")
        self._title.setText(name)
        self._frequency.setText(frequency.strip())
        self._frequency.setVisible(bool(frequency.strip()))

    def _set_card_property(self, name, value):
        if self.property(name) != value:
            for widget in (self, self._rx):
                widget.setProperty(name, value)
            self._refresh_accent()

    def _set_rx_property(self, value):
        self._set_card_property("rx", value)

    def _show_mode_lines(self, mode):
        """A known mode on the badge makes the Proto/Audio lines redundant."""
        self._protocol.setVisible(mode == "OPEN")
        self._audio.setVisible(mode == "OPEN")

    def update_from(self, channel, show_debug):
        if channel is None:
            self._show_mode_lines("OPEN")
            self._crc.hide()
            self._set_rx_property("close")
            self._set_card_property("quality", "")
            self._rx.setText("CLOSE")
            self._protocol.setText("Waiting")
            self._audio.setText("Idle")
            self._secret.setText("key=00000 | Idle")
            self._csm.setText("CSM: -")
            self._sacch.setText("SACCH: -")
            self._age.setText("")
            self.setToolTip("")
            return

        is_open = channel.rx_status == "OPEN"
        self._set_rx_property("open" if is_open else "close")
        crc = channel.crc_percent
        self._set_card_property("quality", quality_level(crc) if is_open else "")
        mode = content_mode(channel)
        if not is_open and mode != "SOUND ONLY":
            mode = "CLOSE"   # audio may still be draining after RX closes
        self._rx.setText(mode)
        self._show_mode_lines("OPEN" if mode == "CLOSE" else mode)
        self._crc.setText(f"CRC {crc:.0f}%" if crc is not None else "CRC --")
        self._crc.setVisible(is_open)
        self._protocol.setText(f"Proto: {channel.protocol_status}")
        self._audio.setText(f"Audio: {channel.audio_status}")
        self._secret.setText(f"key={channel.secret_key:05d} | {channel.secret_status}")
        self._csm.setText(f"CSM: {_format_csm(channel)}")
        self._sacch.setText(_format_sacch_short(channel, self.call_stat_verified))
        self._sacch.setToolTip("" if self.call_stat_verified else CALL_STAT_UNVERIFIED_TIP)
        age = max(0.0, time.time() - channel.last_update)
        self._age.setText(f"{age:4.1f}s")

        # Debug details do not fit in the hexagon; show them on hover instead.
        parts = [
            f"RF: {channel.rf_debug}" if channel.rf_debug else "",
            f"Proto: {channel.protocol_debug}" if channel.protocol_debug else "",
            f"Audio: {channel.audio_debug}" if channel.audio_debug else "",
        ] if show_debug else []
        self.setToolTip("\n".join(part for part in parts if part))

    def mark_recent(self, remaining_seconds):
        """Keep the last received details visible while the channel cools down."""
        self._set_rx_property("recent")
        self._show_mode_lines("OPEN")
        self._rx.setText("受信終了")
        self._age.setText(f"あと {remaining_seconds:.1f}s")

    # --- appearance ----------------------------------------------------------
    def _refresh_accent(self):
        rx = self.property("rx")
        live = rx == "open"
        key = "close" if rx == "close" else (self.property("quality") or ("open" if live else "close"))
        accent = QtGui.QColor(CARD_ACCENTS[key])
        if not live and key != "close":
            accent = accent.darker(160)  # cooling down: keep the last colour, dimmed
        state = (accent.name(), live)
        if state == self._accent:
            return
        self._accent = state
        name = accent.name()
        lit = accent.lighter(135).name()   # the bright core of a neon tube
        tint = f"rgba({accent.red()},{accent.green()},{accent.blue()},{0.16 if live else 0.0})"
        for effect in self._glows:
            effect.setColor(accent)
            effect.setEnabled(live)  # unlit tiles have no halo
        # Per-tile sheet, rebuilt only when the accent actually changes.
        self.setStyleSheet(f"""
            QLabel {{ color: {CARD_TEXT}; background: transparent; }}
            QLabel#channelTitle {{ color: {lit if live else name}; }}
            QLabel#channelFrequency {{ color: {name}; font-family: Consolas, monospace; font-size: 11px; }}
            QLabel#channelAge {{ color: {name}; font-family: Consolas, monospace; font-size: 11px; }}
            QLabel#channelDetail {{ font-family: Consolas, monospace; font-size: 10px; }}
            QLabel#rxBadge {{
                padding: 1px 0; border: {2 if live else 1}px solid {name}; border-radius: 3px;
                color: {lit if live else name}; background: {tint};
            }}
            QLabel#channelCrc {{ color: {name}; font-family: Consolas, monospace; font-size: 11px; font-weight: 700; }}
        """)
        self.update()

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        accent = QtGui.QColor(self._accent[0])
        live = self._accent[1]
        outline = tile_hexagon(1.5)
        p.setPen(QtCore.Qt.NoPen)
        p.setBrush(QtGui.QColor(CARD_BACKGROUND))
        p.drawPolygon(outline)

        # Faint rear honeycomb inside the tile.
        p.save()
        clip = QtGui.QPainterPath()
        clip.addPolygon(tile_hexagon(4))
        p.setClipPath(clip)
        rear = QtGui.QColor(accent)
        rear.setAlpha(40 if live else 16)
        p.setPen(QtGui.QPen(rear, 1))
        p.setBrush(QtCore.Qt.NoBrush)
        radius = 10.0
        dx, dy = radius * 1.5, radius * math.sqrt(3)
        for col in range(int(TILE_WIDTH / dx) + 2):
            for row in range(int(TILE_HEIGHT / dy) + 2):
                p.drawPolygon(_hexagon(col * dx, row * dy + (dy / 2 if col % 2 else 0), radius - 1.5, 0))
        p.restore()

        p.setBrush(QtCore.Qt.NoBrush)
        tube = tile_hexagon(7)
        round_pen = (QtCore.Qt.SolidLine, QtCore.Qt.RoundCap, QtCore.Qt.RoundJoin)
        if live:
            # Neon tube: wide faint halo -> tighter glow -> bright core -> white-hot centre.
            for width, alpha in ((18, 18), (12, 36), (7, 80), (4, 150)):
                halo = QtGui.QColor(accent)
                halo.setAlpha(alpha)
                p.setPen(QtGui.QPen(halo, width, *round_pen))
                p.drawPolygon(tube)
            p.setPen(QtGui.QPen(accent.lighter(140), 2.2, *round_pen))
            p.drawPolygon(tube)
            p.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255, 190), 0.8))
            p.drawPolygon(tube)
        else:
            p.setPen(QtGui.QPen(accent, 1.5))
            p.drawPolygon(tube)
        inner = QtGui.QColor(accent)
        inner.setAlpha(110 if live else 60)
        p.setPen(QtGui.QPen(inner, 1))
        p.drawPolygon(tile_hexagon(15))
        # Marker bar under the top vertex, like the EVA monitors.
        p.setPen(QtCore.Qt.NoPen)
        p.setBrush(accent)
        p.drawRect(QtCore.QRectF(TILE_WIDTH / 2 - 16, 18, 32, 3))
