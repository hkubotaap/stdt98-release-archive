"""Write down where the GUI thread is stuck when the window stops responding.

The GUI runs under pythonw, so there is no console to see a freeze or a crash.
A QTimer in the GUI thread updates a heartbeat; a daemon thread notices when
the heartbeat stops and dumps every thread's stack to the GUI log once per
stall, then logs how long the stall lasted when the GUI recovers.
"""
import faulthandler
import threading
import time

from PyQt5 import QtCore

HEARTBEAT_MS = 250
STALL_SECONDS = 3.0


class StallWatchdog:
    def __init__(self, log_file, stall_seconds=STALL_SECONDS, parent=None):
        self.log_file = log_file
        self.stall_seconds = float(stall_seconds)
        self._beat = time.monotonic()
        self._stop = threading.Event()
        self._timer = QtCore.QTimer(parent)
        self._timer.setInterval(HEARTBEAT_MS)
        self._timer.timeout.connect(self._heartbeat)
        self._thread = threading.Thread(target=self._watch, name="gui-stall-watchdog", daemon=True)

    def start(self):
        self._beat = time.monotonic()
        self._timer.start()
        self._thread.start()

    def stop(self):
        self._stop.set()
        self._timer.stop()

    def _heartbeat(self):
        self._beat = time.monotonic()

    def _watch(self):
        stalled_since = None
        while not self._stop.wait(0.5):
            silent = time.monotonic() - self._beat
            if silent >= self.stall_seconds and stalled_since is None:
                stalled_since = self._beat
                self._write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} GUI not responding for "
                            f"{silent:.1f} s; stacks of all threads (GUI = MainThread) ===\n")
                faulthandler.dump_traceback(self.log_file, all_threads=True)
                self.log_file.flush()
            elif silent < self.stall_seconds and stalled_since is not None:
                self._write(f"=== {time.strftime('%Y-%m-%d %H:%M:%S')} GUI recovered after "
                            f"{time.monotonic() - stalled_since:.1f} s ===\n")
                stalled_since = None

    def _write(self, text):
        try:
            self.log_file.write(text)
            self.log_file.flush()
        except (OSError, ValueError):
            pass
