"""Native-color HackRF gain selectors; allowed values follow hardware steps."""
from PyQt5 import QtCore, QtWidgets
from core.rf.hackrf_gain import HackRFGains


class HackRFGainControls(QtWidgets.QWidget):
    changed = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        row = QtWidgets.QHBoxLayout()
        self.lna = QtWidgets.QComboBox()
        self.vga = QtWidgets.QComboBox()
        for widget, maximum, step in ((self.lna, 40, 8), (self.vga, 62, 2)):
            for value in range(0, maximum + 1, step):
                widget.addItem(f"{value} dB", value)
            widget.currentIndexChanged.connect(lambda _index: self.changed.emit())
        self.amp = QtWidgets.QCheckBox("AMP")
        self.lna.setToolTip("LNA：アンテナ直後の増幅（0〜40dB、8dB刻み）。弱い電波を持ち上げます。")
        self.vga.setToolTip("VGA：ベースバンドの増幅（0〜62dB、2dB刻み）。最後の音量合わせに使います。")
        self.amp.setToolTip("RFアンプのON/OFF。とても弱い電波向けですが、強い電波があると歪みます。\n"
                            "アンテナへの給電（Bias Tee）とは別の設定です。")
        self.amp.toggled.connect(lambda _checked: self.changed.emit())
        for name, widget in (("LNA", self.lna), ("VGA", self.vga)):
            row.addWidget(QtWidgets.QLabel(name))
            row.addWidget(widget)
        row.addWidget(self.amp)
        layout.addLayout(row)
        self.current = QtWidgets.QLabel("開始時の設定値。自動調整中は下に現在値を表示します。")
        self.current.setToolTip("自動調整はIQ入力レベルとクリッピングを監視します。手動設定は自動調整をOFFにすると操作できます。")
        layout.addWidget(self.current)
        self.set_gains(HackRFGains())

    def gains(self):
        return HackRFGains(self.lna.currentData(), self.vga.currentData(), self.amp.isChecked())

    def set_gains(self, gains):
        blockers = [QtCore.QSignalBlocker(widget) for widget in (self.lna, self.vga, self.amp)]
        self.lna.setCurrentIndex(self.lna.findData(int(gains.lna)))
        self.vga.setCurrentIndex(self.vga.findData(int(gains.vga)))
        self.amp.setChecked(gains.amp)
        del blockers

    def set_manual_enabled(self, enabled):
        for widget in (self.lna, self.vga, self.amp):
            widget.setEnabled(enabled)

    def show_current(self, state):
        gains = HackRFGains(state["lna_gain"], state["vga_gain"], state["amp"])
        mode = "自動" if state["auto"] else "手動"
        self.current.setText(f"現在 [{mode}]  LNA {gains.lna:g} dB / VGA {gains.vga:g} dB / AMP {'ON' if gains.amp else 'OFF'}")
