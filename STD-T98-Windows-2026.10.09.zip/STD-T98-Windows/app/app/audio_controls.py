"""Native-color live audio controls and the plugin's portable audition tool."""
import json
import os
from pathlib import Path
import sys

from PyQt5 import QtCore, QtWidgets

from app.channel_roles import build_role_menu
from app.call_notifier import DEFAULT_COOLDOWN_SEC, NotifyRules, parse_csm_list, parse_user_codes
from core.rf.channel_plan import PLAN_BY_FREQUENCY, channel_labels
from core.audio.recordings import default_data_dir, channel_frequencies, minimum_recording_seconds, MAX_MIN_RECORDING_SECONDS, maximum_recordings, excluded_frequencies, recording_crc_percent, priority_duck_percent
from core.audio.recordings import DEFAULT_PLAYBACK_BUFFER_FRAMES, MAX_PLAYBACK_BUFFER_FRAMES, playback_buffer_frames, maximum_playback_channels
from core.audio.data_paths import resolve_data_dir, restore_data_dir, data_dir_setting
from core.audio.recordings import DEFAULT_CRC_MIN_PERCENT, DEFAULT_MIN_RECORDING_SECONDS, DEFAULT_RECORD_CRC_MIN_PERCENT, DEFAULT_MAX_RECORDINGS, DEFAULT_MAX_PLAYBACK_CHANNELS


# Per-frequency listening roles: column in the channel table and settings key.
CHANNEL_ROLES = (("exclude", "除外", "excluded_frequencies"),
                 ("mute", "聞かない", "mute_frequencies"),
                 ("solo", "ソロ", "solo_frequencies"),
                 ("priority", "優先", "priority_frequencies"),
                 ("notify", "通知", "notify_frequencies"))
ROLE_KEYS = {role: key for role, _, key in CHANNEL_ROLES}
AUDIO_CHECK_TIPS = {
    "voice_output": "受信した音声をスピーカーから出します。オフでも受信・録音・通知は続きます。",
    "speaker_agc": "声の大小をならして、聞きやすい音量に自動でそろえます。",
    "noise_suppression": "秘話の鍵が合っていないと判断した音声（ザーという雑音）を消音します。\n"
                         "電波が悪いときの消音は「再生するCRC成功率」で設定します。",
    "crc_concealment": "誤りのある音声の区切り（20ms）を、直前の正常な音声でなめらかに埋めます。\n"
                       "オフにすると、誤りの部分が無音になり、プツプツと途切れて聞こえます。",
    "hq_resampler": "再生用の 8kHz→48kHz 変換を、直線補間から高品質フィルタ（FIR）に切り替えます。\n"
                    "直線補間で出ていた 4〜8kHz のシャリシャリした折り返し音を除き、3kHz 付近の\n"
                    "高音の減衰（約4dB）もなくします。遅延は約2msです。録音（WAV）は変わりません。\n"
                    "受信中にも反映します。",
    "soft_voice_fec": "音声（AMBE）の誤り訂正で、受信したシンボルの確からしさ（軟判定）も使います。\n"
                      "0/1に丸めてから直す従来の方法より、弱い電波で声のパラメータを正しく直せる率が\n"
                      "上がります。直しきれない区切りは誤りとして扱い、補間します。録音（.t98raw）は\n"
                      "従来どおり受信したままのビットです。受信中にも反映します。",
    "pitch_plc": "受信できなかったフレームや誤りのある区切りを、直前の声の基本周期をくり返して埋めます。\n"
                 "20msごとの区切りをくり返す従来の補間で出ていた「ブー」という50Hzのうなりが出ません。\n"
                 "40ms はそのままの音量、その後80msで消えます。音声が戻るときは5msでなめらかにつなぎます。\n"
                 "「CRC / FECエラーを直前の音声で補間」がオンのときだけ働きます。受信中にも反映します。",
    "flywheel_recovery": "通話中に同期語を検出できなかったフレームも、来るはずの位置から取り出し、\n"
                         "通話識別のパリティと制御情報のCRCが両方正しいときに再生します。\n"
                         "取りこぼしによる音切れが減ります。受信中にも反映します。",
    "recording": "通話ごとに、生音声（鍵を変えて聞き直せる .t98raw）、CRC情報、WAVを自動で保存します。",
    "record_frame_bits": "録音対象の通話フレームに、SW・RICH・SACCHを含む全384ビットも保存します。\n"
                         "復調直後の元ビットと、デホワイトニング後の解析用ビットを edu に追加保存します。\n"
                         "フレーム解析で、HEX・ビット列・各項目の解説を確認できます。保存容量は増えます。\n"
                         "自動録音がオンのときに有効です。変更は次の通話の録音から反映します。",
}
# Checks that stay off until the user turns them on.
OPT_IN_CHECKS = {"record_frame_bits"}
ROLE_COLUMNS = {role: column for column, (role, _, _) in enumerate(CHANNEL_ROLES, 1)}
# Turning a role on clears the roles that contradict it.
ROLE_CONFLICTS = {"exclude": {"mute", "solo", "priority", "notify"},
                  "mute": {"exclude", "solo", "priority"},
                  "solo": {"exclude", "mute"},
                  "priority": {"exclude", "mute"},
                  "notify": {"exclude"}}


class AudioControls(QtWidgets.QDialog):
    channel_roles_changed = QtCore.pyqtSignal()
    test_notification_requested = QtCore.pyqtSignal()
    def __init__(self, repo_root, parent=None):
        super().__init__(parent)
        self.repo_root = Path(os.path.abspath(repo_root))
        self.preferences = QtCore.QSettings("std-t98-tools", "receiver")
        saved_dir = self.preferences.value("record_dir", "std98_data", type=str)
        saved_mode = self.preferences.value("record_dir_mode", "", type=str)
        self.data_dir = restore_data_dir(saved_dir, self.repo_root, saved_mode)
        self.setWindowTitle("音声・録音設定")
        self.resize(620, 560)
        self.values = {}
        self.processes = []
        try:
            self.values = json.loads(self.settings_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        layout = QtWidgets.QVBoxLayout(self)
        self.tabs = QtWidgets.QTabWidget()
        layout.addWidget(self.tabs, 1)
        audio_page = QtWidgets.QWidget()
        audio_layout = QtWidgets.QVBoxLayout(audio_page)
        self.tabs.addTab(audio_page, "音声・録音")
        self.checks = {}
        for name, label in (("voice_output", "受信音声を再生"), ("speaker_agc", "音量を一定に保つ"),
                            ("noise_suppression", "ノイズ抑制（復号品質が低い音声を消音）"),
                            ("crc_concealment", "CRC / FECエラーを直前の音声で補間"),
                            ("fill_lost_frames", "受信できなかったフレームを埋めて音切れを抑える"),
                            ("hq_resampler", "高品質リサンプリング"),
                            ("soft_voice_fec", "音声の誤り訂正に軟判定を使う"),
                            ("pitch_plc", "音切れの補間を声の周期で行う"),
                            ("flywheel_recovery", "同期語を取りこぼしたフレームも再生する"),
                            ("recording", "チャンネル別の生音声・WAVを自動保存"),
                            ("record_frame_bits", "SW・RICH・SACCHも保存（フレーム解析用）")):
            check = QtWidgets.QCheckBox(label)
            check.setToolTip(AUDIO_CHECK_TIPS.get(name, ""))
            if name == "fill_lost_frames":
                check.setToolTip("同期を検出できずに失われたフレーム（1つ80ms）を、同じ長さの補間音で埋めて再生します。\n"
                                 "詰めて再生すると再生用のバッファが尽き、ためなおす間の長い音切れになります。\n"
                                 "補間音は直前の音声を短くフェードアウトし、その後は無音です（「CRC / FECエラーを\n"
                                 "直前の音声で補間」がオフなら無音）。リアルタイム再生だけが対象で、録音は変わりません。\n"
                                 "受信中にも反映します。")
            value = self.values.get(name, name not in OPT_IN_CHECKS)
            check.setChecked(value if name != "record_frame_bits" or isinstance(value, bool) else False)
            self.checks[name] = check
            check.toggled.connect(self.save)
            if name == "record_frame_bits":
                row = QtWidgets.QHBoxLayout()
                row.setContentsMargins(18, 0, 0, 0)
                row.addWidget(check, 1)
                self.frame_analysis_button = QtWidgets.QPushButton("フレーム解析…")
                self.frame_analysis_button.setToolTip("保存先の録音フレームを開き、SW・RICH・SACCH・TCHのビットと解説を確認します。")
                self.frame_analysis_button.clicked.connect(self.launch_frame_analysis)
                row.addWidget(self.frame_analysis_button)
                audio_layout.addLayout(row)
            else:
                audio_layout.addWidget(check)
        self.checks["record_frame_bits"].setEnabled(self.checks["recording"].isChecked())
        self.checks["recording"].toggled.connect(self.checks["record_frame_bits"].setEnabled)
        form = QtWidgets.QFormLayout()
        self.volume = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.volume.setRange(0, 200)
        self.volume.setValue(round(self.values.get("volume",1)*100))
        self.volume_label = QtWidgets.QLabel()
        volume_row = QtWidgets.QHBoxLayout()
        volume_row.addWidget(self.volume)
        volume_row.addWidget(self.volume_label)
        self.volume.setToolTip("リアルタイム再生の音量です。100%が標準、200%で2倍です。")
        form.addRow("音量", volume_row)
        self.crc_min = QtWidgets.QSpinBox()
        self.crc_min.setRange(0,100)
        self.crc_min.setSuffix(" %")
        self.crc_min.setSpecialValueText("0 %（率による消音なし）")
        self.crc_min.setValue(self.values.get("crc_min_percent", DEFAULT_CRC_MIN_PERCENT))
        self.crc_min.setToolTip("直近25フレームのCRC成功率がこの値未満なら消音。CRC全滅は常に消音します。")
        form.addRow("再生するCRC成功率",self.crc_min)
        self.playback_buffer = QtWidgets.QSpinBox()
        self.playback_buffer.setRange(1, MAX_PLAYBACK_BUFFER_FRAMES)
        self.playback_buffer.setSuffix(" フレーム")
        self.playback_buffer.setValue(playback_buffer_frames(self.values.get("playback_buffer_frames", DEFAULT_PLAYBACK_BUFFER_FRAMES)))
        self.playback_buffer.setToolTip("リアルタイム再生で、chごとにこの数の音声フレーム（1フレーム80ms）をためてから再生を始めます。\n"
                                        "途中で途切れて追い付いた場合も、再びためてから再開します。\n"
                                        "増やすと音切れが減り、その分ライブ音声が遅れます。秘話の頭出し再生と録音には影響しません。\n"
                                        "受信中にも反映し、次に再生を始めるときから適用します。")
        self.playback_buffer_label = QtWidgets.QLabel()
        buffer_row = QtWidgets.QHBoxLayout()
        buffer_row.addWidget(self.playback_buffer)
        buffer_row.addWidget(self.playback_buffer_label, 1)
        form.addRow("再生前にためるフレーム数", buffer_row)
        self.playback_max = QtWidgets.QSpinBox()
        self.playback_max.setRange(0, 97)
        self.playback_max.setSpecialValueText("制限なし")
        self.playback_max.setSuffix(" ch")
        self.playback_max.setValue(maximum_playback_channels(self.values.get("max_playback_channels", DEFAULT_MAX_PLAYBACK_CHANNELS)))
        self.playback_max.setToolTip("同時に再生するチャンネル数の上限。再生中の通話は最後まで再生し、上限に達した時に\n"
                                     "始まった通話はその通話が終わるまで再生しません（途中から鳴り始めることはありません）。\n"
                                     "優先チャンネルは上限に関係なく追加で再生し、上限の数にも含めません。\n"
                                     "聞かない・ソロで止めているチャンネルは数えません。受信・録音・通知には影響しません。\n"
                                     "受信中にも反映します。")
        form.addRow("同時に再生するch数の上限", self.playback_max)
        self.record_min = QtWidgets.QDoubleSpinBox()
        self.record_min.setRange(0, MAX_MIN_RECORDING_SECONDS)
        self.record_min.setDecimals(1)
        self.record_min.setSingleStep(0.1)
        self.record_min.setSuffix(" 秒")
        self.record_min.setSpecialValueText("0.0 秒（制限なし）")
        self.record_min.setValue(minimum_recording_seconds(self.values.get("min_recording_seconds", DEFAULT_MIN_RECORDING_SECONDS)))
        self.record_min.setToolTip("指定時間以上の交信だけ保存します。終了待ちの2秒は含みません。変更は次の録音から反映します。")
        form.addRow("最短録音時間",self.record_min)
        self.record_crc_min = QtWidgets.QSpinBox()
        self.record_crc_min.setRange(0, 100)
        self.record_crc_min.setSuffix(" %")
        self.record_crc_min.setSpecialValueText("0 %（制限なし）")
        self.record_crc_min.setValue(recording_crc_percent(self.values.get("record_crc_min_percent", DEFAULT_RECORD_CRC_MIN_PERCENT)))
        self.record_crc_min.setToolTip("通話全体のCRC成功率がこの値以上の通話だけ保存します。未満の通話は raw / rec / edu をすべて破棄します。変更は次の録音から反映します。")
        form.addRow("録音するCRC成功率", self.record_crc_min)
        self.record_max = QtWidgets.QSpinBox()
        self.record_max.setRange(0, 97)
        self.record_max.setSpecialValueText("制限なし")
        self.record_max.setSuffix(" ch")
        self.record_max.setValue(maximum_recordings(self.values.get("max_recordings", DEFAULT_MAX_RECORDINGS)))
        self.record_max.setToolTip("同時に録音するチャンネル数の上限。録音中の通話は継続し、上限に達した時に始まった通話は録音を見送ります。受信・再生には影響しません。")
        form.addRow("同時録音数の上限", self.record_max)
        audio_layout.addLayout(form)
        audio_layout.addStretch(1)
        roles_box = QtWidgets.QWidget()
        roles_layout = QtWidgets.QVBoxLayout(roles_box)
        self.channel_table = QtWidgets.QTreeWidget()
        self.channel_table.setHeaderLabels(["チャンネル", *(title for _, title, _ in CHANNEL_ROLES)])
        self.channel_table.setRootIsDecorated(False)
        self.channel_table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.channel_table.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.channel_table.customContextMenuRequested.connect(self._table_menu)
        self.channel_table.viewport().installEventFilter(self)
        self.channel_table.setUniformRowHeights(True)
        self.channel_table.setMinimumHeight(170)
        header = self.channel_table.header()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        for column in ROLE_COLUMNS.values():
            header.setSectionResizeMode(column, QtWidgets.QHeaderView.ResizeToContents)
        tips = {"exclude": "再生・録音・秘話鍵探索を行いません。",
                "mute": "再生だけを止めます。受信・録音・秘話鍵探索・通知は続けます。",
                "solo": "ソロに指定したチャンネルだけを再生します（録音は全チャンネル継続）。",
                "priority": "優先チャンネルの通話中は、他のチャンネルの音量を下げます。",
                "notify": "このチャンネルで通話が始まったら通知します（「通知」タブの設定に従います）。"}
        for role, column in ROLE_COLUMNS.items():
            self.channel_table.headerItem().setToolTip(column, tips[role])
        self.channel_table.setToolTip("Ctrl / Shift+クリックで複数選択し、選択中の行のチェックを切り替えるか右クリックすると、まとめて設定できます。"
                                      "周波数で保存するため、中心周波数を変えても同じ周波数に適用します。受信中にも反映します。"
                                      "チャンネル履歴の列を右クリックしても設定できます。")
        roles_layout.addWidget(self.channel_table)
        duck_row = QtWidgets.QFormLayout()
        self.priority_duck = QtWidgets.QSpinBox()
        self.priority_duck.setRange(0, 100)
        self.priority_duck.setSuffix(" %")
        self.priority_duck.setSpecialValueText("0 %（消音）")
        self.priority_duck.setValue(priority_duck_percent(self.values.get("priority_duck_percent", 25)))
        self.priority_duck.setToolTip("優先チャンネルの音声が出ている間（と途切れてから1.5秒）、他のチャンネルをこの音量にします。")
        duck_row.addRow("優先CH通話中の他CH音量", self.priority_duck)
        roles_layout.addLayout(duck_row)
        roles_buttons = QtWidgets.QHBoxLayout()
        self.roles_summary = QtWidgets.QLabel()
        roles_buttons.addWidget(self.roles_summary)
        roles_buttons.addStretch()
        clear_roles = QtWidgets.QPushButton("すべて解除")
        clear_roles.clicked.connect(self.clear_all_roles)
        clear_roles.setToolTip("すべてのチャンネルの除外・ミュート・ソロ・優先・通知の設定を解除します。")
        roles_buttons.addWidget(clear_roles)
        roles_layout.addLayout(roles_buttons)
        self.tabs.addTab(roles_box, "チャンネル")
        self.roles = {role: set(excluded_frequencies(self.values.get(key, []))) for role, key in ROLE_KEYS.items()}
        if not isinstance(self.values.get("frequencies"), dict):
            try:
                self.values["frequencies"] = channel_frequencies(())
            except Exception:
                self.values["frequencies"] = {}
        self.populate_channels()
        self.channel_table.itemChanged.connect(self.channel_item_changed)
        notify_page = QtWidgets.QWidget()
        notify_layout = QtWidgets.QVBoxLayout(notify_page)
        self.notify_desktop = QtWidgets.QCheckBox("デスクトップ通知（Windows の通知）")
        self.notify_desktop.setChecked(self.values.get("notify_desktop", True))
        self.notify_sound = QtWidgets.QCheckBox("通知音を鳴らす")
        self.notify_desktop.setToolTip("指定した局やチャンネルで通話が始まったら、Windowsの通知で知らせます。")
        self.notify_sound.setToolTip("通知と一緒に音を鳴らします。")
        self.notify_sound.setChecked(self.values.get("notify_sound", True))
        notify_layout.addWidget(self.notify_desktop)
        notify_layout.addWidget(self.notify_sound)
        notify_form = QtWidgets.QFormLayout()
        self.notify_csms = QtWidgets.QLineEdit(", ".join(parse_csm_list(",".join(map(str, self.values.get("notify_csms", []))))))
        self.notify_csms.setPlaceholderText("例: 200446991, 200512345")
        self.notify_csms.setToolTip("この CSM の局が話し始めたら、どのチャンネルでも通知します。カンマ・空白区切り。")
        notify_form.addRow("通知する CSM", self.notify_csms)
        self.notify_user_codes = QtWidgets.QLineEdit(", ".join(map(str, parse_user_codes(",".join(map(str, self.values.get("notify_user_codes", [])))))))
        self.notify_user_codes.setPlaceholderText("例: 12, 34")
        self.notify_user_codes.setToolTip("CRC・パリティが正常な SACCH のユーザーコードと照合します。カンマ・空白区切り。")
        notify_form.addRow("通知するユーザーコード", self.notify_user_codes)
        self.notify_cooldown = QtWidgets.QSpinBox()
        self.notify_cooldown.setRange(0, 3600)
        self.notify_cooldown.setSuffix(" 秒")
        self.notify_cooldown.setSpecialValueText("0 秒（毎回通知）")
        cooldown = self.values.get("notify_cooldown_seconds", DEFAULT_COOLDOWN_SEC)
        self.notify_cooldown.setValue(cooldown if isinstance(cooldown, int) and not isinstance(cooldown, bool) else DEFAULT_COOLDOWN_SEC)
        self.notify_cooldown.setToolTip("同じチャンネル・同じ相手の通話は、この時間内なら再通知しません。")
        notify_form.addRow("同じ相手の再通知まで", self.notify_cooldown)
        notify_layout.addLayout(notify_form)
        notify_hint = QtWidgets.QLabel("周波数で通知するチャンネルは「チャンネル」タブの「通知」列、またはチャンネル履歴の列を右クリックして設定します。"
                                       "1 通話につき 1 回だけ通知します。通知をクリックすると、そのチャンネルを選択します。")
        notify_hint.setWordWrap(True)
        notify_layout.addWidget(notify_hint)
        test_row = QtWidgets.QHBoxLayout()
        test_row.addStretch(1)
        test_notification = QtWidgets.QPushButton("テスト通知")
        test_notification.clicked.connect(self.test_notification_requested.emit)
        test_notification.setToolTip("今の通知設定で、試しに通知を出します。")
        test_row.addWidget(test_notification)
        notify_layout.addLayout(test_row)
        notify_layout.addStretch(1)
        self.tabs.addTab(notify_page, "通知")
        self.notify_desktop.toggled.connect(self.save)
        self.notify_sound.toggled.connect(self.save)
        self.notify_cooldown.valueChanged.connect(self.save)
        self.notify_csms.editingFinished.connect(self._notify_lists_edited)
        self.notify_user_codes.editingFinished.connect(self._notify_lists_edited)
        self.path_label = QtWidgets.QLabel(data_dir_setting(self.data_dir, self.repo_root))
        self.path_label.setToolTip(f"配布フォルダ基準の保存先です。\n実際のフォルダ: {self.data_dir}")
        self.path_label.setWordWrap(True)
        layout.addWidget(self.path_label)
        buttons = QtWidgets.QHBoxLayout()
        self.folder_button = QtWidgets.QPushButton("保存先…")
        self.folder_button.clicked.connect(self.choose_folder)
        self.folder_button.setToolTip("録音（生音声・WAV・CRC情報）の保存先フォルダを変更します。")
        buttons.addWidget(self.folder_button)
        open_folder = QtWidgets.QPushButton("フォルダを開く")
        open_folder.clicked.connect(self.open_folder)
        open_folder.setToolTip("保存先フォルダをエクスプローラーで開きます。")
        buttons.addWidget(open_folder)
        buttons.addStretch()
        close = QtWidgets.QPushButton("閉じる")
        close.clicked.connect(self.close)
        close.setToolTip("この画面を閉じます。設定は変更した時点で保存済みです。")
        buttons.addWidget(close)
        layout.addLayout(buttons)
        library = QtWidgets.QPushButton("既存のSDR#録音フォルダを開く…")
        library.setToolTip("raw / rec / edu が入っているフォルダを指定して試聴します。")
        library.clicked.connect(self.open_library)
        layout.addWidget(library)
        hint = QtWidgets.QLabel("設定は受信中にも反映します。録音制限は新しい通話から適用します。秘話は鍵待ち音声を保持し、鍵取得後に通話の頭から再生します。")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.volume.valueChanged.connect(self.save)
        self.crc_min.valueChanged.connect(self.save)
        self.record_min.valueChanged.connect(self.save)
        self.record_max.valueChanged.connect(self.save)
        self.record_crc_min.valueChanged.connect(self.save)
        self.priority_duck.valueChanged.connect(self.save)
        self.playback_buffer.valueChanged.connect(self.save)
        self.playback_max.valueChanged.connect(self.save)
        self.volume_label.setText(f"{self.volume.value()} %")
        self._update_playback_buffer_label()

    def _update_playback_buffer_label(self):
        frames = self.playback_buffer.value()
        default = "（標準）" if frames == DEFAULT_PLAYBACK_BUFFER_FRAMES else ""
        self.playback_buffer_label.setText(f"再生開始まで約 {frames * 80} ms{default}")

    @property
    def excluded(self):
        return self.roles["exclude"]

    @excluded.setter
    def excluded(self, frequencies):
        self.roles["exclude"] = set(frequencies)

    @property
    def settings_path(self):
        # Stable per-application control path even when the recording destination changes.
        return default_data_dir(self.repo_root) / "audio_settings.json"

    def create_live_volume_control(self, parent=None):
        return LiveVolumeControl(self.volume, self.checks["voice_output"], parent)

    def save(self, *_):
        stored_dir = data_dir_setting(self.data_dir, self.repo_root)
        stored_mode = "absolute" if Path(stored_dir).is_absolute() else "relative"
        self.values.update({name: widget.isChecked() for name,widget in self.checks.items()})
        self.values.update(volume=self.volume.value()/100, crc_min_percent=self.crc_min.value(),
                           min_recording_seconds=self.record_min.value(), data_dir=stored_dir, data_dir_mode=stored_mode)
        self.values["max_recordings"] = self.record_max.value()
        self.values["record_crc_min_percent"] = self.record_crc_min.value()
        for role, key in ROLE_KEYS.items():
            self.values[key] = sorted(self.roles[role])
        self.values["priority_duck_percent"] = self.priority_duck.value()
        self.values["playback_buffer_frames"] = self.playback_buffer.value()
        self.values["max_playback_channels"] = self.playback_max.value()
        self._update_playback_buffer_label()
        self.values.update(notify_desktop=self.notify_desktop.isChecked(), notify_sound=self.notify_sound.isChecked(),
                           notify_csms=parse_csm_list(self.notify_csms.text()),
                           notify_user_codes=parse_user_codes(self.notify_user_codes.text()),
                           notify_cooldown_seconds=self.notify_cooldown.value())
        self.volume_label.setText(f"{self.volume.value()} %")
        try:
            self.settings_path.parent.mkdir(parents=True,exist_ok=True)
            file = QtCore.QSaveFile(str(self.settings_path))
            if not file.open(QtCore.QIODevice.WriteOnly):
                raise OSError(file.errorString())
            content = json.dumps(self.values,ensure_ascii=False).encode("utf-8")
            if file.write(content) != len(content) or not file.commit():
                raise OSError(file.errorString())
        except OSError as exc:
            QtWidgets.QMessageBox.warning(self,"音声設定",f"設定を保存できませんでした。\n{exc}")
            return False
        if hasattr(self.preferences, "setValue"):
            self.preferences.setValue("record_dir", stored_dir)
            self.preferences.setValue("record_dir_mode", stored_mode)
        return True

    def choose_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self,"録音保存先（raw / rec / edu の親フォルダ）",str(self.data_dir))
        if folder:
            self.data_dir = resolve_data_dir(folder, self.repo_root)
            self.path_label.setText(data_dir_setting(self.data_dir, self.repo_root))
            self.path_label.setToolTip(f"実際のフォルダ: {self.data_dir}")
            self.save()

    def open_folder(self):
        from PyQt5.QtGui import QDesktopServices
        self.data_dir.mkdir(parents=True,exist_ok=True)
        QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(self.data_dir)))

    def configure_backend(self, backend_args):
        # Configured raster frequency excludes the radio's calibration correction.
        self.values["frequencies"] = channel_frequencies(backend_args)
        self.populate_channels()
        self.channel_roles_changed.emit()
        return self.save()

    def populate_channels(self):
        """List the current channel raster plus configured frequencies outside it."""
        selected = set(self.selected_frequencies())
        scroll = self.channel_table.verticalScrollBar().value()
        self.channel_table.blockSignals(True)
        self.channel_table.clear()
        frequencies = self.values.get("frequencies") or {}
        channels = sorted(((int(ch), int(freq)) for ch, freq in frequencies.items()), key=lambda item: item[0])
        labels = channel_labels(frequencies)
        known = {freq for _, freq in channels}
        rows = [(f"{labels[ch]}  {freq / 1e6:.5f} MHz", freq) for ch, freq in channels]
        for freq in sorted(set().union(*self.roles.values()) - known):
            info = PLAN_BY_FREQUENCY.get(freq)
            prefix = f"{info.display}  " if info else ""
            rows.append((f"{prefix}{freq / 1e6:.5f} MHz（現在の受信範囲外）", freq))
        for text, freq in rows:
            item = QtWidgets.QTreeWidgetItem([text])
            item.setData(0, QtCore.Qt.UserRole, freq)
            info = PLAN_BY_FREQUENCY.get(freq)
            if info is not None and info.block:
                item.setToolTip(0, f"{info.display}  {info.block}")
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            for role, column in ROLE_COLUMNS.items():
                item.setCheckState(column, QtCore.Qt.Checked if freq in self.roles[role] else QtCore.Qt.Unchecked)
            self.channel_table.addTopLevelItem(item)
            item.setSelected(freq in selected)
        self.channel_table.blockSignals(False)
        self.channel_table.verticalScrollBar().setValue(scroll)
        self.update_roles_summary()

    def _apply_role(self, frequency, role, enabled):
        """Enable/disable a role, clearing the roles that contradict it (ROLE_CONFLICTS)."""
        if not enabled:
            self.roles[role].discard(frequency)
            return
        self.roles[role].add(frequency)
        for other in ROLE_CONFLICTS[role]:
            self.roles[other].discard(frequency)

    def _roles_updated(self):
        self.populate_channels()
        saved = self.save()
        self.channel_roles_changed.emit()
        return saved

    def selected_frequencies(self):
        return [item.data(0, QtCore.Qt.UserRole) for item in self.channel_table.selectedItems()]

    def _refresh_rows(self, frequencies):
        """Show role changes in place; rebuilding the view mid-edit would destroy the item."""
        self.channel_table.blockSignals(True)
        for index in range(self.channel_table.topLevelItemCount()):
            item = self.channel_table.topLevelItem(index)
            frequency = item.data(0, QtCore.Qt.UserRole)
            if frequency in frequencies:
                for role, column in ROLE_COLUMNS.items():
                    item.setCheckState(column, QtCore.Qt.Checked if frequency in self.roles[role] else QtCore.Qt.Unchecked)
        self.channel_table.blockSignals(False)

    def _apply_to_frequencies(self, frequencies, role, enabled):
        for frequency in frequencies:
            self._apply_role(frequency, role, enabled)
        self._refresh_rows(set(frequencies))
        self.update_roles_summary()
        saved = self.save()
        self.channel_roles_changed.emit()
        return saved

    def channel_item_changed(self, item, column):
        role = next((r for r, c in ROLE_COLUMNS.items() if c == column), None)
        if role is None:
            return
        frequency = item.data(0, QtCore.Qt.UserRole)
        selected = self.selected_frequencies()
        # Toggling a box on a selected row applies to every selected row.
        targets = selected if item.isSelected() and len(selected) > 1 else [frequency]
        self._apply_to_frequencies(targets, role, item.checkState(column) == QtCore.Qt.Checked)

    def eventFilter(self, watched, event):
        """A plain click on a role cell toggles it without touching the selection.

        Qt would otherwise collapse a multi-row selection to the clicked row on
        release, so the next change would hit one row only.
        """
        if watched is self.channel_table.viewport() and event.type() in (
                QtCore.QEvent.MouseButtonPress, QtCore.QEvent.MouseButtonRelease, QtCore.QEvent.MouseButtonDblClick):
            if event.button() == QtCore.Qt.LeftButton and not event.modifiers():
                item = self.channel_table.itemAt(event.pos())
                column = self.channel_table.columnAt(event.pos().x())
                if item is not None and column in ROLE_COLUMNS.values():
                    if event.type() == QtCore.QEvent.MouseButtonPress:
                        checked = item.checkState(column) == QtCore.Qt.Checked
                        item.setCheckState(column, QtCore.Qt.Unchecked if checked else QtCore.Qt.Checked)
                    return True
        return super().eventFilter(watched, event)

    def _table_menu(self, position):
        item = self.channel_table.itemAt(position)
        if item is None:
            return
        if not item.isSelected():
            self.channel_table.clearSelection()
            item.setSelected(True)
        targets = self.selected_frequencies()
        title = item.text(0) if len(targets) == 1 else f"{len(targets)} チャンネルを選択中"
        menu = build_role_menu(self, title,
                               lambda role: (sum(f in self.roles[role] for f in targets), len(targets)),
                               lambda role, enabled: self._apply_to_frequencies(targets, role, enabled))
        menu.exec_(self.channel_table.viewport().mapToGlobal(position))

    def clear_role(self, role):
        self.roles[role].clear()
        return self._roles_updated()

    def clear_excluded(self):
        return self.clear_role("exclude")

    def clear_all_roles(self):
        for frequencies in self.roles.values():
            frequencies.clear()
        return self._roles_updated()

    def set_channel_frequencies(self, frequencies):
        """Follow the selected profile's raster before the next start (not persisted until saved)."""
        self.values["frequencies"] = {str(ch): int(freq) for ch, freq in frequencies.items()}
        self.populate_channels()
        self.channel_roles_changed.emit()

    def channel_frequency(self, channel_id):
        frequency = (self.values.get("frequencies") or {}).get(str(channel_id))
        return None if frequency is None else int(frequency)

    def channel_ids(self, role):
        return {int(ch) for ch, freq in (self.values.get("frequencies") or {}).items() if int(freq) in self.roles[role]}

    def excluded_channel_ids(self):
        return self.channel_ids("exclude")

    def set_channels_role(self, channel_ids, role, enabled):
        frequencies = [f for f in map(self.channel_frequency, channel_ids)
                       if f is not None and (f in self.roles[role]) != enabled]
        if not frequencies:
            return False
        for frequency in frequencies:
            self._apply_role(frequency, role, enabled)
        return self._roles_updated()

    def set_channel_role(self, channel_id, role, enabled):
        return self.set_channels_role([channel_id], role, enabled)

    def set_channel_excluded(self, channel_id, exclude):
        return self.set_channel_role(channel_id, "exclude", exclude)

    def _notify_lists_edited(self):
        # Show the normalized lists so typos (letters in user codes, duplicates) are visible.
        self.notify_csms.setText(", ".join(parse_csm_list(self.notify_csms.text())))
        self.notify_user_codes.setText(", ".join(map(str, parse_user_codes(self.notify_user_codes.text()))))
        self.save()

    def notify_rules(self):
        return NotifyRules(frozenset(self.roles["notify"]),
                           frozenset(parse_csm_list(self.notify_csms.text())),
                           frozenset(parse_user_codes(self.notify_user_codes.text())))

    def update_roles_summary(self):
        parts = [f"{title} {len(self.roles[role])}" for role, title, _ in CHANNEL_ROLES if self.roles[role]]
        self.roles_summary.setText("  ·  ".join(parts) if parts else "設定なし")

    def open_library(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self,"SDR#録音ライブラリ（raw / rec / edu の親フォルダ）",str(self.data_dir))
        if folder:
            supervisor = getattr(self.parent(), "supervisor", None)
            self.launch_playback(supervisor.service_python if supervisor else None, folder)

    def launch_frame_analysis(self):
        supervisor = getattr(self.parent(), "supervisor", None)
        self.launch_playback(supervisor.service_python if supervisor else None, frame_anatomy=True)

    def launch_playback(self, interpreter=None, data_directory=None, *, frame_anatomy=False):
        if not self.save():
            return
        script = self.repo_root / "key_tool.py"
        executable = Path(interpreter or sys.executable)
        if os.name == "nt" and executable.name.lower() == "python.exe" and executable.with_name("pythonw.exe").exists():
            executable = executable.with_name("pythonw.exe")
        process = QtCore.QProcess(self)
        env = QtCore.QProcessEnvironment.systemEnvironment()
        env.insert("STD_T98_DATA_DIR",str(resolve_data_dir(data_directory or self.data_dir, self.repo_root)))
        process.setProcessEnvironment(env)
        process.setWorkingDirectory(str(self.repo_root))
        process.setProgram(str(executable))
        process.setArguments([str(script)] + (["--frame-anatomy"] if frame_anatomy else []))
        process.errorOccurred.connect(lambda _: QtWidgets.QMessageBox.warning(self,"録音・再生",process.errorString()))
        def finished(code, _):
            if code:
                detail = bytes(process.readAllStandardError()).decode("utf-8",errors="replace")
                QtWidgets.QMessageBox.warning(self,"録音・再生",detail[-3000:] or f"再生ツール終了コード: {code}")
            self.processes.remove(process)
            process.deleteLater()
        process.finished.connect(finished)
        self.processes.append(process)
        process.start()


class LiveVolumeControl(QtWidgets.QWidget):
    """Main-window volume linked to the existing persistent audio setting."""

    def __init__(self, settings_slider, settings_voice_output, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(QtWidgets.QLabel("再生音量"))
        self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider.setObjectName("liveVolumeSlider")
        self.slider.setAccessibleName("リアルタイム再生音量、0から200パーセント")
        self.slider.setRange(0, 200)
        self.slider.setSingleStep(1)
        self.slider.setPageStep(10)
        self.slider.setTickInterval(50)
        self.slider.setTickPosition(QtWidgets.QSlider.TicksBelow)
        self.slider.setMinimumWidth(180)
        self.slider.setValue(settings_slider.value())
        self.slider.setToolTip("リアルタイム再生の音量。0%：消音、100%：標準、200%：2倍。受信中にも変更できます。")
        layout.addWidget(self.slider, 1)
        self.value_label = QtWidgets.QLabel(f"{self.slider.value()} %")
        self.value_label.setMinimumWidth(52)
        self.value_label.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        layout.addWidget(self.value_label)
        self.play_voice = QtWidgets.QCheckBox("受信音声を再生")
        self.play_voice.setObjectName("liveVoiceOutput")
        self.play_voice.setChecked(settings_voice_output.isChecked())
        self.play_voice.setToolTip("オフにするとスピーカーへの再生だけを止めます。受信・録音・秘話鍵探索・通知は続けます。"
                                   "受信中も切り替えられます。「音量を一定に保つ」は「音声設定…」にあります。")
        layout.addWidget(self.play_voice)
        self.setMaximumWidth(700)
        self.slider.valueChanged.connect(settings_slider.setValue)
        settings_slider.valueChanged.connect(self.slider.setValue)
        self.slider.valueChanged.connect(self.update_label)
        self.play_voice.toggled.connect(settings_voice_output.setChecked)
        settings_voice_output.toggled.connect(self.play_voice.setChecked)

    def update_label(self, value):
        self.value_label.setText(f"{value} %")
