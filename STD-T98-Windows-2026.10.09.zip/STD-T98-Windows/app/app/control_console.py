"""The run-control console: an EVA-style neon panel matching the channel tiles."""
import math

from PyQt5 import QtCore, QtGui, QtWidgets

from app.channel_card import CARD_ACCENTS, CARD_BACKGROUND, CARD_TEXT, _eva_title_font, _glow, _hexagon

IDLE = CARD_ACCENTS["open"]      # orange: standing by
LIVE = CARD_ACCENTS["good"]      # green: receiving
STOP_RED = CARD_ACCENTS["poor"]

CONSOLE_STYLE = f"""
    QLabel {{ color: {CARD_TEXT}; background: transparent; }}
    QLabel#consoleCaption {{
        color: #b98a52; font-family: Consolas, monospace; font-size: 10px;
        font-weight: 700; letter-spacing: 2px;
    }}
    QLabel#squelchReadout {{
        color: {IDLE}; font-family: Consolas, monospace; font-size: 20px; font-weight: 700;
    }}
    QFrame#consoleRule {{ color: #3a2c1c; background: #3a2c1c; }}
    QPushButton, QToolButton {{
        color: {CARD_TEXT}; background: #120e0a; border: 1px solid #6e5232;
        border-radius: 3px; padding: 5px 12px;
    }}
    QPushButton:hover, QToolButton:hover {{ border-color: {IDLE}; color: #ffd9a6; }}
    QPushButton:pressed, QToolButton:pressed, QToolButton:checked {{ background: #23180d; }}
    QPushButton:disabled, QToolButton:disabled {{ color: #5a4630; border-color: #2e2318; }}
    QPushButton#startButton {{
        color: {LIVE}; border: 2px solid {LIVE}; background: rgba(57,255,136,0.08);
        font-size: 15px; font-weight: 700; padding: 7px 22px; letter-spacing: 1px;
    }}
    QPushButton#startButton:hover {{ background: rgba(57,255,136,0.20); }}
    QPushButton#stopButton {{
        color: {STOP_RED}; border: 2px solid {STOP_RED}; background: rgba(255,51,85,0.08);
        font-size: 15px; font-weight: 700; padding: 7px 22px; letter-spacing: 1px;
    }}
    QPushButton#stopButton:hover {{ background: rgba(255,51,85,0.20); }}
    QPushButton#startButton:disabled, QPushButton#stopButton:disabled {{
        color: #4a3d2c; border-color: #2e2318; background: transparent;
    }}
    QSlider::groove:horizontal {{ height: 4px; background: #2a2018; border-radius: 2px; }}
    QSlider::sub-page:horizontal {{ background: {IDLE}; border-radius: 2px; }}
    QSlider::handle:horizontal {{
        width: 10px; margin: -7px 0; background: {IDLE}; border: 1px solid #ffd9a6; border-radius: 2px;
    }}
    QSlider::sub-page:horizontal:disabled, QSlider::handle:horizontal:disabled {{ background: #5a4630; border-color: #5a4630; }}
    QCheckBox {{ color: {CARD_TEXT}; spacing: 6px; }}
    QCheckBox::indicator {{ width: 13px; height: 13px; border: 1px solid {IDLE}; background: #120e0a; }}
    QCheckBox::indicator:checked {{ background: {IDLE}; }}
"""


class StatusLamp(QtWidgets.QWidget):
    """Hexagon lamp beside the session state: lit green while receiving."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(34, 30)
        self.live = False

    def set_live(self, live):
        if self.live != live:
            self.live = live
            self.update()

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        color = QtGui.QColor(LIVE if self.live else IDLE)
        hexagon = _hexagon(self.width() / 2, self.height() / 2, 13, 0)
        if self.live:
            for width, alpha in ((8, 40), (4, 110)):
                halo = QtGui.QColor(color)
                halo.setAlpha(alpha)
                p.setPen(QtGui.QPen(halo, width))
                p.drawPolygon(hexagon)
        p.setPen(QtGui.QPen(color, 2))
        p.setBrush(color if self.live else QtCore.Qt.NoBrush)
        p.drawPolygon(hexagon)


class ConsolePanel(QtWidgets.QFrame):
    """Dark chamfered panel with a neon outline, like the hexagon tiles.

    Orange while standing by, green while receiving.
    """

    CHAMFER = 14

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("controlPanel")
        self.setStyleSheet(CONSOLE_STYLE)
        self.live = False

    def set_live(self, live):
        if self.live != live:
            self.live = live
            self.update()

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        w, h, c = self.width() - 1, self.height() - 1, self.CHAMFER
        accent = QtGui.QColor(LIVE if self.live else IDLE)
        outline = QtGui.QPolygonF([QtCore.QPointF(x, y) for x, y in (
            (c, 1), (w - 1, 1), (w - 1, h - c), (w - c, h - 1), (1, h - 1), (1, c))])
        p.setPen(QtCore.Qt.NoPen)
        p.setBrush(QtGui.QColor(CARD_BACKGROUND))
        p.drawPolygon(outline)

        # Faint rear honeycomb toward the right edge.
        p.save()
        clip = QtGui.QPainterPath()
        clip.addPolygon(outline)
        p.setClipPath(clip)
        p.setClipRect(QtCore.QRectF(w * 0.62, 0, w * 0.38, h), QtCore.Qt.IntersectClip)
        rear = QtGui.QColor(accent)
        rear.setAlpha(22)
        p.setPen(QtGui.QPen(rear, 1))
        p.setBrush(QtCore.Qt.NoBrush)
        radius = 12.0
        dx, dy = radius * 1.5, radius * math.sqrt(3)
        for col in range(int(w / dx) + 2):
            for row in range(int(h / dy) + 2):
                p.drawPolygon(_hexagon(col * dx, row * dy + (dy / 2 if col % 2 else 0), radius - 1.5, 0))
        p.restore()

        p.setBrush(QtCore.Qt.NoBrush)
        for width, alpha in ((7, 26), (4, 60)):
            halo = QtGui.QColor(accent)
            halo.setAlpha(alpha)
            p.setPen(QtGui.QPen(halo, width))
            p.drawPolygon(outline)
        p.setPen(QtGui.QPen(accent, 1.6))
        p.drawPolygon(outline)

        # "COMMAND" tab along the top edge and a corner tick.
        p.setPen(QtCore.Qt.NoPen)
        p.setBrush(accent)
        tab = QtGui.QPolygonF([QtCore.QPointF(x, y) for x, y in (
            (c + 4, 0), (c + 92, 0), (c + 84, 13), (c + 4, 13))])
        p.drawPolygon(tab)
        font = QtGui.QFont("Consolas")
        font.setPixelSize(10)
        font.setBold(True)
        font.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 2)
        p.setFont(font)
        p.setPen(QtGui.QColor(CARD_BACKGROUND))
        p.drawText(QtCore.QRectF(c + 10, 0, 80, 13), QtCore.Qt.AlignVCenter | QtCore.Qt.AlignLeft, "COMMAND")
        p.setPen(QtCore.Qt.NoPen)
        p.setBrush(accent)
        p.drawRect(QtCore.QRectF(w - c - 26, h - 4, 20, 3))


def caption(text):
    label = QtWidgets.QLabel(text)
    label.setObjectName("consoleCaption")
    return label


def rule():
    line = QtWidgets.QFrame()
    line.setObjectName("consoleRule")
    line.setFrameShape(QtWidgets.QFrame.VLine)
    line.setFixedWidth(1)
    return line


def style_session_state(label):
    """Session state in the EVA title lettering, glowing with the panel accent."""
    label.setFont(_eva_title_font(24))
    return _glow(label, IDLE, 16)


def set_session_state_live(label, effect, live):
    color = LIVE if live else IDLE
    label.setStyleSheet(f"color: {color}; background: transparent;")
    effect.setColor(QtGui.QColor(color))
