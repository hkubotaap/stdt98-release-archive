"""Right-click menu for per-channel listening roles, shared by the history grid
and the settings table so both offer the same wording and multi-select rules."""
from PyQt5 import QtWidgets


ROLE_ACTIONS = (
    ("exclude", "受信・録音から除外", "再生・録音・秘話鍵探索を行いません。"),
    ("mute", "聞かない（再生しない・録音は継続）", "音声を再生しません。受信・録音・通知は続けます。"),
    ("solo", "ソロ（このチャンネルを聴く）", "ソロのチャンネルだけを再生します。録音は全チャンネル継続します。"),
    ("priority", "優先（通話中は他を小さく）", "このチャンネルの音声が出ている間、他のチャンネルの音量を下げます。"),
    ("notify", "通知（通話開始を知らせる）", "通話が始まったらデスクトップ通知 / 通知音で知らせます。"),
)


def build_role_menu(parent, title, count_with, apply_role):
    """Menu with one checkable action per role.

    ``count_with(role)`` returns ``(channels_with_role, selected_channels)``;
    ``apply_role(role, enabled)`` applies to every selected channel. An action
    is checked only when all selected channels have the role, so triggering a
    partially-set role turns it on everywhere and a fully-set one off.
    """
    menu = QtWidgets.QMenu(parent)
    header = menu.addAction(title)
    header.setEnabled(False)
    menu.addSeparator()
    for role, text, tip in ROLE_ACTIONS:
        have, total = count_with(role)
        action = menu.addAction(text if total <= 1 or have in (0, total) else f"{text}（{have}/{total}）")
        action.setCheckable(True)
        action.setChecked(total > 0 and have == total)
        action.setToolTip(tip)
        action.triggered.connect(lambda enabled, role=role: apply_role(role, enabled))
        if role == "exclude":
            menu.addSeparator()
    menu.setToolTipsVisible(True)
    return menu
