"""Decide when a channel's call start deserves a desktop notification.

Pure logic, fed from the GUI poll: the protocol service publishes per-channel
``rx_status``/``csm``/``sacch`` (SACCH only after CRC and parity pass, and both
are cleared after a 2 s gap), so one call is one OPEN run on a channel.
"""
from dataclasses import dataclass, field


CALL_END_GAP_SEC = 2.0       # same gap the protocol/audio services use to end a call
IDENTITY_WAIT_SEC = 1.0      # let CSM/UC arrive before a frequency-only notice
DEFAULT_COOLDOWN_SEC = 60


@dataclass(frozen=True)
class NotifyRules:
    frequencies: frozenset = frozenset()
    csms: frozenset = frozenset()
    user_codes: frozenset = frozenset()

    def __bool__(self):
        return bool(self.frequencies or self.csms or self.user_codes)


@dataclass(frozen=True)
class Notice:
    channel_id: int
    reasons: tuple
    csm: str | None
    user_code: int | None
    encrypted: bool


@dataclass
class _Call:
    started: float
    last_open: float
    done: bool = False


@dataclass
class CallNotifier:
    calls: dict = field(default_factory=dict)
    recent: dict = field(default_factory=dict)   # (channel, caller) -> last notice time

    def update(self, channels, rules, frequency_of, now, cooldown=DEFAULT_COOLDOWN_SEC):
        """Return the notices for calls that started matching ``rules`` since the last poll."""
        notices = []
        for channel_id, view in channels.items():
            if view.rx_status != "OPEN":
                continue
            call = self.calls.get(channel_id)
            if call is None or now - call.last_open > CALL_END_GAP_SEC:
                call = self.calls[channel_id] = _Call(started=now, last_open=now)
            call.last_open = now
            if call.done or not rules:
                continue
            sacch = view.sacch or {}
            csm = view.csm or None
            user_code = sacch.get("UserCode")
            reasons = tuple(reason for reason, hit in (
                ("周波数", frequency_of(channel_id) in rules.frequencies),
                ("CSM", csm is not None and csm in rules.csms),
                ("ユーザーコード", user_code is not None and user_code in rules.user_codes),
            ) if hit)
            if not reasons:
                continue
            if reasons == ("周波数",) and csm is None and user_code is None and now - call.started < IDENTITY_WAIT_SEC:
                continue  # wait briefly so the notice can name the caller
            call.done = True
            caller = (channel_id, csm or user_code)
            if cooldown and now - self.recent.get(caller, float("-inf")) < cooldown:
                continue
            self.recent[caller] = now
            notices.append(Notice(channel_id, reasons, csm, user_code,
                                  sacch.get("CallStat") == 1 or view.audio_status in ("Key required", "Replaying from start")))
        for channel_id, call in tuple(self.calls.items()):
            if now - call.last_open > CALL_END_GAP_SEC:
                del self.calls[channel_id]
        horizon = max(cooldown or 0, CALL_END_GAP_SEC)
        self.recent = {caller: at for caller, at in self.recent.items() if now - at < horizon}
        return notices


def _tokens(text):
    for token in str(text).replace("、", ",").replace("，", ",").replace(" ", ",").split(","):
        token = token.strip()
        if token:
            yield token


def parse_csm_list(text):
    """Comma/space separated CSM identifiers, de-duplicated and sorted."""
    return sorted(set(_tokens(text)))


def parse_user_codes(text):
    """Comma/space separated numeric user codes; anything else is ignored."""
    return sorted({int(token) for token in _tokens(text) if token.isdigit()})
