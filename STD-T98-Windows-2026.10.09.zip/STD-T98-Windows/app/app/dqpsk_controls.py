"""Optional data receiver settings and live/saved GNSS analysis view."""
import json
from pathlib import Path
from PyQt5 import QtCore, QtWidgets



class DqpskControls(QtWidgets.QWidget):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.states = {}
        layout = QtWidgets.QVBoxLayout(self)
        self.enabled = QtWidgets.QCheckBox('π/4-DQPSK・RTCM3 の受信・解析を有効にする')
        self.enabled.setChecked(settings.value('dqpsk/enabled', False, type=bool))
        layout.addWidget(self.enabled)
        form = QtWidgets.QFormLayout()
        self.frequencies = QtWidgets.QLineEdit(settings.value('dqpsk/frequencies', '351.200', type=str))
        self.frequencies.setPlaceholderText('例: 351.200, 351.20625')
        self.frequencies.setToolTip('任意の周波数をMHzで1～8件指定します。現在のSDRの受信帯域内に設定してください。')
        form.addRow('対象周波数（MHz）', self.frequencies)
        self.directory = QtWidgets.QLineEdit(settings.value('dqpsk/directory', 'std98_data/dqpsk', type=str))
        form.addRow('保存先', self.directory)
        layout.addLayout(form)
        self.save_data = QtWidgets.QCheckBox('RTCM3・解析結果を保存する')
        self.save_data.setChecked(settings.value('dqpsk/save_data', True, type=bool))
        self.save_iq = QtWidgets.QCheckBox('再解析用のチャネルIQも保存する（約18.4 MB/分/周波数）')
        self.save_iq.setChecked(settings.value('dqpsk/save_iq', True, type=bool))
        layout.addWidget(self.save_data)
        layout.addWidget(self.save_iq)
        note = QtWidgets.QLabel('設定は次回の受信開始から反映します。周波数は固定しません。\n'
                               '資料で実測された4800 symbol/s・PN9本文形式を使用します。異なるデータ形式は別途対応が必要です。')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.open_button = QtWidgets.QPushButton('受信データ・保存済みデータを解析…')
        self.open_button.clicked.connect(self.show_analysis)
        layout.addWidget(self.open_button)
        layout.addStretch(1)
        for checkbox in (self.enabled, self.save_data, self.save_iq):
            checkbox.toggled.connect(self.persist)
        for field in (self.frequencies, self.directory):
            field.editingFinished.connect(self.persist)
        self.enabled.toggled.connect(self.refresh)
        self.save_data.toggled.connect(self.refresh)
        self.dialog = None
        self.refresh()

    def persist(self):
        for key, value in [('enabled', self.enabled.isChecked()), ('frequencies', self.frequencies.text()),
                           ('directory', self.directory.text()), ('save_data', self.save_data.isChecked()),
                           ('save_iq', self.save_iq.isChecked())]:
            self.settings.setValue('dqpsk/' + key, value)

    def refresh(self, *args):
        enabled = self.enabled.isChecked() and self.enabled.isEnabled()
        for widget in (self.frequencies, self.directory, self.save_data):
            widget.setEnabled(enabled)
        self.save_iq.setEnabled(enabled and self.save_data.isChecked())

    def set_running(self, running):
        self.enabled.setEnabled(not running)
        self.refresh()

    def backend_args(self):
        self.persist()
        if not self.enabled.isChecked():
            return []
        from core.rf.dqpsk_options import parse_frequencies
        parse_frequencies(self.frequencies.text())
        args = ['--dqpsk-rtcm', '--dqpsk-frequencies', self.frequencies.text(), '--dqpsk-dir', self.directory.text()]
        if not self.save_data.isChecked():
            args.append('--dqpsk-no-save')
        elif not self.save_iq.isChecked():
            args.append('--dqpsk-no-iq')
        return args

    def update_states(self, states):
        self.states = dict(states)
        if self.dialog:
            self.dialog.update_states(states)

    def show_analysis(self):
        if self.dialog is None:
            self.dialog = DqpskAnalysis(self)
        self.dialog.update_states(self.states)
        self.dialog.show()
        self.dialog.raise_()


class DqpskAnalysis(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('π/4-DQPSK / RTCM3 受信・解析')
        self.resize(1000, 650)
        layout = QtWidgets.QVBoxLayout(self)
        row = QtWidgets.QHBoxLayout()
        load = QtWidgets.QPushButton('保存済みセッションを開く…')
        load.clicked.connect(self.load)
        row.addWidget(load)
        self.mode = QtWidgets.QLabel('ライブ受信：CRC合格データを表示')
        row.addWidget(self.mode, 1)
        live = QtWidgets.QPushButton('ライブ表示に戻る')
        live.clicked.connect(self.live)
        row.addWidget(live)
        layout.addLayout(row)
        self.saved = False
        self.states = {}
        self.table = QtWidgets.QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(['MHz', 'CSM', 'CRC合格', 'CRC不一致候補', 'PICH合格', 'CFO Hz', '集中度', '欠落samples'])
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.itemSelectionChanged.connect(self.selection)
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.ResizeToContents)
        layout.addWidget(self.table)
        self.messages = QtWidgets.QComboBox()
        self.messages.setToolTip('保存済みデータの各RTCM3電文を選び、フィールド解析結果を表示します。')
        self.messages.currentIndexChanged.connect(self.message_selection)
        layout.addWidget(self.messages)
        self.details = QtWidgets.QPlainTextEdit()
        self.details.setReadOnly(True)
        layout.addWidget(self.details, 1)
        note = QtWidgets.QLabel('1005の座標は基準局アンテナ基準点です。MSMのTOWには週番号がありません。\n'
                               'CRC合格は測位品質を保証しません。CSM・GNSS受信機情報・無線機識別は別の情報です。')
        note.setWordWrap(True)
        layout.addWidget(note)

    def update_states(self, states):
        self.states = dict(states)
        if not self.saved:
            self.render(self.states)

    def render(self, states):
        self.displayed = list(states.values())
        selected = max(0, self.table.currentRow())
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.displayed))
        for row, state in enumerate(self.displayed):
            values = [f"{state['frequency_hz'] / 1e6:.6f}", state.get('csm') or '—', state.get('packets', 0),
                      state.get('crc_failures', 0), state.get('pich_valid', 0),
                      f"{state.get('cfo_hz', 0):.1f}", f"{state.get('concentration', 0):.4f}", state.get('dropped_samples', 0)]
            for col, value in enumerate(values):
                self.table.setItem(row, col, QtWidgets.QTableWidgetItem(str(value)))
        self.table.blockSignals(False)
        if self.displayed:
            self.table.selectRow(min(selected, len(self.displayed) - 1))
            self.selection()
        else:
            self.details.setPlainText('データ受信を有効にして受信を開始すると解析結果を表示します。')

    def selection(self):
        row = self.table.currentRow()
        if 0 <= row < len(getattr(self, 'displayed', [])):
            self.details.setPlainText(json.dumps(self.displayed[row], indent=2, ensure_ascii=False))

    def load(self):
        filename, _ = QtWidgets.QFileDialog.getOpenFileName(self, 'セッションの metadata.json を開く', '', '受信メタデータ (metadata.json)')
        if not filename:
            return
        try:
            state = json.loads(Path(filename).read_text(encoding='utf-8'))
            if not isinstance(state.get('frequency_hz'), (int, float)):
                raise ValueError('受信セッションのメタデータではありません。')
            self.saved = True
            self.mode.setText(str(Path(filename).parent))
            self.render({state['frequency_hz']: state})
            self.messages.blockSignals(True)
            self.messages.clear()
            self.messages.addItem('セッション全体の解析結果', None)
            events_path = Path(filename).parent / 'analysis.jsonl'
            if events_path.exists():
                # Read a bounded tail of a long-running session; retain 500
                # complete packet records without blocking on the whole log.
                with events_path.open('rb') as handle:
                    start = max(0, events_path.stat().st_size - 8 * 1024 * 1024)
                    handle.seek(start)
                    if start:
                        handle.readline()
                    rows = []
                    for line in handle:
                        try:
                            event = json.loads(line)
                        except ValueError:
                            continue  # a live session may end in a partial line
                        if event.get('event') == 'packet':
                            rows.append(event)
                    for event in rows[-500:]:
                        fields = event.get('fields', {})
                        self.messages.addItem(f"RTCM {fields.get('message_type')} / TOW {fields.get('epoch_tow_ms', '—')} / sample {event.get('sample_offset')}", event)
            self.messages.blockSignals(False)
        except (OSError, ValueError) as exc:
            QtWidgets.QMessageBox.warning(self, '読み込み失敗', str(exc))

    def live(self):
        self.saved = False
        self.mode.setText('ライブ受信：CRC合格データを表示')
        self.render(self.states)
        self.messages.clear()

    def message_selection(self):
        event = self.messages.currentData()
        if event is not None:
            self.details.setPlainText(json.dumps(event, indent=2, ensure_ascii=False))
        else:
            self.selection()
