"""Shared RF client/server integration for both receiver window variants."""
from pathlib import Path
import tempfile
from PyQt5 import QtWidgets
from app.channel_waterfall import Column
from app.rf_connection_controls import MetadataWorker, RFConnectionControls, RFNetworkStatus
from core.rf.remote_iq import write_client_profile, client_config


class RemoteRFWindow:
    def _setup_remote_rf(self, panel, control_layout):
        self._remote_profile_dir = None
        self._remote_profile = None
        self._remote_format = None
        self._rf_worker = None
        self._pending_rf_start = False
        self._close_after_probe = False
        self._pending_correct_iq = None
        self._rf_controls = RFConnectionControls(self._settings, self._settings_panel)
        panel.addWidget(self._rf_controls)
        self._rf_status = RFNetworkStatus()
        control_layout.addWidget(self._rf_status)
        self._rf_controls.changed.connect(self._on_rf_mode_changed)
        self._rf_controls.correct.toggled.connect(self._on_correct_iq)

    def _on_correct_iq(self, enabled):
        if self.supervisor is not None:
            if not self.supervisor.set_correct_iq(enabled):
                self._pending_correct_iq = bool(enabled)
                self._status_bar.showMessage("Correct IQ：バックエンドの接続待ちです。設定は次の起動にも反映します。")
            else:
                self._pending_correct_iq = None

    def _on_rf_mode_changed(self):
        mode = self._rf_controls.mode.currentData()
        self._rf_status.setVisible(mode != "local")
        self._refresh_gain_controls_enabled()
        self._refresh_freq_field_enabled()
        self._refresh_squelch_controls_enabled()
        self._refresh_profile_tools()
        if hasattr(self, "_waterfall"):
            self._waterfall.setVisible(mode != "server")
            self._detail_cards.setVisible(mode != "server")
            self._cache_label.setVisible(mode != "server")
            self._scroll.setVisible(mode != "server" and self._detail_cards.isChecked())
        if hasattr(self, "_live_volume"):
            self._live_volume.setEnabled(mode != "server")
        if not self._running:
            self._start_button.setText("▶  配信開始" if mode == "server" else "▶  接続・受信開始" if mode == "client" else "▶  受信開始")

    def _start_rf_probe(self, host, port, token):
        if self._rf_worker is not None and self._rf_worker.isRunning():
            return
        self._pending_rf_start = True
        self._rf_controls.set_running(True)
        self._start_button.setEnabled(False)
        self._stop_button.setEnabled(True)
        self._rf_status.reset(f"RFサーバへ接続中… {host}:{port}")
        worker = MetadataWorker(host, port, token, self)
        self._rf_worker = worker
        worker.result.connect(self._rf_metadata_ready)
        worker.finished.connect(self._rf_probe_finished)
        worker.start()

    def _rf_probe_finished(self):
        worker = self._rf_worker
        self._rf_worker = None
        if worker is not None:
            worker.deleteLater()
        if self._close_after_probe:
            self.close()

    def _rf_metadata_ready(self, metadata, error):
        if not self._pending_rf_start:
            return
        self._pending_rf_start = False
        self._rf_controls.set_running(False)
        self._start_button.setEnabled(True)
        self._stop_button.setEnabled(False)
        if error:
            self._rf_status.reset("RFサーバへの接続失敗")
            QtWidgets.QMessageBox.warning(self, "RF接続", f"接続・アクセスキーを確認してください。\n{error}")
            return
        try:
            self._remote_profile_dir = tempfile.TemporaryDirectory(prefix="std-t98-remote-profile-")
            self._remote_profile = Path(self._remote_profile_dir.name) / "remote.toml"
            config = write_client_profile(self._remote_profile, metadata)
            self._set_remote_columns(metadata)
            self._squelch_slider.setValue(int(config.demod.squelch_threshold))
            self._remote_format = metadata["format"]
            self._refresh_squelch_controls_enabled()
            self.start_stack()
        except (ValueError, OSError) as exc:
            self._clear_remote_profile()
            self._rf_status.reset("RFサーバ設定を使用できません")
            QtWidgets.QMessageBox.warning(self, "RF接続", str(exc))

    def _clear_remote_profile(self):
        self._remote_profile = None
        self._remote_format = None
        self._refresh_squelch_controls_enabled()
        if self._remote_profile_dir is not None:
            self._remote_profile_dir.cleanup()
            self._remote_profile_dir = None

    def _update_network_caption(self):
        if self._rf_controls.mode.currentData() == "server":
            state = self.supervisor.aggregator.rf_network if self.supervisor else None
            self._active_count.setText(f"RF配信 · 接続 {state.get('clients', 0) if state else 0}台")

    def _set_remote_columns(self, metadata):
        config = client_config(metadata)
        geometry = config.channelizer
        if len(self._cards) != geometry.num_channels:
            for card in self._cards:
                card.hide()
                card.deleteLater()
            card_class = type(self._cards[0])
            self._cards = [card_class(i + 1, parent=self._grid_host) for i in range(geometry.num_channels)]
            for card in self._cards:
                card.hide()
            self._active_ids = self._visible_ids = ()
            self._recent_until.clear()
            self._grid_width = None
            self._card_slots.clear()
        columns = [Column(i + 1, i + 1, frequency_hz=config.sdr.center_freq +
                    (i - geometry.num_channels // 2) * geometry.channel_spacing) for i in range(geometry.num_channels)]
        try:
            from core.rf.channel_plan import band_for_raster
            band = band_for_raster(config.sdr.center_freq, geometry.channel_spacing, geometry.num_channels)
            if band:
                columns = [Column(c.slot_id, c.channel_number, c.group, c.frequency_hz) for c in band.channels]
            self._plan_key = band.key if band else None
        except ImportError:
            pass
        self._waterfall.set_columns(columns)
        from core.rf.channel_plan import call_stat_verified
        for card, column in zip(self._cards, columns):
            card.set_title(f"{column.label}  {column.frequency_hz / 1e6:.5f} MHz")
            card.call_stat_verified = call_stat_verified(column.frequency_hz)
        self._active_count.setText(f"受信中  0 / {geometry.num_channels}")
        self._layout_active_cards(())

    def _rf_start_arguments(self, mode, host, port, token, limit):
        if mode == "client":
            return ["--config", str(self._remote_profile), "--squelch", str(self._squelch_slider.value()),
                    "--rf-remote", host, "--rf-port", str(port)]
        if mode == "server":
            return ["--rf-listen", host, "--rf-port", str(port), "--rf-max-clients", str(limit),
                    "--rf-iq-format", self._rf_controls.iq_format.currentData()]
        return []
