"""RF mode settings and non-blocking server metadata discovery."""
import secrets
import time
from PyQt5 import QtCore, QtWidgets
from core.rf.remote_iq import DEFAULT_PORT, FRAME_FORMAT, fetch_metadata, require_token


class MetadataWorker(QtCore.QThread):
    result = QtCore.pyqtSignal(object, str)

    def __init__(self, host, port, token, parent=None):
        super().__init__(parent)
        self.host, self.port, self.token = host, port, token

    def run(self):
        try:
            self.result.emit(fetch_metadata(self.host, self.port, self.token), "")
        except Exception as exc:
            self.result.emit(None, str(exc))


class RFConnectionControls(QtWidgets.QGroupBox):
    changed = QtCore.pyqtSignal()

    def __init__(self, preferences, parent=None):
        super().__init__("RF接続・補正", parent)
        self.preferences = preferences
        layout = QtWidgets.QGridLayout(self)
        self.mode = QtWidgets.QComboBox()
        for label, value in (("ローカル受信", "local"), ("IPクライアント", "client"), ("RFデータ配信サーバ", "server")):
            self.mode.addItem(label, value)
        self.mode.setCurrentIndex(max(0, self.mode.findData(preferences.value("rf_mode", "local", type=str))))
        self.mode.setToolTip("ローカル受信：このPCにつないだSDRで受信します。\n"
                             "IPクライアント：別のPCのRFデータ配信サーバからデータを受けて復号します。\n"
                             "RFデータ配信サーバ：このPCのSDRのデータを、ネットワーク越しに別のPCへ配信します。")
        layout.addWidget(QtWidgets.QLabel("動作モード"), 0, 0)
        layout.addWidget(self.mode, 0, 1, 1, 2)
        self.correct = QtWidgets.QCheckBox("Correct IQ（DCオフセット自動補正）")
        self.correct.setChecked(preferences.value("correct_iq", True, type=bool))
        self.correct.setToolTip("中心周波数付近のDCスパイクを自動で除去します。受信中も切り替えられます。\n反射によるマルチパスやアンテナの電波不足は、この補正の対象外です。")
        layout.addWidget(self.correct, 0, 3, 1, 3)
        self.host_label = QtWidgets.QLabel()
        self.host = QtWidgets.QLineEdit()
        self.client_host = preferences.value("rf_client_host", "127.0.0.1", type=str)
        self.listen_host = preferences.value("rf_listen_host", "0.0.0.0", type=str)
        self.host.setText(self.listen_host if self.mode.currentData() == "server" else self.client_host)
        self.previous_mode = self.mode.currentData()
        self.port = QtWidgets.QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(preferences.value("rf_port", DEFAULT_PORT, type=int))
        self.port.setToolTip(f"サーバとクライアントで同じ番号にします（既定 {DEFAULT_PORT}）。")
        self.limit = QtWidgets.QSpinBox()
        self.limit.setRange(1, 16)
        self.limit.setValue(preferences.value("rf_max_clients", 4, type=int))
        self.limit.setToolTip("同時に接続できるクライアント数の上限です（サーバのとき）。")
        self.limit_label = QtWidgets.QLabel("最大接続数")
        layout.addWidget(self.host_label, 1, 0)
        layout.addWidget(self.host, 1, 1)
        layout.addWidget(QtWidgets.QLabel("TCPポート"), 1, 2)
        layout.addWidget(self.port, 1, 3)
        layout.addWidget(self.limit_label, 1, 4)
        layout.addWidget(self.limit, 1, 5)
        self.token = QtWidgets.QLineEdit(preferences.value("rf_token", "", type=str))
        self.token.setEchoMode(QtWidgets.QLineEdit.Password)
        self.token.setPlaceholderText("サーバとクライアントで同じアクセスキー（16文字以上）")
        self.token.setToolTip("サーバとクライアントで同じ文字列にします。知らない相手からの接続を防ぎます。")
        self.generate = QtWidgets.QPushButton("キー生成")
        self.reveal = QtWidgets.QCheckBox("表示")
        self.generate.setToolTip("推測されにくいアクセスキーを自動で作ります。相手側にも同じキーを入力してください。")
        self.reveal.setToolTip("伏せ字のアクセスキーを表示します。")
        self.reveal.toggled.connect(lambda on: self.token.setEchoMode(QtWidgets.QLineEdit.Normal if on else QtWidgets.QLineEdit.Password))
        self.generate.clicked.connect(lambda: self.token.setText(secrets.token_hex(16)))
        layout.addWidget(QtWidgets.QLabel("アクセスキー"), 2, 0)
        layout.addWidget(self.token, 2, 1, 1, 3)
        layout.addWidget(self.generate, 2, 4)
        layout.addWidget(self.reveal, 2, 5)
        self.iq_format_label = QtWidgets.QLabel("配信形式")
        self.iq_format = QtWidgets.QComboBox()
        self.iq_format.addItem("IQ 16bit（軽量・標準）", "cs16")
        self.iq_format.addItem("IQ 32bit float（従来）", "cf32")
        self.iq_format.addItem("復調済みフレーム（サーバで復調・最軽量）", "frames")
        self.iq_format.setCurrentIndex(max(0, self.iq_format.findData(preferences.value("rf_iq_format", "cs16", type=str))))
        self.iq_format.setToolTip("16bitは97chの受信範囲を維持して転送量を約半分にします。\nブロックごとのレベル調整でクリッピングを避けますが、量子化誤差が生じます。\n32bitは従来のIQ精度をそのまま送ります。\n"
                                  "復調済みフレームはこのPCで全chを復調し、同期の取れたフレームだけを送ります。\n"
                                  "クライアントは復調しないため軽くなりますが、このPCに97ch復調分のCPUが必要です。\n"
                                  "スケルチはこのPCで設定します。配信停止中に変更できます。")
        layout.addWidget(self.iq_format_label, 3, 0)
        layout.addWidget(self.iq_format, 3, 1, 1, 3)
        self.hint = QtWidgets.QLabel()
        self.hint.setWordWrap(True)
        layout.addWidget(self.hint, 4, 0, 1, 6)
        self.mode.currentIndexChanged.connect(self.update_mode)
        self.iq_format.currentIndexChanged.connect(self.update_mode)
        self.correct.toggled.connect(self.save_correct)
        self.update_mode()

    def update_mode(self):
        if self.previous_mode == "server":
            self.listen_host = self.host.text()
        else:
            self.client_host = self.host.text()
        mode = self.mode.currentData()
        self.host.setText(self.listen_host if mode == "server" else self.client_host)
        self.previous_mode = mode
        self.host_label.setText("待受IP" if mode == "server" else "サーバIP / ホスト名")
        self.host.setToolTip("接続を待ち受けるこのPCのアドレスです。0.0.0.0 ですべてのネットワークで待ち受けます。"
                             if mode == "server" else "接続先のRFデータ配信サーバのIPアドレスかホスト名です。")
        for widget in (self.host, self.port, self.token, self.generate, self.reveal):
            widget.setEnabled(mode != "local")
        self.limit.setEnabled(mode == "server")
        self.limit_label.setEnabled(mode == "server")
        self.iq_format.setEnabled(mode == "server")
        self.iq_format_label.setEnabled(mode == "server")
        if self.iq_format.currentData() == "frames":
            server_hint = ("プロファイルの無線機で受信し、このPCで全chを復調して同期済みフレームだけを配信します。"
                           "通話中のchだけを送るため転送量は通常数KB/sです。スケルチはこのPCで設定します。"
                           "97chの復調には約4〜5コア分のCPUが必要です。音声再生はクライアントで行います。")
        else:
            mbps = 25.6 if self.iq_format.currentData() == "cs16" else 51.2
            server_hint = f"プロファイルの無線機でIQを配信します。このPCではch解析・音声再生を行いません。97chでは1クライアントあたり約{mbps:.1f} Mbpsです。"
        self.hint.setText({"local": "このPCの無線機で受信・解析します。",
            "client": "無線機は開かず、サーバのIQまたは復調済みフレームを受信して、このPCで解析・再生・録音します。配信形式・周波数・ch構成はサーバから取得します。",
            "server": server_hint}[mode])
        self.changed.emit()

    def save_correct(self):
        self.preferences.setValue("correct_iq", self.correct.isChecked())

    def settings(self):
        mode = self.mode.currentData()
        host = self.host.text().strip()
        token = self.token.text()
        if mode != "local":
            require_token(token)
            if not host or any(c.isspace() for c in host):
                raise ValueError("IP / ホスト名を入力してください")
        self.update_mode()
        self.preferences.setValue("rf_mode", mode)
        self.preferences.setValue("rf_client_host", self.client_host)
        self.preferences.setValue("rf_listen_host", self.listen_host)
        self.preferences.setValue("rf_port", self.port.value())
        self.preferences.setValue("rf_max_clients", self.limit.value())
        self.preferences.setValue("rf_iq_format", self.iq_format.currentData())
        self.preferences.setValue("rf_token", token)
        self.save_correct()
        return mode, host, self.port.value(), token, self.limit.value()

    def set_running(self, running):
        self.mode.setEnabled(not running)
        if running:
            for widget in (self.host, self.port, self.token, self.generate, self.reveal, self.limit, self.iq_format):
                widget.setEnabled(False)
        else:
            self.update_mode()


class RFNetworkStatus(QtWidgets.QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWordWrap(True)
        self.last_bytes = 0
        self.last_time = None
        self.last_state = None
        self.setText("IP配信：停止中")

    def reset(self, text):
        self.last_bytes = 0
        self.last_time = None
        self.last_state = None
        self.setText(text)

    def update_state(self, state):
        if self.last_state is state:
            return
        self.last_state = state
        now = time.monotonic()
        total = state.get("bytes", 0)
        elapsed = now - self.last_time if self.last_time is not None else 0
        rate = max(0, total - self.last_bytes) / elapsed if elapsed > 0 else 0
        self.last_bytes, self.last_time = total, now
        metadata = state.get("metadata", {})
        frames = metadata.get("format") == FRAME_FORMAT
        kind = "フレーム" if frames else "IQ"
        mode = f"{kind}受信中" if state.get("mode") == "client" else f"{kind}配信中" if state.get("clients", 0) else "RFサーバ待受中"
        clients = f" · 接続 {state.get('clients', 0)}台" if state.get("mode") == "server" else ""
        if frames:
            self.setText(f"{mode} · {state.get('endpoint', '')}{clients} · {rate / 1024:.1f} KB/s · {total / 1024**2:.2f} MiB · 復調済みフレーム")
        else:
            precision = "16bit" if metadata.get("format") == "cs16-scaled-le" else "32bit"
            self.setText(f"{mode} · {state.get('endpoint', '')}{clients} · {rate * 8 / 1e6:.1f} Mbps · {total / 1024**2:.1f} MiB · {metadata.get('sample_rate', 0) / 1000:.0f} kS/s · {precision}")
        if state.get("mode") == "client" and frames:
            self.setToolTip("サーバで復調済みのフレームを受信しています。\nスケルチ・Correct IQはサーバ側の設定です。")
        elif state.get("mode") == "client":
            self.setToolTip(f"解析待ち：{state.get('buffer_ms', 0):.0f} ms\n接続前のIQは受信しません")
        else:
            reason = state.get("last_disconnect") or "なし"
            self.setToolTip(f"低速クライアントの切断数：{state.get('overruns', 0)}\n最後の切断理由：{reason}")
