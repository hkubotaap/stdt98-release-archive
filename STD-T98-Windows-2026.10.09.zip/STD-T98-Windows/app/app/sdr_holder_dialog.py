"""Startup check: offer to stop processes that may already hold the SDR."""
import datetime

from PyQt5 import QtCore, QtWidgets

from core.pipeline.sdr_holders import find_holders, stop_holders


class _Worker(QtCore.QThread):
    done = QtCore.pyqtSignal(object, str)

    def __init__(self, function, parent=None):
        super().__init__(parent)
        self.function = function

    def run(self):
        try:
            self.done.emit(self.function(), "")
        except Exception as exc:  # A failed scan must never block startup.
            self.done.emit(None, str(exc))


class SdrHolderDialog(QtWidgets.QDialog):
    def __init__(self, holders, parent=None):
        super().__init__(parent)
        self.setWindowTitle("無線機を使用中のプロセス")
        self.setMinimumWidth(620)
        layout = QtWidgets.QVBoxLayout(self)
        intro = QtWidgets.QLabel(
            "無線機（SDR）を開いている可能性のあるプロセスが動いています。\n"
            "このままでは受信開始時に無線機を開けないことがあります。終了するものを選んでください。")
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.items = QtWidgets.QListWidget()
        self.items.setWordWrap(True)
        self.items.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.items.setSpacing(2)
        for holder in holders:
            started = (datetime.datetime.fromtimestamp(holder.root.created).strftime("%m/%d %H:%M:%S")
                       if holder.root.created else "不明")
            children = len(holder.members) - 1
            text = (f"{holder.label}　PID {holder.root.pid}　起動 {started}\n"
                    f"    {holder.detail}" + (f"（関連プロセス {children} 個も終了）" if children else ""))
            item = QtWidgets.QListWidgetItem(text)
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            # Leftover receivers are checked; other people's SDR software is opt-in.
            item.setCheckState(QtCore.Qt.Unchecked if holder.external else QtCore.Qt.Checked)
            item.setToolTip(holder.root.cmdline or holder.root.name)
            item.setData(QtCore.Qt.UserRole, holder)
            self.items.addItem(item)
        # Show every entry without scrolling for the usual handful of holders.
        rows = sum(self.items.sizeHintForRow(i) + 2 * self.items.spacing() for i in range(self.items.count()))
        self.items.setMinimumHeight(min(rows + 8, 420))
        layout.addWidget(self.items)
        warning = QtWidgets.QLabel(
            "選択したプロセスは関連プロセスごと強制終了します。別のウィンドウで受信・録音中の場合、"
            "録音の最後の部分が保存されないことがあります。外部ソフトは保存していない作業が失われます。")
        warning.setWordWrap(True)
        warning.setStyleSheet("color: #ffb45c;")
        layout.addWidget(warning)
        buttons = QtWidgets.QDialogButtonBox()
        self.stop_button = buttons.addButton("選択したプロセスを終了", QtWidgets.QDialogButtonBox.AcceptRole)
        buttons.addButton("終了せずに続ける", QtWidgets.QDialogButtonBox.RejectRole)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        self.items.itemChanged.connect(lambda _item: self.stop_button.setEnabled(bool(self.selected())))
        layout.addWidget(buttons)

    def selected(self):
        return [self.items.item(i).data(QtCore.Qt.UserRole) for i in range(self.items.count())
                if self.items.item(i).checkState() == QtCore.Qt.Checked]


class SdrHolderCheck(QtCore.QObject):
    """Scan in the background after the window is shown; ask only if something is found."""

    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.worker = None

    def start(self):
        self._run(find_holders, self._scanned)

    def _run(self, function, slot):
        self.worker = _Worker(function, self)
        self.worker.done.connect(slot)
        self.worker.start()

    def _scanned(self, holders, error):
        if error or not holders:
            return
        dialog = SdrHolderDialog(holders, self.window)
        if dialog.exec_() != QtWidgets.QDialog.Accepted or not dialog.selected():
            return
        chosen = dialog.selected()
        self.window.statusBar().showMessage("無線機を使用中のプロセスを終了しています…")
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        self._run(lambda: stop_holders(chosen), lambda remaining, err: self._stopped(chosen, remaining, err))

    def _stopped(self, chosen, remaining, error):
        QtWidgets.QApplication.restoreOverrideCursor()
        if error or remaining:
            names = "\n".join(f"{h.label}（PID {h.root.pid}）" for h in (remaining or chosen))
            QtWidgets.QMessageBox.warning(self.window, "プロセスの終了",
                f"終了できなかったプロセスがあります。\n{names}\n{error}\n"
                "管理者権限で動いている場合は、タスクマネージャーから終了してください。")
            self.window.statusBar().showMessage("一部のプロセスを終了できませんでした。")
        else:
            self.window.statusBar().showMessage(f"{len(chosen)} 件のプロセスを終了しました。")
