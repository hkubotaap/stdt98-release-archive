"""Research view for an actual 20 ms AMBE+2 block, with chronological audition."""
import io
import gc
import json
import queue
import os
import tempfile
import threading
import tkinter as tk
from tkinter import filedialog, ttk
import wave

import numpy as np

from core.analysis.ambe_voice import (AnalysisCancelled, VoiceBurst, analyse_recording,
                                     parse_trial_key, serialisable)
from core.analysis.ambe_voice_help import (GUIDE_SECTIONS, TONE_HELP,
                                          field_explanation, state_explanation)


class AmbeVoiceWindow(tk.Toplevel):
    def __init__(self, anatomy, player_factory=None):
        super().__init__(anatomy)
        self.anatomy = anatomy
        self.title("AMBE+2 音声ビット解析・試聴")
        self.geometry("1120x800")
        self.minsize(880, 620)
        self.key_var = anatomy.trial_key_var
        self.frame_var = tk.StringVar(self, str(anatomy.framelist.curselection()[0]))
        self.soft_var = tk.BooleanVar(self, False)
        self._result = None
        self._player = None
        self._player_factory = player_factory
        self._cancel = threading.Event()
        self._queue = queue.Queue()
        self._generation = 0
        self._closed = False
        self._debounce = None
        self._poll = None
        self._fallback_path = None
        self._bursts = self._capture_bursts()
        self._build()
        self._key_trace = self.key_var.trace_add("write", self._key_changed)
        self._frame_bind = anatomy.framelist.bind("<<ListboxSelect>>", self._follow_frame, add="+")
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self._poll = self.after(50, self._poll_result)
        self._request()

    def _capture_bursts(self):
        bursts = []
        for index, frame in enumerate(self.anatomy.frames):
            F, mode, valid, _source = self.anatomy._frame_role(index)
            blocks = []
            for name in ("TCH1", "TCH2"):
                bits = self.anatomy._section_bits(index, name)
                blocks.extend(int(bits[i:i + 72], 2).to_bytes(9, "big") if bits else None for i in (0, 72))
            sacch = frame.get("sacch") or {}
            secret = sacch.get("callStat") == 1 if valid and sacch.get("crcOK") and sacch.get("callStat") in (0, 1) else None
            soft = ()
            saved = frame.get("soft_fec") or {}
            try:
                data = bytes.fromhex(saved.get("blocks", ""))
                if len(data) == 36:
                    soft = tuple(data[i:i + 9] for i in range(0, 36, 9))
            except (ValueError, TypeError, AttributeError):
                pass
            bursts.append(VoiceBurst(tuple(blocks), F, mode, valid, frame.get("missed", 0) or 0, secret, soft))
        return tuple(bursts)

    def _build(self):
        outer = ttk.Frame(self, padding=10)
        outer.pack(fill=tk.BOTH, expand=True)
        controls = ttk.Frame(outer)
        controls.pack(fill=tk.X)
        ttk.Label(controls, text="試聴キー（0=解除なし）").pack(side=tk.LEFT)
        validate = self.register(lambda value: value == "" or
                                 (value.isascii() and value.isdecimal() and int(value) <= 32767))
        self.key_entry = ttk.Entry(controls, textvariable=self.key_var, width=9, validate="key",
                                   validatecommand=(validate, "%P"))
        self.key_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(controls, text="再解析", command=self._request).pack(side=tk.LEFT, padx=5)
        ttk.Checkbutton(controls, text="記録済み軟判定FECを使用", variable=self.soft_var,
                        command=self._request).pack(side=tk.LEFT, padx=12)
        ttk.Label(controls, text="フレーム #").pack(side=tk.LEFT)
        self.frame_entry = ttk.Spinbox(controls, from_=0, to=max(0, len(self._bursts) - 1),
                                       textvariable=self.frame_var, width=7, command=self._choose_frame)
        self.frame_entry.pack(side=tk.LEFT, padx=4)
        self.frame_entry.bind("<Return>", self._choose_frame)
        ttk.Button(controls, text="←", width=3, command=lambda: self._move(-1)).pack(side=tk.LEFT)
        ttk.Button(controls, text="→", width=3, command=lambda: self._move(1)).pack(side=tk.LEFT)
        self.status = ttk.Label(outer, text="解析準備中…", wraplength=1000)
        self.status.pack(fill=tk.X, pady=(6, 2))
        self.context = ttk.Label(outer, text="", wraplength=1000)
        self.context.pack(fill=tk.X)
        outer.bind("<Configure>", lambda e: [w.configure(wraplength=max(200, e.width - 25)) for w in (self.status, self.context)])
        self.blocks = ttk.Treeview(outer, columns=("tch", "time", "fec", "kind", "action", "pitch"),
                                   show="headings", height=4, selectmode="browse")
        for name, label, width in (("tch", "音声ブロック", 145), ("time", "80ms内の位置", 140),
                                   ("fec", "FEC e0 / e1", 120), ("kind", "受信情報の種別", 170),
                                   ("action", "実際の合成処理", 150), ("pitch", "基本周波数 Hz", 130)):
            self.blocks.heading(name, text=label)
            self.blocks.column(name, width=width, anchor="w")
        self.blocks.pack(fill=tk.X, pady=6)
        self.blocks.bind("<<TreeviewSelect>>", self._show_block)
        # Reserve the action row before the expanding notebook, including when
        # Japanese fonts or display scaling increase the requested tab height.
        actions = ttk.Frame(outer)
        actions.pack(side=tk.BOTTOM, fill=tk.X, pady=(8, 0))
        self.tabs = ttk.Notebook(outer)
        self.tabs.pack(fill=tk.BOTH, expand=True)
        self.bit_text = self._text_page("ビット・FEC・秘話解除")
        self.parameter_page = ttk.Frame(self.tabs)
        self.tabs.add(self.parameter_page, text="量子化・音声パラメータ")
        self.parameters = ttk.Treeview(self.parameter_page, columns=("value", "bits", "meaning", "positions"),
                                       show="tree headings", height=9, selectmode="browse")
        self.parameters.heading("#0", text="項目")
        self.parameters.column("#0", width=60, stretch=False)
        for name, label, width in (("value", "値", 55), ("bits", "ビット列", 100),
                                   ("meaning", "意味", 270), ("positions", "INFO49 p の位置（分散配置）", 390)):
            self.parameters.heading(name, text=label)
            self.parameters.column(name, width=width)
        self.parameters.pack(fill=tk.X)
        parameter_scroll = ttk.Scrollbar(self.parameter_page, orient="horizontal", command=self.parameters.xview)
        parameter_scroll.pack(fill=tk.X)
        self.parameters.configure(xscrollcommand=parameter_scroll.set)
        self.parameters.bind("<<TreeviewSelect>>", self._show_field)
        self.parameter_text = self._text_widget(self.parameter_page, readable=True)
        self.chart_page = ttk.Frame(self.tabs)
        self.tabs.add(self.chart_page, text="波形・倍音スペクトル")
        self.chart = tk.Canvas(self.chart_page, bg="#ffffff", highlightthickness=0)
        self.chart.pack(fill=tk.BOTH, expand=True)
        self.chart.bind("<Configure>", lambda _e: self._draw_chart())
        self.state_text = self._text_page("復号状態・解説")
        self.state_text.configure(wrap="word", font=("Meiryo", 10))
        guide_page = ttk.Frame(self.tabs)
        self.tabs.add(guide_page, text="項目・用語ガイド")
        guide_controls = ttk.Frame(guide_page, padding=(8, 6))
        guide_controls.pack(fill=tk.X)
        ttk.Label(guide_controls, text="説明を選択").pack(side=tk.LEFT)
        self.guide_topic = ttk.Combobox(guide_controls, values=tuple(GUIDE_SECTIONS),
                                        state="readonly", width=38)
        self.guide_topic.pack(side=tk.LEFT, padx=8)
        self.guide_topic.current(0)
        self.guide_topic.bind("<<ComboboxSelected>>", self._show_guide)
        self.guide_text = self._text_widget(guide_page, readable=True)
        self._show_guide()
        self.output_buttons = []
        for label, callback in (("選択20msを試聴", lambda: self._play("block")),
                                ("この80msを試聴", lambda: self._play("frame")),
                                ("前後約1秒を試聴", lambda: self._play("context")),
                                ("80ms WAV保存…", self._export_wav),
                                ("解析JSON・BIN保存…", self._export_trace)):
            button = ttk.Button(actions, text=label, command=callback, state="disabled")
            button.pack(side=tk.LEFT, padx=(0, 5))
            self.output_buttons.append(button)
        ttk.Button(actions, text="停止", command=self._stop).pack(side=tk.LEFT)

    def _text_widget(self, parent, readable=False):
        host = ttk.Frame(parent)
        host.pack(fill=tk.BOTH, expand=True)
        host.rowconfigure(0, weight=1)
        host.columnconfigure(0, weight=1)
        text = tk.Text(host, wrap="word" if readable else "none",
                       font=("Meiryo", 10) if readable else ("Consolas", 10), bg="#ffffff", fg="#24292f",
                       padx=12, pady=10, state="disabled", height=8)
        text.grid(row=0, column=0, sticky="nsew")
        y = ttk.Scrollbar(host, command=text.yview)
        y.grid(row=0, column=1, sticky="ns")
        x = ttk.Scrollbar(host, orient=tk.HORIZONTAL, command=text.xview)
        x.grid(row=1, column=0, sticky="ew")
        text.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        text.tag_configure("title", font=("Segoe UI", 11, "bold"))
        text.tag_configure("guide_heading", font=("Meiryo", 10, "bold"))
        text.tag_configure("changed", foreground="#b42318", background="#ffebe9", font=("Consolas", 10, "bold"))
        text.tag_configure("field", foreground="#1d5fbf", background="#eaf2ff", font=("Consolas", 10, "bold"))
        text.tag_configure("dim", foreground="#57606a")
        return text

    def _text_page(self, title):
        page = ttk.Frame(self.tabs)
        self.tabs.add(page, text=title)
        return self._text_widget(page)

    def _show_guide(self, _event=None):
        topic = self.guide_topic.get()
        text = self.guide_text
        text.configure(state="normal")
        text.delete("1.0", tk.END)
        text.insert(tk.END, topic + "\n\n", "title")
        for paragraph in GUIDE_SECTIONS[topic].split("\n\n"):
            lines = paragraph.splitlines()
            if len(lines) > 1 and len(lines[0]) < 65 and not lines[0].startswith("1."):
                text.insert(tk.END, lines[0] + "\n", "guide_heading")
                text.insert(tk.END, "\n".join(lines[1:]) + "\n\n")
            else:
                text.insert(tk.END, paragraph + "\n\n")
        text.configure(state="disabled")
        text.yview_moveto(0)

    @staticmethod
    def _replace(text, content):
        text.configure(state="normal")
        text.delete("1.0", tk.END)
        text.insert(tk.END, content)
        text.configure(state="disabled")
        text.yview_moveto(0)

    def _invalidate(self):
        self._cancel.set()
        self._generation += 1
        self._result = None
        self._stop()
        self.blocks.delete(*self.blocks.get_children())
        self.parameters.delete(*self.parameters.get_children())
        for widget in (self.bit_text, self.parameter_text, self.state_text):
            self._replace(widget, "")
        self.chart.delete("all")
        for button in self.output_buttons:
            button.configure(state="disabled")

    def _key_changed(self, *_):
        self._invalidate()
        self.status.configure(text="試聴キー変更中…")
        if self._debounce:
            self.after_cancel(self._debounce)
        self._debounce = self.after(250, self._request)

    def _follow_frame(self, _event=None):
        selected = self.anatomy.framelist.curselection()
        if selected:
            self.frame_var.set(str(selected[0]))
            self._request()

    def _choose_frame(self, _event=None):
        try:
            index = int(self.frame_var.get())
            if not 0 <= index < len(self._bursts):
                raise ValueError()
        except (ValueError, tk.TclError):
            self._invalidate()
            self.status.configure(text="フレーム番号が記録範囲外です。")
            return
        self.anatomy.framelist.selection_clear(0, tk.END)
        self.anatomy.framelist.selection_set(index)
        self.anatomy.framelist.see(index)
        self.anatomy._on_frame(None)
        self._request()

    def _move(self, delta):
        try:
            index = int(self.frame_var.get())
        except ValueError:
            return
        self.frame_var.set(str(max(0, min(len(self._bursts) - 1, index + delta))))
        self._choose_frame()

    def _request(self):
        if self._closed:
            return
        if self._debounce:
            self.after_cancel(self._debounce)
            self._debounce = None
        self._invalidate()
        try:
            key = parse_trial_key(self.key_var.get())
            index = int(self.frame_var.get())
            if not 0 <= index < len(self._bursts):
                raise ValueError("フレーム番号が記録範囲外です。")
        except (ValueError, tk.TclError) as exc:
            self.status.configure(text=str(exc) if isinstance(exc, ValueError) else "試聴キーを入力してください。")
            return
        self._cancel = threading.Event()
        token, cancel, soft = self._generation, self._cancel, self.soft_var.get()
        bursts, mailbox = self._bursts, self._queue
        self.status.configure(text=f"フレーム #{index:03d} / 試聴キー {key}：録音先頭から復号履歴を再構成中…")
        self.context.configure(text="受信ビットは変更しません。解析・試聴は参照コーデックの出力（8kHz mono / 160 sample・20ms）です。")
        def work():
            try:
                result = analyse_recording(bursts, index, key, soft, cancelled=cancel.is_set)
                mailbox.put((token, result, None))
            except AnalysisCancelled:
                pass
            except Exception as exc:
                mailbox.put((token, None, str(exc)))
        # Tcl variables must be finalized on the UI thread. The worker owns
        # only immutable inputs and a mailbox, never a widget or Tk variable.
        gc.collect()
        threading.Thread(target=work, name="ambe-voice-analysis", daemon=True).start()

    def _poll_result(self):
        if self._closed:
            return
        try:
            while True:
                token, result, error = self._queue.get_nowait()
                if token != self._generation:
                    continue
                if error:
                    self.status.configure(text=f"解析できませんでした: {error}")
                    continue
                self._result = result
                secret = self._bursts[result["frame"]].secret
                call = "秘話" if secret is True else "平文" if secret is False else "秘話状態未確定"
                mode = f"キー {result['key']} による解除候補" if result["key"] else "解除なし（平文として解析）"
                self.status.configure(text=f"フレーム #{result['frame']:03d} / 記録: {call} / 解析: {mode}")
                self.context.configure(text="FECは試聴キーの正否を検証しません。INFO49/T49は49bit、保存時の末尾7bitはパディングです。" +
                                       (" この記録は秘話のため、キー0では未解除の候補値です。" if secret is True and not result["key"] else ""))
                for trace in result["blocks"]:
                    block = trace["block"]
                    model = trace.get("model") or {}
                    fec = trace.get("fec") or {}
                    self.blocks.insert("", tk.END, iid=str(block), values=(
                        f"{trace['TCH']} / {block % 2 + 1} ({block + 1}/4)", f"{block * 20}〜{(block + 1) * 20} ms",
                        f"{fec.get('e0', '—')} / {fec.get('e1', '—')}", trace.get("unavailable") or trace["meta"].get("wire_type"),
                        trace["meta"].get("action"), f"{model['f0_hz']:.3f}" if model and trace["meta"].get("action") == "VOICE" else "—"))
                self.blocks.selection_set("0")
                self._show_block()
                playable = any("unavailable" not in t for t in result["blocks"])
                for button in self.output_buttons:
                    button.configure(state="normal" if playable else "disabled")
        except queue.Empty:
            pass
        self._poll = self.after(50, self._poll_result)

    def _current(self):
        selected = self.blocks.selection()
        return self._result["blocks"][int(selected[0])] if self._result and selected else None

    def _show_block(self, _event=None):
        trace = self._current()
        if trace is None:
            return
        self.parameters.delete(*self.parameters.get_children())
        if "unavailable" in trace:
            self._replace(self.bit_text, trace["unavailable"] + "\n受信ビット／音声パラメータを推測で生成しません。")
            self._replace(self.parameter_text, "音声パラメータなし。")
        else:
            self._render_bits(trace)
            for field in trace["fields"]:
                self.parameters.insert("", tk.END, iid=field["name"], text=field["name"], values=(
                    field["value"], field["bits"], field["meaning"], ",".join(map(str, field["info49_positions"]))))
            if trace.get("tone"):
                self._replace(self.parameter_text, "TONE専用配置（情報ビットの診断候補）。b0〜b8の通常音声表を適用しません。\n" + TONE_HELP + json.dumps(trace["tone"], ensure_ascii=False, indent=2))
            else:
                self.parameters.selection_set("b0")
                self._show_field()
        state = {k: v for k, v in trace.items() if k in ("meta", "fec", "state_before", "state_after", "candidate_type", "soft_note")}
        content = ("HR-PUBLIC-ALLFRAMES-v1 / D:\\ai\\ambe\\AMBE2_DECODER_SPEC.md v0.13 の参照実装\n"
                   "パラメータは参照プロファイルの値です。公式DVSI機器とのPCM一致を保証する値ではありません。\n\n"
                   "診断データ（JSON）\n")
        self._replace(self.state_text, state_explanation(trace) + content + json.dumps(serialisable(state), ensure_ascii=False, indent=2))
        self._draw_chart()

    def _render_bits(self, trace, positions=()):
        text = self.bit_text
        text.configure(state="normal")
        text.delete("1.0", tk.END)
        text.insert(tk.END, f"フレーム #{trace['recording_frame']:03d} / ブロック {trace['block'] + 1}/4 / {trace['TCH']}\n", "title")
        text.insert(tk.END, f"受信フレームbit {trace['frame_bits'][0]}〜{trace['frame_bits'][1]} / byte 0x{trace['frame_bits'][0] // 8:02X}〜0x{trace['frame_bits'][1] // 8:02X}\n")
        text.insert(tk.END, "経路: DIBIT36 → インタリーブ解除 → CODE72 → Golay/PN FEC → INFO49 ↔ T49 → 秘話PN XOR → 音声情報\n")
        text.insert(tk.END, "赤=FEC訂正候補との差、青=選択したb項目。C0/C1は符号化されるため情報bitとの1対1対応ではありません。\n\n")
        labels = {"DIBIT36_received": "受信72bit（デホワイトニング後）", "CODE72_received": "インタリーブ解除72bit",
                  "CODE72_corrected_candidate": "FEC訂正候補72bit", "INFO49_before_key": "FEC後49bit（キー適用前）",
                  "T49_before_key": "T49配置49bit（キー適用前）", "PN49_in_T49_order": "PN49（T49と同じ表示順）",
                  "T49_after_key": "キー適用後 T49（解除候補）", "INFO49_after_key": "キー適用後 INFO49 p[0..48]"}
        for stage, label in labels.items():
            bits = trace["formats"][stage]
            text.insert(tk.END, label + "\n", "title")
            if stage in trace["hex"]:
                text.insert(tk.END, "HEX " + trace["hex"][stage].upper() + (" / 49bit+末尾7bitの0パディング" if len(bits) == 49 else "") + "\n", "dim")
            text.insert(tk.END, "BIN ")
            changes = trace["fec"]["changed_wire"] if stage == "DIBIT36_received" else trace["fec"]["changed_code72"] if stage in ("CODE72_received", "CODE72_corrected_candidate") else ()
            for i, bit in enumerate(bits):
                text.insert(tk.END, bit, "field" if stage == "INFO49_after_key" and i in positions else "changed" if i in changes else ())
                if i % 8 == 7:
                    text.insert(tk.END, " ")
            text.insert(tk.END, "\n\n")
        fec = trace["fec"]
        text.insert(tk.END, f"FEC: {fec['procedure']} / e0={fec['e0']} / e1={fec['e1']} / failure={fec['failure']}\n")
        text.insert(tk.END, f"PN位置: 196bit中の{trace['pn196_range'][0]}〜{trace['pn196_range'][1]}。T49のbit tにはPN[offset + THUMBDV_MAP[t]]を適用します。\n")
        text.insert(tk.END, "C0=24bit(G24)、C1=23bit(G23+u0由来PN)、C2=11bit・C3=14bitは無保護。FECのPNと秘話PNは別です。\n")
        if fec["failure"]:
            text.insert(tk.END, "訂正候補はFEC失敗判定です。パラメータを合成に採用せず、状態に従ってREPEAT/MUTEDを出力します。\n", "changed")
        if trace.get("soft_note"):
            text.insert(tk.END, trace["soft_note"] + "\n", "changed")
        text.configure(state="disabled")

    def _show_field(self, _event=None):
        trace, selected = self._current(), self.parameters.selection()
        if not trace or not selected:
            return
        field = next(f for f in trace["fields"] if f["name"] == selected[0])
        self._render_bits(trace, field["info49_positions"])
        content = (f"{field['name']} = {field['value']} / {field['width']}bit / {field['meaning']}\n"
                   f"値のビット列（MSB→LSB）: {field['bits']}\n\n"
                   + field_explanation(field, trace) + "\n"
                   f"INFO49 p の取得順: {field['info49_positions']}\n"
                   f"u語の位置: {', '.join(field['word_bits'])}\n"
                   f"T49の位置: {field['t49_positions']}\n"
                   f"対応する秘話PN196の位置: {field['pn196_positions']}\n\n"
                   "INFO49のb項目は分散配置です。通常のb0〜b8の順に49bitを切り分けると誤解析になります。\n")
        if trace.get("model"):
            content += "\n音声モデル（参照規則による復元値）\n" + json.dumps(trace["model"], ensure_ascii=False, indent=2)
        else:
            content += "\n合成に採用された通常音声モデルはありません。上の値は情報ビットの診断候補です。\n"
        self._replace(self.parameter_text, content)

    def _draw_chart(self):
        c, trace = self.chart, self._current()
        c.delete("all")
        if trace is None:
            return
        w, h = max(350, c.winfo_width()), max(210, c.winfo_height())
        pcm = trace["pcm"].astype(float)
        peak = float(np.max(np.abs(pcm)))
        scale = max(1, peak)
        top, bottom = 35, max(105, h * .44)
        c.create_text(12, 12, anchor="nw", text=f"PCM16 / 8kHz / 160 sample・20ms / 最大絶対値 {int(peak)}（波形は表示用に正規化）")
        points = [value for i, sample in enumerate(pcm) for value in (45 + i / 159 * (w - 65), (top + bottom) / 2 - sample / scale * (bottom - top) / 2)]
        c.create_line(45, (top + bottom) / 2, w - 20, (top + bottom) / 2, fill="#d0d7de")
        c.create_line(*points, fill="#1d5fbf")
        c.create_text(45, bottom + 12, text="0 ms", anchor="w")
        c.create_text(w - 20, bottom + 12, text="20 ms", anchor="e")
        model = trace.get("model")
        y0, y1 = bottom + 55, h - 30
        if not model:
            c.create_text(12, y0, anchor="nw", text="通常音声モデルなし。TONE / REPEAT / MUTED / 未記録を通常VOICEのスペクトルとして表示しません。")
            return
        c.create_text(12, y0 - 22, anchor="nw", text=f"合成倍音 E[l] / L={model['L']} / f0={model['f0_hz']:.3f} Hz / 緑=有声・灰=無声 / 自動倍率・モデル値")
        maximum = max(max(model["E"]), 1e-12)
        for frequency, magnitude, voiced in zip(model["frequency_hz"], model["E"], model["vbar"]):
            x = 45 + frequency / 4000 * (w - 65)
            y = y1 - magnitude / maximum * max(1, y1 - y0)
            c.create_line(x, y1, x, y, width=4, fill="#116329" if voiced else "#57606a")
        c.create_line(45, y1, w - 20, y1, fill="#57606a")
        for frequency in (0, 1000, 2000, 3000, 4000):
            c.create_text(45 + frequency / 4000 * (w - 65), y1 + 13, text=f"{frequency} Hz")

    def _play(self, scope):
        trace = self._current()
        if self._result is None or trace is None:
            return
        pcm = trace["pcm"] if scope == "block" else self._result["selected_pcm"] if scope == "frame" else self._result["context_pcm"]
        # Stop ordinary audition before opening a second audio stream.
        master = self.anatomy.master
        if hasattr(master, "_stop_play"):
            master._stop_play()
        try:
            if self._player is None:
                if self._player_factory is None:
                    from key_tool import SeekPlayer
                    self._player_factory = SeekPlayer
                self._player = self._player_factory()
            if self._player.available:
                self._player.load(pcm, 8000)
                self._player.play()
                if not self._player.playing:
                    self.status.configure(text="音声出力を開始できませんでした。出力デバイスを確認してください。")
            else:
                import winsound
                self._stop()
                with tempfile.NamedTemporaryFile(suffix=".wav", prefix="std_t98_ambe_", delete=False) as stream:
                    stream.write(self._wav_bytes(pcm))
                    self._fallback_path = stream.name
                winsound.PlaySound(self._fallback_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception as exc:
            self.status.configure(text=f"試聴できませんでした: {exc}")

    def _stop(self):
        if self._player is not None:
            self._player.stop()
        if self._fallback_path is not None:
            import winsound
            winsound.PlaySound(None, 0)
            try:
                os.unlink(self._fallback_path)
            except OSError:
                pass
            self._fallback_path = None

    @staticmethod
    def _wav_bytes(pcm):
        stream = io.BytesIO()
        with wave.open(stream, "wb") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(8000)
            wav.writeframes(np.asarray(pcm, dtype="<i2").tobytes())
        return stream.getvalue()

    def _export_wav(self):
        if self._result is None:
            return
        path = filedialog.asksaveasfilename(parent=self, title="選択80msの参照復号音声を保存", defaultextension=".wav",
                                           initialfile=f"frame{self._result['frame']:03d}_key{self._result['key']}.wav", filetypes=[("WAV", "*.wav")])
        if path:
            try:
                with open(path, "wb") as stream:
                    stream.write(self._wav_bytes(self._result["selected_pcm"]))
            except OSError as exc:
                self.status.configure(text=f"保存できませんでした: {exc}")

    def _export_trace(self):
        if self._result is None:
            return
        path = filedialog.asksaveasfilename(parent=self, title="選択80msの解析結果を保存", defaultextension=".json",
                                           initialfile=f"frame{self._result['frame']:03d}_key{self._result['key']}_ambe.json", filetypes=[("JSON", "*.json")])
        if not path:
            return
        from pathlib import Path
        destination = Path(path)
        report = {k: v for k, v in self._result.items() if k != "context_pcm"}
        report["source_recording"] = self.anatomy.files[self.anatomy.filelist.curselection()[0]]
        report["source_frame"] = self.anatomy.frames[self._result["frame"]]
        try:
            destination.write_text(json.dumps(serialisable(report), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
            for trace in self._result["blocks"]:
                if "unavailable" in trace:
                    continue
                for format_name in ("DIBIT36_received", "CODE72_received", "CODE72_corrected_candidate",
                                    "INFO49_before_key", "T49_before_key", "T49_after_key", "INFO49_after_key"):
                    destination.with_name(f"{destination.stem}_block{trace['block'] + 1}_{format_name}.bin").write_bytes(bytes.fromhex(trace["hex"][format_name]))
        except (OSError, ValueError) as exc:
            self.status.configure(text=f"保存できませんでした: {exc}")

    def destroy(self):
        if self._closed:
            return
        self._closed = True
        self._cancel.set()
        for timer in (self._poll, self._debounce):
            if timer:
                self.after_cancel(timer)
        self.key_var.trace_remove("write", self._key_trace)
        self.anatomy.framelist.unbind("<<ListboxSelect>>", self._frame_bind)
        self._stop()
        if self._player is not None:
            self._player.close()
        super().destroy()
