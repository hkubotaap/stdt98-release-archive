"""Privacy-key analysis is disabled in this distribution."""
import sys


def main(argv=None):
    print("Privacy-key analysis is disabled in this distribution.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
