# STD-T98 Windows 配布版

Windows向けのデジタル簡易無線受信・録音・解析ツールです。
Copyright (C) 2026 ToTon。独自コードはGPL-3.0-onlyで配布します。

## 利用前に

**[電波法と受信データの取扱い](LEGAL_NOTICE.md)を確認してください。**
特定の相手方に向けた通信の存在・内容の漏えいと窃用には電波法上の規制があります。
秘話キーの自動探索・推定は無効ですが、既知キーによる復号・試聴は利用できます。

## 初回セットアップと起動

1. ZIPを、書き込み可能で十分な空き容量があるフォルダへ展開します。
2. `setup_env.bat` を実行します。初回はインターネット接続が必要で、
   radiocondaと必要な依存を準備します。実行環境の構築には数GBの空き容量が必要です。
3. `run_gui.vbs` でGUIを起動します。起動時の表示を確認する場合は `run_gui.bat` を使います。
4. 使用するSDR機種を選び、デバイス・周波数等を設定します。

コンソール受信は `run.bat`、録音の試聴は `key_tool.bat`、解析ツールは `ana_run.bat` です。
詳しい要件・機種別設定・トラブル対応は [README_Windows.txt](README_Windows.txt)、
機能の説明は [app/README.md](app/README.md) を参照してください。

## このZIPの内容

アプリのソース、起動スクリプト、独自AMBE DLLと対応ソース、設定テンプレート、
説明書、ライセンス全文を含みます。Python実行環境、受信録音、個人設定、既知キー、
探索用モデル、Git履歴は含みません。保存先 `std98_data/` は利用時に作成されます。

音声強調のVoiceFixerは任意機能で、利用時に追加のパッケージ・モデルを取得します。
通常の受信・復号のために探索用の機械学習モデルを導入する必要はありません。

## 著作権・ライセンス・対応ソース

- [独自コードの権利者・年・対象・版](COPYRIGHT.md)
- [GNU GPL v3.0全文](LICENSE)
- [同梱コードの条件とMIT全文の案内](app/THIRD_PARTY_NOTICES.md)
- [AMBE DLLの対応ソース・ビルド手順](app/vendor/ambe2_source/README.md)
- [この配布版の変更記録](RELEASE_NOTES.md)

## 再配布用ZIPの作成

`RELEASE_MANIFEST.json` に記録したファイルだけを梱包します。録音・設定・実行環境は
対象外です。ハッシュが変わったファイルがあると、梱包処理は停止します。

```powershell
python tools/package_release.py --output dist/STD-T98-Windows-2026.10.09.zip
```

`python/`の実行環境やモデルを別途同梱する版は、追加物のライセンスとソース提供条件を
確認してから作成してください。
