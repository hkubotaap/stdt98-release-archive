# 著作権・ライセンス表示

Copyright (C) 2026 ToTon

- 権利者：ToTon
- 年：2026年
- 対象：このSTD-T98配布版に含まれるToTon作成のアプリケーションコード、独自AMBE+2
  デコーダー実装、起動・環境設定スクリプト、および独自作成の文書。
- ライセンス：GNU General Public License version 3.0（GPL-3.0-only）。
- ライセンス全文：[LICENSE](LICENSE)

対象の独自コードは、Free Software Foundationが公表するGNU General Public License
version 3の条件に従って、再配布および改変できます。

本プログラムは有用であることを期待して配布しますが、無保証です。
商品性または特定目的適合性についての黙示の保証もありません。
詳しい条件は同梱のGNU General Public Licenseを参照してください。

第三者のコード・資料の著作権表示とライセンスは、それぞれの権利者のものです。
この表示の対象はToTonの独自著作部分です。同梱Chart.js・@kurkle/color等については
[app/THIRD_PARTY_NOTICES.md](app/THIRD_PARTY_NOTICES.md)と各ライセンス全文を参照してください。

AMBE DLLの対応ソース・生成／ビルド手順は
[app/vendor/ambe2_source/README.md](app/vendor/ambe2_source/README.md)にあります。
