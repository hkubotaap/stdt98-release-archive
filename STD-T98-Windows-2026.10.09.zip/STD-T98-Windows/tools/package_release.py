"""Build a release ZIP from the audited, hash-verified distribution manifest."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    manifest_path = ROOT / "RELEASE_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    prefix = manifest["archive_root"]
    if not prefix or Path(prefix).name != prefix or prefix in (".", ".."):
        raise ValueError("Invalid archive root")
    paths = []
    seen = set()
    for entry in manifest["files"]:
        rel = Path(entry["path"])
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Unsafe manifest path")
        if rel.as_posix() in seen:
            raise ValueError("Duplicate manifest path")
        seen.add(rel.as_posix())
        if any(part in {".git", "std98_data", "python", ".venv", "venv", "env", "dist", "__pycache__"} for part in rel.parts):
            raise ValueError("Excluded directory in manifest")
        path = (ROOT / rel).resolve(strict=True)
        path.relative_to(ROOT.resolve(strict=True))
        if not path.is_file():
            raise ValueError("Manifest entry is not a file")
        data = path.read_bytes()
        if len(data) != entry["size"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise ValueError("File differs from release manifest: " + rel.as_posix())
        paths.append((rel.as_posix(), data))
    paths.append(("RELEASE_MANIFEST.json", manifest_path.read_bytes()))
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError("Output already exists: " + str(output))
    output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation; all source bytes are checked before opening the archive.
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for rel, data in sorted(paths):
            info = zipfile.ZipInfo(prefix + "/" + rel, (2026, 10, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compresslevel=9)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    checksum = output.with_name(output.name + ".sha256")
    if checksum.exists():
        raise FileExistsError("Checksum output already exists: " + str(checksum))
    checksum.write_text(digest + "  " + output.name + "\n", encoding="ascii")
    print(json.dumps({"zip":str(output),"files":len(paths),"sha256":digest},ensure_ascii=False))

if __name__ == "__main__":
    main()
