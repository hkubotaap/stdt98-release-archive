@echo off
rem ====================================================================
rem  STD-T98 receiver - desktop GUI (PyQt5). Same portable env rules as
rem  run.bat. Launches with pythonw so no console window stays open.
rem  run_gui.vbs runs this hidden (argument "hidden") so no console shows.
rem ====================================================================
setlocal
cd /d "%~dp0"
set "ROOT=%~dp0"
set "APP=%ROOT%app"

rem Without python\ or radioconda, install radioconda automatically; with
rem radioconda, add any missing SoapySDR packages.
set "PYDIR="
if exist "%ROOT%python\python.exe" set "PYDIR=%ROOT%python"
if not defined PYDIR (
  if not exist "%USERPROFILE%\radioconda\python.exe" echo [INFO] No Python environment found. Installing radioconda ^(about 630 MB download^) ...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%APP%\tools\install_radioconda.ps1" -Target "%USERPROFILE%\radioconda"
  if errorlevel 1 (
    rem Hidden (run_gui.vbs): a pause would wait forever on an invisible window.
    if /i "%~1"=="hidden" (
      powershell -NoProfile -Command "Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show('radioconda / SoapySDR setup failed. Run run_gui.bat directly to see the details.','STD-T98')" >nul
      exit /b 1
    )
    echo [ERROR] radioconda / SoapySDR setup failed. See the messages above.
    pause
    exit /b 1
  )
  set "PYDIR=%USERPROFILE%\radioconda"
)

if exist "%PYDIR%\Scripts\activate.bat" call "%PYDIR%\Scripts\activate.bat" "%PYDIR%" >nul 2>&1
set "PATH=%PYDIR%;%PYDIR%\Library\bin;%PYDIR%\Library\usr\bin;%PYDIR%\Library\mingw-w64\bin;%PYDIR%\Scripts;%PATH%"
set "PY=%PYDIR%\python.exe"
set "PYW=%PYDIR%\pythonw.exe"
if not exist "%PYW%" set "PYW=%PY%"

rem pip-layer dep (the AMBE+2 voice decoder is bundled at app\vendor\ambe2)
"%PY%" -c "import sounddevice" 2>nul || "%PY%" -m pip install --no-input sounddevice

rem Privacy-key analysis is permanently disabled in this distribution.
set "STD_T98_NO_SECRET=1"

rem Detect connected SDR; the GUI reads STD_T98_SDR_DRIVER and uses it even when
rem a profile selects a different radio (override: set it before run_gui.bat).
if not defined STD_T98_SDR_DRIVER (
  for /f "usebackq delims=" %%D in (`"%PY%" -c "import SoapySDR;S={'hackrf','rtlsdr','airspy','airspyhf','uhd','bladerf','lime','sdrplay','plutosdr','rtltcp'};print(next((dict(d).get('driver','') for d in SoapySDR.Device.enumerate() if dict(d).get('driver','') in S),''))" 2^>nul`) do set "STD_T98_SDR_DRIVER=%%D"
)
if /i "%STD_T98_SDR_DRIVER%"=="hackrf" if not defined STD_T98_BACKEND_CONFIG set "STD_T98_BACKEND_CONFIG=%APP%\devices\hackrf.toml"

rem The flywheel probe (recovers frames whose sync word was missed; totals in
rem %TEMP%\std-t98-flywheel.log) is on by default. To turn it off:
rem   set "STD_T98_FLYWHEEL_PROBE=0"

start "" "%PYW%" "%APP%\std_t98_gui.py"
endlocal
