@echo off
rem ====================================================================
rem  STD-T98 (grport) : one-time setup of the portable python\ env.
rem
rem  GNU Radio + SoapySDR cannot be installed with pip, so this builds a
rem  self-contained copy of your radioconda environment INSIDE this
rem  folder (python\) using conda-pack. After this finishes, the whole
rem  STD-T98_grport_win folder is self-contained and can be copied as-is.
rem
rem  radioconda (GNU Radio + SoapySDR) is downloaded and installed to
rem  %USERPROFILE%\radioconda automatically when missing, and any missing
rem  SoapySDR packages are added:
rem      https://github.com/radioconda/radioconda-installer
rem  The build is several GB and can take a while (one time only).
rem ====================================================================
setlocal
cd /d "%~dp0"
set "ROOT=%~dp0"
set "RC=%USERPROFILE%\radioconda"

echo ============================================================
echo  Building portable python\ environment
echo ============================================================

if exist "%ROOT%python\python.exe" (
  echo [INFO] python\ already exists here. To rebuild, delete it first.
  goto :pipdeps
)

rem Install radioconda when missing and add any missing SoapySDR packages
rem before packing, so the portable python\ always contains them.
echo [INFO] Checking radioconda / SoapySDR at %RC% ...
powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%app\tools\install_radioconda.ps1" -Target "%RC%"
if errorlevel 1 (
  echo [ERROR] radioconda / SoapySDR setup failed. See the messages above.
  pause
  exit /b 1
)

echo [INFO] Activating radioconda ...
call "%RC%\Scripts\activate.bat" "%RC%"

echo [INFO] Ensuring conda-pack is available ...
python -c "import conda_pack" 2>nul
if errorlevel 1 (
  conda install -y conda-pack
  if errorlevel 1 python -m pip install --no-input conda-pack
)

echo [INFO] Packing the environment (several GB; please wait) ...
set "PACK=%TEMP%\std_t98_env.tar"
if exist "%PACK%" del /q "%PACK%"
conda pack -p "%RC%" -o "%PACK%" --n-threads -1 --ignore-missing-files --force
if errorlevel 1 (
  echo [ERROR] conda pack failed.
  pause
  exit /b 1
)

echo [INFO] Unpacking into %ROOT%python ...
mkdir "%ROOT%python"
tar -xf "%PACK%" -C "%ROOT%python"
if errorlevel 1 (
  echo [ERROR] unpack failed ^(need Windows 10+ tar^).
  pause
  exit /b 1
)
del /q "%PACK%"

echo [INFO] Finalizing relocation ...
call "%ROOT%python\Scripts\activate.bat"
if exist "%ROOT%python\Scripts\conda-unpack.exe" (
  "%ROOT%python\Scripts\conda-unpack.exe"
) else (
  "%ROOT%python\python.exe" -m conda_pack.scripts.conda_unpack
)

:pipdeps
set "PY=%ROOT%python\python.exe"
if not exist "%PY%" set "PY=%RC%\python.exe"
echo [INFO] Installing pip deps: sounddevice ...
"%PY%" -m pip install --no-input sounddevice
echo [INFO] The AMBE+2 voice decoder is bundled at app\vendor\ambe2 (self-contained,
echo        prebuilt _ambe2c.dll loaded via ctypes); no build/install needed.

echo.
echo [INFO] Privacy-key analysis is disabled in this distribution.
echo        Known keys can be entered and saved in key_tool; no ML models are needed.
echo.
echo [DONE] Setup complete.
echo        Start receiving with:  run.bat   (terminal)  or  run_gui.bat (GUI)
pause
endlocal
